import { motion } from "motion/react";
import { ArrowRight, FileText, Download, Eye, Calendar, CheckCircle, Clock } from "lucide-react";
import { useTheme } from "../context/ThemeContext";

export function ContractsScreen({ onBack }: { onBack: () => void }) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const contracts = [
    { id: 1, title: "عقد إيجار موحد - شقة النرجس", date: "2024/01/15", status: "active", party: "محمد السالم" },
    { id: 2, title: "اتفاقية وساطة - فيلا الملقا", date: "2023/12/20", status: "pending", party: "شركة الأفق" },
    { id: 3, title: "عقد بيع مبدئي", date: "2023/11/05", status: "completed", party: "عبدالله العتيبي" },
  ];

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-5 pt-12 pb-4 flex items-center gap-4 ${isDark ? 'bg-[#0D1221]' : 'bg-white shadow-sm'}`}>
        <button 
          onClick={onBack}
          className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            isDark ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-900'
          }`}
        >
          <ArrowRight className="w-5 h-5" />
        </button>
        <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>العقود</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-4">
        {contracts.map((contract, i) => (
          <motion.div
            key={contract.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`rounded-2xl p-5 border ${
              isDark 
                ? 'bg-[#1E2330] border-white/5' 
                : 'bg-white border-gray-100 shadow-sm'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  isDark ? 'bg-blue-500/10 text-blue-400' : 'bg-blue-50 text-blue-600'
                }`}>
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className={`font-bold text-sm mb-1 ${isDark ? 'text-white' : 'text-gray-900'}`}>{contract.title}</h3>
                  <p className={`text-xs ${isDark ? 'text-white/50' : 'text-gray-500'}`}>الطرف الثاني: {contract.party}</p>
                </div>
              </div>
              
              <div className={`px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                contract.status === 'active' 
                  ? isDark ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-700'
                  : contract.status === 'pending'
                    ? isDark ? 'bg-amber-500/20 text-amber-400' : 'bg-amber-100 text-amber-700'
                    : isDark ? 'bg-gray-500/20 text-gray-400' : 'bg-gray-100 text-gray-600'
              }`}>
                {contract.status === 'active' ? 'نشط' : contract.status === 'pending' ? 'قيد المراجعة' : 'مكتمل'}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-dashed border-gray-200 dark:border-white/10">
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Calendar className="w-3.5 h-3.5" />
                <span>{contract.date}</span>
              </div>
              
              <div className="flex gap-2">
                <button className={`p-2 rounded-lg ${
                  isDark ? 'hover:bg-white/10 text-white/70' : 'hover:bg-gray-100 text-gray-600'
                }`}>
                  <Eye className="w-4 h-4" />
                </button>
                <button className={`p-2 rounded-lg ${
                  isDark ? 'hover:bg-white/10 text-white/70' : 'hover:bg-gray-100 text-gray-600'
                }`}>
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
