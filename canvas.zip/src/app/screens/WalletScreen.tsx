import { motion } from "motion/react";
import { ArrowRight, Wallet, TrendingUp, ArrowUpRight, ArrowDownLeft, CreditCard, History, Building2 } from "lucide-react";
import { useTheme } from "../context/ThemeContext";

export function WalletScreen({ onBack }: { onBack: () => void }) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-5 pt-12 pb-4 flex items-center gap-4 ${isDark ? 'bg-[#0D1221]' : 'bg-white shadow-sm'}`}>
        <button 
          onClick={onBack}
          className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            isDark ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-900'
          }`}
        >
          <ArrowRight className="w-5 h-5" />
        </button>
        <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>المحفظة</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-6">
        {/* Main Balance Card */}
        <div className={`rounded-3xl p-6 relative overflow-hidden ${
          isDark 
            ? 'bg-gradient-to-br from-emerald-900 to-cyan-900 border border-emerald-500/30' 
            : 'bg-gradient-to-br from-emerald-600 to-teal-700 shadow-xl'
        }`}>
          {/* Background Decor */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          
          <div className="relative z-10">
            <p className="text-emerald-100 text-sm font-medium mb-1">الرصيد الحالي</p>
            <h1 className="text-4xl font-black text-white mb-6" dir="ltr">SAR 24,500.00</h1>
            
            <div className="flex gap-3">
              <button className="flex-1 bg-white/20 backdrop-blur-md rounded-xl py-3 text-white font-bold text-sm flex items-center justify-center gap-2 hover:bg-white/30 transition-colors">
                <ArrowDownLeft className="w-4 h-4" />
                إيداع
              </button>
              <button className="flex-1 bg-white/20 backdrop-blur-md rounded-xl py-3 text-white font-bold text-sm flex items-center justify-center gap-2 hover:bg-white/30 transition-colors">
                <ArrowUpRight className="w-4 h-4" />
                سحب
              </button>
            </div>
          </div>
        </div>

        {/* Transactions */}
        <div>
          <h3 className={`font-bold text-lg mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>آخر العمليات</h3>
          <div className="space-y-3">
            {[
              { title: "عربون فيلا الملقا", date: "اليوم، 10:30 ص", amount: "-5,000", type: "out" },
              { title: "استرداد تأمين", date: "أمس، 04:15 م", amount: "+2,000", type: "in" },
              { title: "رسوم اشتراك برو", date: "20 يناير", amount: "-499", type: "out" },
            ].map((tx, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`rounded-2xl p-4 flex items-center justify-between ${
                  isDark ? 'glass-strong hover:bg-white/5' : 'bg-white shadow-sm hover:shadow-md'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    tx.type === "in" 
                      ? isDark ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-600'
                      : isDark ? 'bg-red-500/20 text-red-400' : 'bg-red-100 text-red-600'
                  }`}>
                    {tx.type === "in" ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                  </div>
                  <div>
                    <h4 className={`font-bold text-sm ${isDark ? 'text-white' : 'text-gray-900'}`}>{tx.title}</h4>
                    <p className={`text-xs ${isDark ? 'text-white/50' : 'text-gray-500'}`}>{tx.date}</p>
                  </div>
                </div>
                <span className={`font-bold text-sm ${
                  tx.type === "in" 
                    ? isDark ? 'text-emerald-400' : 'text-emerald-600'
                    : isDark ? 'text-white' : 'text-gray-900'
                }`}>
                  {tx.amount} SAR
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
