import { motion } from "motion/react";
import { 
  Terminal, Activity, Server, Users, ShieldCheck, 
  AlertTriangle, Zap, CheckCircle, XCircle, Search, 
  Database, Cpu, Globe, MessageSquare, ChevronDown,
  TrendingUp, BarChart3, Lock, Bell, Settings, LogOut,
  LayoutDashboard, PieChart, FileCode, Layers, Menu,
  GitBranch, Network, Split, ShieldAlert, RefreshCw, Eye
} from "lucide-react";
import { useState, useEffect } from "react";
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

// --- DATA ---
const REVENUE_DATA = [
  { time: '10:00', value: 4200 },
  { time: '11:00', value: 3800 },
  { time: '12:00', value: 5100 },
  { time: '13:00', value: 4800 },
  { time: '14:00', value: 5900 },
  { time: '15:00', value: 6200 },
  { time: '16:00', value: 7400 },
];

const AGENT_ACTIVITY = [
  { name: 'السبت', queries: 2400, resolved: 2100 },
  { name: 'الأحد', queries: 1398, resolved: 1200 },
  { name: 'الاثنين', queries: 9800, resolved: 8900 },
  { name: 'الثلاثاء', queries: 3908, resolved: 3600 },
  { name: 'الأربعاء', queries: 4800, resolved: 4100 },
  { name: 'الخميس', queries: 3800, resolved: 3500 },
  { name: 'الجمعة', queries: 4300, resolved: 4000 },
];

const SECURITY_LOGS = [
  { time: "10:01 AM", type: "BLOCKED", msg: "Jailbreak Attempt (User: 502)", risk: "Critical" },
  { time: "10:05 AM", type: "FLAGGED", msg: "Price Fixing Keywords (Broker Group A)", risk: "High" },
  { time: "10:12 AM", type: "INFO", msg: "New API Key Generated (Dev: Emaar)", risk: "Low" },
  { time: "10:45 AM", type: "BLOCKED", msg: "SQL Injection Payload Detected", risk: "Critical" },
  { time: "11:00 AM", type: "FLAGGED", msg: "Unusual Traffic Spike (Jeddah Node)", risk: "Medium" },
  { time: "11:20 AM", type: "BLOCKED", msg: "Botnet Signature Matched", risk: "Critical" },
];

const GRAPH_NODES = [
  { id: 1, x: 20, y: 30, type: "broker", risk: 10 },
  { id: 2, x: 40, y: 50, type: "broker", risk: 85 }, // Fraud Ring Center
  { id: 3, x: 60, y: 20, type: "client", risk: 5 },
  { id: 4, x: 70, y: 60, type: "property", risk: 0 },
  { id: 5, x: 30, y: 70, type: "client", risk: 85 },
  { id: 6, x: 50, y: 80, type: "broker", risk: 85 },
];

const GRAPH_EDGES = [
  { from: 1, to: 2 },
  { from: 2, to: 3 },
  { from: 2, to: 4 },
  { from: 2, to: 5, color: "red" }, // Suspicious
  { from: 5, to: 6, color: "red" }, // Suspicious
  { from: 6, to: 2, color: "red" }, // Loop (Wash Trading)
];

const USERS_DB = [
  { id: "USR-001", name: "الراجحي المالية", type: "Developer", status: "Verified", nafath: true, assets: "5B SAR", location: "الرياض" },
  { id: "USR-002", name: "أحمد سالم", type: "Broker", status: "Verified", nafath: true, assets: "N/A", location: "جدة" },
  { id: "USR-003", name: "مساكن المستقبل", type: "Broker", status: "Pending", nafath: false, assets: "N/A", location: "الدمام" },
  { id: "USR-004", name: "سارة خالد", type: "Seeker", status: "Active", nafath: true, assets: "2M SAR", location: "الرياض" },
  { id: "USR-005", name: "أبراج الذهبية", type: "Landlord", status: "Verified", nafath: true, assets: "120M SAR", location: "الخبر" },
];

export function SuperAdminDashboard({ onBack }: { onBack?: () => void }) {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [command, setCommand] = useState("");
  const [isFineTuning, setIsFineTuning] = useState(false);
  const [currentModel, setCurrentModel] = useState("Qwen 2.5 (Production)");
  const [challengerModel, setChallengerModel] = useState("DeepSeek V3 (Shadow)");
  const [systemStatus, setSystemStatus] = useState("يعمل بكفاءة");

  // Interaction Mocking
  const handleCommand = () => {
    if (!command) return;
    setCommand("");
    alert(`تم إرسال الأمر: "${command}" إلى النظام.`);
  };

  const handleFineTune = () => {
    setIsFineTuning(true);
    setTimeout(() => {
        setIsFineTuning(false);
        alert("تم تحديث النموذج بنجاح! (Simulation)");
    }, 3000);
  };

  const swapModels = () => {
    const temp = currentModel;
    setCurrentModel(challengerModel);
    setChallengerModel(temp);
  };
  
  const toggleSystemStatus = () => {
      setSystemStatus(prev => prev === "يعمل بكفاءة" ? "تحت الصيانة" : "يعمل بكفاءة");
  };

  return (
    <div className="flex h-screen w-full bg-[#050505] text-white font-sans overflow-hidden" dir="rtl">
      
      {/* SIDEBAR NAVIGATION */}
      <aside className="w-64 bg-[#0A0A0A] border-l border-white/5 flex flex-col shrink-0 z-20">
        {/* Logo Area */}
        <div className="h-16 flex items-center gap-3 px-6 border-b border-white/5">
           <div className="w-8 h-8 rounded bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center shadow-lg shadow-cyan-900/20">
             <Cpu className="w-5 h-5 text-white" />
           </div>
           <div>
             <h1 className="font-bold text-lg tracking-tight">EON <span className="text-cyan-500">ADMIN</span></h1>
             <span className="text-[10px] text-white/40 uppercase tracking-widest">مركز القيادة</span>
           </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
           <div className="text-[10px] font-bold text-white/30 px-3 mb-2 uppercase tracking-wider">القائمة الرئيسية</div>
           <NavItem active={activeTab === "dashboard"} icon={LayoutDashboard} label="لوحة التحكم" onClick={() => setActiveTab("dashboard")} />
           <NavItem active={activeTab === "agents"} icon={Activity} label="حالة الوكلاء (Agents)" onClick={() => setActiveTab("agents")} />
           <NavItem active={activeTab === "users"} icon={Users} label="منظومة المستخدمين" onClick={() => setActiveTab("users")} />
           <NavItem active={activeTab === "finance"} icon={PieChart} label="المالية والإيرادات" onClick={() => setActiveTab("finance")} />
           
           <div className="mt-8 text-[10px] font-bold text-white/30 px-3 mb-2 uppercase tracking-wider">الذكاء والتحليل</div>
           <NavItem active={activeTab === "godmode"} icon={Eye} label="وضع الآلهة (God Mode)" onClick={() => setActiveTab("godmode")} highlight />
           <NavItem active={activeTab === "training"} icon={Zap} label="تدريب النموذج (RLHF)" onClick={() => setActiveTab("training")} />
           <NavItem active={activeTab === "logs"} icon={FileCode} label="سجلات النظام" onClick={() => setActiveTab("logs")} />
           <NavItem active={activeTab === "models"} icon={Layers} label="إدارة النماذج" onClick={() => setActiveTab("models")} />
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-white/5">
           <button onClick={onBack} className="flex items-center gap-3 w-full px-3 py-2 text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition-all text-sm font-medium">
             <LogOut className="w-4 h-4" />
             <span>خروج من الكونسول</span>
           </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#050505]">
        
        {/* TOP HEADER */}
        <header className="h-16 bg-[#0A0A0A]/50 backdrop-blur-md border-b border-white/5 flex items-center justify-between px-8 sticky top-0 z-10">
           {/* Breadcrumbs / Title */}
           <div className="flex items-center gap-4">
              <span className="text-white/40 text-sm font-medium">المشرف العام</span>
              <span className="text-white/20">/</span>
              <span className="text-white font-bold text-sm">نظرة عامة</span>
           </div>

           {/* Right Actions */}
           <div className="flex items-center gap-6">
              {/* Search Bar */}
              <div className="relative">
                 <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-white/30" />
                 <input 
                   type="text" 
                   placeholder="بحث شامل (مستخدمين، سجلات، أصول)..." 
                   className="bg-[#151515] border border-white/10 rounded-full pr-10 pl-4 py-1.5 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-cyan-500/50 w-64 transition-all"
                 />
              </div>

              {/* Status Indicators */}
              <div className="flex items-center gap-4 border-r border-white/10 pr-6">
                 <div className="flex flex-col items-start cursor-pointer" onClick={toggleSystemStatus}>
                    <span className="text-[10px] text-white/40 font-bold uppercase">حالة النظام</span>
                    <span className={`text-xs font-bold flex items-center gap-1.5 ${systemStatus === "يعمل بكفاءة" ? "text-emerald-500" : "text-yellow-500"}`}>
                       <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${systemStatus === "يعمل بكفاءة" ? "bg-emerald-500" : "bg-yellow-500"}`} />
                       {systemStatus}
                    </span>
                 </div>
                 <button className="relative p-2 rounded-full hover:bg-white/5 transition-colors">
                    <Bell className="w-5 h-5 text-white/60" />
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-[#0A0A0A]" />
                 </button>
                 <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 border-2 border-white/10" />
              </div>
           </div>
        </header>

        {/* SCROLLABLE DASHBOARD CONTENT */}
        <main className="flex-1 overflow-y-auto p-8 custom-scrollbar">
           <div className="max-w-[1600px] mx-auto space-y-6">
              
              {/* ZONE 1: COMMAND CENTER */}
              <section className="relative w-full">
                 <div className="absolute inset-0 bg-gradient-to-l from-cyan-500/10 via-purple-500/10 to-pink-500/10 blur-3xl -z-10" />
                 <div className="bg-[#0F0F0F]/80 backdrop-blur-xl border border-white/10 rounded-xl p-1 shadow-2xl">
                    <div className="flex items-center gap-0">
                       <div className="h-14 px-6 flex items-center justify-center border-l border-white/5">
                          <Terminal className="w-6 h-6 text-cyan-400" />
                       </div>
                       <input 
                          type="text" 
                          value={command}
                          onChange={(e) => setCommand(e.target.value)}
                          placeholder="اسأل عقل EON: 'شغّل استطلاع لوسطاء الرياض' أو 'توقع إيرادات الربع القادم'..."
                          className="flex-1 h-14 bg-transparent border-none outline-none text-white text-lg px-6 font-mono placeholder:text-white/20 text-right"
                          dir="rtl"
                       />
                       <button onClick={handleCommand} className="h-12 px-8 bg-white/10 hover:bg-white/20 text-white text-xs font-bold tracking-widest uppercase rounded-lg ml-1 transition-all border border-white/5 active:scale-95">
                          تنفيذ الأمر
                       </button>
                    </div>
                 </div>
              </section>

              {/* ZONE 2: MAIN METRICS */}
              <div className="grid grid-cols-12 gap-6">
                 {/* Top Row Stats */}
                 <div className="col-span-12 grid grid-cols-4 gap-6">
                       <StatCard 
                          title="إجمالي الإيرادات" 
                          value="8.4M ريال" 
                          trend="+12.5%" 
                          icon={TrendingUp} 
                          color="emerald" 
                          data={REVENUE_DATA}
                       />
                       <StatCard 
                          title="المستخدمون النشطون" 
                          value="12,405" 
                          trend="+5.2%" 
                          icon={Users} 
                          color="blue" 
                          simple 
                       />
                       <StatCard 
                          title="حمل الخادم (Server Load)" 
                          value="42%" 
                          trend="مستقر" 
                          icon={Server} 
                          color="purple" 
                          simple 
                       />
                       <div className="bg-[#0F0F0F] border border-white/10 rounded-xl p-5 flex flex-col justify-center items-center relative overflow-hidden group">
                           <div className="absolute inset-0 bg-gradient-to-br from-pink-500/10 to-purple-600/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                           <button onClick={handleFineTune} disabled={isFineTuning} className="relative z-10 flex flex-col items-center gap-2">
                               {isFineTuning ? (
                                   <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                               ) : (
                                   <div className="w-10 h-10 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-900/40">
                                       <Zap className="w-5 h-5 text-white" />
                                   </div>
                               )}
                               <span className="font-bold text-sm mt-1">تحديث النموذج (One-Click)</span>
                               <span className="text-[10px] text-white/40">RLHF Fine-Tuning</span>
                           </button>
                       </div>
                 </div>
              </div>

              {/* ZONE 3: GOD MODE MODULES */}
              <div className="space-y-4">
                  <div className="flex items-center gap-2 text-cyan-500 mb-2">
                      <Eye className="w-4 h-4" />
                      <h3 className="text-sm font-bold tracking-widest uppercase">وحدات وضع الآلهة (God Mode Analytics)</h3>
                  </div>
                  
                  <div className="grid grid-cols-12 gap-6 h-[500px]">
                      
                      {/* MODULE 1: EON GRAPH (MEMGRAPH) */}
                      <div className="col-span-6 bg-[#080808] border border-white/10 rounded-xl relative overflow-hidden group">
                          <div className="absolute top-4 right-4 z-10 flex items-center gap-2 bg-black/60 backdrop-blur px-3 py-1.5 rounded-lg border border-white/10">
                              <Network className="w-4 h-4 text-cyan-500" />
                              <span className="text-xs font-bold text-white">EON Graph (Memgraph)</span>
                          </div>
                          <div className="absolute bottom-4 left-4 z-10">
                              <div className="bg-red-500/10 border border-red-500/30 px-3 py-2 rounded-lg backdrop-blur-md">
                                  <div className="flex items-center gap-2 text-red-500 text-xs font-bold mb-1">
                                      <AlertTriangle className="w-3 h-3" />
                                      كشف احتيال محتمل
                                  </div>
                                  <p className="text-[10px] text-white/70">تم رصد حلقة تداول وهمي (Wash Trading) بين 3 وسطاء.</p>
                              </div>
                          </div>
                          
                          {/* Simulated Graph Visualization */}
                          <div className="absolute inset-0 flex items-center justify-center">
                              <div className="relative w-full h-full">
                                  <svg className="w-full h-full absolute inset-0 pointer-events-none">
                                      {GRAPH_EDGES.map((edge, i) => {
                                          const fromNode = GRAPH_NODES.find(n => n.id === edge.from);
                                          const toNode = GRAPH_NODES.find(n => n.id === edge.to);
                                          if (!fromNode || !toNode) return null;
                                          return (
                                              <motion.line 
                                                  key={i}
                                                  initial={{ pathLength: 0, opacity: 0 }}
                                                  animate={{ pathLength: 1, opacity: 1 }}
                                                  transition={{ duration: 1.5, delay: i * 0.2 }}
                                                  x1={`${fromNode.x}%`} y1={`${fromNode.y}%`}
                                                  x2={`${toNode.x}%`} y2={`${toNode.y}%`}
                                                  stroke={edge.color === "red" ? "#ef4444" : "#ffffff30"}
                                                  strokeWidth={edge.color === "red" ? 2 : 1}
                                                  strokeDasharray={edge.color === "red" ? "5,5" : "0"}
                                              />
                                          );
                                      })}
                                  </svg>
                                  {GRAPH_NODES.map((node) => (
                                      <motion.div
                                          key={node.id}
                                          initial={{ scale: 0 }}
                                          animate={{ scale: 1 }}
                                          transition={{ type: "spring", delay: 0.5 + node.id * 0.1 }}
                                          className={`absolute w-4 h-4 rounded-full -ml-2 -mt-2 cursor-pointer transition-all hover:scale-150 z-10 ${
                                              node.risk > 80 ? "bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.6)]" : 
                                              node.type === "property" ? "bg-emerald-500" :
                                              "bg-blue-500"
                                          }`}
                                          style={{ left: `${node.x}%`, top: `${node.y}%` }}
                                      >
                                          <div className={`absolute -inset-2 rounded-full opacity-20 animate-ping ${
                                              node.risk > 80 ? "bg-red-500" : "bg-blue-500"
                                          }`} />
                                      </motion.div>
                                  ))}
                              </div>
                          </div>
                      </div>

                      {/* RIGHT COLUMN SPLIT */}
                      <div className="col-span-6 flex flex-col gap-6">
                          
                          {/* MODULE 2: SHADOW TESTER (LiteLLM) */}
                          <div className="flex-1 bg-[#0F0F0F] border border-white/10 rounded-xl flex flex-col overflow-hidden">
                              <div className="px-4 py-3 border-b border-white/10 flex justify-between items-center bg-white/5">
                                  <div className="flex items-center gap-2">
                                      <Split className="w-4 h-4 text-purple-500" />
                                      <span className="text-xs font-bold text-white">Shadow Tester (LiteLLM Proxy)</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                      <div className="text-[10px] text-white/50 font-mono">
                                          Latency: <span className="text-emerald-400">120ms</span> vs <span className="text-yellow-400">210ms</span>
                                      </div>
                                      <button onClick={swapModels} className="flex items-center gap-1.5 px-2 py-1 rounded bg-purple-500/20 text-purple-400 text-[10px] font-bold border border-purple-500/30 hover:bg-purple-500/30 transition">
                                          <RefreshCw className="w-3 h-3" /> SWAP
                                      </button>
                                  </div>
                              </div>
                              <div className="flex-1 flex text-[10px] font-mono">
                                  <div className="flex-1 border-l border-white/10 p-3 relative">
                                      <div className="absolute top-2 right-2 text-white/20 font-bold">{currentModel}</div>
                                      <p className="text-emerald-400 mb-1">$ PROMPT: Analyze listing #402</p>
                                      <p className="text-white/70 leading-relaxed">
                                          Based on current market trends in Riyadh North, listing #402 is priced 15% above average. Recommended action: Suggest price adjustment to owner.
                                      </p>
                                  </div>
                                  <div className="flex-1 bg-black/30 p-3 relative">
                                      <div className="absolute top-2 right-2 text-white/20 font-bold">{challengerModel}</div>
                                      <p className="text-yellow-400 mb-1">$ PROMPT: Analyze listing #402</p>
                                      <p className="text-white/60 leading-relaxed opacity-80">
                                          Listing #402 analysis: Overpriced by approx 14.8%. Market velocity indicates slow absorption for this bracket. Suggest -10% drop.
                                      </p>
                                  </div>
                              </div>
                          </div>

                          {/* MODULE 3: GOVERNANCE RADAR (NeMo) */}
                          <div className="h-48 bg-[#0F0F0F] border border-white/10 rounded-xl flex flex-col overflow-hidden">
                               <div className="px-4 py-2 border-b border-white/10 flex justify-between items-center bg-red-900/10">
                                  <div className="flex items-center gap-2">
                                      <ShieldAlert className="w-4 h-4 text-red-500" />
                                      <span className="text-xs font-bold text-white">Governance Radar (NeMo Guardrails)</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                      <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                                      <span className="text-[10px] text-red-400 font-mono">LIVE FEED</span>
                                  </div>
                              </div>
                              <div className="flex-1 overflow-y-auto p-0 relative">
                                  <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/20 pointer-events-none" />
                                  {SECURITY_LOGS.map((log, i) => (
                                      <div key={i} className="flex items-center gap-3 px-4 py-2 border-b border-white/5 hover:bg-white/5 font-mono text-[10px]">
                                          <span className="text-white/30">{log.time}</span>
                                          <span className={`w-14 text-center py-0.5 rounded font-bold ${
                                              log.type === "BLOCKED" ? "bg-red-500/20 text-red-500" :
                                              log.type === "FLAGGED" ? "bg-yellow-500/20 text-yellow-500" :
                                              "bg-blue-500/20 text-blue-500"
                                          }`}>{log.type}</span>
                                          <span className="text-white/80 flex-1 truncate">{log.msg}</span>
                                          <span className={`text-[9px] ${
                                              log.risk === "Critical" ? "text-red-600 font-bold" : "text-white/30"
                                          }`}>{log.risk}</span>
                                      </div>
                                  ))}
                              </div>
                          </div>

                      </div>
                  </div>
              </div>

           </div>
        </main>

      </div>
    </div>
  );
}

// --- COMPONENTS ---

function NavItem({ icon: Icon, label, active, onClick, highlight }: any) {
   return (
      <button 
        onClick={onClick}
        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
           active 
             ? "bg-gradient-to-l from-cyan-900/30 to-blue-900/10 text-cyan-400 border-r-2 border-cyan-500" 
             : "text-white/50 hover:text-white hover:bg-white/5"
        } ${highlight ? "text-purple-400 hover:text-purple-300" : ""}`}
      >
         <Icon className={`w-4 h-4 ${active ? "text-cyan-400" : highlight ? "text-purple-500" : "text-white/40 group-hover:text-white"}`} />
         {label}
      </button>
   );
}

function StatCard({ title, value, trend, icon: Icon, color, simple, data }: any) {
   return (
      <div className="bg-[#0F0F0F] border border-white/10 rounded-xl p-5 flex flex-col justify-between relative overflow-hidden group hover:border-white/20 transition-all h-32">
         {/* Background Glow */}
         <div className={`absolute -left-4 -top-4 w-24 h-24 rounded-full blur-2xl opacity-10 group-hover:opacity-20 transition-opacity bg-${color}-500`} />
         
         <div className="flex justify-between items-start relative z-10">
            <div>
               <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1">{title}</p>
               <h3 className="text-2xl font-black text-white" style={{ fontFamily: 'Cairo, sans-serif' }}>{value}</h3>
            </div>
            <div className={`p-2 rounded-lg bg-${color}-500/10 border border-${color}-500/20`}>
               <Icon className={`w-5 h-5 text-${color}-500`} />
            </div>
         </div>

         {simple ? (
            <div className="relative z-10 mt-auto">
               <span className="text-emerald-500 text-xs font-bold flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" /> {trend}
                  <span className="text-white/30 font-normal mr-1">مقارنة بالأسبوع الماضي</span>
               </span>
            </div>
         ) : (
            <div className="relative z-10 h-10 mt-auto w-full opacity-50">
               <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                     <Area type="monotone" dataKey="value" stroke={color === 'emerald' ? '#10b981' : '#3b82f6'} fill="transparent" strokeWidth={2} />
                  </AreaChart>
               </ResponsiveContainer>
            </div>
         )}
      </div>
   );
}
