import { motion } from "motion/react";
import { User, Lock, ArrowLeft, Building2, Key, ShieldCheck, Cpu, Globe } from "lucide-react";
import { useState } from "react";
import { useTheme } from "../context/ThemeContext";

interface LoginScreenProps {
  onLogin: (role: string) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [selectedRole, setSelectedRole] = useState("admin");
  const [isLoading, setIsLoading] = useState(false);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      onLogin(selectedRole);
    }, 1500);
  };

  const roles = [
    { id: "admin", label: "المشرف العام", icon: ShieldCheck, color: "text-red-500" },
    { id: "broker", label: "وسيط عقاري", icon: User, color: "text-emerald-500" },
    { id: "developer", label: "مطور عقاري", icon: Building2, color: "text-blue-500" },
    { id: "landlord", label: "مالك عقار", icon: Key, color: "text-amber-500" },
  ];

  return (
    <div className="min-h-screen w-full flex relative overflow-hidden bg-[#050505]" dir="rtl">
      
      {/* RIGHT SIDE: BRANDING (The "Vibe") */}
      <div className="hidden lg:flex w-1/2 relative flex-col justify-between p-12 overflow-hidden">
        {/* Background Video/Image Simulation */}
        <div className="absolute inset-0 z-0">
           <img 
             src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop" 
             className="w-full h-full object-cover opacity-40 grayscale"
             alt="Building"
           />
           <div className="absolute inset-0 bg-gradient-to-l from-[#050505] via-[#050505]/80 to-cyan-900/40" />
        </div>

        <div className="relative z-10">
           <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-2xl shadow-cyan-500/20 mb-6">
              <span className="text-4xl font-black text-white">A</span>
           </div>
           <h1 className="text-6xl font-black text-white mb-4 tracking-tighter" style={{ fontFamily: 'Cairo' }}>
             أيون <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">العقارية</span>
           </h1>
           <p className="text-xl text-white/60 max-w-md leading-relaxed">
             المنصة الأولى المدعومة بالذكاء الاصطناعي لإدارة الثروات العقارية والصفقات الكبرى.
           </p>
        </div>

        <div className="relative z-10 flex gap-8">
            <div className="flex flex-col">
                <span className="text-4xl font-bold text-white">8.2B</span>
                <span className="text-sm text-cyan-400 uppercase tracking-widest">قيمة الأصول المدارة</span>
            </div>
            <div className="flex flex-col">
                <span className="text-4xl font-bold text-white">14K</span>
                <span className="text-sm text-purple-400 uppercase tracking-widest">وسيط نشط</span>
            </div>
        </div>
      </div>

      {/* LEFT SIDE: LOGIN FORM */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-[#050505] relative">
         <div className="absolute top-8 left-8">
            <button className="flex items-center gap-2 text-white/40 hover:text-white transition-colors text-sm font-bold">
                <Globe className="w-4 h-4" />
                English
            </button>
         </div>

         <div className="w-full max-w-md space-y-8">
            <div className="text-center lg:text-right">
                <h2 className="text-3xl font-bold text-white mb-2" style={{ fontFamily: 'Cairo' }}>تسجيل الدخول</h2>
                <p className="text-white/40 text-sm">مرحباً بعودتك إلى مساحة العمل الخاصة بك.</p>
            </div>

            {/* Role Selector */}
            <div className="grid grid-cols-2 gap-3">
                {roles.map((role) => (
                    <button
                        key={role.id}
                        onClick={() => setSelectedRole(role.id)}
                        className={`flex flex-col items-center gap-2 p-4 rounded-xl border transition-all ${
                            selectedRole === role.id 
                            ? "bg-white/10 border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.1)]" 
                            : "bg-white/5 border-white/5 hover:bg-white/10"
                        }`}
                    >
                        <role.icon className={`w-6 h-6 ${selectedRole === role.id ? role.color : "text-white/40"}`} />
                        <span className={`text-xs font-bold ${selectedRole === role.id ? "text-white" : "text-white/40"}`}>
                            {role.label}
                        </span>
                    </button>
                ))}
            </div>

            {/* Form */}
            <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                    <label className="text-xs font-bold text-white/60">البريد الإلكتروني أو المعرف</label>
                    <div className="relative">
                        <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" />
                        <input 
                            type="text" 
                            defaultValue="admin@aion.sa"
                            className="w-full h-12 bg-white/5 border border-white/10 rounded-xl pr-12 pl-4 text-white placeholder:text-white/20 focus:outline-none focus:border-cyan-500/50 transition-all text-sm font-medium"
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-xs font-bold text-white/60">كلمة المرور</label>
                    <div className="relative">
                        <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" />
                        <input 
                            type="password" 
                            defaultValue="password"
                            className="w-full h-12 bg-white/5 border border-white/10 rounded-xl pr-12 pl-4 text-white placeholder:text-white/20 focus:outline-none focus:border-cyan-500/50 transition-all text-sm font-medium"
                        />
                    </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="rounded border-white/20 bg-white/5 text-cyan-500 focus:ring-0" />
                        <span className="text-white/60">تذكر جهازي</span>
                    </label>
                    <a href="#" className="text-cyan-500 hover:text-cyan-400 font-bold">نسيت كلمة المرور؟</a>
                </div>

                <button 
                    type="submit" 
                    disabled={isLoading}
                    className="w-full h-14 bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 text-white font-bold rounded-xl shadow-lg shadow-cyan-900/20 flex items-center justify-center gap-3 transition-all transform hover:-translate-y-0.5 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isLoading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                        <>
                            <span>دخول آمن</span>
                            <ArrowLeft className="w-5 h-5" />
                        </>
                    )}
                </button>
            </form>

            <div className="text-center pt-4">
                <p className="text-xs text-white/30">
                    محمي بواسطة <span className="text-cyan-500 font-mono">ڤال™ SENTINEL</span>
                </p>
            </div>
         </div>
      </div>
    </div>
  );
}