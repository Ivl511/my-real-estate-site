import { useState } from "react";
import { AionHeader } from "../components/aion/AionHeader";
import { PropertyCard } from "../components/aion/PropertyCard";
import { ArrowRight, SlidersHorizontal, MapPin, Grid3x3, List } from "lucide-react";

interface SearchResultsScreenProps {
  onNavigate: (screen: string, data?: any) => void;
}

export function SearchResultsScreen({ onNavigate }: SearchResultsScreenProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [selectedFilter, setSelectedFilter] = useState('all');
  
  const properties = [
    {
      id: "1",
      image: "https://images.unsplash.com/photo-1622015663381-d2e05ae91b72?w=600",
      title: "فيلا فاخرة مع حديقة واسعة",
      price: "2,500,000",
      location: "حي النرجس، شمال الرياض",
      bedrooms: 5,
      bathrooms: 4,
      area: "450 م²",
      aiInsight: "سعر ممتاز! هذه الفيلا أقل من متوسط السوق بـ 8%. الموقع مميز بقربه من المدارس والخدمات.",
      priceStatus: "excellent" as const,
    },
    {
      id: "2",
      image: "https://images.unsplash.com/photo-1621919200669-2779566a6eaf?w=600",
      title: "شقة حديثة مع إطلالة بانورامية",
      price: "850,000",
      location: "حي الملقا، شمال الرياض",
      bedrooms: 3,
      bathrooms: 2,
      area: "180 م²",
      aiInsight: "فرصة استثمارية جيدة. المنطقة شهدت نمو 15% في الأسعار خلال العام الماضي. طلب عالي على الإيجار.",
      priceStatus: "good" as const,
    },
    {
      id: "3",
      image: "https://images.unsplash.com/photo-1759630815249-3c410d221a07?w=600",
      title: "دوبلكس راقي في مجمع حديث",
      price: "1,200,000",
      location: "حي العليا، وسط الرياض",
      bedrooms: 4,
      bathrooms: 3,
      area: "280 م²",
      aiInsight: "موقع استراتيجي في قلب الرياض. مناسب للسكن أو الاستثمار. المجمع يوفر كافة الخدمات.",
      priceStatus: "fair" as const,
    },
    {
      id: "4",
      image: "https://images.unsplash.com/photo-1624343385944-b99336163b50?w=600",
      title: "تاون هاوس عصري في كمباوند مغلق",
      price: "1,650,000",
      location: "حي الياسمين، شمال الرياض",
      bedrooms: 4,
      bathrooms: 3,
      area: "320 م²",
      aiInsight: "منطقة هادئة وآمنة. الكمباوند يحتوي على حمام سباحة ونادي رياضي. مثالي للعائلات.",
      priceStatus: "good" as const,
    },
  ];
  
  const filters = [
    { id: 'all', label: 'الكل', count: 23 },
    { id: 'excellent', label: 'فرص ممتازة', count: 5 },
    { id: 'new', label: 'جديد', count: 8 },
    { id: 'investment', label: 'استثماري', count: 12 },
  ];
  
  return (
    <div className="min-h-screen bg-[var(--aion-gray-50)]">
      {/* الهيدر */}
      <div className="bg-[var(--aion-navy)] text-white px-5 py-4 sticky top-0 z-50" style={{ boxShadow: 'var(--aion-shadow-lg)' }}>
        <div className="flex items-center justify-between max-w-md mx-auto mb-4">
          <button 
            onClick={() => onNavigate("home")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowRight className="w-6 h-6" />
          </button>
          
          <h1 className="text-xl font-bold">نتائج البحث</h1>
          
          <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            <SlidersHorizontal className="w-6 h-6" />
          </button>
        </div>
        
        {/* شريط البحث المصغر */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl px-4 py-2.5 max-w-md mx-auto">
          <div className="flex items-center gap-2 text-sm text-white/90">
            <MapPin className="w-4 h-4" />
            <span>شقق • الرياض • 3 غرف</span>
          </div>
        </div>
      </div>
      
      <div className="px-5 py-6 max-w-md mx-auto">
        {/* الفلاتر السريعة */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 -mx-5 px-5 scrollbar-hide">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setSelectedFilter(filter.id)}
              className={`flex-shrink-0 px-4 py-2 rounded-full font-semibold text-sm transition-all ${
                selectedFilter === filter.id
                  ? 'bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] text-white'
                  : 'bg-white text-[var(--aion-gray-700)] border border-[var(--aion-gray-200)]'
              }`}
            >
              {filter.label} ({filter.count})
            </button>
          ))}
        </div>
        
        {/* أدوات العرض */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-[var(--aion-gray-600)]">
            وجدنا <span className="font-bold text-[var(--aion-navy)]">23 عقار</span> مناسب
          </p>
          
          <div className="flex gap-1 bg-white rounded-lg p-1" style={{ boxShadow: 'var(--aion-shadow-sm)' }}>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded transition-colors ${
                viewMode === 'list' 
                  ? 'bg-[var(--aion-navy)] text-white' 
                  : 'text-[var(--aion-gray-500)]'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded transition-colors ${
                viewMode === 'grid' 
                  ? 'bg-[var(--aion-navy)] text-white' 
                  : 'text-[var(--aion-gray-500)]'
              }`}
            >
              <Grid3x3 className="w-4 h-4" />
            </button>
          </div>
        </div>
        
        {/* قائمة العقارات */}
        <div className={`${viewMode === 'grid' ? 'grid grid-cols-2 gap-3' : 'space-y-4'}`}>
          {properties.map((property) => (
            <PropertyCard
              key={property.id}
              {...property}
              onClick={() => onNavigate("details", { property })}
            />
          ))}
        </div>
        
        {/* زر تحميل المزيد */}
        <button 
          className="w-full mt-6 bg-white text-[var(--aion-navy)] py-4 rounded-2xl font-bold transition-all active:scale-95 border-2 border-[var(--aion-gray-200)]"
        >
          تحميل المزيد من النتائج
        </button>
      </div>
    </div>
  );
}
