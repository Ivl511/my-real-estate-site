import { ArrowRight, Heart, Share2, MapPin, Bed, Bath, Maximize, Sparkles, Phone, MessageCircle, TrendingUp, Shield, Navigation } from "lucide-react";
import { useState } from "react";

interface PropertyDetailsScreenProps {
  onNavigate: (screen: string) => void;
  property?: any;
}

export function PropertyDetailsScreen({ onNavigate, property }: PropertyDetailsScreenProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  
  const propertyData = property || {
    images: [
      "https://images.unsplash.com/photo-1622015663381-d2e05ae91b72?w=800",
      "https://images.unsplash.com/photo-1621919200669-2779566a6eaf?w=800",
      "https://images.unsplash.com/photo-1759630815249-3c410d221a07?w=800",
    ],
    title: "فيلا فاخرة مع حديقة واسعة",
    price: "2,500,000",
    location: "حي النرجس، شمال الرياض",
    bedrooms: 5,
    bathrooms: 4,
    area: "450 م²",
    yearBuilt: "2022",
    features: [
      "مسبح خاص",
      "حديقة كبيرة",
      "موقف سيارات مظلل",
      "مطبخ راقي",
      "غرفة خادمة",
      "مدخل خاص",
    ],
    description: "فيلا فاخرة بتصميم عصري في أرقى أحياء الرياض. تتميز بمساحات واسعة وإطلالات رائعة. جميع الغرف ماستر مع دورات مياه خاصة. المطبخ مجهز بالكامل بأحدث الأجهزة.",
    aiAnalysis: {
      priceStatus: "ممتاز",
      marketComparison: "أقل من متوسط السوق بـ 8%",
      investment: "عائد استثماري متوقع: 7.5% سنوياً",
      recommendation: "فرصة ممتازة للشراء. السعر مناسب جداً مقارنة بالمنطقة والمواصفات.",
      risks: "منخفضة - المنطقة مستقرة وذات طلب عالي",
    },
  };
  
  return (
    <div className="min-h-screen bg-[var(--aion-gray-50)]">
      {/* معرض الصور */}
      <div className="relative h-80 bg-[var(--aion-gray-300)]">
        <img 
          src={propertyData.images[selectedImage]} 
          alt={propertyData.title}
          className="w-full h-full object-cover"
        />
        
        {/* أزرار التنقل */}
        <div className="absolute top-4 left-0 right-0 px-5 flex items-center justify-between max-w-md mx-auto">
          <button 
            onClick={() => onNavigate("search")}
            className="p-3 bg-white/90 backdrop-blur-sm rounded-xl transition-all active:scale-95"
            style={{ boxShadow: 'var(--aion-shadow-md)' }}
          >
            <ArrowRight className="w-5 h-5 text-[var(--aion-navy)]" />
          </button>
          
          <div className="flex gap-2">
            <button 
              onClick={() => setIsFavorite(!isFavorite)}
              className="p-3 bg-white/90 backdrop-blur-sm rounded-xl transition-all active:scale-95"
              style={{ boxShadow: 'var(--aion-shadow-md)' }}
            >
              <Heart className={`w-5 h-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-[var(--aion-navy)]'}`} />
            </button>
            <button 
              className="p-3 bg-white/90 backdrop-blur-sm rounded-xl transition-all active:scale-95"
              style={{ boxShadow: 'var(--aion-shadow-md)' }}
            >
              <Share2 className="w-5 h-5 text-[var(--aion-navy)]" />
            </button>
          </div>
        </div>
        
        {/* مؤشرات الصور */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {propertyData.images.map((_: any, index: number) => (
            <button
              key={index}
              onClick={() => setSelectedImage(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === selectedImage 
                  ? 'bg-white w-6' 
                  : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>
      
      <div className="px-5 pb-24 max-w-md mx-auto">
        {/* شارة رأي AI البارزة */}
        <div 
          className="bg-gradient-to-br from-[var(--aion-navy)] to-[var(--aion-navy-light)] text-white rounded-2xl p-5 -mt-8 relative z-10 mb-5"
          style={{ boxShadow: 'var(--aion-shadow-xl)' }}
        >
          <div className="flex items-start gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-lg mb-1">تحليل أيون الذكي</h3>
              <p className="text-sm text-white/80">مدعوم بالذكاء الاصطناعي</p>
            </div>
            <div className="bg-[var(--aion-green)] px-3 py-1 rounded-full text-xs font-bold">
              {propertyData.aiAnalysis.priceStatus}
            </div>
          </div>
          
          <p className="text-sm leading-relaxed text-white/95 mb-4">
            {propertyData.aiAnalysis.recommendation}
          </p>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
              <div className="text-xs text-white/70 mb-1">مقارنة السوق</div>
              <div className="text-sm font-bold text-[var(--aion-green-light)]">
                {propertyData.aiAnalysis.marketComparison}
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
              <div className="text-xs text-white/70 mb-1">العائد المتوقع</div>
              <div className="text-sm font-bold text-[var(--aion-green-light)]">7.5%</div>
            </div>
          </div>
        </div>
        
        {/* معلومات العقار الأساسية */}
        <div className="bg-white rounded-2xl p-5 mb-4" style={{ boxShadow: 'var(--aion-shadow-md)' }}>
          <h1 className="text-2xl font-bold text-[var(--aion-navy)] mb-2">
            {propertyData.title}
          </h1>
          
          <div className="flex items-center gap-2 text-[var(--aion-gray-600)] mb-4">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{propertyData.location}</span>
          </div>
          
          <div className="text-3xl font-bold text-[var(--aion-green)] mb-4">
            {propertyData.price} <span className="text-base font-normal text-[var(--aion-gray-600)]">ريال</span>
          </div>
          
          <div className="grid grid-cols-4 gap-4 pt-4 border-t border-[var(--aion-gray-200)]">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-[var(--aion-navy)]/5 flex items-center justify-center mx-auto mb-2">
                <Bed className="w-5 h-5 text-[var(--aion-navy)]" />
              </div>
              <div className="text-sm font-bold text-[var(--aion-navy)]">{propertyData.bedrooms}</div>
              <div className="text-xs text-[var(--aion-gray-600)]">غرف</div>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-[var(--aion-navy)]/5 flex items-center justify-center mx-auto mb-2">
                <Bath className="w-5 h-5 text-[var(--aion-navy)]" />
              </div>
              <div className="text-sm font-bold text-[var(--aion-navy)]">{propertyData.bathrooms}</div>
              <div className="text-xs text-[var(--aion-gray-600)]">حمامات</div>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-[var(--aion-navy)]/5 flex items-center justify-center mx-auto mb-2">
                <Maximize className="w-5 h-5 text-[var(--aion-navy)]" />
              </div>
              <div className="text-sm font-bold text-[var(--aion-navy)]">{propertyData.area}</div>
              <div className="text-xs text-[var(--aion-gray-600)]">المساحة</div>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-[var(--aion-navy)]/5 flex items-center justify-center mx-auto mb-2">
                <TrendingUp className="w-5 h-5 text-[var(--aion-navy)]" />
              </div>
              <div className="text-sm font-bold text-[var(--aion-navy)]">{propertyData.yearBuilt}</div>
              <div className="text-xs text-[var(--aion-gray-600)]">سنة البناء</div>
            </div>
          </div>
        </div>
        
        {/* الوصف */}
        <div className="bg-white rounded-2xl p-5 mb-4" style={{ boxShadow: 'var(--aion-shadow-md)' }}>
          <h3 className="font-bold text-[var(--aion-navy)] mb-3">الوصف</h3>
          <p className="text-sm text-[var(--aion-gray-700)] leading-relaxed">
            {propertyData.description}
          </p>
        </div>
        
        {/* المميزات */}
        <div className="bg-white rounded-2xl p-5 mb-4" style={{ boxShadow: 'var(--aion-shadow-md)' }}>
          <h3 className="font-bold text-[var(--aion-navy)] mb-3">المميزات</h3>
          <div className="grid grid-cols-2 gap-2">
            {propertyData.features.map((feature: string, index: number) => (
              <div key={index} className="flex items-center gap-2 bg-[var(--aion-gray-50)] rounded-lg p-2.5">
                <div className="w-1.5 h-1.5 rounded-full bg-[var(--aion-green)]"></div>
                <span className="text-sm text-[var(--aion-gray-700)]">{feature}</span>
              </div>
            ))}
          </div>
        </div>
        
        {/* التحليل الاستثماري */}
        <div className="bg-gradient-to-br from-[var(--aion-green)]/10 to-[var(--aion-green)]/5 rounded-2xl p-5 mb-4 border-2 border-[var(--aion-green)]/20">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-5 h-5 text-[var(--aion-green)]" />
            <h3 className="font-bold text-[var(--aion-navy)]">تقييم المخاطر</h3>
          </div>
          <p className="text-sm text-[var(--aion-gray-700)]">
            <span className="font-bold text-[var(--aion-green)]">مخاطر منخفضة:</span> {propertyData.aiAnalysis.risks}
          </p>
        </div>
        
        {/* الموقع */}
        <div className="bg-white rounded-2xl p-5 mb-4" style={{ boxShadow: 'var(--aion-shadow-md)' }}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-[var(--aion-navy)]">الموقع</h3>
            <button className="flex items-center gap-1 text-sm text-[var(--aion-green)] font-semibold">
              <Navigation className="w-4 h-4" />
              <span>فتح الخريطة</span>
            </button>
          </div>
          <div className="h-40 bg-[var(--aion-gray-200)] rounded-xl flex items-center justify-center">
            <MapPin className="w-8 h-8 text-[var(--aion-gray-400)]" />
          </div>
        </div>
      </div>
      
      {/* أزرار الاتصال الثابتة */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[var(--aion-gray-200)] px-5 py-4" style={{ boxShadow: 'var(--aion-shadow-xl)' }}>
        <div className="max-w-md mx-auto flex gap-3">
          <button className="flex-1 bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95">
            <Phone className="w-5 h-5" />
            <span>اتصل الآن</span>
          </button>
          <button className="flex-1 bg-[var(--aion-navy)] text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95">
            <MessageCircle className="w-5 h-5" />
            <span>محادثة</span>
          </button>
        </div>
      </div>
    </div>
  );
}
