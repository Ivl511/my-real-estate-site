import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Search, Filter, MessageCircle, User, Building2, Key, CheckCircle, ShieldCheck, Sparkles, MoreVertical, Zap, ChevronRight, LayoutGrid } from "lucide-react";
import { useState } from "react";
import { useTheme } from "../context/ThemeContext";

interface InboxScreenProps {
  onBack: () => void;
  onNavigate: (screen: string) => void;
  onOpenChat: (chat: any) => void;
}

type CategoryType = "brokers" | "developers" | "landlords" | "seekers";

const categories = [
  { 
    id: "brokers", 
    label: "الوسطاء", 
    icon: User, 
    color: "from-amber-500 to-orange-600", 
    count: 12, 
    unread: 2,
    desc: "محادثات مع وسطاء مرخصين"
  },
  { 
    id: "developers", 
    label: "المطورين", 
    icon: Building2, 
    color: "from-blue-500 to-indigo-600", 
    count: 5, 
    unread: 1,
    desc: "تحديثات المشاريع والعروض"
  },
  { 
    id: "landlords", 
    label: "الملاك", 
    icon: Key, 
    color: "from-emerald-500 to-green-600", 
    count: 8, 
    unread: 0,
    desc: "مفاوضات مباشرة مع الملاك"
  },
  { 
    id: "seekers", 
    label: "الباحثين", 
    icon: Search, 
    color: "from-purple-500 to-pink-600", 
    count: 15, 
    unread: 3,
    desc: "طلبات البحث عن عقارات"
  },
];

const conversations = {
  brokers: [
    { id: "1", name: "محمد العقاري", role: "وسيط عقاري", message: "السلام عليكم، هل العقار ما زال متاحاً؟", time: "10:30 ص", unread: 2, avatar: "👨‍💼", verified: true, online: true, type: "broker", match: 92 },
    { id: "2", name: "شركة الأفق", role: "مكتب عقاري", message: "لدينا مشتري جاد للفيلا", time: "أمس", unread: 0, avatar: "🏢", verified: true, online: false, type: "broker", match: 60 },
  ],
  developers: [
    { id: "3", name: "إعمار الرياض", role: "مطور عقاري", message: "تم تحديث مخطط المشروع الجديد", time: "09:15 ص", unread: 1, avatar: "🏗️", verified: true, online: true, type: "developer", match: 85 },
  ],
  landlords: [
    { id: "4", name: "أبو خالد", role: "مالك عقار", message: "هل يمكن تخفيض السعر قليلاً؟", time: "أمس", unread: 0, avatar: "🔑", verified: false, online: false, type: "landlord", match: 40 },
  ],
  seekers: [
    { id: "5", name: "سارة أحمد", role: "باحث عن عقار", message: "متى يمكنني زيارة الشقة؟", time: "11:00 ص", unread: 3, avatar: "🔍", verified: true, online: true, type: "seeker", match: 78 },
    { id: "6", name: "فهد العتيبي", role: "باحث عن عقار", message: "أبحث عن فيلا في الملقا", time: "أمس", unread: 0, avatar: "👤", verified: false, online: false, type: "seeker", match: 30 },
  ]
};

export function InboxScreen({ onBack, onNavigate, onOpenChat }: InboxScreenProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";
  const [activeCategory, setActiveCategory] = useState<CategoryType | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const handleCategoryClick = (id: string) => {
    setActiveCategory(id as CategoryType);
  };

  const handleBack = () => {
    if (activeCategory) {
      setActiveCategory(null);
    } else {
      onBack();
    }
  };

  // @ts-ignore
  const filteredConversations = activeCategory ? conversations[activeCategory].filter(c => 
    c.name.includes(searchQuery) || c.message.includes(searchQuery)
  ) : [];

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gradient-to-br from-gray-50 to-gray-100'}`}>
      
      {/* Header */}
      <div className="px-5 pt-12 pb-4 relative z-10 bg-gradient-to-b from-black/20 to-transparent">
        <div className="flex items-center justify-between mb-6">
          <button 
            onClick={handleBack} 
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              isDark ? 'bg-white/5 hover:bg-white/10 text-white' : 'bg-white shadow-sm hover:bg-gray-50 text-gray-900'
            }`}
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="flex flex-col items-center">
            <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>
              {activeCategory ? categories.find(c => c.id === activeCategory)?.label : "المحادثات"}
            </h2>
            <div className="flex items-center gap-1.5 mt-0.5">
                <span className={`w-2 h-2 rounded-full ${isDark ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-emerald-500'}`} />
                <p className={`text-[10px] font-bold ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>متصل الآن</p>
            </div>
          </div>
          <button 
            onClick={toggleTheme}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              isDark ? 'bg-white/5 hover:bg-white/10 text-white' : 'bg-white shadow-sm hover:bg-gray-50 text-gray-900'
            }`}
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar - Always Visible */}
        <div className="mb-2 relative">
            <div className={`absolute inset-0 rounded-2xl blur opacity-20 ${isDark ? 'bg-cyan-500' : 'bg-blue-200'}`} />
            <div className={`relative rounded-2xl flex items-center gap-3 p-1 ${
                isDark ? 'bg-[#151A2D] border border-white/10' : 'bg-white shadow-sm border border-gray-100'
            }`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDark ? 'bg-white/5 text-white/40' : 'bg-gray-50 text-gray-400'
                }`}>
                    <Search className="w-5 h-5" />
                </div>
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن محادثة..."
                    className={`flex-1 bg-transparent outline-none text-sm font-bold h-10 ${
                        isDark ? 'text-white placeholder:text-white/20' : 'text-gray-900 placeholder:text-gray-400'
                    }`}
                />
                <button className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDark ? 'bg-cyan-500/10 text-cyan-400' : 'bg-blue-50 text-blue-600'
                }`}>
                    <Filter className="w-4 h-4" />
                </button>
            </div>
        </div>
      </div>

      {/* Main Content Area */}
      <AnimatePresence mode="wait">
        {!activeCategory ? (
          /* CATEGORIES GRID VIEW */
          <motion.div
            key="categories"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex-1 px-5 pt-2 pb-10 overflow-y-auto"
          >
             <h3 className={`font-bold mb-4 ${isDark ? 'text-white/70' : 'text-gray-500'}`}>التصنيفات</h3>
             <div className="grid grid-cols-2 gap-4">
               {categories.map((cat, i) => (
                 <motion.button
                   key={cat.id}
                   initial={{ opacity: 0, scale: 0.9 }}
                   animate={{ opacity: 1, scale: 1 }}
                   transition={{ delay: i * 0.1 }}
                   onClick={() => handleCategoryClick(cat.id)}
                   className={`relative overflow-hidden p-5 rounded-[24px] text-right group transition-all ${
                     isDark 
                       ? 'bg-[#1E2330] border border-white/5 hover:border-white/20' 
                       : 'bg-white shadow-sm border border-gray-100 hover:shadow-md'
                   }`}
                 >
                   {/* Gradient Background on Hover */}
                   <div className={`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity bg-gradient-to-br ${cat.color}`} />
                   
                   <div className="flex justify-between items-start mb-4">
                     <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-gradient-to-br ${cat.color} text-white shadow-lg`}>
                        <cat.icon className="w-6 h-6" />
                     </div>
                     {cat.unread > 0 && (
                       <div className="w-6 h-6 rounded-full bg-red-500 text-white text-xs font-black flex items-center justify-center border-2 border-[#1E2330]">
                         {cat.unread}
                       </div>
                     )}
                   </div>

                   <h3 className={`text-lg font-black mb-1 ${isDark ? 'text-white' : 'text-gray-900'}`}>{cat.label}</h3>
                   <p className={`text-[10px] font-bold mb-3 ${isDark ? 'text-white/40' : 'text-gray-400'}`}>{cat.desc}</p>
                   
                   <div className="flex items-center justify-between">
                     <span className={`text-xs font-bold ${isDark ? 'text-white/60' : 'text-gray-500'}`}>{cat.count} محادثة</span>
                     <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isDark ? 'bg-white/5 group-hover:bg-white/10' : 'bg-gray-50 group-hover:bg-gray-100'}`}>
                        <ArrowRight className={`w-4 h-4 ${isDark ? 'text-white' : 'text-gray-900'} rotate-180`} />
                     </div>
                   </div>
                 </motion.button>
               ))}
             </div>

             {/* Recent Activity Section (Optional) */}
             <div className="mt-8">
                <div className="flex items-center justify-between mb-4">
                  <h3 className={`font-bold ${isDark ? 'text-white/70' : 'text-gray-500'}`}>نشط مؤخراً</h3>
                </div>
                {/* Horizontal scroll of recent avatars could go here */}
                <div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar" dir="rtl">
                   {[1,2,3,4,5].map((_,i) => (
                      <div key={i} className={`w-14 h-14 rounded-full flex-shrink-0 flex items-center justify-center text-2xl border-2 ${isDark ? 'bg-[#1E2330] border-white/5' : 'bg-white border-gray-100'}`}>
                        {["👨‍💼","🏗️","🔍","🔑","👤"][i]}
                      </div>
                   ))}
                </div>
             </div>
          </motion.div>
        ) : (
          /* CONVERSATIONS LIST VIEW */
          <motion.div
            key="list"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 overflow-y-auto px-5 pb-32 pt-2"
          >
            <div className="space-y-3">
              {filteredConversations.length > 0 ? (
                filteredConversations.map((chat, index) => (
                  <motion.div
                    key={chat.id}
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => onOpenChat(chat)}
                    className={`relative group cursor-pointer rounded-[24px] p-1 transition-all ${
                        isDark ? 'hover:bg-white/5' : 'hover:bg-blue-50/50'
                    }`}
                  >
                    <div className={`relative z-10 flex items-start gap-4 p-4 rounded-[20px] border backdrop-blur-sm transition-all ${
                        isDark 
                            ? 'bg-[#1E2330]/80 border-white/5 group-hover:border-cyan-500/30' 
                            : 'bg-white border-gray-100 shadow-sm group-hover:shadow-md group-hover:border-blue-200'
                    }`}>
                        {/* Avatar */}
                        <div className="relative shrink-0">
                            {/* Glow Ring */}
                            {chat.unread > 0 && (
                                <div className="absolute inset-0 -m-1 rounded-full animate-spin-slow bg-gradient-to-tr from-cyan-500 via-purple-500 to-transparent opacity-50 blur-[2px]" />
                            )}
                            <div className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl relative z-10 ${
                                isDark ? 'bg-[#151A2D] text-white shadow-inner' : 'bg-gray-50 text-gray-900 border border-gray-100'
                            }`}>
                                {chat.avatar}
                            </div>
                            {chat.online && (
                                <div className={`absolute bottom-0 right-0 z-20 w-4 h-4 rounded-full border-[3px] ${
                                    isDark ? 'border-[#1E2330] bg-emerald-500' : 'border-white bg-emerald-500'
                                }`} />
                            )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0 pt-1">
                            <div className="flex items-center justify-between mb-1">
                                <div className="flex items-center gap-2">
                                    <h3 className={`font-black text-sm truncate ${isDark ? 'text-white' : 'text-gray-900'}`}>
                                        {chat.name}
                                    </h3>
                                    {chat.verified && (
                                        <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />
                                    )}
                                </div>
                                <span className={`text-[10px] font-bold ${isDark ? 'text-white/30' : 'text-gray-400'}`}>
                                    {chat.time}
                                </span>
                            </div>

                            <div className="flex items-center gap-2 mb-2">
                                 <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                                     chat.type === 'broker' ? (isDark ? 'bg-amber-500/10 text-amber-500' : 'bg-amber-50 text-amber-600') :
                                     chat.type === 'developer' ? (isDark ? 'bg-blue-500/10 text-blue-500' : 'bg-blue-50 text-blue-600') :
                                     (isDark ? 'bg-purple-500/10 text-purple-500' : 'bg-purple-50 text-purple-600')
                                 }`}>
                                     {chat.role}
                                 </span>
                                 {chat.match > 80 && (
                                     <div className={`flex items-center gap-1 text-[9px] font-bold ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>
                                         <Sparkles className="w-2.5 h-2.5" />
                                         <span>{chat.match}% تطابق</span>
                                     </div>
                                 )}
                            </div>

                            <div className="flex items-center justify-between">
                                <p className={`text-xs truncate max-w-[180px] ${
                                    chat.unread > 0 
                                        ? isDark ? 'text-white font-medium' : 'text-gray-900 font-bold'
                                        : isDark ? 'text-white/40' : 'text-gray-500'
                                }`}>
                                    {chat.message}
                                </p>
                                {chat.unread > 0 && (
                                    <div className={`h-5 min-w-[20px] px-1.5 rounded-full flex items-center justify-center text-[10px] font-black ${
                                        isDark 
                                            ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-[0_0_10px_rgba(6,182,212,0.4)]' 
                                            : 'bg-blue-600 text-white shadow-md'
                                    }`}>
                                        {chat.unread}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center py-20 opacity-50">
                  <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${isDark ? 'bg-white/5' : 'bg-gray-100'}`}>
                      <MessageCircle className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className={`font-bold ${isDark ? 'text-white/40' : 'text-gray-400'}`}>لا توجد محادثات نشطة</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
