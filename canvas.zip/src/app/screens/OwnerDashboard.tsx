import { ArrowRight, Plus, Eye, Edit, TrendingUp, MessageSquare, Sparkles, DollarSign } from "lucide-react";

interface OwnerDashboardProps {
  onNavigate: (screen: string) => void;
}

export function OwnerDashboard({ onNavigate }: OwnerDashboardProps) {
  const myProperties = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1622015663381-d2e05ae91b72?w=400",
      title: "فيلا فاخرة - حي النرجس",
      price: "2,500,000",
      views: 234,
      inquiries: 12,
      aiScore: 92,
      status: "active",
      daysListed: 5,
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1621919200669-2779566a6eaf?w=400",
      title: "شقة حديثة - حي الملقا",
      price: "850,000",
      views: 156,
      inquiries: 8,
      aiScore: 87,
      status: "active",
      daysListed: 12,
    },
  ];
  
  return (
    <div className="min-h-screen bg-[var(--aion-gray-50)]">
      {/* الهيدر */}
      <div className="bg-gradient-to-br from-[var(--aion-navy)] to-[var(--aion-navy-light)] text-white px-5 pt-4 pb-6">
        <div className="flex items-center justify-between max-w-md mx-auto mb-6">
          <button 
            onClick={() => onNavigate("home")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowRight className="w-6 h-6" />
          </button>
          
          <div className="text-center">
            <h1 className="text-xl font-bold">عقاراتي</h1>
            <p className="text-sm text-white/80">خالد المالك</p>
          </div>
          
          <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            <Plus className="w-6 h-6" />
          </button>
        </div>
        
        {/* إحصائيات سريعة */}
        <div className="grid grid-cols-3 gap-3 max-w-md mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center">
            <div className="text-2xl font-bold">2</div>
            <div className="text-xs text-white/80">عقارات</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center">
            <div className="text-2xl font-bold">390</div>
            <div className="text-xs text-white/80">مشاهدات</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center">
            <div className="text-2xl font-bold">20</div>
            <div className="text-xs text-white/80">استفسارات</div>
          </div>
        </div>
      </div>
      
      <div className="px-5 py-6 max-w-md mx-auto">
        {/* تحليل أيون */}
        <div 
          className="bg-gradient-to-br from-[var(--aion-green)]/10 to-[var(--aion-green)]/5 rounded-2xl p-5 mb-6 border-2 border-[var(--aion-green)]/20"
        >
          <div className="flex items-start gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-[var(--aion-navy)] mb-1">تحليل أيون لعقاراتك</h3>
              <p className="text-sm text-[var(--aion-gray-700)] leading-relaxed">
                عقاراتك تحصل على أداء ممتاز! متوسط درجة التقييم 89.5/100
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[var(--aion-gray-600)]">معدل المشاهدات اليومي</span>
              <span className="font-bold text-[var(--aion-navy)]">+23%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[var(--aion-gray-600)]">جودة الصور</span>
              <span className="font-bold text-[var(--aion-green)]">ممتازة</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[var(--aion-gray-600)]">التسعير</span>
              <span className="font-bold text-[var(--aion-green)]">مناسب</span>
            </div>
          </div>
        </div>
        
        {/* زر إضافة عقار جديد */}
        <button className="w-full bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] text-white p-4 rounded-2xl font-bold flex items-center justify-center gap-2 mb-6 transition-all active:scale-95" style={{ boxShadow: 'var(--aion-shadow-lg)' }}>
          <Plus className="w-5 h-5" />
          <span>أضف عقار جديد</span>
        </button>
        
        {/* العقارات */}
        <div className="space-y-4">
          <h3 className="font-bold text-[var(--aion-navy)]">عقاراتي النشطة</h3>
          
          {myProperties.map((property) => (
            <div 
              key={property.id}
              className="bg-white rounded-2xl overflow-hidden"
              style={{ boxShadow: 'var(--aion-shadow-md)' }}
            >
              {/* الصورة والحالة */}
              <div className="relative h-40">
                <img 
                  src={property.image} 
                  alt={property.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 right-3 bg-[var(--aion-green)] text-white px-3 py-1 rounded-full text-xs font-bold">
                  نشط
                </div>
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-[var(--aion-navy)]">
                  {property.daysListed} أيام
                </div>
              </div>
              
              {/* المحتوى */}
              <div className="p-4">
                <h4 className="font-bold text-[var(--aion-navy)] mb-2">{property.title}</h4>
                <div className="text-xl font-bold text-[var(--aion-green)] mb-3">
                  {property.price} <span className="text-sm font-normal">ريال</span>
                </div>
                
                {/* الإحصائيات */}
                <div className="grid grid-cols-3 gap-3 mb-3 pb-3 border-b border-[var(--aion-gray-200)]">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 text-[var(--aion-gray-600)] mb-1">
                      <Eye className="w-4 h-4" />
                    </div>
                    <div className="text-sm font-bold text-[var(--aion-navy)]">{property.views}</div>
                    <div className="text-xs text-[var(--aion-gray-600)]">مشاهدة</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 text-[var(--aion-gray-600)] mb-1">
                      <MessageSquare className="w-4 h-4" />
                    </div>
                    <div className="text-sm font-bold text-[var(--aion-navy)]">{property.inquiries}</div>
                    <div className="text-xs text-[var(--aion-gray-600)]">استفسار</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 text-[var(--aion-gray-600)] mb-1">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div className="text-sm font-bold text-[var(--aion-green)]">{property.aiScore}</div>
                    <div className="text-xs text-[var(--aion-gray-600)]">تقييم AI</div>
                  </div>
                </div>
                
                {/* رؤية AI */}
                <div className="bg-[var(--aion-green)]/5 rounded-xl p-3 mb-3">
                  <div className="flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-[var(--aion-green)] mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-[var(--aion-gray-700)] leading-relaxed">
                      أداء ممتاز! العقار يحصل على مشاهدات أعلى من المتوسط بـ 34%. السعر مناسب جداً.
                    </p>
                  </div>
                </div>
                
                {/* الأزرار */}
                <div className="flex gap-2">
                  <button className="flex-1 bg-[var(--aion-navy)] text-white py-2.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all active:scale-95">
                    <Edit className="w-4 h-4" />
                    <span>تعديل</span>
                  </button>
                  <button className="flex-1 bg-[var(--aion-gray-100)] text-[var(--aion-navy)] py-2.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all active:scale-95">
                    <TrendingUp className="w-4 h-4" />
                    <span>الإحصائيات</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* نصائح التسعير */}
        <div 
          className="mt-6 bg-white rounded-2xl p-5"
          style={{ boxShadow: 'var(--aion-shadow-md)' }}
        >
          <div className="flex items-center gap-2 mb-3">
            <DollarSign className="w-5 h-5 text-[var(--aion-green)]" />
            <h3 className="font-bold text-[var(--aion-navy)]">نصائح التسعير الذكية</h3>
          </div>
          <p className="text-sm text-[var(--aion-gray-700)] leading-relaxed mb-3">
            بناءً على تحليل السوق، هذا هو أفضل وقت للبيع في حي النرجس. الطلب مرتفع والأسعار في صعود.
          </p>
          <div className="flex items-center justify-between bg-[var(--aion-green)]/5 rounded-xl p-3">
            <div>
              <div className="text-xs text-[var(--aion-gray-600)] mb-1">متوسط السعر في الحي</div>
              <div className="text-lg font-bold text-[var(--aion-navy)]">5,555 ريال/م²</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-[var(--aion-gray-600)] mb-1">سعر عقارك</div>
              <div className="text-lg font-bold text-[var(--aion-green)]">5,432 ريال/م²</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
