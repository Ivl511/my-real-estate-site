import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Briefcase, Building2, Key, Search, Lock, 
  TrendingUp, Users, MapPin, FileText, Shield, 
  Zap, Star, CheckCircle, XCircle, AlertTriangle,
  ChevronRight, Crown, Sparkles, ArrowRight, Mic, Target
} from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import { SeekerMatchingAssistant, DeveloperMatchingAssistant } from "../components/MatchingAssistant";
// v2: dual-mode developer matching assistant

type Persona = "broker" | "developer" | "landlord" | "seeker";
type BrokerTier = "starter" | "nomad" | "pro";
type DeveloperTier = "starter" | "business" | "enterprise";
type LandlordTier = "free" | "premium";
type SeekerTier = "guest" | "vip";

interface ProfileDashboardProps {
  onBack: () => void;
}

export function ProfileDashboard({ onBack }: ProfileDashboardProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  
  const [persona, setPersona] = useState<Persona>("broker");
  const [brokerTier, setBrokerTier] = useState<BrokerTier>("starter");
  const [developerTier, setDeveloperTier] = useState<DeveloperTier>("starter");
  const [landlordTier, setLandlordTier] = useState<LandlordTier>("free");
  const [seekerTier, setSeekerTier] = useState<SeekerTier>("guest");

  const getCurrentTier = () => {
    switch (persona) {
      case "broker": return brokerTier;
      case "developer": return developerTier;
      case "landlord": return landlordTier;
      case "seeker": return seekerTier;
    }
  };

  const getTierOptions = () => {
    switch (persona) {
      case "broker":
        return [
          { value: "starter", label: "Starter" },
          { value: "nomad", label: "Nomad" },
          { value: "pro", label: "PRO" }
        ];
      case "developer":
        return [
          { value: "starter", label: "Starter" },
          { value: "business", label: "Business" },
          { value: "enterprise", label: "Enterprise" }
        ];
      case "landlord":
        return [
          { value: "free", label: "Free" },
          { value: "premium", label: "Premium" }
        ];
      case "seeker":
        return [
          { value: "guest", label: "Guest" },
          { value: "vip", label: "VIP Hunter" }
        ];
    }
  };

  const handleTierChange = (tier: string) => {
    switch (persona) {
      case "broker": setBrokerTier(tier as BrokerTier); break;
      case "developer": setDeveloperTier(tier as DeveloperTier); break;
      case "landlord": setLandlordTier(tier as LandlordTier); break;
      case "seeker": setSeekerTier(tier as SeekerTier); break;
    }
  };

  return (
    <div className={`min-h-screen ${isDark ? 'bg-[#0A0E1A]' : 'bg-gray-50'}`}>
      {/* ZONE 1: Simulation Controller - Fixed at TOP */}
      <div className={`fixed top-0 left-0 right-0 z-50 backdrop-blur-xl border-b ${
        isDark ? 'bg-[#0D1221]/95 border-cyan-500/20' : 'bg-white/95 border-gray-200'
      }`}>
        {/* Back Button */}
        <button
          onClick={onBack}
          className={`absolute top-3 left-4 z-10 p-2 rounded-full backdrop-blur-xl transition-all ${
            isDark 
              ? 'bg-white/10 hover:bg-white/20 text-white' 
              : 'bg-white hover:bg-gray-50 text-gray-900 border border-gray-200'
          }`}
        >
          <ArrowRight className="w-4 h-4" />
        </button>

        <div className="px-4 py-3">
          {/* Title */}
          <div className="flex items-center justify-center mb-3">
            <span className={`text-xs px-3 py-1 rounded-full ${
              isDark 
                ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border border-cyan-500/30' 
                : 'bg-blue-50 text-blue-600 border border-blue-200'
            }`}>
              🎯 SALES DEMO - نظام القفل التجريبي
            </span>
          </div>

          {/* Persona Toggle */}
          <div className="mb-2">
            <div className="grid grid-cols-4 gap-2">
              {[
                { value: "broker", label: "وسيط", icon: Briefcase, emoji: "👔" },
                { value: "developer", label: "مطور", icon: Building2, emoji: "🏗️" },
                { value: "landlord", label: "مالك", icon: Key, emoji: "🔑" },
                { value: "seeker", label: "باحث", icon: Search, emoji: "🔍" }
              ].map((p) => (
                <button
                  key={p.value}
                  onClick={() => setPersona(p.value as Persona)}
                  className={`px-2 py-1.5 rounded-lg text-[10px] font-bold transition-all ${
                    persona === p.value
                      ? (isDark 
                          ? 'bg-gradient-to-br from-cyan-500 to-purple-600 text-white shadow-lg shadow-cyan-500/50'
                          : 'bg-gradient-to-br from-blue-600 to-purple-600 text-white shadow-lg')
                      : (isDark
                          ? 'bg-white/5 text-gray-400 hover:bg-white/10'
                          : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200')
                  }`}
                >
                  <span className="block text-xs mb-0.5">{p.emoji}</span>
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tier Toggle */}
          <div>
            <div className={`grid gap-2 ${getTierOptions().length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
              {getTierOptions().map((t) => (
                <button
                  key={t.value}
                  onClick={() => handleTierChange(t.value)}
                  className={`px-2 py-1.5 rounded-lg text-[10px] font-bold transition-all ${
                    getCurrentTier() === t.value
                      ? (isDark 
                          ? 'bg-gradient-to-br from-emerald-500 to-cyan-600 text-white shadow-lg shadow-emerald-500/50'
                          : 'bg-gradient-to-br from-emerald-600 to-cyan-600 text-white shadow-lg')
                      : (isDark
                          ? 'bg-white/5 text-gray-400 hover:bg-white/10'
                          : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200')
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ZONE 2: Scrollable Content (Profile Card + Grid) */}
      <div className="pt-32 px-4 pb-32 overflow-y-auto h-screen">
        <AnimatePresence mode="wait">
          {persona === "broker" && (
            <BrokerDashboard key={`broker-${brokerTier}`} tier={brokerTier} isDark={isDark} />
          )}
          {persona === "developer" && (
            <DeveloperDashboard key={`developer-${developerTier}`} tier={developerTier} isDark={isDark} />
          )}
          {persona === "landlord" && (
            <LandlordDashboard key={`landlord-${landlordTier}`} tier={landlordTier} isDark={isDark} />
          )}
          {persona === "seeker" && (
            <SeekerDashboard key={`seeker-${seekerTier}`} tier={seekerTier} isDark={isDark} />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ==================== BROKER DASHBOARD ====================
function BrokerDashboard({ tier, isDark }: { tier: BrokerTier; isDark: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-4"
    >
      {/* ID Card */}
      <BrokerIDCard tier={tier} isDark={isDark} />

      {/* WIDGETS GRID */}
      <div className="grid grid-cols-1 gap-4">
        {/* My Listings Widget */}
        <Widget
          title="عقاراتي"
          icon={Building2}
          state={tier === "starter" ? "active-basic" : "active"}
          isDark={isDark}
        >
          <div className="space-y-2">
            <StatRow label="إجمالي العقارات" value={tier === "starter" ? "12" : "20"} isDark={isDark} />
            <StatRow label="نشط" value={tier === "starter" ? "8" : "15"} isDark={isDark} />
            {tier !== "starter" && (
              <StatRow label="مسودات" value="3" badge="جديد" isDark={isDark} />
            )}
            <StatRow label="مباع" value="4" isDark={isDark} />
          </div>
        </Widget>

        {/* My Tasks Widget */}
        <Widget
          title="مهامي"
          icon={FileText}
          state={tier === "starter" ? "active-basic" : "active"}
          isDark={isDark}
        >
          <div className="space-y-2">
            <TaskItem text="زيارة عقار في الملقا" isDark={isDark} />
            <TaskItem text="تحديث صور الفيلا" isDark={isDark} />
            {tier !== "starter" && (
              <div className={`p-3 rounded-lg border ${isDark ? "bg-purple-500/10 border-purple-500/30" : "bg-purple-50 border-purple-200"}`}>
                <div className="flex items-center gap-2">
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-purple-300" : "text-purple-700"}`}>
                    AI: مراجعة عقد البيع متاحة
                  </span>
                </div>
              </div>
            )}
          </div>
        </Widget>

        {/* My Landlords Widget */}
        <Widget
          title="ملاكي"
          icon={Users}
          state={tier === "starter" ? "restricted" : "active"}
          isDark={isDark}
          upgradeMessage={tier === "starter" ? "ترقية إلى Nomad لعرض التفاصيل الكاملة" : undefined}
        >
          {tier === "starter" ? (
            <div className={`text-center py-4 ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm font-bold">إجمالي الملاك: 24</p>
              <p className="text-xs mt-1">انقر للترقية ورؤية التفاصيل</p>
            </div>
          ) : (
            <div className="space-y-2">
              <LandlordItem name="أحمد السعيد" properties={5} alerts={2} isDark={isDark} />
              <LandlordItem name="فاطمة العمري" properties={3} alerts={0} isDark={isDark} />
              <LandlordItem name="محمد الغامدي" properties={8} alerts={1} isDark={isDark} />
              {tier === "pro" && (
                <div className={`p-3 rounded-lg border ${isDark ? "bg-cyan-500/10 border-cyan-500/30" : "bg-cyan-50 border-cyan-200"}`}>
                  <div className="flex items-center gap-2">
                    <Zap className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
                    <span className={`text-xs font-bold ${isDark ? "text-cyan-300" : "text-cyan-700"}`}>
                      AI: 3 ملاك قد يضيفون عقارات قريباً
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </Widget>

        {/* Market Heatmap Widget */}
        <Widget
          title="خريطة السوق"
          icon={MapPin}
          state={tier === "pro" ? "active" : "locked"}
          isDark={isDark}
          lockMessage={tier !== "pro" ? "ميزة PRO حصرية - خريطة المناطق الساخنة" : undefined}
          upgradeMessage={tier !== "pro" ? "ترقية إلى PRO لفتح تحليل السوق" : undefined}
        >
          {tier === "pro" && (
            <div className="space-y-2">
              <HeatmapZone zone="الملقا" heat="high" isDark={isDark} />
              <HeatmapZone zone="العليا" heat="medium" isDark={isDark} />
              <HeatmapZone zone="النرجس" heat="high" isDark={isDark} />
              <div className={`mt-3 p-3 rounded-lg ${isDark ? "bg-gradient-to-r from-red-500/20 to-orange-500/20" : "bg-gradient-to-r from-red-50 to-orange-50"}`}>
                <div className="flex items-center gap-2">
                  <TrendingUp className={`w-4 h-4 ${isDark ? "text-orange-400" : "text-orange-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-orange-300" : "text-orange-700"}`}>
                    الطلب في الملقا ارتفع 15% هذا الشهر
                  </span>
                </div>
              </div>
            </div>
          )}
        </Widget>
      </div>
    </motion.div>
  );
}

// ==================== DEVELOPER SEMANTIC SEARCH ====================
function DeveloperSemanticSearch({ tier, isDark }: { tier: DeveloperTier; isDark: boolean }) {
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<{ title: string; area: string; price: string; match: number }[]>([]);

  const examples = tier === "enterprise"
    ? ["أرض تجارية شمال الرياض بأقل من 3 مليون", "موقع سكني قريب من المدارس", "أرض خام للتطوير في منطقة نمو"]
    : ["مشترين لشقق تحت المليون", "عملاء يبحثون عن تاون هاوس", "طلبات فلل في الملقا والنرجس"];

  const mockResults = tier === "enterprise"
    ? [
        { title: "أرض تجارية - النرجس", area: "شمال الرياض", price: "2.4M ر.س", match: 96 },
        { title: "موقع سكني - الياسمين", area: "شمال الرياض", price: "1.9M ر.س", match: 89 },
        { title: "أرض مختلطة - حطين", area: "وسط الرياض", price: "3.1M ر.س", match: 82 },
      ]
    : [
        { title: "محمد العتيبي - يبحث فيلا", area: "الملقا", price: "ميزانية 2M+", match: 94 },
        { title: "سارة الشمري - تاون هاوس", area: "النرجس", price: "ميزانية 1.5M", match: 88 },
        { title: "خالد المالك - شقة 3 غرف", area: "العليا", price: "ميزانية 900K", match: 80 },
      ];

  const handleSearch = () => {
    if (!query.trim()) return;
    setSearching(true);
    setResults([]);
    setTimeout(() => {
      setSearching(false);
      setResults(mockResults);
    }, 1400);
  };

  return (
    <div className="space-y-3">
      {/* Search Bar */}
      <div className={`flex items-center gap-2 p-2 rounded-xl border ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
        <button className={`p-1.5 rounded-lg ${isDark ? "bg-blue-500/20 text-blue-400" : "bg-blue-100 text-blue-600"}`}>
          <Mic className="w-3.5 h-3.5" />
        </button>
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleSearch()}
          placeholder="ابحث بالكلام العامي..."
          className={`flex-1 bg-transparent text-xs outline-none ${isDark ? "text-white placeholder-gray-500" : "text-gray-900 placeholder-gray-400"}`}
        />
        <button onClick={handleSearch} className="p-1.5 rounded-lg bg-purple-600 text-white">
          <Search className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Enterprise AI badge */}
      {tier === "enterprise" && !results.length && !searching && (
        <div className={`flex items-center gap-2 p-2 rounded-lg ${isDark ? "bg-cyan-500/10 border border-cyan-500/20" : "bg-cyan-50 border border-cyan-200"}`}>
          <Zap className={`w-3.5 h-3.5 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
          <span className={`text-[10px] font-bold ${isDark ? "text-cyan-300" : "text-cyan-700"}`}>AI يبحث في الأراضي والفرص تلقائياً</span>
        </div>
      )}

      {/* Example chips */}
      {!results.length && !searching && (
        <div className="flex flex-wrap gap-1.5">
          {examples.map((e, i) => (
            <button
              key={i}
              onClick={() => setQuery(e)}
              className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-colors ${isDark ? "border-purple-500/30 text-purple-400 bg-purple-500/5 hover:bg-purple-500/15" : "border-purple-200 text-purple-600 bg-purple-50 hover:bg-purple-100"}`}
            >
              {e}
            </button>
          ))}
        </div>
      )}

      {/* Searching */}
      {searching && (
        <div className="flex items-center gap-3 py-3">
          <div className="flex gap-1">
            {[0, 1, 2].map(i => (
              <motion.div key={i} animate={{ scale: [1, 1.4, 1] }} transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.15 }}
                className="w-2 h-2 rounded-full bg-purple-500" />
            ))}
          </div>
          <span className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>يحلل الطلب ويبحث...</span>
        </div>
      )}

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-2">
          {results.map((r, i) => (
            <div key={i} className={`p-3 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
              <div className="flex items-center justify-between mb-1">
                <span className={`text-xs font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{r.title}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700"}`}>
                  {r.match}%
                </span>
              </div>
              <div className={`text-[10px] ${isDark ? "text-gray-400" : "text-gray-500"}`}>{r.area} · {r.price}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ==================== DEVELOPER DASHBOARD ====================
function DeveloperDashboard({ tier, isDark }: { tier: DeveloperTier; isDark: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-4"
    >
      {/* ID Card */}
      <DeveloperIDCard tier={tier} isDark={isDark} />

      {/* WIDGETS GRID */}
      <div className="grid grid-cols-1 gap-4">
        {/* Project Dashboard Widget */}
        <Widget
          title="لوحة المشاريع"
          icon={Building2}
          state="active"
          isDark={isDark}
        >
          <div className="space-y-2">
            {tier === "starter" && (
              <>
                <ProjectItem name="مشروع النرجس السكني" progress={75} isDark={isDark} />
                <div className={`p-3 rounded-lg border text-center ${isDark ? "bg-amber-500/10 border-amber-500/30 text-amber-400" : "bg-amber-50 border-amber-200 text-amber-700"}`}>
                  <p className="text-xs font-bold">حد واحد مشروع - ترقية إلى Business لمشاريع متعددة</p>
                </div>
              </>
            )}
            {tier === "business" && (
              <>
                <ProjectItem name="مشروع النرجس السكني" progress={75} isDark={isDark} />
                <ProjectItem name="أبراج العليا التجارية" progress={45} isDark={isDark} />
                <ProjectItem name="فلل الملقا الفاخرة" progress={90} isDark={isDark} />
              </>
            )}
            {tier === "enterprise" && (
              <>
                <ProjectItem name="مشروع النرجس السكني" progress={75} isDark={isDark} />
                <ProjectItem name="أبراج العليا التجارية" progress={45} isDark={isDark} />
                <ProjectItem name="فلل الملقا الفاخرة" progress={90} isDark={isDark} />
                <ProjectItem name="مجمع الرياض الكبير" progress={30} isDark={isDark} />
                <div className={`p-3 rounded-lg ${isDark ? "bg-gradient-to-r from-purple-500/20 to-cyan-500/20" : "bg-gradient-to-r from-purple-50 to-cyan-50"}`}>
                  <StatRow label="إجمالي المشاريع" value="10+" isDark={isDark} />
                </div>
              </>
            )}
          </div>
        </Widget>

        {/* Inventory Widget */}
        <Widget
          title="المخزون"
          icon={FileText}
          state={tier === "starter" ? "active-basic" : "active"}
          isDark={isDark}
        >
          <div className="space-y-2">
            <StatRow label="إجمالي الوحدات" value="48" isDark={isDark} />
            <StatRow label="متاح" value="22" isDark={isDark} />
            <StatRow label="محجوز" value="18" isDark={isDark} />
            <StatRow label="مباع" value="8" isDark={isDark} />
            {tier !== "starter" && (
              <div className={`mt-2 p-3 rounded-lg ${isDark ? "bg-emerald-500/10" : "bg-emerald-50"}`}>
                <StatRow label="معدل البيع الشهري" value="6 وحدات" badge="+12%" isDark={isDark} />
              </div>
            )}
          </div>
        </Widget>

        {/* Semantic Search Widget */}
        <Widget
          title="البحث الدلالي"
          icon={Search}
          state={tier === "starter" ? "locked" : "active"}
          isDark={isDark}
          lockMessage={tier === "starter" ? "ترقية إلى Business للوصول للبحث الذكي" : undefined}
          upgradeMessage={tier === "starter" ? "Business+" : undefined}
        >
          {tier !== "starter" && (
            <DeveloperSemanticSearch tier={tier} isDark={isDark} />
          )}
        </Widget>

        {/* Sales Team Widget */}
        <Widget
          title="فريق المبيعات"
          icon={Users}
          state={tier === "starter" ? "locked" : "active"}
          isDark={isDark}
          lockMessage={tier === "starter" ? "ترقية إلى Business لإضافة فريق مبيعات" : undefined}
          upgradeMessage={tier === "starter" ? "Business+" : undefined}
        >
          {tier !== "starter" && (
            <div className="space-y-2">
              <AgentItem name="سارة المطيري" deals={12} isDark={isDark} />
              <AgentItem name="خالد العتيبي" deals={8} isDark={isDark} />
              <AgentItem name="نورة الشمري" deals={15} isDark={isDark} />
              {tier === "enterprise" && (
                <div className={`mt-2 p-3 rounded-lg border ${isDark ? "bg-purple-500/10 border-purple-500/30" : "bg-purple-50 border-purple-200"}`}>
                  <StatRow label="إجمالي الوكلاء" value="8" badge="نشط" isDark={isDark} />
                </div>
              )}
            </div>
          )}
        </Widget>

        {/* Campaigns Widget - Business & Enterprise only */}
        <Widget
          title="الحملات التسويقية"
          icon={Zap}
          state={tier === "starter" ? "locked" : "active"}
          isDark={isDark}
          lockMessage={tier === "starter" ? "ترقية إلى Business لتفعيل الحملات الذكية" : undefined}
          upgradeMessage={tier === "starter" ? "Business+" : undefined}
        >
          {tier !== "starter" && (
            <div className="space-y-2">
              <CampaignItem name="حملة فلل الملقا" reach="12,400" isDark={isDark} />
              <CampaignItem name="إعلان أبراج العليا" reach="8,700" isDark={isDark} />
              {tier === "enterprise" && (
                <>
                  <CampaignItem name="تسويق مجمع الرياض" reach="21,300" isDark={isDark} />
                  <div className={`p-3 rounded-lg border ${isDark ? "bg-emerald-500/10 border-emerald-500/30" : "bg-emerald-50 border-emerald-200"}`}>
                    <div className="flex items-center gap-2">
                      <TrendingUp className={`w-4 h-4 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                      <span className={`text-xs font-bold ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>
                        AI: أفضل وقت للنشر غداً الساعة 7م
                      </span>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </Widget>

        {/* Predictive Analytics Widget - Enterprise only */}
        <Widget
          title="التحليلات التنبؤية"
          icon={TrendingUp}
          state={tier === "enterprise" ? "active" : "locked"}
          isDark={isDark}
          lockMessage={tier !== "enterprise" ? "ميزة Enterprise حصرية - تحليلات AI متقدمة" : undefined}
          upgradeMessage={tier !== "enterprise" ? "Enterprise" : undefined}
        >
          {tier === "enterprise" && (
            <div className="space-y-2">
              <div className={`p-4 rounded-lg ${isDark ? "bg-gradient-to-r from-purple-500/20 to-cyan-500/20" : "bg-gradient-to-r from-purple-50 to-cyan-50"}`}>
                <div className={`text-2xl font-black mb-1 ${isDark ? "text-purple-300" : "text-purple-700"}`}>+23%</div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>زيادة متوقعة في المبيعات Q2</div>
              </div>
              <StatRow label="أفضل منطقة للاستثمار" value="النرجس" isDark={isDark} />
              <StatRow label="نوع الوحدات الأعلى طلباً" value="فيلا 4 غرف" isDark={isDark} />
              <StatRow label="الميزانية الأكثر شيوعاً" value="1.5M – 2M" isDark={isDark} />
              <div className={`p-3 rounded-lg border ${isDark ? "bg-cyan-500/10 border-cyan-500/30" : "bg-cyan-50 border-cyan-200"}`}>
                <div className="flex items-center gap-2">
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-cyan-300" : "text-cyan-700"}`}>
                    AI: ابدأ مشروع سكني في الياسمين خلال 6 أشهر
                  </span>
                </div>
              </div>
            </div>
          )}
        </Widget>

        {/* Land Acquisition Widget */}
        <Widget
          title="اقتناء الأراضي"
          icon={MapPin}
          state={tier === "enterprise" ? "active" : "locked"}
          isDark={isDark}
          lockMessage={tier !== "enterprise" ? "ميزة Enterprise حصرية - AI لاكتشاف الأراضي" : undefined}
          upgradeMessage={tier !== "enterprise" ? "Enterprise" : undefined}
        >
          {tier === "enterprise" && (
            <div className="space-y-2">
              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>أرض الملقا الشمالية</span>
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-blue-600"}`} />
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>5,000 م² - سعر مناسب</div>
              </div>
              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>أرض العليا الغربية</span>
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-blue-600"}`} />
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>8,000 م² - فرصة ذهبية</div>
              </div>
              <div className={`p-3 rounded-lg border ${isDark ? "bg-cyan-500/10 border-cyan-500/30" : "bg-cyan-50 border-cyan-200"}`}>
                <div className="flex items-center gap-2">
                  <Zap className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-cyan-300" : "text-cyan-700"}`}>
                    AI وجد 3 أراضي خام مناسبة للتطوير
                  </span>
                </div>
              </div>
            </div>
          )}
        </Widget>

        {/* Developer Matching Assistant Widget */}
        {tier === "starter" ? (
          <Widget
            title="مساعد المطابقة AI"
            icon={Target}
            state="locked"
            isDark={isDark}
            lockMessage="ترقية إلى Business لإرسال عروضك للباحثين المطابقين"
            upgradeMessage="Business+"
          >
            {null}
          </Widget>
        ) : (
          <DeveloperMatchingAssistant tier={tier} isDark={isDark} />
        )}
      </div>
    </motion.div>
  );
}

// ==================== LANDLORD DASHBOARD ====================
function LandlordDashboard({ tier, isDark }: { tier: LandlordTier; isDark: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-4"
    >
      {/* ID Card */}
      <LandlordIDCard tier={tier} isDark={isDark} />

      {/* WIDGETS GRID */}
      <div className="grid grid-cols-1 gap-4">
        {/* My Assets Widget */}
        <Widget
          title="أصولي العقارية"
          icon={Building2}
          state="active"
          isDark={isDark}
        >
          <div className="space-y-2">
            <div className={`p-4 rounded-lg ${isDark ? "bg-gradient-to-r from-emerald-500/20 to-cyan-500/20" : "bg-gradient-to-r from-emerald-50 to-cyan-50"}`}>
              <div className={`text-2xl font-black mb-1 ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>
                2.4M ر.س
              </div>
              <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>إجمالي قيمة الأصول</div>
            </div>
            <StatRow label="فيلا الملقا" value="1.2M ر.س" isDark={isDark} />
            <StatRow label="شقة العليا" value="800K ر.س" isDark={isDark} />
            <StatRow label="محل تجاري" value="400K ر.س" isDark={isDark} />
          </div>
        </Widget>

        {/* My Tasks Widget */}
        <Widget
          title="مهامي"
          icon={FileText}
          state="active"
          isDark={isDark}
        >
          <div className="space-y-2">
            <TaskItem text="تجديد عقد إيجار فيلا الملقا" isDark={isDark} />
            <TaskItem text="متابعة طلب الصيانة للشقة" isDark={isDark} />
            {tier === "premium" && (
              <div className={`p-3 rounded-lg border ${isDark ? "bg-purple-500/10 border-purple-500/30" : "bg-purple-50 border-purple-200"}`}>
                <div className="flex items-center gap-2">
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-purple-300" : "text-purple-700"}`}>
                    AI: عقد الإيجار ينتهي خلال 30 يوم
                  </span>
                </div>
              </div>
            )}
          </div>
        </Widget>

        {/* Offers Widget */}
        <Widget
          title="العروض الواردة"
          icon={FileText}
          state="active"
          isDark={isDark}
        >
          <div className="space-y-2">
            <OfferItem buyer="محمد العتيبي" amount="1.1M" status="pending" isDark={isDark} />
            <OfferItem buyer="سارة الشمري" amount="780K" status="accepted" isDark={isDark} />
          </div>
        </Widget>

        {/* AI Inquiry Guard Widget */}
        <Widget
          title="حارس الاستفسارات AI"
          icon={Shield}
          state={tier === "premium" ? "active" : "active-basic"}
          isDark={isDark}
        >
          {tier === "free" ? (
            <div className="space-y-2">
              <div className={`p-3 rounded-lg border ${isDark ? "bg-gray-500/10 border-gray-500/30" : "bg-gray-50 border-gray-200"}`}>
                <div className="flex items-center gap-2 mb-2">
                  <div className={`text-sm font-bold ${isDark ? "text-gray-300" : "text-gray-700"}`}>وضع يدوي</div>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-500" : "text-gray-600"}`}>
                  جميع الرسائل تصل مباشرة
                </div>
              </div>
              <div className={`p-3 rounded-lg border ${isDark ? "bg-amber-500/10 border-amber-500/30 text-amber-400" : "bg-amber-50 border-amber-200 text-amber-700"}`}>
                <p className="text-xs font-bold text-center">ترقية إلى Premium للحصول على AI فلترة ذكية</p>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className={`p-3 rounded-lg ${isDark ? "bg-emerald-500/10" : "bg-emerald-50"}`}>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                  <div className={`text-sm font-bold ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>AI نشط 🟢</div>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  تم فلترة 15 استفسار غير جاد
                </div>
              </div>
              <StatRow label="استفسارات جادة" value="8" badge="اليوم" isDark={isDark} />
              <StatRow label="تم حظرها" value="15" isDark={isDark} />
            </div>
          )}
        </Widget>

        {/* Broker Match Widget */}
        <Widget
          title="مطابقة الوسطاء"
          icon={Users}
          state={tier === "premium" ? "active" : "locked"}
          isDark={isDark}
          lockMessage={tier === "free" ? "ترقية إلى Premium للعثور على وسطاء محترفين" : undefined}
          upgradeMessage={tier === "free" ? "Premium" : undefined}
        >
          {tier === "premium" && (
            <div className="space-y-2">
              <div className={`p-3 rounded-lg border ${isDark ? "bg-purple-500/10 border-purple-500/30" : "bg-purple-50 border-purple-200"}`}>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-purple-300" : "text-purple-700"}`}>
                    3 وسطاء يطلبون الوصول
                  </span>
                </div>
              </div>
              <BrokerRequestItem name="أحمد المحترف" experience="5 سنوات خبرة" isDark={isDark} />
              <BrokerRequestItem name="خالد السعيد" experience="8 سنوات خبرة" isDark={isDark} />
              <BrokerRequestItem name="فاطمة العمري" experience="3 سنوات خبرة" isDark={isDark} />
            </div>
          )}
        </Widget>

        {/* Legal Contracts Widget - Premium Only */}
        {tier === "premium" && (
          <Widget
            title="العقود القانونية"
            icon={FileText}
            state="active"
            isDark={isDark}
          >
            <div className="space-y-2">
              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>عقد إيجار - فيلا الملقا</span>
                  <CheckCircle className={`w-4 h-4 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>تم إنشاؤه تلقائياً بواسطة AI</div>
              </div>
              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>عقد بيع - شقة العليا</span>
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-blue-600"}`} />
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>جاهز للتوقيع</div>
              </div>
            </div>
          </Widget>
        )}
      </div>
    </motion.div>
  );
}

// ==================== SEEKER DASHBOARD ====================
function SeekerDashboard({ tier, isDark }: { tier: SeekerTier; isDark: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-4"
    >
      {/* ID Card */}
      <SeekerIDCard tier={tier} isDark={isDark} />

      {/* WIDGETS GRID */}
      <div className="grid grid-cols-1 gap-4">
        {/* My Tasks Widget */}
        <Widget
          title="مهامي"
          icon={FileText}
          state="active"
          isDark={isDark}
        >
          <div className="space-y-2">
            <TaskItem text="زيارة فيلا الملقا الفاخرة" isDark={isDark} />
            <TaskItem text="مراجعة عرض شقة العليا" isDark={isDark} />
            {tier === "vip" && (
              <div className={`p-3 rounded-lg border ${isDark ? "bg-purple-500/10 border-purple-500/30" : "bg-purple-50 border-purple-200"}`}>
                <div className="flex items-center gap-2">
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-purple-300" : "text-purple-700"}`}>
                    AI: عقار جديد يطابق معاييرك 95%
                  </span>
                </div>
              </div>
            )}
          </div>
        </Widget>

        {/* Wishlist Widget */}
        <Widget
          title="قائمة الرغبات"
          icon={Star}
          state="active"
          isDark={isDark}
        >
          <div className="space-y-2">
            <WishlistItem name="فيلا الملقا الفاخرة" price="1.2M ر.س" isDark={isDark} />
            <WishlistItem name="شقة العليا الحديثة" price="850K ر.س" isDark={isDark} />
            <WishlistItem name="دوبلكس النرجس" price="950K ر.س" isDark={isDark} />
          </div>
        </Widget>

        {/* My Requests Widget */}
        <Widget
          title="طلبات البحث"
          icon={Search}
          state="active"
          isDark={isDark}
        >
          <div className="space-y-2">
            <RequestItem type="فيلا في الملقا - 4 غرف" status="active" isDark={isDark} />
            <RequestItem type="شقة في العليا - 3 غرف" status="pending" isDark={isDark} />
            {tier === "vip" && (
              <div className={`p-3 rounded-lg border ${isDark ? "bg-purple-500/10 border-purple-500/30" : "bg-purple-50 border-purple-200"}`}>
                <div className="flex items-center gap-2">
                  <Zap className={`w-4 h-4 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-purple-300" : "text-purple-700"}`}>
                    AI يبحث عن 12 عقار يطابق معاييرك
                  </span>
                </div>
              </div>
            )}
          </div>
        </Widget>

        {/* Fair Price Analysis Widget */}
        <Widget
          title="تحليل السعر العادل"
          icon={TrendingUp}
          state={tier === "vip" ? "active" : "locked"}
          isDark={isDark}
          lockMessage={tier === "guest" ? "ميزة VIP حصرية - احصل على تحليل AI للأسعار" : undefined}
          upgradeMessage={tier === "guest" ? "VIP Hunter" : undefined}
        >
          {tier === "vip" && (
            <div className="space-y-2">
              <div className={`p-4 rounded-lg ${isDark ? "bg-gradient-to-r from-emerald-500/20 to-cyan-500/20" : "bg-gradient-to-r from-emerald-50 to-cyan-50"}`}>
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className={`w-5 h-5 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                  <span className={`text-sm font-bold ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>
                    سعر أقل من السوق
                  </span>
                </div>
                <div className={`text-3xl font-black ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>
                  -10%
                </div>
                <div className={`text-xs mt-1 ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  فيلا الملقا الفاخرة - فرصة ممتازة
                </div>
              </div>
              <StatRow label="السعر المطلوب" value="1.2M ر.س" isDark={isDark} />
              <StatRow label="متوسط السوق" value="1.33M ر.س" badge="+10%" isDark={isDark} />
              <div className={`p-3 rounded-lg ${isDark ? "bg-cyan-500/10" : "bg-cyan-50"}`}>
                <div className="flex items-center gap-2">
                  <Sparkles className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-cyan-300" : "text-cyan-700"}`}>
                    AI ينصح: صفقة ممتازة - تصرف بسرعة
                  </span>
                </div>
              </div>
            </div>
          )}
        </Widget>

        {/* Smart Matching Widget - مساعد المطابقة AI */}
        {tier === "guest" ? (
          <Widget
            title="مساعد المطابقة AI"
            icon={Sparkles}
            state="locked"
            isDark={isDark}
            lockMessage="ميزة VIP - در��ش مع AI لتحديد رغبتك وإيجاد أفضل العروض"
            upgradeMessage="VIP Hunter"
          >
            {null}
          </Widget>
        ) : (
          <SeekerMatchingAssistant isDark={isDark} />
        )}

        {/* Early Alerts Widget - VIP Only */}
        {tier === "vip" && (
          <Widget
            title="التنبيهات المبكرة"
            icon={Zap}
            state="active"
            isDark={isDark}
          >
            <div className="space-y-2">
              <div className={`p-3 rounded-lg border ${isDark ? "bg-cyan-500/10 border-cyan-500/30" : "bg-cyan-50 border-cyan-200"}`}>
                <div className="flex items-center gap-2 mb-2">
                  <Zap className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
                  <span className={`text-xs font-bold ${isDark ? "text-cyan-300" : "text-cyan-700"}`}>
                    إشعار قبل 24 ساعة من النشر
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  احصل على العقارات قبل المنافسين
                </div>
              </div>
              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>فيلا جديدة في النرجس</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${isDark ? "bg-orange-500/20 text-orange-400" : "bg-orange-100 text-orange-700"}`}>
                    غداً
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>سيتم نشرها خلال 18 ساعة</div>
              </div>
            </div>
          </Widget>
        )}
      </div>
    </motion.div>
  );
}

// ==================== ID CARDS ====================
function BrokerIDCard({ tier, isDark }: { tier: BrokerTier; isDark: boolean }) {
  const cardStyles = {
    starter: isDark 
      ? "bg-gradient-to-br from-emerald-500/30 to-cyan-500/30 border-emerald-500/50"
      : "bg-gradient-to-br from-emerald-100 to-cyan-100 border-emerald-300",
    nomad: "bg-gradient-to-br from-purple-500/40 via-pink-500/40 to-cyan-500/40 border-purple-500/50 relative overflow-hidden",
    pro: isDark
      ? "bg-gradient-to-br from-gray-900 to-black border-amber-500/50"
      : "bg-gradient-to-br from-gray-800 to-gray-900 border-amber-400"
  };

  const textStyles = {
    starter: isDark ? "text-emerald-300" : "text-emerald-700",
    nomad: "text-white",
    pro: "text-amber-400"
  };

  return (
    <div className={`p-6 rounded-2xl border-2 ${cardStyles[tier]} relative`}>
      {tier === "nomad" && (
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer" />
      )}
      {tier === "pro" && (
        <div className="absolute top-4 left-4">
          <Crown className="w-8 h-8 text-amber-400" />
        </div>
      )}
      <div className="relative">
        <div className="flex items-center gap-3 mb-3">
          <Briefcase className={`w-6 h-6 ${textStyles[tier]}`} />
          <span className={`text-lg font-black ${textStyles[tier]}`}>
            وسيط عقاري
          </span>
        </div>
        <div className={`text-2xl font-black mb-1 ${tier === "pro" ? "text-white" : textStyles[tier]}`}>
          أحمد المحترف
        </div>
        <div className={`text-sm ${tier === "pro" ? "text-amber-300" : (isDark ? "text-gray-300" : "text-gray-600")}`}>
          {tier === "starter" && "باقة Starter"}
          {tier === "nomad" && "باقة Nomad - المحترف"}
          {tier === "pro" && "باقة PRO - النخبة"}
        </div>
        {tier === "pro" && (
          <div className="mt-3 flex items-center gap-2">
            <div className="px-3 py-1 bg-amber-500/20 border border-amber-500/50 rounded-full">
              <span className="text-xs font-bold text-amber-400">ختم هيئة FAL الذهبي</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function DeveloperIDCard({ tier, isDark }: { tier: DeveloperTier; isDark: boolean }) {
  const cardStyles = {
    starter: isDark 
      ? "bg-gradient-to-br from-blue-500/30 to-purple-500/30 border-blue-500/50"
      : "bg-gradient-to-br from-blue-100 to-purple-100 border-blue-300",
    business: isDark
      ? "bg-gradient-to-br from-indigo-500/40 to-purple-500/40 border-indigo-500/50"
      : "bg-gradient-to-br from-indigo-100 to-purple-100 border-indigo-300",
    enterprise: isDark
      ? "bg-gradient-to-br from-gray-900 to-black border-gray-400"
      : "bg-gradient-to-br from-gray-800 to-gray-900 border-gray-400"
  };

  const textStyles = {
    starter: isDark ? "text-blue-300" : "text-blue-700",
    business: isDark ? "text-indigo-300" : "text-indigo-700",
    enterprise: "text-gray-300"
  };

  return (
    <div className={`p-6 rounded-2xl border-2 ${cardStyles[tier]}`}>
      <div className="flex items-center gap-3 mb-3">
        <Building2 className={`w-6 h-6 ${textStyles[tier]}`} />
        <span className={`text-lg font-black ${textStyles[tier]}`}>
          مطور عقاري
        </span>
      </div>
      <div className={`text-2xl font-black mb-1 ${tier === "enterprise" ? "text-white" : textStyles[tier]}`}>
        شركة العمران
      </div>
      <div className={`text-sm ${tier === "enterprise" ? "text-gray-400" : (isDark ? "text-gray-300" : "text-gray-600")}`}>
        {tier === "starter" && "باقة Starter - مشروع واحد"}
        {tier === "business" && "باقة Business - الشركة"}
        {tier === "enterprise" && "باقة Enterprise - قطب العقارات"}
      </div>
    </div>
  );
}

function LandlordIDCard({ tier, isDark }: { tier: LandlordTier; isDark: boolean }) {
  const cardStyles = {
    free: isDark 
      ? "bg-gradient-to-br from-orange-500/30 to-amber-500/30 border-orange-500/50"
      : "bg-gradient-to-br from-orange-100 to-amber-100 border-orange-300",
    premium: isDark
      ? "bg-gradient-to-br from-amber-500/40 to-yellow-500/40 border-amber-500/50"
      : "bg-gradient-to-br from-amber-100 to-yellow-100 border-amber-300"
  };

  const textStyles = {
    free: isDark ? "text-orange-300" : "text-orange-700",
    premium: isDark ? "text-amber-300" : "text-amber-700"
  };

  return (
    <div className={`p-6 rounded-2xl border-2 ${cardStyles[tier]}`}>
      <div className="flex items-center gap-3 mb-3">
        <Key className={`w-6 h-6 ${textStyles[tier]}`} />
        <span className={`text-lg font-black ${textStyles[tier]}`}>
          مالك عقار
        </span>
      </div>
      <div className={`text-2xl font-black mb-1 ${textStyles[tier]}`}>
        خالد المالك
      </div>
      <div className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}>
        {tier === "free" && "باقة Free - الأساسي"}
        {tier === "premium" && "باقة Premium - المالك الذكي"}
      </div>
    </div>
  );
}

function SeekerIDCard({ tier, isDark }: { tier: SeekerTier; isDark: boolean }) {
  const cardStyles = {
    guest: isDark 
      ? "bg-gradient-to-br from-blue-500/30 to-cyan-500/30 border-blue-500/50"
      : "bg-gradient-to-br from-blue-100 to-cyan-100 border-blue-300",
    vip: "bg-gradient-to-br from-purple-600/50 via-pink-600/50 to-cyan-600/50 border-purple-500/60 relative overflow-hidden"
  };

  const textStyles = {
    guest: isDark ? "text-blue-300" : "text-blue-700",
    vip: "text-white"
  };

  return (
    <div className={`p-6 rounded-2xl border-2 ${cardStyles[tier]}`}>
      {tier === "vip" && (
        <>
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer" />
          <div className="absolute top-4 left-4">
            <Crown className="w-8 h-8 text-purple-300" />
          </div>
        </>
      )}
      <div className="relative">
        <div className="flex items-center gap-3 mb-3">
          <Search className={`w-6 h-6 ${textStyles[tier]}`} />
          <span className={`text-lg font-black ${textStyles[tier]}`}>
            باحث عقاري
          </span>
        </div>
        <div className={`text-2xl font-black mb-1 ${textStyles[tier]}`}>
          فاطمة الباحثة
        </div>
        <div className={`text-sm ${tier === "vip" ? "text-purple-200" : (isDark ? "text-gray-300" : "text-gray-600")}`}>
          {tier === "guest" && "باقة Guest - مجاني"}
          {tier === "vip" && "باقة VIP Hunter - الصياد المحترف"}
        </div>
      </div>
    </div>
  );
}

// ==================== WIDGET COMPONENT ====================
type WidgetState = "active" | "active-basic" | "restricted" | "locked" | "hidden";

function Widget({
  title,
  icon: Icon,
  state,
  isDark,
  children,
  lockMessage,
  upgradeMessage
}: {
  title: string;
  icon: any;
  state: WidgetState;
  isDark: boolean;
  children: React.ReactNode;
  lockMessage?: string;
  upgradeMessage?: string;
}) {
  if (state === "hidden") return null;

  const isLocked = state === "locked";
  const isRestricted = state === "restricted";

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`rounded-2xl border overflow-hidden relative ${
        isLocked
          ? (isDark ? "bg-white/5 border-white/10" : "bg-gray-100 border-gray-200")
          : (isDark ? "bg-white/10 border-white/20" : "bg-white border-gray-200")
      } ${isLocked ? "opacity-60" : ""}`}
    >
      <div className={`p-4 border-b ${
        isDark ? "border-white/10" : "border-gray-200"
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon className={`w-5 h-5 ${isLocked ? (isDark ? "text-gray-600" : "text-gray-400") : (isDark ? "text-cyan-400" : "text-blue-600")}`} />
            <h3 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              {title}
            </h3>
          </div>
          {isLocked && (
            <Lock className={`w-4 h-4 ${isDark ? "text-gray-500" : "text-gray-400"}`} />
          )}
          {isRestricted && (
            <AlertTriangle className={`w-4 h-4 ${isDark ? "text-amber-400" : "text-amber-600"}`} />
          )}
        </div>
      </div>

      <div className={`p-4 ${isLocked ? "blur-sm pointer-events-none" : ""}`}>
        {!isLocked && children}
        {isLocked && (
          <div className="space-y-2">
            <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
              <div className={`h-4 rounded ${isDark ? "bg-white/10" : "bg-gray-200"} mb-2`}></div>
              <div className={`h-3 rounded ${isDark ? "bg-white/10" : "bg-gray-200"} w-3/4`}></div>
            </div>
            <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
              <div className={`h-4 rounded ${isDark ? "bg-white/10" : "bg-gray-200"} mb-2`}></div>
              <div className={`h-3 rounded ${isDark ? "bg-white/10" : "bg-gray-200"} w-2/3`}></div>
            </div>
          </div>
        )}
      </div>

      {/* Lock Overlay */}
      {isLocked && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[2px]">
          <div className={`text-center p-6 rounded-2xl ${isDark ? "bg-gray-900/90" : "bg-white/90"} border ${isDark ? "border-white/20" : "border-gray-300"} backdrop-blur-xl shadow-2xl`}>
            <Lock className={`w-12 h-12 mx-auto mb-3 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
            <p className={`text-sm font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
              {lockMessage || "ميزة مقفلة"}
            </p>
            {upgradeMessage && (
              <div className={`mt-3 px-4 py-2 rounded-full text-xs font-bold ${isDark ? "bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-lg" : "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"}`}>
                ترقية إلى {upgradeMessage}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Restricted State Warning */}
      {isRestricted && upgradeMessage && (
        <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold ${isDark ? "bg-amber-500/20 border border-amber-500/50 text-amber-400 shadow-lg" : "bg-amber-100 border border-amber-300 text-amber-700 shadow-md"}`}>
          {upgradeMessage}
        </div>
      )}
    </motion.div>
  );
}

// ==================== HELPER COMPONENTS ====================
function StatRow({ label, value, badge, isDark }: { label: string; value: string; badge?: string; isDark: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <span className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>{label}</span>
        {badge && (
          <span className={`text-[10px] px-2 py-0.5 rounded-full ${
            isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"
          }`}>
            {badge}
          </span>
        )}
      </div>
      <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{value}</span>
    </div>
  );
}

function TaskItem({ text, isDark }: { text: string; isDark: boolean }) {
  return (
    <div className={`flex items-center gap-2 p-2 rounded-lg ${
      isDark ? "bg-white/5" : "bg-gray-50"
    }`}>
      <CheckCircle className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-blue-600"}`} />
      <span className={`text-xs ${isDark ? "text-gray-300" : "text-gray-700"}`}>{text}</span>
    </div>
  );
}

function LandlordItem({ name, properties, alerts, isDark }: { name: string; properties: number; alerts: number; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between mb-1">
        <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{name}</span>
        {alerts > 0 && (
          <span className="text-xs px-2 py-0.5 rounded-full bg-red-500 text-white">{alerts}</span>
        )}
      </div>
      <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
        {properties} عقارات
      </div>
    </div>
  );
}

function HeatmapZone({ zone, heat, isDark }: { zone: string; heat: "high" | "medium" | "low"; isDark: boolean }) {
  const colors = {
    high: isDark ? "from-red-500/30 to-orange-500/30 border-red-500/50" : "from-red-100 to-orange-100 border-red-300",
    medium: isDark ? "from-yellow-500/30 to-amber-500/30 border-yellow-500/50" : "from-yellow-100 to-amber-100 border-yellow-300",
    low: isDark ? "from-blue-500/30 to-cyan-500/30 border-blue-500/50" : "from-blue-100 to-cyan-100 border-blue-300"
  };

  const labels = { high: "ساخن 🔥", medium: "متوسط", low: "هادئ" };

  return (
    <div className={`p-3 rounded-lg bg-gradient-to-r border ${colors[heat]}`}>
      <div className="flex items-center justify-between">
        <span className={`text-xs font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{zone}</span>
        <span className={`text-xs ${isDark ? "text-gray-300" : "text-gray-600"}`}>{labels[heat]}</span>
      </div>
    </div>
  );
}

function ProjectItem({ name, progress, isDark }: { name: string; progress: number; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between mb-2">
        <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{name}</span>
        <span className={`text-xs ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{progress}%</span>
      </div>
      <div className={`h-2 rounded-full ${isDark ? "bg-white/10" : "bg-gray-200"}`}>
        <div 
          className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-purple-500"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}

function AgentItem({ name, deals, isDark }: { name: string; deals: number; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between">
        <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{name}</span>
        <span className={`text-xs px-2 py-1 rounded-full ${
          isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700"
        }`}>
          {deals} صفقات
        </span>
      </div>
    </div>
  );
}

function CampaignItem({ name, reach, isDark }: { name: string; reach: string; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between">
        <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{name}</span>
        <span className={`text-xs ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{reach} وصول</span>
      </div>
    </div>
  );
}

function OfferItem({ buyer, amount, status, isDark }: { buyer: string; amount: string; status: "pending" | "accepted"; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between mb-1">
        <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{buyer}</span>
        <span className={`text-xs px-2 py-0.5 rounded-full ${
          status === "accepted"
            ? (isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700")
            : (isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700")
        }`}>
          {status === "accepted" ? "مقبول" : "معلق"}
        </span>
      </div>
      <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
        {amount} ريال
      </div>
    </div>
  );
}

function BrokerRequestItem({ name, experience, isDark }: { name: string; experience: string; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between">
        <div>
          <div className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{name}</div>
          <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>{experience}</div>
        </div>
        <ChevronRight className={`w-4 h-4 ${isDark ? "text-gray-400" : "text-gray-600"}`} />
      </div>
    </div>
  );
}

function WishlistItem({ name, price, isDark }: { name: string; price: string; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between">
        <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{name}</span>
        <span className={`text-xs ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{price}</span>
      </div>
    </div>
  );
}

function RequestItem({ type, status, isDark }: { type: string; status: "active" | "pending"; isDark: boolean }) {
  return (
    <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
      <div className="flex items-center justify-between">
        <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{type}</span>
        <span className={`text-xs px-2 py-0.5 rounded-full ${
          status === "active"
            ? (isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700")
            : (isDark ? "bg-gray-500/20 text-gray-400" : "bg-gray-100 text-gray-700")
        }`}>
          {status === "active" ? "نشط" : "معلق"}
        </span>
      </div>
    </div>
  );
}

// ==================== BENTO BUTTON ====================
function BentoButton({
  icon: Icon,
  title,
  badge,
  state,
  isDark,
  upgradeMessage
}: {
  icon: any;
  title: string;
  badge: string;
  state: WidgetState;
  isDark: boolean;
  upgradeMessage?: string;
}) {
  const isLocked = state === "locked";
  const isRestricted = state === "restricted";

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`rounded-2xl border overflow-hidden ${
        isLocked
          ? (isDark ? "bg-white/5 border-white/10" : "bg-gray-100 border-gray-200")
          : (isDark ? "bg-white/10 border-white/20" : "bg-white border-gray-200")
      } ${isLocked ? "grayscale opacity-50" : ""}`}
    >
      <div className={`p-4 border-b ${
        isDark ? "border-white/10" : "border-gray-200"
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon className={`w-5 h-5 ${isDark ? "text-cyan-400" : "text-blue-600"}`} />
            <h3 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              {title}
            </h3>
          </div>
          {isLocked && (
            <Lock className={`w-4 h-4 ${isDark ? "text-gray-500" : "text-gray-400"}`} />
          )}
          {isRestricted && (
            <AlertTriangle className={`w-4 h-4 ${isDark ? "text-amber-400" : "text-amber-600"}`} />
          )}
        </div>
      </div>

      <div className="p-4">
        {isLocked && (
          <div className={`text-center py-6 ${isDark ? "text-gray-500" : "text-gray-400"}`}>
            <Lock className="w-8 h-8 mx-auto mb-2" />
            <p className="text-sm font-bold">ميزة PRO فقط</p>
          </div>
        )}
        
        {isRestricted && upgradeMessage && (
          <div className={`mb-3 p-3 rounded-lg border ${
            isDark 
              ? "bg-amber-500/10 border-amber-500/30 text-amber-400" 
              : "bg-amber-50 border-amber-200 text-amber-700"
          }`}>
            <p className="text-xs font-bold text-center">{upgradeMessage}</p>
          </div>
        )}

        {!isLocked && (
          <div className="text-center">
            <div className={`text-2xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              {badge}
            </div>
            <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              {title}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}