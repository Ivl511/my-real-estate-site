import { ArrowRight, Plus, Search, TrendingUp, Users, Home, DollarSign, Sparkles, AlertCircle } from "lucide-react";
import { AionHeader } from "../components/aion/AionHeader";

interface BrokerDashboardProps {
  onNavigate: (screen: string) => void;
}

export function BrokerDashboard({ onNavigate }: BrokerDashboardProps) {
  const stats = [
    { icon: Home, label: "عقارات نشطة", value: "24", color: "text-[var(--aion-navy)]" },
    { icon: Users, label: "عملاء نشطين", value: "18", color: "text-[var(--aion-green)]" },
    { icon: TrendingUp, label: "صفقات هذا الشهر", value: "7", color: "text-blue-600" },
    { icon: DollarSign, label: "العمولات", value: "85K", color: "text-yellow-600" },
  ];
  
  const aiMatches = [
    {
      type: "match",
      title: "تطابق جديد!",
      description: "العميل أحمد السعيد يبحث عن فيلا في حي النرجس - لديك 3 فلل مطابقة",
      time: "منذ 5 دقائق",
      priority: "high",
    },
    {
      type: "price",
      title: "تنبيه سعر",
      description: "الفيلا في حي الياسمين - رفض 4 عملاء السعر. أيون ينصح بتخفيض 7%",
      time: "منذ ساعة",
      priority: "medium",
    },
    {
      type: "opportunity",
      title: "فرصة استثمارية",
      description: "طلب جديد لأرض تجارية 1000م² - ميزانية 2M ريال",
      time: "منذ ساعتين",
      priority: "high",
    },
  ];
  
  const recentRequests = [
    {
      client: "محمد العتيبي",
      request: "شقة 3 غرف، حي الملقا",
      budget: "800K - 1M ريال",
      status: "جديد",
    },
    {
      client: "سارة الأحمد",
      request: "فيلا، شمال الرياض",
      budget: "2M - 2.5M ريال",
      status: "قيد المتابعة",
    },
    {
      client: "خالد المطيري",
      request: "عقار استثماري",
      budget: "1.5M ريال",
      status: "جديد",
    },
  ];
  
  return (
    <div className="min-h-screen bg-[var(--aion-gray-50)]">
      {/* الهيدر */}
      <div className="bg-gradient-to-br from-[var(--aion-navy)] to-[var(--aion-navy-light)] text-white px-5 pt-4 pb-6">
        <div className="flex items-center justify-between max-w-md mx-auto mb-6">
          <button 
            onClick={() => onNavigate("home")}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowRight className="w-6 h-6" />
          </button>
          
          <div className="text-center">
            <h1 className="text-xl font-bold">لوحة تحكم الوسيط</h1>
            <p className="text-sm text-white/80">أحمد العقاري</p>
          </div>
          
          <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            <Search className="w-6 h-6" />
          </button>
        </div>
        
        {/* إحصائيات سريعة */}
        <div className="grid grid-cols-2 gap-3 max-w-md mx-auto">
          {stats.map((stat, index) => (
            <div 
              key={index}
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-xs text-white/80">{stat.label}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="px-5 py-6 max-w-md mx-auto">
        {/* تنبيهات AI الذكية */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[var(--aion-green)]" />
              <h3 className="font-bold text-[var(--aion-navy)]">تنبيهات أيون الذكية</h3>
            </div>
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">3</span>
          </div>
          
          <div className="space-y-3">
            {aiMatches.map((match, index) => (
              <div 
                key={index}
                className={`bg-white rounded-2xl p-4 border-r-4 ${
                  match.priority === 'high' 
                    ? 'border-[var(--aion-green)]' 
                    : 'border-yellow-500'
                }`}
                style={{ boxShadow: 'var(--aion-shadow-md)' }}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-xl ${
                    match.priority === 'high' 
                      ? 'bg-[var(--aion-green)]/10' 
                      : 'bg-yellow-500/10'
                  } flex items-center justify-center flex-shrink-0`}>
                    {match.type === 'match' && <Users className="w-5 h-5 text-[var(--aion-green)]" />}
                    {match.type === 'price' && <AlertCircle className="w-5 h-5 text-yellow-600" />}
                    {match.type === 'opportunity' && <TrendingUp className="w-5 h-5 text-[var(--aion-green)]" />}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-[var(--aion-navy)] mb-1">{match.title}</h4>
                    <p className="text-sm text-[var(--aion-gray-700)] mb-2 leading-relaxed">
                      {match.description}
                    </p>
                    <span className="text-xs text-[var(--aion-gray-500)]">{match.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* أزرار الإجراءات السريعة */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <button className="bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] text-white p-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95" style={{ boxShadow: 'var(--aion-shadow-lg)' }}>
            <Plus className="w-5 h-5" />
            <span>إضافة عقار</span>
          </button>
          <button className="bg-white text-[var(--aion-navy)] p-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 border-2 border-[var(--aion-gray-200)]">
            <Sparkles className="w-5 h-5 text-[var(--aion-green)]" />
            <span>مساعد AI</span>
          </button>
        </div>
        
        {/* طلبات العملاء الأخيرة */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-[var(--aion-navy)]">طلبات العملاء</h3>
            <button className="text-sm text-[var(--aion-green)] font-semibold">
              عرض الكل
            </button>
          </div>
          
          <div className="space-y-3">
            {recentRequests.map((request, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl p-4"
                style={{ boxShadow: 'var(--aion-shadow-md)' }}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-bold text-[var(--aion-navy)]">{request.client}</h4>
                    <p className="text-sm text-[var(--aion-gray-600)] mt-1">{request.request}</p>
                  </div>
                  <span className={`text-xs font-bold px-2 py-1 rounded-full ${
                    request.status === 'جديد' 
                      ? 'bg-[var(--aion-green)]/10 text-[var(--aion-green)]'
                      : 'bg-blue-100 text-blue-600'
                  }`}>
                    {request.status}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-[var(--aion-navy)]">
                    {request.budget}
                  </span>
                  <button className="text-sm text-[var(--aion-green)] font-semibold">
                    عرض التفاصيل ←
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* نصائح أيون الذكية */}
        <div 
          className="bg-gradient-to-br from-[var(--aion-navy)]/5 to-[var(--aion-green)]/5 rounded-2xl p-5 border-2 border-[var(--aion-green)]/20"
        >
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h4 className="font-bold text-[var(--aion-navy)] mb-2">نصيحة اليوم من أيون</h4>
              <p className="text-sm text-[var(--aion-gray-700)] leading-relaxed">
                التركيز على حي الملقا هذا الأسبوع! هناك طلب عالي على الشقق 3 غرف. 
                لديك 5 عقارات مطابقة - قم بتفعيل خاصية "التمييز" لزيادة الظهور.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
