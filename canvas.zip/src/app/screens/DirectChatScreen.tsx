import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ArrowRight, Send, Paperclip, Mic, Phone, Video, MoreVertical, 
  Check, CheckCheck, Bot, Sparkles, Calendar, FileText, CheckCircle2,
  Search, Filter, ShieldCheck, Clock, MapPin, User, Building2, X,
  MessageCircle
} from "lucide-react";
import { useTheme } from "../context/ThemeContext";

interface DirectChatScreenProps {
  onBack: () => void;
  chatData?: any;
}

interface Message {
  id: string;
  text: string;
  sender: "me" | "other";
  time: string;
  status: "sent" | "delivered" | "read";
  type: "text" | "image" | "location";
  isAi?: boolean;
}

interface ChatContact {
  id: string;
  name: string;
  role: string;
  roleType: "broker" | "seeker" | "developer" | "landlord";
  lastMessage: string;
  time: string;
  unread: number;
  avatar: string;
  online: boolean;
  verified: boolean;
  confidence: number;
}

const defaultContacts: ChatContact[] = [
  { id: "1", name: "محمد العقاري", role: "وسيط عقاري", roleType: "broker", lastMessage: "متى يناسبك الوقت للمعاينة؟", time: "10:30 ص", unread: 2, avatar: "👨‍💼", online: true, verified: true, confidence: 85 },
  { id: "2", name: "أبو خالد", role: "باحث عن عقار", roleType: "seeker", lastMessage: "هل السعر قابل للتفاوض؟", time: "أمس", unread: 0, avatar: "👤", online: false, verified: true, confidence: 60 },
  { id: "3", name: "إعمار الرياض", role: "مطور عقاري", roleType: "developer", lastMessage: "تحديث بشأن مشروع النرجس", time: "09:15 ص", unread: 1, avatar: "🏗️", online: true, verified: true, confidence: 95 },
  { id: "4", name: "سارة الغامدي", role: "مالكة عقار", roleType: "landlord", lastMessage: "هل يمكن ترتيب معاينة غداً؟", time: "أمس", unread: 0, avatar: "🔑", online: false, verified: false, confidence: 70 },
];

const messagesDb: Record<string, Message[]> = {
  "1": [
    { id: "1", text: "السلام عليكم، هل العقار ما زال متاحاً؟", sender: "other", time: "10:30 ص", status: "read", type: "text" },
    { id: "2", text: "وعليكم السلام! نعم العقار متاح. نسبة التوافق مع طلبك 85%.", sender: "me", time: "10:30 ص", status: "read", type: "text", isAi: true },
    { id: "3", text: "ممتاز، متى يمكنني المعاينة؟", sender: "other", time: "10:31 ص", status: "read", type: "text" },
    { id: "4", text: "يمكنك الحجز غداً من 10 ص إلى 12 ظهراً. هل يناسبك؟", sender: "me", time: "10:32 ص", status: "read", type: "text" },
  ],
  "2": [
    { id: "1", text: "هل السعر قابل للتفاوض؟", sender: "other", time: "أمس", status: "read", type: "text" },
    { id: "2", text: "يمكن التفاوض في حدود 100,000 ريال.", sender: "me", time: "أمس", status: "read", type: "text" },
  ],
  "3": [
    { id: "1", text: "تحديث بشأن مشروع النرجس - نسبة الإنجاز 75%", sender: "other", time: "09:15 ص", status: "read", type: "text" },
    { id: "2", text: "لدينا 50 وحدة جاهزة للتسويق بعمولة 5%", sender: "other", time: "09:20 ص", status: "read", type: "text" },
    { id: "3", text: "ممتاز، سنتواصل مع فريق المبيعات.", sender: "me", time: "09:25 ص", status: "read", type: "text" },
  ],
  "4": [
    { id: "1", text: "هل يمكن ترتيب معاينة غداً الساعة 10 صباحاً؟", sender: "other", time: "أمس", status: "read", type: "text" },
    { id: "2", text: "نعم، سيكون الموعد مؤكداً. شكراً.", sender: "me", time: "أمس", status: "delivered", type: "text" },
  ],
};

export function DirectChatScreen({ onBack, chatData }: DirectChatScreenProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [inputText, setInputText] = useState("");

  // If chatData comes from InboxScreen, map it to our contact format
  const incomingContact: ChatContact | null = chatData ? {
    id: chatData.id || "0",
    name: chatData.name || "محادثة",
    role: chatData.role || "مستخدم",
    roleType: (chatData.type as any) || "broker",
    lastMessage: chatData.message || "",
    time: chatData.time || "",
    unread: chatData.unread || 0,
    avatar: chatData.avatar || "👤",
    online: chatData.online ?? false,
    verified: chatData.verified ?? false,
    confidence: chatData.match || 0,
  } : null;

  // Desktop: show sidebar, Mobile: show only chat
  const [selectedChatId, setSelectedChatId] = useState<string>(
    incomingContact ? incomingContact.id : "1"
  );
  // On mobile, sidebar starts hidden if chatData was provided (came directly to a chat)
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);

  const contacts = incomingContact
    ? [incomingContact, ...defaultContacts.filter(c => c.id !== incomingContact.id)]
    : defaultContacts;

  const activeContact = contacts.find(c => c.id === selectedChatId) || contacts[0];

  const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>(() => {
    // seed with DB + generate for incoming contact
    const base = { ...messagesDb };
    if (incomingContact && !base[incomingContact.id]) {
      base[incomingContact.id] = [
        { id: "1", text: incomingContact.lastMessage || "مرحباً!", sender: "other", time: incomingContact.time || "الآن", status: "read", type: "text" },
      ];
    }
    return base;
  });

  const messages: Message[] = messagesMap[selectedChatId] || [
    { id: "1", text: "مرحباً! كيف أستطيع مساعدتك؟", sender: "other", time: "الآن", status: "read", type: "text" },
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, selectedChatId]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    const newMsg: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: "me",
      time: new Date().toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }),
      status: "sent",
      type: "text",
    };
    setMessagesMap(prev => ({ ...prev, [selectedChatId]: [...(prev[selectedChatId] || []), newMsg] }));
    setInputText("");
    setTimeout(() => {
      const reply: Message = {
        id: (Date.now() + 1).toString(),
        text: "شكراً على رسالتك، سأرد عليك في أقرب وقت ممكن.",
        sender: "other",
        time: new Date().toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }),
        status: "read",
        type: "text",
      };
      setMessagesMap(prev => ({ ...prev, [selectedChatId]: [...(prev[selectedChatId] || []), reply] }));
    }, 1800);
  };

  const handleSelectChat = (id: string) => {
    setSelectedChatId(id);
    setMobileSidebarOpen(false); // close sidebar after selecting on mobile
  };

  const actionChips = [
    { label: "جدولة معاينة", icon: Calendar, color: "blue" },
    { label: "قبول العرض", icon: CheckCircle2, color: "emerald" },
    { label: "تقرير ROI", icon: FileText, color: "purple" },
  ];

  const roleColor = (type: string) => {
    if (type === "broker") return isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700";
    if (type === "developer") return isDark ? "bg-blue-500/20 text-blue-400" : "bg-blue-100 text-blue-700";
    if (type === "landlord") return isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700";
    return isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700";
  };

  return (
    <div className={`h-full flex overflow-hidden relative ${isDark ? "bg-[#05080f]" : "bg-gray-50"}`}>

      {/* ── SIDEBAR (always right panel on desktop, drawer on mobile) ── */}
      {/* Mobile overlay */}
      <AnimatePresence>
        {mobileSidebarOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-30 md:hidden"
            onClick={() => setMobileSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar panel */}
      <motion.div
        initial={false}
        animate={{ x: mobileSidebarOpen ? 0 : "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        className={`fixed top-0 right-0 h-full w-80 z-40 flex flex-col border-l md:static md:translate-x-0 md:flex md:w-80 md:z-auto ${
          isDark ? "bg-[#0A0E1A] border-white/8" : "bg-white border-gray-200"
        }`}
        style={{ transform: undefined }} // let animate handle it on mobile
      >
        {/* Sidebar Header */}
        <div className={`p-5 pb-3 border-b ${isDark ? "border-white/5" : "border-gray-100"}`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={`text-lg font-black ${isDark ? "text-white" : "text-gray-900"}`}>المحادثات</h2>
            <div className="flex items-center gap-2">
              <div className={`px-2 py-1 rounded-lg text-xs font-bold ${isDark ? "bg-cyan-500/10 text-cyan-400" : "bg-blue-50 text-blue-600"}`}>
                {contacts.length} نشطة
              </div>
              <button onClick={() => setMobileSidebarOpen(false)} className="md:hidden w-8 h-8 rounded-xl flex items-center justify-center opacity-50 hover:opacity-80">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className={`flex items-center gap-2 px-3 py-2 rounded-xl ${isDark ? "bg-[#151A2D]" : "bg-gray-100"}`}>
            <Search className={`w-4 h-4 shrink-0 ${isDark ? "text-white/30" : "text-gray-400"}`} />
            <input type="text" placeholder="ابحث في المحادثات..." className={`flex-1 bg-transparent outline-none text-xs font-medium ${isDark ? "text-white placeholder:text-white/30" : "text-gray-900 placeholder:text-gray-400"}`} />
          </div>
        </div>

        {/* Contacts */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2">
          {contacts.map(contact => (
            <motion.button key={contact.id} whileTap={{ scale: 0.97 }}
              onClick={() => handleSelectChat(contact.id)}
              className={`w-full p-3.5 rounded-2xl flex items-start gap-3 text-right transition-all ${
                selectedChatId === contact.id
                  ? isDark ? "bg-gradient-to-r from-[#1E2330] to-[#151A2D] border border-cyan-500/30" : "bg-blue-50 border border-blue-200"
                  : isDark ? "bg-[#151A2D] border border-white/5 hover:border-white/10" : "bg-white border border-gray-100 hover:shadow-sm"
              }`}>
              <div className="relative shrink-0">
                <div className={`w-11 h-11 rounded-full flex items-center justify-center text-lg ${isDark ? "bg-[#0A0E1A]" : "bg-gray-100"}`}>
                  {contact.avatar}
                </div>
                {contact.online && <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#0A0E1A]" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <div className="flex items-center gap-1">
                    <span className={`font-black text-xs ${isDark ? "text-white" : "text-gray-900"}`}>{contact.name}</span>
                    {contact.verified && <ShieldCheck className="w-3 h-3 text-blue-500" />}
                  </div>
                  <span className={`text-[9px] ${isDark ? "text-white/30" : "text-gray-400"}`}>{contact.time}</span>
                </div>
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded mb-1 inline-block ${roleColor(contact.roleType)}`}>{contact.role}</span>
                <div className="flex items-center justify-between">
                  <p className={`text-[10px] truncate max-w-[150px] ${contact.unread > 0 ? isDark ? "text-white font-medium" : "text-gray-900 font-medium" : isDark ? "text-gray-500" : "text-gray-500"}`}>
                    {contact.lastMessage}
                  </p>
                  {contact.unread > 0 && (
                    <div className="min-w-[18px] h-[18px] rounded-full bg-cyan-500 text-black text-[9px] font-black flex items-center justify-center px-1">
                      {contact.unread}
                    </div>
                  )}
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* ── MAIN CHAT AREA ── */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* Chat Header */}
        <div className={`px-4 py-3 flex items-center gap-3 border-b z-10 ${isDark ? "bg-[#0A0E1A]/95 backdrop-blur border-white/8" : "bg-white border-gray-200 shadow-sm"}`}>
          {/* Back button */}
          <button onClick={onBack}
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-colors ${isDark ? "bg-white/8 text-white hover:bg-white/15" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>
            <ArrowRight className="w-5 h-5" />
          </button>

          {/* Avatar */}
          <div className="relative shrink-0">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${isDark ? "bg-[#151A2D]" : "bg-gray-100"}`}>
              {activeContact.avatar}
            </div>
            {activeContact.online && <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white" />}
          </div>

          {/* Name + Status */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className={`font-black text-sm truncate ${isDark ? "text-white" : "text-gray-900"}`}>{activeContact.name}</h3>
              {activeContact.verified && <ShieldCheck className="w-3.5 h-3.5 text-blue-500 shrink-0" />}
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded shrink-0 ${roleColor(activeContact.roleType)}`}>{activeContact.role}</span>
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              {activeContact.online
                ? <span className="text-emerald-500 font-bold text-[10px] flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />متصل الآن</span>
                : <span className={`text-[10px] ${isDark ? "text-white/30" : "text-gray-400"}`}>آخر ظهور {activeContact.time}</span>
              }
              {activeContact.confidence > 0 && (
                <>
                  <span className={`text-[10px] ${isDark ? "text-white/20" : "text-gray-300"}`}>•</span>
                  <span className="text-[10px] font-bold text-cyan-500 flex items-center gap-0.5">
                    <Sparkles className="w-2.5 h-2.5" />{activeContact.confidence}% تطابق
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Show all chats button - visible on mobile */}
            <button onClick={() => setMobileSidebarOpen(true)}
              className={`md:hidden w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${isDark ? "bg-white/8 text-white/60" : "bg-gray-100 text-gray-600"}`}>
              <MessageCircle className="w-4 h-4" />
            </button>
            <button className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${isDark ? "bg-white/8 text-white/60 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}><Phone className="w-4 h-4" /></button>
            <button className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors hidden sm:flex ${isDark ? "bg-white/8 text-white/60 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}><Video className="w-4 h-4" /></button>
            <button className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${isDark ? "bg-white/8 text-white/60 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}><MoreVertical className="w-4 h-4" /></button>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          <div className="text-center mb-4">
            <span className={`text-[10px] font-bold px-3 py-1 rounded-full ${isDark ? "bg-white/5 text-white/30 border border-white/5" : "bg-gray-100 text-gray-400"}`}>
              بداية المحادثة • {activeContact.time}
            </span>
          </div>

          {messages.map(msg => (
            <motion.div key={msg.id} initial={{ opacity: 0, y: 8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"}`}>
              {msg.sender === "other" && (
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm mr-2 self-end mb-1 shrink-0 ${isDark ? "bg-[#151A2D]" : "bg-gray-100"}`}>
                  {activeContact.avatar}
                </div>
              )}
              <div className={`flex flex-col gap-1 max-w-[75%] sm:max-w-[65%] ${msg.sender === "me" ? "items-end" : "items-start"}`}>
                {msg.isAi && (
                  <div className="flex items-center gap-1 text-[10px] text-cyan-400 font-bold px-1">
                    <Bot className="w-3 h-3" /><span>AI AGENT</span>
                  </div>
                )}
                <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-sm ${
                  msg.sender === "me"
                    ? msg.isAi
                      ? isDark ? "bg-[#0f172a] border border-cyan-500/30 text-cyan-100 rounded-tl-sm" : "bg-cyan-50 border border-cyan-200 text-cyan-900 rounded-tl-sm"
                      : isDark ? "bg-gradient-to-br from-cyan-600 to-blue-700 text-white rounded-tl-sm" : "bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-tl-sm"
                    : isDark ? "bg-[#151A2D] text-gray-200 rounded-tr-sm border border-white/5" : "bg-white text-gray-800 rounded-tr-sm border border-gray-100"
                }`} style={{ direction: "rtl" }}>
                  {msg.text}
                </div>
                <div className={`flex items-center gap-1 px-1 ${isDark ? "text-white/30" : "text-gray-400"}`}>
                  <span style={{ fontSize: "9px" }}>{msg.time}</span>
                  {msg.sender === "me" && (
                    msg.status === "read" ? <CheckCheck className="w-3 h-3 text-cyan-400" /> : <Check className="w-3 h-3" />
                  )}
                </div>
              </div>
            </motion.div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Action Chips */}
        <div className={`px-4 pb-1 border-t ${isDark ? "bg-[#0A0E1A] border-white/5" : "bg-white border-gray-100"}`}>
          <div className="flex gap-2 overflow-x-auto no-scrollbar py-2.5">
            {actionChips.map((chip, i) => (
              <motion.button key={i} whileTap={{ scale: 0.96 }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap border transition-all ${
                  isDark ? "bg-[#151A2D] text-white/70 border-white/8 hover:border-cyan-500/30" : "bg-gray-50 text-gray-700 border-gray-200 hover:border-blue-300"
                }`}>
                <chip.icon className={`w-3.5 h-3.5 ${chip.color === "blue" ? "text-blue-400" : chip.color === "emerald" ? "text-emerald-400" : "text-purple-400"}`} />
                {chip.label}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Input Area */}
        <div className={`px-4 pb-5 pt-2 ${isDark ? "bg-[#0A0E1A]" : "bg-white"}`}>
          <div className={`flex items-end gap-2 p-2 rounded-2xl border transition-all focus-within:ring-2 ${isDark ? "bg-[#151A2D] border-white/8 focus-within:border-cyan-500/30 focus-within:ring-cyan-500/10" : "bg-gray-50 border-gray-200 focus-within:border-blue-300 focus-within:ring-blue-100"}`}>
            <button className={`p-2.5 rounded-xl transition-colors ${isDark ? "text-white/40 hover:text-white hover:bg-white/10" : "text-gray-400 hover:text-gray-600"}`}>
              <Paperclip className="w-5 h-5" />
            </button>
            <div className="flex-1 py-1">
              <input type="text" value={inputText} onChange={e => setInputText(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSend()}
                placeholder="اكتب رسالتك..."
                className={`w-full bg-transparent outline-none text-right text-sm font-medium ${isDark ? "text-white placeholder:text-white/30" : "text-gray-900 placeholder:text-gray-400"}`}
              />
            </div>
            {inputText.trim() ? (
              <motion.button whileTap={{ scale: 0.9 }} onClick={handleSend}
                className={`p-2.5 rounded-xl transition-all ${isDark ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30" : "bg-blue-600 text-white shadow-md"}`}>
                <Send className="w-5 h-5" />
              </motion.button>
            ) : (
              <button className={`p-2.5 rounded-xl transition-colors ${isDark ? "text-white/40 hover:text-white hover:bg-white/10" : "text-gray-400 hover:text-gray-600"}`}>
                <Mic className="w-5 h-5" />
              </button>
            )}
          </div>
          <p className={`text-center mt-2 text-[9px] ${isDark ? "text-white/15" : "text-gray-300"}`}>
            المحادثة محمية ومشفرة عبر Nafath Verify™
          </p>
        </div>
      </div>
    </div>
  );
}
