import { motion } from "motion/react";
import { ArrowRight, Bell, Moon, Globe, Shield, HelpCircle, LogOut, ChevronLeft } from "lucide-react";
import { useTheme } from "../context/ThemeContext";

export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  const sections = [
    {
      title: "عام",
      items: [
        { icon: Bell, label: "الإشعارات", value: "مفعل", type: "toggle" },
        { icon: Moon, label: "المظهر الداكن", value: isDark, type: "action", action: toggleTheme },
        { icon: Globe, label: "اللغة", value: "العربية", type: "link" },
      ]
    },
    {
      title: "الأمان والدعم",
      items: [
        { icon: Shield, label: "الخصوصية والأمان", type: "link" },
        { icon: HelpCircle, label: "المساعدة والدعم", type: "link" },
      ]
    }
  ];

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`px-5 pt-12 pb-4 flex items-center gap-4 ${isDark ? 'bg-[#0D1221]' : 'bg-white shadow-sm'}`}>
        <button 
          onClick={onBack}
          className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            isDark ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-900'
          }`}
        >
          <ArrowRight className="w-5 h-5" />
        </button>
        <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>الإعدادات</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-8">
        {sections.map((section, idx) => (
          <div key={idx}>
            <h3 className={`text-xs font-bold mb-3 px-1 ${isDark ? 'text-white/40' : 'text-gray-400'}`}>
              {section.title}
            </h3>
            <div className={`rounded-2xl overflow-hidden ${
              isDark ? 'bg-[#1E2330]' : 'bg-white shadow-sm'
            }`}>
              {section.items.map((item, i) => (
                <div 
                  key={i}
                  onClick={item.type === 'action' ? item.action : undefined}
                  className={`p-4 flex items-center justify-between cursor-pointer ${
                    i !== section.items.length - 1 
                      ? isDark ? 'border-b border-white/5' : 'border-b border-gray-100' 
                      : ''
                  } ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-50'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      isDark ? 'bg-white/5 text-white' : 'bg-gray-100 text-gray-600'
                    }`}>
                      <item.icon className="w-4 h-4" />
                    </div>
                    <span className={`text-sm font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      {item.label}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {item.value !== undefined && (
                      <span className={`text-xs ${isDark ? 'text-white/40' : 'text-gray-400'}`}>
                        {typeof item.value === 'boolean' ? '' : item.value}
                      </span>
                    )}
                    {item.type === 'toggle' ? (
                      <div className="w-10 h-6 rounded-full bg-emerald-500 relative">
                        <div className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white shadow-sm" />
                      </div>
                    ) : (
                      <ChevronLeft className={`w-4 h-4 ${isDark ? 'text-white/20' : 'text-gray-300'}`} />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        <button className={`w-full p-4 rounded-2xl flex items-center justify-center gap-2 font-bold transition-colors ${
          isDark 
            ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20' 
            : 'bg-red-50 text-red-600 hover:bg-red-100'
        }`}>
          <LogOut className="w-5 h-5" />
          تسجيل الخروج
        </button>
      </div>
    </div>
  );
}
