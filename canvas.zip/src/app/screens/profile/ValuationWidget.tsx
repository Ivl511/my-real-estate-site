import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Calculator, X, Sparkles, Lock, TrendingUp, MapPin, ChevronDown } from "lucide-react";

const REGIONS = ["الرياض", "مكة المكرمة", "المدينة المنورة", "المنطقة الشرقية", "عسير", "تبوك", "القصيم"];
const CITIES: Record<string, string[]> = {
  "الرياض": ["الرياض", "الخرج", "الدوادمي", "المجمعة", "الزلفي"],
  "مكة المكرمة": ["مكة المكرمة", "جدة", "الطائف", "رابغ"],
  "المدينة المنورة": ["المدينة المنورة", "ينبع", "العلا"],
  "المنطقة الشرقية": ["الدمام", "الخبر", "الظهران", "الأحساء", "الجبيل"],
  "عسير": ["أبها", "خميس مشيط", "بيشة", "النماص"],
  "تبوك": ["تبوك", "ضباء", "تيماء"],
  "القصيم": ["بريدة", "عنيزة", "الرس"]
};
const NEIGHBORHOODS: Record<string, string[]> = {
  "الرياض": ["الملقا", "العليا", "النرجس", "الروضة", "الورود", "الحمراء", "المربع", "الغدير", "الربوة", "حي الجامعة"],
  "جدة": ["الزهراء", "السلامة", "الروضة", "الحمراء", "البساتين", "النعيم", "الصفا"],
  "الدمام": ["الشاطئ", "الفيصلية", "الروضة", "العدامة"],
  "الخبر": ["العقربية", "اليرموك", "الراكة"],
  "مكة المكرمة": ["العزيزية", "الزاهر", "أجياد"],
  "المدينة المنورة": ["العوالي", "قباء", "الحرة الغربية"],
};
const PROPERTY_TYPES = ["جميع الأنواع", "فيلا", "أرض", "شقة", "عمارة", "دوبلكس", "قصر"];
const CLASSIFICATIONS = ["سكني", "تجاري", "زراعي"];

interface ValuationResult {
  min: string;
  max: string;
  perSqm: string;
  confidence: string;
  recommendation: string;
}

interface ValuationWidgetProps {
  isDark: boolean;
  isLocked?: boolean;
  lockMessage?: string;
  lockTier?: string;
}

export function ValuationWidget({ isDark, isLocked, lockMessage, lockTier }: ValuationWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [region, setRegion] = useState("");
  const [city, setCity] = useState("");
  const [neighborhood, setNeighborhood] = useState("");
  const [propertyType, setPropertyType] = useState("");
  const [classification, setClassification] = useState("");
  const [area, setArea] = useState("");
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [result, setResult] = useState<ValuationResult | null>(null);

  const canEvaluate = region && city && propertyType && classification && area;

  const handleEvaluate = () => {
    if (!canEvaluate) return;
    setIsEvaluating(true);
    setResult(null);
    setTimeout(() => {
      setIsEvaluating(false);
      const areaNum = parseInt(area) || 400;
      const basePrice = propertyType === "أرض" ? 2200 : propertyType === "فيلا" ? 4500 : 3200;
      const classMultiplier = classification === "تجاري" ? 1.4 : classification === "زراعي" ? 0.6 : 1;
      const regionMultiplier = region === "الرياض" ? 1.2 : region === "مكة المكرمة" ? 1.15 : 1;
      const perSqm = Math.round(basePrice * classMultiplier * regionMultiplier);
      const total = areaNum * perSqm;
      const min = Math.round(total * 0.92 / 1000) * 1000;
      const max = Math.round(total * 1.08 / 1000) * 1000;

      setResult({
        min: min.toLocaleString("ar-SA"),
        max: max.toLocaleString("ar-SA"),
        perSqm: perSqm.toLocaleString("ar-SA"),
        confidence: "93%",
        recommendation: `السوق في ${city || region} يشهد ارتفاعاً مستمراً. توصية AI: هذا سعر تنافسي مناسب للبيع أو التفاوض.`
      });
    }, 2000);
  };

  const handleClose = () => {
    setIsOpen(false);
    setResult(null);
    setIsEvaluating(false);
  };

  const selectStyle = `flex-shrink-0 text-[11px] px-3 py-2 rounded-xl border outline-none cursor-pointer font-bold appearance-none ${
    isDark
      ? "bg-white/8 border-white/15 text-white hover:border-amber-500/50 focus:border-amber-500"
      : "bg-white border-gray-200 text-gray-800 hover:border-amber-400 focus:border-amber-500"
  } transition-colors`;

  return (
    <>
      {/* Widget Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className={`rounded-2xl border overflow-hidden relative ${
          isLocked
            ? (isDark ? "bg-white/5 border-white/10 opacity-60" : "bg-gray-100 border-gray-200 opacity-60")
            : (isDark ? "bg-white/10 border-white/20" : "bg-white border-gray-200")
        }`}
      >
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between ${isDark ? "border-white/10" : "border-gray-100"}`}>
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              isLocked
                ? (isDark ? "bg-gray-700" : "bg-gray-200")
                : "bg-gradient-to-br from-amber-500 to-orange-600"
            }`}>
              {isLocked
                ? <Lock className={`w-4 h-4 ${isDark ? "text-gray-500" : "text-gray-400"}`} />
                : <Calculator className="w-4 h-4 text-white" />
              }
            </div>
            <h3 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              وكيل التقييم
            </h3>
          </div>
          {isLocked && <Lock className={`w-4 h-4 ${isDark ? "text-gray-500" : "text-gray-400"}`} />}
          {!isLocked && (
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${isDark ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
              AI
            </span>
          )}
        </div>

        {/* Body */}
        {isLocked ? (
          <div className="relative">
            <div className="p-4 blur-sm pointer-events-none space-y-2">
              <div className={`h-4 rounded-lg ${isDark ? "bg-white/10" : "bg-gray-200"}`} />
              <div className={`h-4 rounded-lg w-3/4 ${isDark ? "bg-white/10" : "bg-gray-200"}`} />
              <div className={`h-10 rounded-xl ${isDark ? "bg-white/10" : "bg-gray-200"}`} />
            </div>
            <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[2px]">
              <div className={`text-center p-5 rounded-2xl border shadow-2xl ${isDark ? "bg-gray-900/90 border-white/20" : "bg-white/95 border-gray-300"}`}>
                <Lock className={`w-10 h-10 mx-auto mb-2 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                <p className={`text-xs font-bold mb-3 ${isDark ? "text-white" : "text-gray-900"}`}>
                  {lockMessage || "ميزة مقفلة"}
                </p>
                {lockTier && (
                  <div className="px-4 py-2 rounded-full text-xs font-black bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg">
                    ترقية إلى {lockTier}
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setIsOpen(true)}
            className={`w-full p-4 text-right flex items-center justify-between gap-3 transition-all group ${
              isDark ? "hover:bg-white/5" : "hover:bg-amber-50/50"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                isDark
                  ? "bg-gradient-to-br from-amber-500/20 to-orange-500/20 group-hover:from-amber-500/30 group-hover:to-orange-500/30"
                  : "bg-gradient-to-br from-amber-50 to-orange-50 group-hover:from-amber-100 group-hover:to-orange-100"
              }`}>
                <MapPin className={`w-5 h-5 ${isDark ? "text-amber-400" : "text-amber-600"}`} />
              </div>
              <div className="text-right">
                <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>ابدأ تقييم عقار</p>
                <p className={`text-[11px] ${isDark ? "text-gray-400" : "text-gray-500"}`}>حدد الموقع والنوع للحصول على تقييم AI فوري</p>
              </div>
            </div>
            <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${
              isDark ? "bg-amber-500/20" : "bg-amber-100"
            }`}>
              <Sparkles className={`w-3.5 h-3.5 ${isDark ? "text-amber-400" : "text-amber-600"}`} />
            </div>
          </button>
        )}
      </motion.div>

      {/* Modal */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] flex items-end sm:items-center justify-center"
          >
            <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={handleClose} />
            <motion.div
              initial={{ y: 80, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 80, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className={`relative w-full max-w-xl mx-4 rounded-2xl border overflow-hidden shadow-2xl max-h-[90vh] overflow-y-auto ${
                isDark
                  ? "bg-[#0D1221] border-amber-500/40"
                  : "bg-white border-amber-200"
              }`}
            >
              {/* Modal Header */}
              <div className={`sticky top-0 z-10 flex items-center justify-between p-4 border-b ${
                isDark ? "bg-[#0D1221] border-white/10" : "bg-white border-gray-100"
              }`}>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/30">
                    <Calculator className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>وكيل التقييم</h3>
                    <p className={`text-[10px] font-bold ${isDark ? "text-amber-400" : "text-amber-600"}`}>مدعوم بالذكاء الاصطناعي ✦</p>
                  </div>
                </div>
                <button
                  onClick={handleClose}
                  className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                    isDark ? "bg-white/10 hover:bg-white/20 text-gray-400" : "bg-gray-100 hover:bg-gray-200 text-gray-600"
                  }`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 space-y-4">
                {/* Filters Label */}
                <div className="flex items-center gap-2">
                  <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-gray-100"}`} />
                  <span className={`text-[11px] font-black px-3 ${isDark ? "text-gray-400" : "text-gray-500"}`}>بيانات العقار</span>
                  <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-gray-100"}`} />
                </div>

                {/* Single Horizontal Filter Row */}
                <div
                  className="flex gap-2 overflow-x-auto pb-2"
                  style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                >
                  {/* 1. Region */}
                  <div className="flex-shrink-0 relative">
                    <select
                      value={region}
                      onChange={e => { setRegion(e.target.value); setCity(""); setNeighborhood(""); }}
                      className={selectStyle}
                      style={{ paddingLeft: "2rem" }}
                    >
                      <option value="">📍 المنطقة</option>
                      {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>

                  {/* 2. City */}
                  <div className="flex-shrink-0 relative">
                    <select
                      value={city}
                      onChange={e => { setCity(e.target.value); setNeighborhood(""); }}
                      disabled={!region}
                      className={`${selectStyle} ${!region ? "opacity-40 cursor-not-allowed" : ""}`}
                    >
                      <option value="">🏙️ المدينة</option>
                      {(CITIES[region] || []).map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>

                  {/* 3. Neighborhood */}
                  <div className="flex-shrink-0 relative">
                    <select
                      value={neighborhood}
                      onChange={e => setNeighborhood(e.target.value)}
                      disabled={!city}
                      className={`${selectStyle} ${!city ? "opacity-40 cursor-not-allowed" : ""}`}
                    >
                      <option value="">🏘️ الحي</option>
                      {(NEIGHBORHOODS[city] || ["حي المركز", "حي الشمال", "حي الجنوب", "حي الغرب"]).map(n => (
                        <option key={n} value={n}>{n}</option>
                      ))}
                    </select>
                  </div>

                  {/* 4. Property Type */}
                  <div className="flex-shrink-0 relative">
                    <select
                      value={propertyType}
                      onChange={e => setPropertyType(e.target.value)}
                      className={selectStyle}
                    >
                      <option value="">🏠 نوع العقار</option>
                      {PROPERTY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>

                  {/* 5. Classification */}
                  <div className="flex-shrink-0 relative">
                    <select
                      value={classification}
                      onChange={e => setClassification(e.target.value)}
                      className={selectStyle}
                    >
                      <option value="">🏷️ التصنيف</option>
                      {CLASSIFICATIONS.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>

                  {/* 6. Area */}
                  <div className="flex-shrink-0">
                    <input
                      type="number"
                      value={area}
                      onChange={e => setArea(e.target.value)}
                      placeholder="م² المساحة"
                      min="1"
                      className={`w-28 text-[11px] px-3 py-2 rounded-xl border outline-none font-bold ${
                        isDark
                          ? "bg-white/8 border-white/15 text-white placeholder:text-gray-500 focus:border-amber-500"
                          : "bg-white border-gray-200 text-gray-800 placeholder:text-gray-400 focus:border-amber-500"
                      } transition-colors`}
                    />
                  </div>
                </div>

                {/* Filter Summary Pills */}
                {(region || city || propertyType || classification) && (
                  <div className="flex flex-wrap gap-1.5">
                    {region && (
                      <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${isDark ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
                        {region}
                      </span>
                    )}
                    {city && (
                      <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${isDark ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
                        {city}
                      </span>
                    )}
                    {neighborhood && (
                      <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${isDark ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
                        {neighborhood}
                      </span>
                    )}
                    {propertyType && (
                      <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${isDark ? "bg-orange-500/20 text-orange-400 border border-orange-500/30" : "bg-orange-50 text-orange-700 border border-orange-200"}`}>
                        {propertyType}
                      </span>
                    )}
                    {classification && (
                      <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${isDark ? "bg-orange-500/20 text-orange-400 border border-orange-500/30" : "bg-orange-50 text-orange-700 border border-orange-200"}`}>
                        {classification}
                      </span>
                    )}
                    {area && (
                      <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${isDark ? "bg-orange-500/20 text-orange-400 border border-orange-500/30" : "bg-orange-50 text-orange-700 border border-orange-200"}`}>
                        {area} م²
                      </span>
                    )}
                  </div>
                )}

                {/* Evaluate Button */}
                <button
                  onClick={handleEvaluate}
                  disabled={!canEvaluate || isEvaluating}
                  className={`w-full py-3.5 rounded-xl font-black text-sm transition-all flex items-center justify-center gap-2 ${
                    !canEvaluate || isEvaluating
                      ? (isDark ? "bg-white/10 text-gray-500 cursor-not-allowed" : "bg-gray-100 text-gray-400 cursor-not-allowed")
                      : "bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/30 hover:shadow-amber-500/50 hover:scale-[1.01]"
                  }`}
                >
                  {isEvaluating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      جاري التقييم...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      قيّم بالذكاء الاصطناعي
                    </>
                  )}
                </button>

                {/* Results */}
                <AnimatePresence>
                  {result && (
                    <motion.div
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`rounded-2xl border overflow-hidden ${isDark ? "border-amber-500/30" : "border-amber-200"}`}
                    >
                      {/* Value Banner */}
                      <div className={`p-4 ${isDark ? "bg-gradient-to-r from-amber-500/20 via-orange-500/15 to-amber-500/20" : "bg-gradient-to-r from-amber-50 to-orange-50"}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <TrendingUp className={`w-4 h-4 ${isDark ? "text-amber-400" : "text-amber-600"}`} />
                          <span className={`text-xs font-bold ${isDark ? "text-amber-300" : "text-amber-700"}`}>تقدير قيمة العقار</span>
                        </div>
                        <p className={`text-xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>
                          {result.min} – {result.max} ر.س
                        </p>
                      </div>

                      {/* Stats */}
                      <div className={`grid grid-cols-2 gap-0 border-t ${isDark ? "border-amber-500/20" : "border-amber-100"}`}>
                        <div className={`p-3 border-l ${isDark ? "border-amber-500/20 bg-white/5" : "border-amber-100 bg-white"}`}>
                          <p className={`text-[10px] mb-0.5 ${isDark ? "text-gray-500" : "text-gray-500"}`}>متوسط سعر المتر</p>
                          <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{result.perSqm} ر.س</p>
                        </div>
                        <div className={`p-3 ${isDark ? "bg-white/5" : "bg-white"}`}>
                          <p className={`text-[10px] mb-0.5 ${isDark ? "text-gray-500" : "text-gray-500"}`}>دقة التقييم</p>
                          <p className="text-sm font-black text-emerald-500">{result.confidence}</p>
                        </div>
                      </div>

                      {/* AI Recommendation */}
                      <div className={`p-3 border-t flex items-start gap-2 ${isDark ? "border-amber-500/20 bg-amber-500/5" : "border-amber-100 bg-amber-50/50"}`}>
                        <Sparkles className={`w-3.5 h-3.5 mt-0.5 flex-shrink-0 ${isDark ? "text-amber-400" : "text-amber-600"}`} />
                        <p className={`text-[11px] leading-relaxed ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                          {result.recommendation}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
