import { useState, useRef, useEffect } from "react";
import { AionHeader } from "../components/aion/AionHeader";
import { AIMessage } from "../components/aion/AIMessage";
import { TypingIndicator } from "../components/aion/TypingIndicator";
import { Send, ArrowRight, Home, TrendingUp, DollarSign, MapPin } from "lucide-react";

interface ChatScreenProps {
  onNavigate: (screen: string, data?: any) => void;
  initialMessage?: string;
}

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: string;
}

export function ChatScreen({ onNavigate, initialMessage }: ChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "مرحباً! أنا مساعد أيون الذكي 👋\n\nيمكنني مساعدتك في:\n• البحث عن عقارات مناسبة\n• تقييم الأسعار\n• تحليل الفرص الاستثمارية\n• التواصل مع الوسطاء\n\nكيف يمكنني مساعدتك اليوم؟",
      isUser: false,
      timestamp: "الآن",
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);
  
  useEffect(() => {
    if (initialMessage) {
      handleSendMessage(initialMessage);
    }
  }, []);
  
  const generateAIResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes("شقة") || lowerMessage.includes("سكن")) {
      return "بحثت لك عن أفضل الشقق المتاحة! 🏢\n\nوجدت 23 شقة مناسبة في المناطق التالية:\n• حي الملقا - من 800,000 ريال\n• حي النرجس - من 950,000 ريال\n• حي العليا - من 750,000 ريال\n\nهل تريد رؤية النتائج أم تفضل تحديد المنطقة أكثر؟";
    }
    
    if (lowerMessage.includes("استثمار")) {
      return "رائع! استثمارك في العقار خيار ذكي 📈\n\nبناءً على تحليلي للسوق، أنصحك بالمناطق التالية:\n• حي الياسمين - عائد استثماري 8.5% سنوياً\n• حي النخيل - نمو متوقع 12% خلال 3 سنوات\n• حي الربوة - طلب عالي على الإيجار\n\nما هي ميزانيتك الاستثمارية؟";
    }
    
    if (lowerMessage.includes("سعر") || lowerMessage.includes("المتر")) {
      return "سعر المتر يختلف حسب المنطقة 💰\n\nإليك متوسط الأسعار الحالية:\n• شمال الرياض: 3,200 - 4,500 ريال/م²\n• شرق الرياض: 2,800 - 3,800 ريال/م²\n• غرب الرياض: 2,500 - 3,500 ريال/م²\n\nأي منطقة تهمك بالتحديد؟";
    }
    
    if (lowerMessage.includes("فيلا")) {
      return "أبحث عن الفلل المتاحة... 🏡\n\nوجدت 18 فيلا فاخرة:\n• 5 فلل في حي النرجس (1.8M - 3.2M ريال)\n• 7 فلل في حي الياسمين (2.1M - 4.5M ريال)\n• 6 فلل في حي الملقا (1.5M - 2.8M ريال)\n\nجميعها بتقييم AI إيجابي! هل تريد رؤية التفاصيل؟";
    }
    
    return "فهمت طلبك! 🎯\n\nدعني أبحث في قاعدة بياناتنا الذكية... لقد وجدت عدة خيارات مناسبة لك.\n\nهل تريد أن أعرض لك النتائج أم تفضل تحديد معايير إضافية مثل:\n• الميزانية المحددة\n• عدد الغرف\n• المساحة المطلوبة\n• المنطقة المفضلة";
  };
  
  const handleSendMessage = (messageText?: string) => {
    const textToSend = messageText || inputValue;
    if (!textToSend.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      text: textToSend,
      isUser: true,
      timestamp: new Date().toLocaleTimeString("ar-SA", {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);
    
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: generateAIResponse(textToSend),
        isUser: false,
        timestamp: new Date().toLocaleTimeString("ar-SA", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };
      setMessages((prev) => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };
  
  const quickSuggestions = [
    { icon: Home, text: "شقق للبيع" },
    { icon: TrendingUp, text: "فرص استثمارية" },
    { icon: DollarSign, text: "تقييم سعر" },
    { icon: MapPin, text: "مناطق مميزة" },
  ];
  
  return (
    <div className="flex flex-col h-screen bg-[var(--aion-gray-50)]">
      {/* الهيدر */}
      <div className="flex-shrink-0">
        <div className="bg-[var(--aion-navy)] text-white px-5 py-4">
          <div className="flex items-center justify-between max-w-md mx-auto">
            <button 
              onClick={() => onNavigate("home")}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ArrowRight className="w-6 h-6" />
            </button>
            
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] flex items-center justify-center">
                <span className="text-lg">✨</span>
              </div>
              <div>
                <h2 className="font-bold">مساعد أيون</h2>
                <p className="text-xs text-white/80">متصل الآن</p>
              </div>
            </div>
            
            <div className="w-10"></div>
          </div>
        </div>
      </div>
      
      {/* منطقة المحادثة */}
      <div className="flex-1 overflow-y-auto px-5 py-6 max-w-md mx-auto w-full">
        {messages.map((message) => (
          <AIMessage
            key={message.id}
            message={message.text}
            isUser={message.isUser}
            timestamp={message.timestamp}
          />
        ))}
        {isTyping && <TypingIndicator />}
        <div ref={messagesEndRef} />
        
        {/* اقتراحات سريعة */}
        {messages.length === 1 && !isTyping && (
          <div className="mt-6">
            <p className="text-sm text-[var(--aion-gray-600)] mb-3 text-center">
              أو اختر أحد الاقتراحات:
            </p>
            <div className="grid grid-cols-2 gap-2">
              {quickSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSendMessage(suggestion.text)}
                  className="flex items-center gap-2 bg-white p-3 rounded-xl text-sm font-semibold text-[var(--aion-navy)] transition-all active:scale-95"
                  style={{ boxShadow: 'var(--aion-shadow-sm)' }}
                >
                  <suggestion.icon className="w-4 h-4 text-[var(--aion-green)]" />
                  <span>{suggestion.text}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        
        {/* زر عرض النتائج */}
        {messages.length > 2 && !isTyping && (
          <div className="mt-6">
            <button
              onClick={() => onNavigate("search")}
              className="w-full bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] text-white py-4 rounded-2xl font-bold transition-all active:scale-95"
              style={{ boxShadow: 'var(--aion-shadow-lg)' }}
            >
              عرض نتائج البحث (23 عقار) 🔍
            </button>
          </div>
        )}
      </div>
      
      {/* حقل الإدخال */}
      <div className="flex-shrink-0 bg-white border-t border-[var(--aion-gray-200)] px-5 py-4">
        <div className="max-w-md mx-auto">
          <div className="flex items-end gap-2">
            <div className="flex-1 bg-[var(--aion-gray-100)] rounded-2xl px-4 py-3">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSendMessage();
                  }
                }}
                placeholder="اكتب رسالتك..."
                className="w-full bg-transparent outline-none text-[var(--aion-gray-800)] placeholder:text-[var(--aion-gray-500)]"
              />
            </div>
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputValue.trim()}
              className={`p-3 rounded-xl transition-all ${
                inputValue.trim()
                  ? 'bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] text-white active:scale-95'
                  : 'bg-[var(--aion-gray-200)] text-[var(--aion-gray-400)]'
              }`}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
