import { useState } from "react";
import { Calculator, Sparkles, ChevronDown } from "lucide-react";

// Evaluation Assistant Widget Component
export function EvaluationAssistantWidget({ 
  tier, 
  isDark 
}: { 
  tier: string; 
  isDark: boolean;
}) {
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    region: "",
    city: "",
    neighborhood: "",
    propertyType: "",
    classification: "",
    area: ""
  });

  return (
    <div className={`rounded-2xl border overflow-hidden ${
      isDark ? "bg-white/10 border-white/20" : "bg-white border-gray-200"
    }`}>
      {/* Header */}
      <div className={`p-4 border-b ${isDark ? "border-white/10" : "border-gray-200"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Calculator className={`w-5 h-5 ${isDark ? "text-cyan-400" : "text-blue-600"}`} />
            <h3 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              مساعد التقييم
            </h3>
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`p-1.5 rounded-lg transition-all ${
              isDark ? "hover:bg-white/10" : "hover:bg-gray-100"
            }`}
          >
            <ChevronDown 
              className={`w-4 h-4 transition-transform ${
                showFilters ? "rotate-180" : ""
              } ${isDark ? "text-gray-400" : "text-gray-600"}`} 
            />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Filters Row - Single Row Layout */}
        {showFilters && (
          <div className="mb-4 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {/* Region */}
              <select
                value={filters.region}
                onChange={(e) => setFilters({...filters, region: e.target.value})}
                className={`px-3 py-2 rounded-lg text-xs font-bold ${
                  isDark 
                    ? "bg-white/10 border border-white/20 text-white focus:border-cyan-500" 
                    : "bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500"
                } outline-none transition-colors`}
              >
                <option value="">المنطقة</option>
                <option value="riyadh">الرياض</option>
                <option value="jeddah">جدة</option>
                <option value="dammam">الدمام</option>
              </select>

              {/* City */}
              <select
                value={filters.city}
                onChange={(e) => setFilters({...filters, city: e.target.value})}
                className={`px-3 py-2 rounded-lg text-xs font-bold ${
                  isDark 
                    ? "bg-white/10 border border-white/20 text-white focus:border-cyan-500" 
                    : "bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500"
                } outline-none transition-colors`}
              >
                <option value="">المدينة</option>
                <option value="riyadh">الرياض</option>
                <option value="khobar">الخبر</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Neighborhood */}
              <select
                value={filters.neighborhood}
                onChange={(e) => setFilters({...filters, neighborhood: e.target.value})}
                className={`px-3 py-2 rounded-lg text-xs font-bold ${
                  isDark 
                    ? "bg-white/10 border border-white/20 text-white focus:border-cyan-500" 
                    : "bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500"
                } outline-none transition-colors`}
              >
                <option value="">الحي</option>
                <option value="malqa">الملقا</option>
                <option value="olaya">العليا</option>
                <option value="narjis">النرجس</option>
              </select>

              {/* Property Type */}
              <select
                value={filters.propertyType}
                onChange={(e) => setFilters({...filters, propertyType: e.target.value})}
                className={`px-3 py-2 rounded-lg text-xs font-bold ${
                  isDark 
                    ? "bg-white/10 border border-white/20 text-white focus:border-cyan-500" 
                    : "bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500"
                } outline-none transition-colors`}
              >
                <option value="">نوع العقار</option>
                <option value="villa">فيلا</option>
                <option value="land">أرض</option>
                <option value="apartment">شقة</option>
                <option value="all">جميع الأنواع</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Classification */}
              <select
                value={filters.classification}
                onChange={(e) => setFilters({...filters, classification: e.target.value})}
                className={`px-3 py-2 rounded-lg text-xs font-bold ${
                  isDark 
                    ? "bg-white/10 border border-white/20 text-white focus:border-cyan-500" 
                    : "bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500"
                } outline-none transition-colors`}
              >
                <option value="">التصنيف</option>
                <option value="residential">سكني</option>
                <option value="commercial">تجاري</option>
                <option value="agricultural">زراعي</option>
              </select>

              {/* Area */}
              <input
                type="number"
                value={filters.area}
                onChange={(e) => setFilters({...filters, area: e.target.value})}
                placeholder="المساحة (م²)"
                className={`px-3 py-2 rounded-lg text-xs font-bold ${
                  isDark 
                    ? "bg-white/10 border border-white/20 text-white placeholder:text-gray-500 focus:border-cyan-500" 
                    : "bg-gray-50 border border-gray-200 text-gray-900 placeholder:text-gray-500 focus:border-blue-500"
                } outline-none transition-colors`}
              />
            </div>
          </div>
        )}

        {/* AI Evaluate Button */}
        <button
          className={`w-full py-3 rounded-lg font-bold text-sm transition-all ${
            isDark
              ? "bg-gradient-to-r from-cyan-500 to-purple-600 text-white hover:shadow-lg hover:shadow-cyan-500/50"
              : "bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:shadow-lg"
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span>قيّم بذكاء الاصطناعي</span>
          </div>
        </button>

        {/* Result Preview */}
        {filters.neighborhood && (
          <div className={`mt-4 p-4 rounded-lg ${
            isDark ? "bg-gradient-to-r from-emerald-500/20 to-cyan-500/20" : "bg-gradient-to-r from-emerald-50 to-cyan-50"
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <Calculator className={`w-5 h-5 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
              <span className={`text-sm font-bold ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>
                تقييم تقريبي
              </span>
            </div>
            <div className={`text-2xl font-black ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>
              1.2M - 1.5M ر.س
            </div>
            <div className={`text-xs mt-1 ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              بناءً على معايير السوق الحالية
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Smart Matching Widget for Seeker
export function SeekerSmartMatchingWidget({ 
  tier, 
  isDark 
}: { 
  tier: string; 
  isDark: boolean;
}) {
  const [preferences, setPreferences] = useState("");
  const [savedPreferences, setSavedPreferences] = useState(false);

  const handleSave = () => {
    if (preferences.trim()) {
      setSavedPreferences(true);
    }
  };

  const isVIP = tier === "vip";

  return (
    <div className={`rounded-2xl border overflow-hidden ${
      isVIP 
        ? (isDark ? "bg-white/10 border-white/20" : "bg-white border-gray-200")
        : (isDark ? "bg-white/5 border-white/10 opacity-60" : "bg-gray-100 border-gray-200 opacity-60")
    }`}>
      {/* Header */}
      <div className={`p-4 border-b ${isDark ? "border-white/10" : "border-gray-200"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Sparkles className={`w-5 h-5 ${isVIP ? (isDark ? "text-cyan-400" : "text-blue-600") : (isDark ? "text-gray-600" : "text-gray-400")}`} />
            <h3 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              مساعد المطابقة الذكية
            </h3>
          </div>
          {!isVIP && (
            <span className={`text-xs px-2 py-1 rounded-full ${
              isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"
            }`}>
              VIP
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className={`p-4 ${!isVIP ? "blur-sm pointer-events-none" : ""}`}>
        {isVIP && !savedPreferences && (
          <div className="space-y-3">
            <p className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              أخبر AI عن العقار المثالي لك:
            </p>
            <textarea
              value={preferences}
              onChange={(e) => setPreferences(e.target.value)}
              placeholder="مثال: أبحث عن فيلا في الملقا، 4 غرف نوم، حديقة كبيرة، قريبة من المدارس، ميزانية 1.5M..."
              rows={4}
              className={`w-full px-3 py-2 rounded-lg text-xs ${
                isDark 
                  ? "bg-white/10 border border-white/20 text-white placeholder:text-gray-500 focus:border-cyan-500" 
                  : "bg-gray-50 border border-gray-200 text-gray-900 placeholder:text-gray-500 focus:border-blue-500"
              } outline-none transition-colors resize-none`}
            />
            <button
              onClick={handleSave}
              className={`w-full py-2.5 rounded-lg font-bold text-xs transition-all ${
                isDark
                  ? "bg-gradient-to-r from-purple-500 to-cyan-600 text-white hover:shadow-lg hover:shadow-purple-500/50"
                  : "bg-gradient-to-r from-purple-600 to-cyan-600 text-white hover:shadow-lg"
              }`}
            >
              حفظ التفضيلات والبحث
            </button>
          </div>
        )}

        {isVIP && savedPreferences && (
          <div className="space-y-3">
            <div className={`p-3 rounded-lg border ${
              isDark ? "bg-emerald-500/10 border-emerald-500/30" : "bg-emerald-50 border-emerald-200"
            }`}>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className={`w-4 h-4 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                <span className={`text-xs font-bold ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>
                  تم حفظ تفضيلاتك
                </span>
              </div>
            </div>

            {/* Matching Properties */}
            <div className="space-y-2">
              <p className={`text-xs font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                العقارات المطابقة (3):
              </p>
              
              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                    فيلا الملقا الفاخرة
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700"
                  }`}>
                    95% تطابق
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  4 غرف • 500م² • 1.2M ر.س
                </div>
              </div>

              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                    فيلا الملقا الحديثة
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    isDark ? "bg-cyan-500/20 text-cyan-400" : "bg-cyan-100 text-cyan-700"
                  }`}>
                    88% تطابق
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  4 غرف • 450م² • 1.4M ر.س
                </div>
              </div>

              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                    فيلا النرجس المميزة
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"
                  }`}>
                    82% تطابق
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  5 غرف • 550م² • 1.6M ر.س
                </div>
              </div>
            </div>

            <button
              onClick={() => setSavedPreferences(false)}
              className={`w-full py-2 rounded-lg font-bold text-xs transition-all ${
                isDark
                  ? "bg-white/10 text-gray-300 hover:bg-white/20"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              تعديل التفضيلات
            </button>
          </div>
        )}
      </div>

      {/* Lock Overlay for non-VIP */}
      {!isVIP && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[2px]">
          <div className={`text-center p-6 rounded-2xl ${
            isDark ? "bg-gray-900/90" : "bg-white/90"
          } border ${
            isDark ? "border-white/20" : "border-gray-300"
          } backdrop-blur-xl shadow-2xl`}>
            <Sparkles className={`w-12 h-12 mx-auto mb-3 ${isDark ? "text-purple-400" : "text-purple-500"}`} />
            <p className={`text-sm font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
              ميزة VIP - AI يجد لك العقار المثالي
            </p>
            <div className={`mt-3 px-4 py-2 rounded-full text-xs font-bold ${
              isDark 
                ? "bg-gradient-to-r from-purple-500 to-cyan-600 text-white shadow-lg" 
                : "bg-gradient-to-r from-purple-600 to-cyan-600 text-white shadow-lg"
            }`}>
              ترقية إلى VIP Hunter
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Smart Matching Widget for Developer
export function DeveloperSmartMatchingWidget({ 
  tier, 
  isDark 
}: { 
  tier: string; 
  isDark: boolean;
}) {
  const [selectedProject, setSelectedProject] = useState("");
  const [showMatches, setShowMatches] = useState(false);

  const handleProjectSelect = (project: string) => {
    setSelectedProject(project);
    setShowMatches(true);
  };

  const isActive = tier !== "starter";

  return (
    <div className={`rounded-2xl border overflow-hidden ${
      isActive 
        ? (isDark ? "bg-white/10 border-white/20" : "bg-white border-gray-200")
        : (isDark ? "bg-white/5 border-white/10 opacity-60" : "bg-gray-100 border-gray-200 opacity-60")
    }`}>
      {/* Header */}
      <div className={`p-4 border-b ${isDark ? "border-white/10" : "border-gray-200"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Sparkles className={`w-5 h-5 ${isActive ? (isDark ? "text-cyan-400" : "text-blue-600") : (isDark ? "text-gray-600" : "text-gray-400")}`} />
            <h3 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              مساعد المطابقة
            </h3>
          </div>
          {!isActive && (
            <span className={`text-xs px-2 py-1 rounded-full ${
              isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700"
            }`}>
              Business+
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className={`p-4 ${!isActive ? "blur-sm pointer-events-none" : ""}`}>
        {isActive && !showMatches && (
          <div className="space-y-3">
            <p className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              اختر مشروعك لإيجاد الباحثين المطابقين:
            </p>
            
            <div className="space-y-2">
              <button
                onClick={() => handleProjectSelect("narjis")}
                className={`w-full p-3 rounded-lg text-right transition-all ${
                  isDark 
                    ? "bg-white/5 hover:bg-white/10" 
                    : "bg-gray-50 hover:bg-gray-100"
                }`}
              >
                <div className={`text-sm font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
                  مشروع النرجس السكني
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  48 وحدة • 22 متاح
                </div>
              </button>

              {tier !== "starter" && (
                <>
                  <button
                    onClick={() => handleProjectSelect("olaya")}
                    className={`w-full p-3 rounded-lg text-right transition-all ${
                      isDark 
                        ? "bg-white/5 hover:bg-white/10" 
                        : "bg-gray-50 hover:bg-gray-100"
                    }`}
                  >
                    <div className={`text-sm font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
                      أبراج العليا التجارية
                    </div>
                    <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                      32 وحدة • 18 متاح
                    </div>
                  </button>

                  <button
                    onClick={() => handleProjectSelect("malqa")}
                    className={`w-full p-3 rounded-lg text-right transition-all ${
                      isDark 
                        ? "bg-white/5 hover:bg-white/10" 
                        : "bg-gray-50 hover:bg-gray-100"
                    }`}
                  >
                    <div className={`text-sm font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
                      فلل الملقا الفاخرة
                    </div>
                    <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                      12 وحدة • 8 متاح
                    </div>
                  </button>
                </>
              )}
            </div>
          </div>
        )}

        {isActive && showMatches && (
          <div className="space-y-3">
            <div className={`p-3 rounded-lg border ${
              isDark ? "bg-emerald-500/10 border-emerald-500/30" : "bg-emerald-50 border-emerald-200"
            }`}>
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className={`w-4 h-4 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                <span className={`text-xs font-bold ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>
                  وجدنا 12 باحث مطابق
                </span>
              </div>
            </div>

            {/* Matched Seekers */}
            <div className="space-y-2">
              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                    أحمد الباحث
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700"
                  }`}>
                    95% تطابق
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  يبحث عن: شقة 3 غرف • ميزانية 800K
                </div>
              </div>

              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                    فاطمة السعيد
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    isDark ? "bg-cyan-500/20 text-cyan-400" : "bg-cyan-100 text-cyan-700"
                  }`}>
                    90% تطابق
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  يبحث عن: شقة 2 غرف • ميزانية 650K
                </div>
              </div>

              <div className={`p-3 rounded-lg ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                    خالد المحترف
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"
                  }`}>
                    85% تطابق
                  </span>
                </div>
                <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  يبحث عن: شقة 4 غرف • ميزانية 900K
                </div>
              </div>
            </div>

            {/* Send Offer Button */}
            <button
              className={`w-full py-2.5 rounded-lg font-bold text-xs transition-all ${
                isDark
                  ? "bg-gradient-to-r from-cyan-500 to-purple-600 text-white hover:shadow-lg hover:shadow-cyan-500/50"
                  : "bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:shadow-lg"
              }`}
            >
              إرسال لكل المطابقين (12)
            </button>

            <button
              onClick={() => setShowMatches(false)}
              className={`w-full py-2 rounded-lg font-bold text-xs transition-all ${
                isDark
                  ? "bg-white/10 text-gray-300 hover:bg-white/20"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              اختر مشروع آخر
            </button>
          </div>
        )}
      </div>

      {/* Lock Overlay for starter tier */}
      {!isActive && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[2px]">
          <div className={`text-center p-6 rounded-2xl ${
            isDark ? "bg-gray-900/90" : "bg-white/90"
          } border ${
            isDark ? "border-white/20" : "border-gray-300"
          } backdrop-blur-xl shadow-2xl`}>
            <Sparkles className={`w-12 h-12 mx-auto mb-3 ${isDark ? "text-cyan-400" : "text-cyan-500"}`} />
            <p className={`text-sm font-bold mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
              ميزة Business - اعثر على الباحثين المطابقين
            </p>
            <div className={`mt-3 px-4 py-2 rounded-full text-xs font-bold ${
              isDark 
                ? "bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-lg" 
                : "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
            }`}>
              ترقية إلى Business
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
