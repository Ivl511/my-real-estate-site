import { ArrowRight, Sparkles, MapPin, Maximize, Phone, MessageCircle, Share2, Heart } from "lucide-react";

interface PropertyDetailsProps {
  onBack: () => void;
}

const propertyImages = [
  "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800",
  "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800",
  "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800",
];

export function PropertyDetails({ onBack }: PropertyDetailsProps) {
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Image Gallery */}
      <div className="relative">
        <div className="w-full h-72 overflow-hidden">
          <img
            src={propertyImages[0]}
            alt="Property"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Top Actions */}
        <div className="absolute top-4 right-4 left-4 flex items-center justify-between">
          <div className="flex gap-2">
            <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg">
              <Share2 className="w-5 h-5 text-gray-700" />
            </button>
            <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg">
              <Heart className="w-5 h-5 text-gray-700" />
            </button>
          </div>
          <button
            onClick={onBack}
            className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg"
          >
            <ArrowRight className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        {/* Image Count */}
        <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-sm rounded-full px-3 py-1.5">
          <span className="text-white text-xs font-semibold">1 / 3</span>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6">
          {/* Price & Title */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">للبيع</span>
              <h1 className="text-3xl font-bold text-blue-900">2,500,000 ريال</h1>
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">فيلا فاخرة - حي الملقا</h2>
            <div className="flex items-center gap-2 text-gray-600">
              <MapPin className="w-4 h-4" />
              <span className="text-sm">الرياض، حي الملقا، شارع التخصصي</span>
            </div>
          </div>

          {/* AI Insight Banner */}
          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-4 mb-6 shadow-lg">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 text-right">
                <h3 className="text-white font-bold mb-1">رأي الذكاء الاصطناعي</h3>
                <p className="text-green-50 text-sm leading-relaxed">
                  هذا العقار يمثل فرصة استثمارية ممتازة. السعر مناسب مقارنة بالسوق بنسبة 8% أقل من المتوسط. المنطقة شهدت نمواً عمرانياً بنسبة 12% خلال العام الماضي. معدل العائد الاستثماري المتوقع: 7.5% سنوياً.
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <div className="bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                    <span className="text-white text-xs font-bold">تقييم AI: 92%</span>
                  </div>
                  <div className="bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                    <span className="text-white text-xs font-bold">سعر مناسب ✓</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Property Details */}
          <div className="bg-gray-50 rounded-2xl p-4 mb-6">
            <h3 className="font-bold text-gray-900 mb-4">تفاصيل العقار</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-right">
                <p className="text-gray-500 text-sm mb-1">المساحة</p>
                <p className="font-bold text-gray-900">450 م²</p>
              </div>
              <div className="text-right">
                <p className="text-gray-500 text-sm mb-1">الغرف</p>
                <p className="font-bold text-gray-900">5 غرف</p>
              </div>
              <div className="text-right">
                <p className="text-gray-500 text-sm mb-1">دورات المياه</p>
                <p className="font-bold text-gray-900">4</p>
              </div>
              <div className="text-right">
                <p className="text-gray-500 text-sm mb-1">العمر</p>
                <p className="font-bold text-gray-900">3 سنوات</p>
              </div>
              <div className="text-right">
                <p className="text-gray-500 text-sm mb-1">الواجهة</p>
                <p className="font-bold text-gray-900">شمالية</p>
              </div>
              <div className="text-right">
                <p className="text-gray-500 text-sm mb-1">نوع العقار</p>
                <p className="font-bold text-gray-900">فيلا</p>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="font-bold text-gray-900 mb-3">الوصف</h3>
            <p className="text-gray-600 text-sm leading-relaxed text-right">
              فيلا فاخرة في موقع مميز بحي الملقا، تتميز بتصميم عصري وتشطيبات راقية. تحتوي على 5 غرف نوم رئيسية مع دورات مياه خاصة، مجلس رجال، مجلس نساء، غرفة طعام واسعة، مطبخ مجهز بالكامل، حديقة خارجية، موقف سيارات مظلل لـ 4 سيارات. المنطقة هادئة وقريبة من جميع الخدمات.
            </p>
          </div>

          {/* Amenities */}
          <div className="mb-6">
            <h3 className="font-bold text-gray-900 mb-3">المميزات</h3>
            <div className="flex flex-wrap gap-2">
              {["مسبح خاص", "حديقة", "مصعد", "نظام أمني", "تكييف مركزي", "مطبخ راقي"].map((amenity) => (
                <span key={amenity} className="bg-blue-50 text-blue-900 px-3 py-1.5 rounded-full text-xs font-semibold">
                  {amenity}
                </span>
              ))}
            </div>
          </div>

          {/* Location */}
          <div className="mb-6">
            <h3 className="font-bold text-gray-900 mb-3">الموقع</h3>
            <div className="bg-gray-200 rounded-2xl h-48 flex items-center justify-center">
              <MapPin className="w-12 h-12 text-gray-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="border-t bg-white px-6 py-4">
        <div className="flex gap-3">
          <button className="flex-1 bg-gradient-to-r from-blue-900 to-blue-800 text-white rounded-2xl py-4 flex items-center justify-center gap-2 font-bold shadow-lg hover:shadow-xl transition-all">
            <Phone className="w-5 h-5" />
            <span>اتصال</span>
          </button>
          <button className="flex-1 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-2xl py-4 flex items-center justify-center gap-2 font-bold shadow-lg hover:shadow-xl transition-all">
            <MessageCircle className="w-5 h-5" />
            <span>محادثة</span>
          </button>
        </div>
      </div>
    </div>
  );
}
