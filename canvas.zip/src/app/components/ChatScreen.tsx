import { useState, useRef, useEffect } from "react";
import { ArrowRight, Send, Sparkles } from "lucide-react";

interface ChatScreenProps {
  onBack: () => void;
}

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: string;
}

const initialMessages: Message[] = [
  {
    id: "1",
    text: "مرحباً بك في أيون العقاري! 👋\n\nأنا مساعدك الذكي المتخصص في العقارات. يمكنني مساعدتك في:\n\n🏠 البحث عن عقارات\n💰 تقييم الأسعار\n📊 تحليل فرص الاستثمار\n📍 معلومات عن الأحياء\n\nكيف يمكنني مساعدتك اليوم؟",
    isUser: false,
    timestamp: "الآن",
  },
];

export function ChatScreen({ onBack }: ChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isUser: true,
      timestamp: "الآن",
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputText("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "بالتأكيد! دعني أساعدك في البحث عن العقار المناسب.\n\n🔍 جاري البحث في قاعدة البيانات...\n\nوجدت عدة خيارات ممتازة تطابق معاييرك. هل تريد أن أعرض لك:\n\n1️⃣ عقارات سكنية في شمال الرياض\n2️⃣ فرص استثمارية في المناطق الواعدة\n3️⃣ عقارات ضمن ميزانية محددة\n\nما الذي يهمك أكثر؟",
        isUser: false,
        timestamp: "الآن",
      };
      setMessages((prev) => [...prev, aiResponse]);
      setIsTyping(false);
    }, 2000);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-800 px-4 py-4 flex items-center gap-3 shadow-lg">
        <button
          onClick={onBack}
          className="p-2 hover:bg-blue-800 rounded-lg transition-colors"
        >
          <ArrowRight className="w-5 h-5 text-white" />
        </button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="text-right">
            <h2 className="text-white font-bold">مساعد أيون الذكي</h2>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-200 text-xs">متصل الآن</span>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isUser ? "justify-start" : "justify-end"}`}
          >
            <div className={`max-w-[80%] ${message.isUser ? "order-2" : "order-1"}`}>
              {!message.isUser && (
                <div className="flex items-center gap-2 mb-1 justify-end">
                  <span className="text-xs text-gray-500">أيون AI</span>
                  <Sparkles className="w-3 h-3 text-green-600" />
                </div>
              )}
              <div
                className={`rounded-2xl px-4 py-3 ${
                  message.isUser
                    ? "bg-blue-900 text-white rounded-tr-sm"
                    : "bg-gradient-to-br from-green-50 to-green-100 text-gray-900 rounded-tl-sm border border-green-200"
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.text}</p>
              </div>
              <span className="text-xs text-gray-400 mt-1 block">{message.timestamp}</span>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-end">
            <div className="max-w-[80%]">
              <div className="flex items-center gap-2 mb-1 justify-end">
                <span className="text-xs text-gray-500">أيون AI</span>
                <Sparkles className="w-3 h-3 text-green-600" />
              </div>
              <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl rounded-tl-sm px-4 py-3 border border-green-200">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-green-600 rounded-full animate-bounce"></span>
                  <span className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></span>
                  <span className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></span>
                </div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t bg-white px-4 py-3">
        <div className="flex items-center gap-2">
          <button
            onClick={handleSend}
            disabled={!inputText.trim()}
            className={`p-3 rounded-full transition-all ${
              inputText.trim()
                ? "bg-gradient-to-r from-blue-900 to-blue-800 hover:shadow-lg"
                : "bg-gray-300"
            }`}
          >
            <Send className="w-5 h-5 text-white" />
          </button>
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSend()}
            placeholder="اكتب رسالتك هنا..."
            className="flex-1 bg-gray-100 rounded-2xl px-4 py-3 outline-none text-right text-sm"
          />
        </div>
      </div>
    </div>
  );
}
