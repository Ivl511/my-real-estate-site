export function TypingIndicator() {
  return (
    <div className="flex justify-start mb-4 px-4">
      <div className="flex flex-col max-w-[75%] items-start">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
            <span className="text-white text-xs font-medium">AI</span>
          </div>
          <span className="text-xs text-gray-500">AI Assistant</span>
        </div>
        <div className="rounded-2xl rounded-tl-sm px-4 py-3 bg-gray-100">
          <div className="flex gap-1">
            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
          </div>
        </div>
      </div>
    </div>
  );
}
