import { Home, MessageSquare, Search, User, Briefcase, X } from "lucide-react";

interface NavigationMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (screen: string) => void;
  currentMode: string;
}

export function NavigationMenu({ isOpen, onClose, onNavigate, currentMode }: NavigationMenuProps) {
  if (!isOpen) return null;
  
  const menuItems = [
    { id: "home", icon: Home, label: "الرئيسية", description: "العودة للصفحة الرئيسية" },
    { id: "chat", icon: MessageSquare, label: "محادثة AI", description: "تحدث مع مساعد أيون" },
    { id: "search", icon: Search, label: "نتائج البحث", description: "تصفح العقارات" },
  ];
  
  const userModes = [
    { id: "buyer", icon: User, label: "وضع المشتري", color: "text-blue-600" },
    { id: "owner", icon: Home, label: "وضع المالك", color: "text-[var(--aion-green)]" },
    { id: "broker", icon: Briefcase, label: "وضع الوسيط", color: "text-purple-600" },
  ];
  
  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40 animate-fade-in"
        onClick={onClose}
      />
      
      {/* Menu */}
      <div className="fixed right-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white z-50 animate-slide-in" style={{ boxShadow: 'var(--aion-shadow-xl)' }}>
        {/* الهيدر */}
        <div className="bg-gradient-to-br from-[var(--aion-navy)] to-[var(--aion-navy-light)] text-white p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] flex items-center justify-center font-bold">
                AI
              </div>
              <div>
                <h2 className="text-lg font-bold">أيون العقاري</h2>
                <p className="text-xs text-white/80">مساعدك الذكي</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="text-sm text-white/90 mb-1">مرحباً بك،</div>
            <div className="font-bold">أحمد العقاري</div>
          </div>
        </div>
        
        {/* القائمة الرئيسية */}
        <div className="p-4">
          <div className="mb-6">
            <h3 className="text-xs font-bold text-[var(--aion-gray-500)] mb-3 px-2">التنقل</h3>
            <div className="space-y-1">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    onClose();
                  }}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-[var(--aion-gray-100)] transition-colors text-right"
                >
                  <div className="w-10 h-10 rounded-lg bg-[var(--aion-navy)]/5 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-[var(--aion-navy)]" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-[var(--aion-navy)]">{item.label}</div>
                    <div className="text-xs text-[var(--aion-gray-600)]">{item.description}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
          
          {/* أوضاع المستخدم */}
          <div className="border-t border-[var(--aion-gray-200)] pt-4">
            <h3 className="text-xs font-bold text-[var(--aion-gray-500)] mb-3 px-2">جرب الأوضاع المختلفة</h3>
            <div className="space-y-2">
              {userModes.map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => {
                    onNavigate(mode.id === "buyer" ? "home" : mode.id);
                    onClose();
                  }}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
                    currentMode === mode.id 
                      ? 'bg-[var(--aion-green)]/10 border-2 border-[var(--aion-green)]' 
                      : 'bg-[var(--aion-gray-50)] border-2 border-transparent'
                  }`}
                >
                  <mode.icon className={`w-5 h-5 ${mode.color}`} />
                  <span className="font-semibold text-[var(--aion-navy)]">{mode.label}</span>
                  {currentMode === mode.id && (
                    <span className="mr-auto bg-[var(--aion-green)] text-white text-xs px-2 py-0.5 rounded-full">نشط</span>
                  )}
                </button>
              ))}
            </div>
          </div>
          
          {/* معلومات إضافية */}
          <div className="mt-6 bg-gradient-to-br from-[var(--aion-green)]/5 to-[var(--aion-green)]/10 rounded-xl p-4 border border-[var(--aion-green)]/20">
            <div className="text-sm font-bold text-[var(--aion-navy)] mb-1">💡 نصيحة</div>
            <p className="text-xs text-[var(--aion-gray-700)] leading-relaxed">
              جرب "وضع الوسيط" لترى كيف يساعد أيون الوسطاء في إدارة عملائهم وعقاراتهم بذكاء!
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
