import { motion } from "motion/react";
import { ArrowRight, Heart } from "lucide-react";

interface FavoritesScreenProps {
  onBack: () => void;
}

export function FavoritesScreen({ onBack }: FavoritesScreenProps) {
  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0A0E1A] to-[#0D1221]">
      <div className="px-5 pt-12 pb-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="w-10 h-10 glass rounded-xl flex items-center justify-center">
            <ArrowRight className="w-5 h-5 text-white" />
          </button>
          <h2 className="text-xl font-black text-white flex-1 text-right">Favorites</h2>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center">
        <div className="text-center px-8">
          <div className="w-20 h-20 glass rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Heart className="w-10 h-10 text-pink-500" />
          </div>
          <h3 className="text-lg font-black text-white mb-2">No Favorites Yet</h3>
          <p className="text-white/60 text-sm">Start adding properties to your favorites</p>
        </div>
      </div>
    </div>
  );
}
