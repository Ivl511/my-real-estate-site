import { motion, AnimatePresence } from "motion/react";
import { Sparkles, X, Search, ShieldCheck, DollarSign, Zap, MessageSquare, Lock, TrendingUp, BarChart3, Users, EyeOff, PenTool, Package, Target, Megaphone, Mic, Handshake, Database } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";
import type { Screen } from "../../App";
import { useState, useRef } from "react";

interface FloatingAIONProps {
  onNavigate?: (screen: Screen) => void;
  currentPersona?: "seeker" | "broker" | "developer" | "landlord";
  tier?: string;
  brokerType?: "individual" | "corporate";
}

type InternalPersona = "seeker" | "broker" | "developer" | "landlord";
type SeekerTier = "basic" | "smart";
type LandlordTier = "basic" | "professional";
type BrokerTier = "basic" | "advanced" | "elite";
type DevTier = "basic" | "advanced" | "growth";
type BrokerType = "individual" | "corporate";

interface AgentFeature {
  icon: any;
  nameAr: string;
  agentName: string;
  desc: string;
  locked?: boolean;
  exclusive?: boolean;
  color: string;
}

// ─── Feature Definitions ─────────────────────────────────────────────────────

function getFeatures(
  persona: InternalPersona,
  seekerTier: SeekerTier,
  landlordTier: LandlordTier,
  brokerTier: BrokerTier,
  devTier: DevTier,
  brokerType: BrokerType
): AgentFeature[] {
  if (persona === "seeker") {
    const isSmart = seekerTier === "smart";
    return [
      { icon: Search, agentName: "SearchAgent", nameAr: "الباحث الذكي", desc: "يبحث بالكلام العامي: \"ابي فيلا شرحه شمال الرياض\" ويفهم الطلب بدقة", locked: false, color: "purple" },
      { icon: Target, agentName: "MatchingAgent", nameAr: "المطابق", desc: "تنبيهات فورية وحصرية إذا نزل عقار يطابق ذوقه — سُحبت من الوسطاء وأُعطيت له", locked: !isSmart, exclusive: true, color: "emerald" },
      { icon: ShieldCheck, agentName: "ValuationAgent", nameAr: "المقيّم", desc: "يعطيه السعر العادل للعقار عشان ما ينغش", locked: !isSmart, color: "cyan" },
      { icon: Mic, agentName: "DraftAgent", nameAr: "المحادثة", desc: "يقدر يكلم التطبيق صوتاً وكتابةً", locked: false, color: "blue" },
    ];
  }

  if (persona === "landlord") {
    const isPro = landlordTier === "professional";
    return [
      { icon: PenTool, agentName: "EditorAgent", nameAr: "المحرر", desc: "يكتب وصف الإعلان احترافياً ويحسّن الصور تلقائياً", locked: !isPro, color: "pink" },
      { icon: DollarSign, agentName: "ValuationAgent", nameAr: "المقيّم", desc: "يقول له كم يسوى عقاره في السوق حالياً", locked: !isPro, color: "emerald" },
      { icon: EyeOff, agentName: "GuardianAgent", nameAr: "الحارس", desc: "يحمي رقمه وبياناته من الإزعاج ويخفيها عن العامة", locked: false, color: "blue" },
      { icon: Zap, agentName: "Auto-Reply", nameAr: "الرد الآلي", desc: "ردود آلية أساسية على المستفسرين", locked: false, color: "purple" },
    ];
  }

  if (persona === "developer") {
    const isAdv = devTier === "advanced" || devTier === "growth";
    const isGrowth = devTier === "growth";
    return [
      { icon: Target, agentName: "MatchingAgent", nameAr: "المطابق", desc: "الأقوى؛ النظام يجلب المشترين الجاهزين ويوصلهم بالمشروع مباشرةً", locked: false, exclusive: true, color: "blue" },
      { icon: Handshake, agentName: "NegotiatorAgent", nameAr: "المفاوض", desc: "يتفاوض على السعر، يفرز العروض الجادة، ويجدول مواعيد الزيارة (بدون كتابة عقود)", locked: !isAdv, color: "purple" },
      { icon: Package, agentName: "InventoryAgent", nameAr: "مدير المخزون", desc: "يدير آلاف الوحدات ويحدّث حالتها (مباع/متاح) بضغطة زر", locked: false, color: "red" },
      { icon: TrendingUp, agentName: "GrowthAgent & MarketingAgent", nameAr: "النمو والتسويق", desc: "يراقب المبيعات ويسوّي حملات تسويقية آلية", locked: !isGrowth, color: "emerald" },
      { icon: BarChart3, agentName: "AnalystAgent", nameAr: "المحلل", desc: "يعطيه تحليل دقيق عن المنطقة وسكانها والطلب فيها", locked: !isAdv, color: "indigo" },
    ];
  }

  // broker
  const isAdv = brokerTier === "advanced" || brokerTier === "elite";
  const isCorp = brokerType === "corporate";
  const features: AgentFeature[] = [
    { icon: Megaphone, agentName: "Marketer Role", nameAr: "دور المسوّق", desc: "ميزته الرئيسية: زر تسويق على عقارات المطورين لضمان سعيه (2.5%)", locked: false, color: "amber" },
    { icon: MessageSquare, agentName: "NegotiatorAgent (مساعد)", nameAr: "السكرتير", desc: "يرد على الأسئلة العامة ويحجز المواعيد فقط — ممنوع من التفاوض أو المطابقة", locked: !isAdv, color: "cyan" },
    { icon: DollarSign, agentName: "ValuationAgent", nameAr: "التقييم", desc: "يساعده في تقييم العقارات التي يسوّقها", locked: false, color: "emerald" },
    { icon: PenTool, agentName: "EditorAgent", nameAr: "تحرير المحتوى", desc: "يحسّن عرض العقارات التي يسوّقها", locked: false, color: "pink" },
  ];
  if (isCorp) {
    features.push(
      { icon: Users, agentName: "Team Management", nameAr: "إدارة الفريق", desc: "لوحة تحكم لإدارة عدة وسطاء تحت سجل المنشأة", locked: false, color: "indigo" },
      { icon: BarChart3, agentName: "Performance Reports", nameAr: "تقارير الأداء", desc: "يشوف مين من الموظفين شغّال صح", locked: false, color: "blue" },
      { icon: Database, agentName: "InventoryAgent", nameAr: "مخزون المنشأة", desc: "لترتيب عقارات المنشأة الداخلية فقط", locked: false, color: "red" }
    );
  }
  return features;
}

function getTierActivationLabel(
  persona: InternalPersona,
  seekerTier: SeekerTier,
  landlordTier: LandlordTier,
  brokerTier: BrokerTier,
  devTier: DevTier
): { label: string; active: boolean } {
  if (persona === "seeker") return seekerTier === "smart" ? { label: "Smart Search مفعّلة ✓", active: true } : { label: "تفعيل باقة Smart Search", active: false };
  if (persona === "landlord") return landlordTier === "professional" ? { label: "Professional مفعّلة ✓", active: true } : { label: "تفعيل باقة Professional", active: false };
  if (persona === "broker") {
    if (brokerTier === "elite") return { label: "Elite مفعّلة ✓", active: true };
    if (brokerTier === "advanced") return { label: "تفعيل باقة Elite", active: false };
    return { label: "تفعيل الباقة", active: false };
  }
  // developer
  if (devTier === "growth") return { label: "Growth مفعّلة ✓", active: true };
  if (devTier === "advanced") return { label: "تفعيل باقة Growth", active: false };
  return { label: "تفعيل الباقة", active: false };
}

// ─── Feature Item ─────────────────────────────────────────────────────────────
const colorMap: Record<string, string> = {
  purple: "text-purple-400 bg-purple-500/20",
  emerald: "text-emerald-400 bg-emerald-500/20",
  cyan: "text-cyan-400 bg-cyan-500/20",
  blue: "text-blue-400 bg-blue-500/20",
  pink: "text-pink-400 bg-pink-500/20",
  amber: "text-amber-400 bg-amber-500/20",
  red: "text-red-400 bg-red-500/20",
  indigo: "text-indigo-400 bg-indigo-500/20",
};

function FeatureItem({ feature, isDark }: { feature: AgentFeature; isDark: boolean }) {
  const Icon = feature.icon;
  const cls = colorMap[feature.color] || colorMap.blue;
  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl border transition-all ${
      feature.locked
        ? "opacity-40 grayscale " + (isDark ? "border-white/5" : "border-gray-100")
        : isDark ? "border-white/8 bg-white/[0.03] hover:bg-white/[0.06]" : "border-gray-100 bg-white hover:bg-gray-50"
    }`}>
      <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${feature.locked ? "bg-gray-500/20 text-gray-500" : cls}`}>
        {feature.locked ? <Lock className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
          <p className={`text-xs font-black ${feature.locked ? "text-gray-500" : isDark ? "text-white/90" : "text-gray-800"}`}>
            {feature.nameAr}
          </p>
          <span className={`text-[8px] opacity-60 ${isDark ? "text-white/40" : "text-gray-400"}`}>{feature.agentName}</span>
          {feature.exclusive && !feature.locked && (
            <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 font-black flex items-center gap-0.5"><Star style={{width:"8px",height:"8px",fill:"currentColor"}} /> حصري</span>
          )}
          {feature.locked && (
            <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 font-black flex items-center gap-0.5"><Lock style={{width:"8px",height:"8px"}} /> مغلق</span>
          )}
        </div>
        <p className="text-[10px] opacity-60 leading-relaxed">{feature.desc}</p>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export function FloatingAION({ onNavigate, currentPersona = "seeker", brokerType: parentBrokerType = "individual" }: FloatingAIONProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [isDragging, setIsDragging] = useState(false);
  const constraintsRef = useRef(null);

  // Internal simulator state — independent from parent
  const [internalPersona, setInternalPersona] = useState<InternalPersona>(currentPersona);
  const [seekerTier, setSeekerTier] = useState<SeekerTier>("basic");
  const [landlordTier, setLandlordTier] = useState<LandlordTier>("basic");
  const [brokerTier, setBrokerTier] = useState<BrokerTier>("basic");
  const [devTier, setDevTier] = useState<DevTier>("basic");
  const [brokerType, setBrokerType] = useState<BrokerType>(parentBrokerType);

  const personaGlow = internalPersona === "seeker" ? "bg-purple-500" : internalPersona === "landlord" ? "bg-emerald-500" : internalPersona === "broker" ? "bg-amber-500" : "bg-blue-600";
  const personaGrad = internalPersona === "seeker" ? "from-purple-500 to-cyan-500" : internalPersona === "landlord" ? "from-emerald-500 to-teal-500" : internalPersona === "broker" ? "from-amber-500 to-orange-500" : "from-blue-600 to-indigo-600";

  return (
    <>
      <div ref={constraintsRef} className="fixed inset-0 pointer-events-none z-[100]" />

      <motion.div
        drag
        dragConstraints={constraintsRef}
        dragElastic={0.1}
        dragMomentum={false}
        onDragStart={() => setIsDragging(true)}
        onDragEnd={() => setIsDragging(false)}
        initial={{ x: 0, y: 0 }}
        className="fixed bottom-8 left-8 z-[101] pointer-events-auto flex flex-col items-start gap-4"
        style={{ touchAction: "none" }}
      >
        {/* ── FAB BUTTON — opens AION Chat ── */}
        <motion.button
          onClick={() => { if (!isDragging) onNavigate?.("aionChat"); }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="relative group w-16 h-16 rounded-full flex items-center justify-center shadow-2xl overflow-visible"
        >
          <div className={`absolute inset-0 rounded-full blur-xl opacity-60 animate-pulse ${personaGlow}`} />
          <div className={`relative w-full h-full rounded-full flex items-center justify-center border-2 z-10 overflow-hidden ${isDark ? "bg-[#1e293b] border-white/20" : "bg-white border-white"}`}>
            <div className={`absolute inset-0 opacity-20 bg-gradient-to-tr ${personaGrad}`} />
            <Sparkles className="w-6 h-6 z-20 animate-pulse" />
          </div>
        </motion.button>
      </motion.div>
    </>
  );
}