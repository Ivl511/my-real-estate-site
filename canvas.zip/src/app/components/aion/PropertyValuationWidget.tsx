import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Award, RefreshCcw, Sparkles } from "lucide-react";

interface PropertyValuationWidgetProps {
  isDark: boolean;
}

export function PropertyValuationWidget({ isDark }: PropertyValuationWidgetProps) {
  const [region, setRegion] = useState("الرياض");
  const [city, setCity] = useState("الرياض");
  const [neighborhood, setNeighborhood] = useState("النرجس");
  const [propType, setPropType] = useState("فيلا");
  const [propClass, setPropClass] = useState("سكني");
  const [area, setArea] = useState("600");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const regions = ["الرياض", "مكة المكرمة", "المنطقة الشرقية"];
  
  const cities: Record<string, string[]> = {
    "الرياض": ["الرياض"],
    "مكة المكرمة": ["جدة", "مكة"],
    "المنطقة الشرقية": ["الدمام", "الخبر"],
  };

  const neighborhoods: Record<string, string[]> = {
    "الرياض": ["النرجس", "الملقا", "حطين", "الياسمين", "العليا"],
    "جدة": ["أبحر الشمالية", "الشاطئ", "الزهراء"],
    "الدمام": ["الشاطئ", "العزيزية"],
    "مكة": ["العزيزية", "جرول"],
    "الخبر": ["الكورنيش", "العقربية"],
  };

  const propertyTypes = ["فيلا", "شقة", "أرض", "عمارة", "دور", "جميع الأنواع"];
  const propertyClasses = ["سكني", "تجاري", "زراعي"];

  const handleValuate = () => {
    setLoading(true);
    setResult(null);
    setTimeout(() => {
      const basePrice = 2800000;
      const typeFactor = propType === "فيلا" ? 1.2 : propType === "أرض" ? 0.8 : 1.0;
      const classFactor = propClass === "تجاري" ? 1.3 : propClass === "زراعي" ? 0.7 : 1.0;
      const estimated = Math.round(basePrice * typeFactor * classFactor / 50000) * 50000;
      const low = Math.round(estimated * 0.92 / 50000) * 50000;
      const high = Math.round(estimated * 1.08 / 50000) * 50000;
      const pricePerSqm = Math.round(estimated / parseInt(area || "600"));
      setResult({ estimated, low, high, pricePerSqm, typeFactor, classFactor });
      setLoading(false);
    }, 2800);
  };

  const fmt = (n: number) => n.toLocaleString("ar-SA");

  return (
    <div className="space-y-5 pb-6">
      {/* AI Badge */}
      <div className={`p-4 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-gradient-to-br from-emerald-900/20 to-teal-900/20 border-emerald-500/25" : "bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200"}`}>
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/30 shrink-0">
          <Award className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>مساعد التقييم العقاري AI</p>
          <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>يحلل سعر السوق، الموقع، ونوع العقار</p>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[9px] font-black text-emerald-400">LIVE</span>
        </div>
      </div>

      {/* Form - Single Row of Filters */}
      <div className="space-y-4">
        <p className={`text-[11px] font-black uppercase tracking-widest ${isDark ? "text-white/30" : "text-gray-400"}`}>فلاتر التقييم</p>

        {/* Row 1: Region → City → District */}
        <div className="grid grid-cols-3 gap-2">
          <div>
            <label className={`block text-[10px] font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>المنطقة</label>
            <select 
              value={region} 
              onChange={(e) => { 
                setRegion(e.target.value); 
                setCity(cities[e.target.value]?.[0] || "");
                setNeighborhood(neighborhoods[cities[e.target.value]?.[0] || ""]?.[0] || "");
              }}
              className={`w-full px-2 py-2 rounded-xl border text-[10px] font-bold outline-none transition-all ${isDark ? "bg-[#151a2d] border-white/8 text-white" : "bg-white border-gray-200 text-gray-900"}`}
            >
              {regions.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          
          <div>
            <label className={`block text-[10px] font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>المدينة</label>
            <select 
              value={city} 
              onChange={(e) => { 
                setCity(e.target.value);
                setNeighborhood(neighborhoods[e.target.value]?.[0] || "");
              }}
              className={`w-full px-2 py-2 rounded-xl border text-[10px] font-bold outline-none transition-all ${isDark ? "bg-[#151a2d] border-white/8 text-white" : "bg-white border-gray-200 text-gray-900"}`}
            >
              {(cities[region] || []).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div>
            <label className={`block text-[10px] font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>الحي</label>
            <select 
              value={neighborhood} 
              onChange={(e) => setNeighborhood(e.target.value)}
              className={`w-full px-2 py-2 rounded-xl border text-[10px] font-bold outline-none transition-all ${isDark ? "bg-[#151a2d] border-white/8 text-white" : "bg-white border-gray-200 text-gray-900"}`}
            >
              {(neighborhoods[city] || []).map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
        </div>

        {/* Row 2: Property Type → Classification → Area */}
        <div className="grid grid-cols-3 gap-2">
          <div>
            <label className={`block text-[10px] font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>نوع العقار</label>
            <select 
              value={propType} 
              onChange={(e) => setPropType(e.target.value)}
              className={`w-full px-2 py-2 rounded-xl border text-[10px] font-bold outline-none transition-all ${isDark ? "bg-[#151a2d] border-white/8 text-white" : "bg-white border-gray-200 text-gray-900"}`}
            >
              {propertyTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div>
            <label className={`block text-[10px] font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>التصنيف</label>
            <select 
              value={propClass} 
              onChange={(e) => setPropClass(e.target.value)}
              className={`w-full px-2 py-2 rounded-xl border text-[10px] font-bold outline-none transition-all ${isDark ? "bg-[#151a2d] border-white/8 text-white" : "bg-white border-gray-200 text-gray-900"}`}
            >
              {propertyClasses.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div>
            <label className={`block text-[10px] font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>المساحة (م²)</label>
            <input 
              type="tel" 
              value={area} 
              onChange={e => setArea(e.target.value)} 
              placeholder="600"
              className={`w-full px-2 py-2 rounded-xl border text-[10px] text-center font-black outline-none transition-all ${isDark ? "bg-[#151a2d] border-white/8 text-white focus:border-emerald-500/40" : "bg-white border-gray-200 text-gray-900 focus:border-emerald-400"}`} 
            />
          </div>
        </div>
      </div>

      {/* Evaluate Button */}
      <button onClick={handleValuate} disabled={loading}
        className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all ${loading ? "opacity-60 cursor-not-allowed " + (isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-600") : "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25 hover:shadow-xl"}`}>
        {loading ? (
          <><RefreshCcw className="w-4 h-4 animate-spin" /> يحلل البيانات...</>
        ) : (
          <><Award className="w-4 h-4" /> قيّم بالذكاء الاصطناعي</> 
        )}
      </button>

      {/* Loading animation */}
      <AnimatePresence>
        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className={`p-5 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <div className="flex items-center gap-3 mb-4">
              <RefreshCcw className="w-4 h-4 animate-spin text-emerald-500" />
              <p className={`text-xs font-bold ${isDark ? "text-white/70" : "text-gray-600"}`}>يحلل الذكاء الاصطناعي العقار...</p>
            </div>
            <div className="space-y-2.5">
              {["تحليل صفقات المنطقة", "تقييم نوع العقار والتصنيف", "حساب السعر العادل للمتر"].map((step, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.5 }}
                  className="flex items-center gap-2">
                  <motion.div animate={{ backgroundColor: ["#10b981", "#10b981"] }} transition={{ delay: i * 0.5 }}
                    className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className={`text-[11px] ${isDark ? "text-white/60" : "text-gray-500"}`}>{step}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Result */}
      <AnimatePresence>
        {result && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {/* Main Value */}
            <div className={`p-6 rounded-3xl border mb-3 text-center relative overflow-hidden ${isDark ? "bg-gradient-to-br from-emerald-900/30 to-teal-900/30 border-emerald-500/30" : "bg-gradient-to-br from-emerald-50 to-teal-100 border-emerald-300"}`}>
              {/* Glow */}
              <div className="absolute inset-0 bg-gradient-to-t from-emerald-500/5 to-transparent pointer-events-none" />
              <p className={`text-[11px] font-black uppercase tracking-widest mb-3 ${isDark ? "text-emerald-400/70" : "text-emerald-600/70"}`}>التقييم العادل للعقار</p>
              <p className="text-4xl font-black text-emerald-500 mb-1" style={{ textShadow: "0 0 30px #10b98140" }}>{fmt(result.estimated)}</p>
              <p className={`text-sm font-bold ${isDark ? "text-white/50" : "text-gray-600"}`}>ريال سعودي</p>
              <div className={`flex justify-center gap-4 mt-4 pt-4 border-t ${isDark ? "border-white/5" : "border-emerald-200"}`}>
                <div className="text-center">
                  <p className={`text-[9px] uppercase font-black mb-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>الحد الأدنى</p>
                  <p className={`text-sm font-black ${isDark ? "text-red-400" : "text-red-600"}`}>{fmt(result.low)}</p>
                </div>
                <div className={`w-px ${isDark ? "bg-white/5" : "bg-emerald-200"}`} />
                <div className="text-center">
                  <p className={`text-[9px] uppercase font-black mb-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>الحد الأعلى</p>
                  <p className={`text-sm font-black ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{fmt(result.high)}</p>
                </div>
                <div className={`w-px ${isDark ? "bg-white/5" : "bg-emerald-200"}`} />
                <div className="text-center">
                  <p className={`text-[9px] uppercase font-black mb-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>سعر المتر</p>
                  <p className={`text-sm font-black ${isDark ? "text-cyan-400" : "text-cyan-600"}`}>{fmt(result.pricePerSqm)}</p>
                </div>
              </div>
            </div>

            {/* Factors Breakdown */}
            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/40" : "text-gray-400"}`}>تفاصيل عوامل التقييم</p>
              <div className="space-y-2.5">
                {[
                  { label: "سعر المنطقة المرجعي", val: "2,800,000 ريال", bar: 100, color: "bg-blue-500" },
                  { label: `نوع العقار (${propType})`, val: (result.typeFactor * 100).toFixed(0) + "%", bar: result.typeFactor * 100, color: "bg-amber-500" },
                  { label: `التصنيف (${propClass})`, val: (result.classFactor * 100).toFixed(0) + "%", bar: Math.min(100, result.classFactor * 90), color: "bg-cyan-500" },
                  { label: "صفقات المنطقة المشابهة", val: "آخر 6 أشهر", bar: 85, color: "bg-purple-500" },
                ].map((f, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-[10px] font-bold ${isDark ? "text-white/60" : "text-gray-600"}`}>{f.label}</span>
                      <span className={`text-[10px] font-black ${isDark ? "text-white" : "text-gray-900"}`}>{f.val}</span>
                    </div>
                    <div className={`h-1.5 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                      <motion.div initial={{ width: 0 }} animate={{ width: `${f.bar}%` }} transition={{ duration: 0.8, delay: i * 0.1 }}
                        className={`h-full rounded-full ${f.color}`} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Recommendation */}
            <div className={`p-4 rounded-2xl border mt-3 ${isDark ? "bg-gradient-to-br from-purple-900/15 to-cyan-900/15 border-purple-500/20" : "bg-gradient-to-br from-purple-50 to-cyan-50 border-purple-200"}`}>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className={`text-xs font-black ${isDark ? "text-purple-400" : "text-purple-600"}`}>توصية الذكاء الاصطناعي</span>
              </div>
              <p className={`text-xs leading-6 ${isDark ? "text-white/70" : "text-gray-700"}`}>
                بناءً على التحليل، السعر العادل لهذا {propType} {propClass} في {neighborhood} هو <strong>{fmt(result.estimated)}</strong> ريال. يُنصح بطرحه في نطاق <strong>{fmt(result.low)} - {fmt(result.high)}</strong> ريال مع مراعاة التفاوض. سعر المتر المربع <strong>{fmt(result.pricePerSqm)}</strong> ريال يعكس متوسط المنطقة.
              </p>
              <button onClick={() => { setResult(null); }} className={`mt-3 w-full py-2.5 rounded-xl text-xs font-black border flex items-center justify-center gap-1.5 transition-all ${isDark ? "border-white/10 text-white/60 hover:bg-white/5" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
                <RefreshCcw className="w-3 h-3" /> تقييم عقار آخر
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
