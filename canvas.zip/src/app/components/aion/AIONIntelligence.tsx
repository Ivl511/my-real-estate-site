import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Sparkles, User, Building2, Key, Search, Zap, ShieldCheck, TrendingUp, BarChart3, MapPin, FileText, Target, BrainCircuit, MessageSquare, Handshake, Lock, PenTool, Package, Megaphone, Mic, EyeOff, Database, CheckCircle, Star } from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../context/ThemeContext";

interface AIONIntelligenceProps {
  onBack: () => void;
}

type Persona = "broker" | "developer" | "landlord" | "seeker";
type SeekerTier = "basic" | "smart";
type LandlordTier = "basic" | "professional";
type BrokerTier = "basic" | "advanced" | "elite";
type DevTier = "basic" | "advanced" | "growth";
type BrokerType = "individual" | "corporate";

const personas = [
  { id: "seeker", label: "الباحث", emoji: "🔍", color: "from-purple-500 to-pink-600", glow: "bg-purple-500" },
  { id: "broker", label: "الوسيط", emoji: "👔", color: "from-emerald-500 to-teal-600", glow: "bg-emerald-500" },
  { id: "landlord", label: "المالك", emoji: "🔑", color: "from-amber-500 to-orange-600", glow: "bg-amber-500" },
  { id: "developer", label: "المطور", emoji: "🏗️", color: "from-blue-500 to-indigo-600", glow: "bg-blue-500" },
];

const colorMap: Record<string, string> = {
  purple: "text-purple-400 bg-purple-500/20",
  emerald: "text-emerald-400 bg-emerald-500/20",
  cyan: "text-cyan-400 bg-cyan-500/20",
  blue: "text-blue-400 bg-blue-500/20",
  pink: "text-pink-400 bg-pink-500/20",
  amber: "text-amber-400 bg-amber-500/20",
  red: "text-red-400 bg-red-500/20",
  indigo: "text-indigo-400 bg-indigo-500/20",
};

interface AgentFeature {
  icon: any;
  nameAr: string;
  agentName: string;
  desc: string;
  locked?: boolean;
  exclusive?: boolean;
  color: string;
}

function getFeatures(
  persona: Persona, seekerTier: SeekerTier, landlordTier: LandlordTier,
  brokerTier: BrokerTier, devTier: DevTier, brokerType: BrokerType
): AgentFeature[] {
  if (persona === "seeker") {
    const isSmart = seekerTier === "smart";
    return [
      { icon: Search, agentName: "SearchAgent", nameAr: "الباحث الذكي", desc: "يبحث بالكلام العامي: \"ابي فيلا شرحه شمال الرياض\" ويفهم الطلب بدقة.", locked: false, color: "purple" },
      { icon: Target, agentName: "MatchingAgent", nameAr: "المطابق — حصري", desc: "تنبيهات فورية وحصرية إذا نزل عقار يطابق ذوقه. سُحبت من الوسطاء وأُعطيت للباحث.", locked: !isSmart, exclusive: true, color: "emerald" },
      { icon: ShieldCheck, agentName: "ValuationAgent", nameAr: "المقيّم", desc: "يعطيه السعر العادل للعقار مدعوماً ببيانات الصفقات الحقيقية حتى لا يُغبن.", locked: !isSmart, color: "cyan" },
      { icon: Mic, agentName: "DraftAgent", nameAr: "المحادثة الذكية", desc: "يقدر يكلم التطبيق صوتاً وكتابةً ويفهم طلبه.", locked: false, color: "blue" },
    ];
  }
  if (persona === "landlord") {
    const isPro = landlordTier === "professional";
    return [
      { icon: PenTool, agentName: "EditorAgent", nameAr: "المحرر", desc: "يكتب وصف الإعلان احترافياً ويحسّن الصور تلقائياً.", locked: !isPro, color: "pink" },
      { icon: TrendingUp, agentName: "ValuationAgent", nameAr: "المقيّم", desc: "يقول له كم يسوى عقاره في السوق حالياً بناءً على بيانات الهيئة.", locked: !isPro, color: "emerald" },
      { icon: EyeOff, agentName: "GuardianAgent", nameAr: "الحارس", desc: "يحمي رقمه وبياناته من الإزعاج ويخفيها عن العامة.", locked: false, color: "blue" },
      { icon: Zap, agentName: "Auto-Reply", nameAr: "الرد الآلي", desc: "ردود آلية أساسية على المستفسرين دون الحاجة للرد يدوياً.", locked: false, color: "purple" },
    ];
  }
  if (persona === "developer") {
    const isAdv = devTier === "advanced" || devTier === "growth";
    const isGrowth = devTier === "growth";
    return [
      { icon: Target, agentName: "MatchingAgent", nameAr: "المطابق — الأقوى", desc: "النظام يجلب المشترين الجاهزين ويوصلهم بالمشروع مباشرةً.", locked: false, exclusive: true, color: "blue" },
      { icon: Handshake, agentName: "NegotiatorAgent", nameAr: "المفاوض", desc: "يتفاوض على السعر، يفرز العروض الجادة، ويجدول مواعيد الزيارة (بدون كتابة عقود).", locked: !isAdv, color: "purple" },
      { icon: Package, agentName: "InventoryAgent", nameAr: "مدير المخزون", desc: "يدير آلاف الوحدات ويحدّث حالتها (مباع/متاح) بضغطة زر.", locked: false, color: "red" },
      { icon: BarChart3, agentName: "GrowthAgent & MarketingAgent", nameAr: "النمو والتسويق", desc: "يراقب المبيعات ويسوّي حملات تسويقية آلية.", locked: !isGrowth, color: "emerald" },
      { icon: MapPin, agentName: "AnalystAgent", nameAr: "المحلل", desc: "يعطيه تحليل دقيق عن المنطقة وسكانها والطلب فيها.", locked: !isAdv, color: "indigo" },
    ];
  }
  // broker
  const isAdv = brokerTier === "advanced" || brokerTier === "elite";
  const isCorp = brokerType === "corporate";
  const features: AgentFeature[] = [
    { icon: Megaphone, agentName: "Marketer Role", nameAr: "دور المسوّق", desc: "الميزة الرئيسية: زر تسويق على عقارات المطورين لضمان سعيه (2.5%).", locked: false, color: "amber" },
    { icon: MessageSquare, agentName: "NegotiatorAgent (مساعد)", nameAr: "السكرتير الذكي", desc: "يرد على الأسئلة العامة ويحجز المواعيد فقط — ممنوع من التفاوض أو المطابقة.", locked: !isAdv, color: "cyan" },
    { icon: TrendingUp, agentName: "ValuationAgent", nameAr: "التقييم", desc: "يساعده في تقييم العقارات التي يسوّقها.", locked: false, color: "emerald" },
    { icon: PenTool, agentName: "EditorAgent", nameAr: "تحرير المحتوى", desc: "يحسّن عرض العقارات التي يسوّقها.", locked: false, color: "pink" },
  ];
  if (isCorp) {
    features.push(
      { icon: User, agentName: "Team Management", nameAr: "إدارة الفريق", desc: "لوحة تحكم لإدارة عدة وسطاء تحت سجل المنشأة.", locked: false, color: "indigo" },
      { icon: BarChart3, agentName: "Performance Reports", nameAr: "تقارير الأداء", desc: "يشوف مين من الموظفين شغّال صح.", locked: false, color: "blue" },
      { icon: Database, agentName: "InventoryAgent", nameAr: "مخزون المنشأة", desc: "لترتيب عقارات المنشأة الداخلية فقط.", locked: false, color: "red" }
    );
  }
  return features;
}

function getTierLabel(persona: Persona, seekerTier: SeekerTier, landlordTier: LandlordTier, brokerTier: BrokerTier, devTier: DevTier): { label: string; active: boolean } {
  if (persona === "seeker") return seekerTier === "smart" ? { label: "Smart Search مفعّلة ✓", active: true } : { label: "تفعيل باقة Smart Search", active: false };
  if (persona === "landlord") return landlordTier === "professional" ? { label: "Professional مفعّلة ✓", active: true } : { label: "تفعيل باقة Professional", active: false };
  if (persona === "broker") {
    if (brokerTier === "elite") return { label: "Elite مفعّلة ✓", active: true };
    if (brokerTier === "advanced") return { label: "تفعيل باقة Elite", active: false };
    return { label: "تفعيل الباقة", active: false };
  }
  if (devTier === "growth") return { label: "Growth مفعّلة ✓", active: true };
  if (devTier === "advanced") return { label: "تفعيل باقة Growth", active: false };
  return { label: "تفعيل الباقة", active: false };
}

function User2(props: any) {
  return <User {...props} />;
}

export function AIONIntelligence({ onBack }: AIONIntelligenceProps) {
  const [activePersona, setActivePersona] = useState<Persona>("seeker");
  const [seekerTier, setSeekerTier] = useState<SeekerTier>("basic");
  const [landlordTier, setLandlordTier] = useState<LandlordTier>("basic");
  const [brokerTier, setBrokerTier] = useState<BrokerTier>("basic");
  const [devTier, setDevTier] = useState<DevTier>("basic");
  const [brokerType, setBrokerType] = useState<BrokerType>("individual");
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const currentPersona = personas.find(p => p.id === activePersona)!;
  const features = getFeatures(activePersona, seekerTier, landlordTier, brokerTier, devTier, brokerType);
  const tierCTA = getTierLabel(activePersona, seekerTier, landlordTier, brokerTier, devTier);

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gradient-to-br from-gray-50 to-gray-100'}`}>

      {/* HEADER */}
      <div className="px-5 pt-12 pb-4 relative z-10">
        <div className="flex items-center justify-between mb-6">
          <button onClick={onBack} className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${isDark ? 'glass-premium hover:bg-white/10' : 'bg-white shadow-lg hover:bg-gray-50'}`}>
            <ArrowRight className={`w-5 h-5 ${isDark ? 'text-white' : 'text-gray-900'}`} />
          </button>
          <div className="flex flex-col items-center">
            <h2 className={`text-xl font-black tracking-wide ${isDark ? 'text-white' : 'text-gray-900'}`}>مركز ذكاء أيون</h2>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse shadow-[0_0_8px_#06b6d4]" />
              <span className={`text-[10px] font-bold ${isDark ? 'text-cyan-400' : 'text-cyan-600'}`}>محاكي الميزات التفاعلي</span>
            </div>
          </div>
          <div className="w-11" />
        </div>

        {/* ORB ANIMATION */}
        <div className="flex justify-center mb-6 relative">
          <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 rounded-full blur-3xl opacity-25 pointer-events-none bg-gradient-to-r ${currentPersona.color}`} />
          <motion.div key={activePersona} initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.4 }} className="relative w-24 h-24">
            <div className={`absolute inset-0 rounded-full opacity-50 bg-gradient-to-tr ${currentPersona.color}`} style={{ filter: 'blur(18px)' }} />
            <div className={`relative w-full h-full rounded-full flex items-center justify-center border-2 backdrop-blur-md shadow-2xl ${isDark ? 'border-white/20 bg-black/40' : 'border-white/60 bg-white/40'}`}>
              <motion.div animate={{ rotate: 360 }} transition={{ duration: 10, repeat: Infinity, ease: "linear" }} className="absolute inset-2 rounded-full border border-dashed border-white/30" />
              <Sparkles className="w-8 h-8 text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]" />
            </div>
          </motion.div>
        </div>

        {/* PERSONA TABS */}
        <div className="flex justify-center mb-3">
          <div className={`p-1.5 rounded-2xl flex gap-1 ${isDark ? 'bg-black/40 border border-white/10' : 'bg-white shadow-lg border border-gray-100'}`}>
            {personas.map(persona => {
              const isActive = activePersona === persona.id;
              return (
                <button
                  key={persona.id}
                  onClick={() => setActivePersona(persona.id as Persona)}
                  className={`relative px-3 py-2.5 rounded-xl flex items-center gap-1.5 transition-all overflow-hidden ${isActive ? 'shadow-lg' : 'hover:bg-white/5'}`}
                >
                  {isActive && <motion.div layoutId="activeTabAION" className={`absolute inset-0 bg-gradient-to-r ${persona.color}`} />}
                  <span className="relative z-10 text-base">{persona.emoji}</span>
                  <span className={`text-xs font-black relative z-10 ${isActive ? 'text-white' : isDark ? 'text-white/50' : 'text-gray-500'}`}>{persona.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* TIER SELECTOR */}
        <div className={`p-3 rounded-2xl border ${isDark ? 'bg-black/30 border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activePersona}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="flex items-center gap-2"
            >
              {activePersona === "broker" && (
                <>
                  <div className={`flex rounded-lg p-0.5 ${isDark ? "bg-black/30" : "bg-gray-100"}`}>
                    {(["individual", "corporate"] as BrokerType[]).map(t => (
                      <button key={t} onClick={() => setBrokerType(t)}
                        className={`px-2 py-1 rounded text-[9px] font-bold transition-all ${brokerType === t ? (isDark ? "bg-white/20 text-white" : "bg-white text-gray-800 shadow-sm") : "text-gray-400"}`}>
                        {t === "individual" ? "فرد" : "منشأة"}
                      </button>
                    ))}
                  </div>
                  <div className="w-px h-4 bg-white/10 shrink-0" />
                  <div className="flex gap-1 flex-1">
                    {(["basic", "advanced", "elite"] as BrokerTier[]).map(t => (
                      <button key={t} onClick={() => setBrokerTier(t)}
                        className={`flex-1 py-1.5 rounded-lg text-[9px] font-black transition-all ${brokerTier === t ? "bg-amber-500 text-white" : isDark ? "text-white/40 bg-white/5 hover:bg-white/10" : "text-gray-500 bg-gray-100 hover:bg-gray-200"}`}>
                        {t === "basic" ? "Basic" : t === "advanced" ? "Adv" : "Elite"}
                      </button>
                    ))}
                  </div>
                </>
              )}
              {activePersona === "developer" && (
                <div className="flex gap-1 flex-1">
                  {(["basic", "advanced", "growth"] as DevTier[]).map(t => (
                    <button key={t} onClick={() => setDevTier(t)}
                      className={`flex-1 py-1.5 rounded-lg text-[9px] font-black transition-all ${devTier === t ? "bg-blue-600 text-white" : isDark ? "text-white/40 bg-white/5 hover:bg-white/10" : "text-gray-500 bg-gray-100 hover:bg-gray-200"}`}>
                      {t === "basic" ? "Basic" : t === "advanced" ? "Advanced" : "Growth"}
                    </button>
                  ))}
                </div>
              )}
              {activePersona === "landlord" && (
                <div className="flex gap-1 flex-1">
                  {(["basic", "professional"] as LandlordTier[]).map(t => (
                    <button key={t} onClick={() => setLandlordTier(t)}
                      className={`flex-1 py-1.5 rounded-lg text-[9px] font-black transition-all ${landlordTier === t ? "bg-amber-600 text-white" : isDark ? "text-white/40 bg-white/5 hover:bg-white/10" : "text-gray-500 bg-gray-100 hover:bg-gray-200"}`}>
                      {t === "basic" ? "Basic" : "Professional"}
                    </button>
                  ))}
                </div>
              )}
              {activePersona === "seeker" && (
                <div className="flex gap-1 flex-1">
                  {(["basic", "smart"] as SeekerTier[]).map(t => (
                    <button key={t} onClick={() => setSeekerTier(t)}
                      className={`flex-1 py-1.5 rounded-lg text-[9px] font-black transition-all ${seekerTier === t ? "bg-purple-600 text-white" : isDark ? "text-white/40 bg-white/5 hover:bg-white/10" : "text-gray-500 bg-gray-100 hover:bg-gray-200"}`}>
                      {t === "basic" ? "Basic" : "Smart"}
                    </button>
                  ))}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* FEATURES LIST */}
      <div className="flex-1 overflow-y-auto px-5 pb-32">
        <div className="space-y-3">
          <p className={`text-[10px] uppercase font-black opacity-40 tracking-wider mb-3`}>
            الوكلاء والمميزات — كيف يخدمك أيون كـ {currentPersona.label}؟
          </p>
          <AnimatePresence mode="wait">
            <motion.div
              key={`${activePersona}-${seekerTier}-${landlordTier}-${brokerTier}-${devTier}-${brokerType}`}
              initial={{ opacity: 0, x: 15 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -15 }}
              transition={{ duration: 0.2 }}
              className="space-y-3"
            >
              {features.map((feature, index) => {
                const Icon = feature.icon;
                const cls = colorMap[feature.color] || colorMap.blue;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.07 }}
                    className={`p-5 rounded-3xl relative overflow-hidden group border transition-all ${
                      feature.locked
                        ? isDark ? 'bg-[#1E2330]/40 border-white/5 opacity-50 grayscale' : 'bg-gray-50 border-gray-100 opacity-50 grayscale'
                        : isDark ? 'bg-[#1E2330]/80 border-white/5 hover:border-white/20 cursor-pointer' : 'bg-white shadow-md hover:shadow-lg border-gray-100 cursor-pointer'
                    }`}
                  >
                    {/* Hover Gradient */}
                    {!feature.locked && <div className={`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity bg-gradient-to-r ${currentPersona.color}`} />}

                    <div className="flex items-start gap-4 relative z-10">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${feature.locked ? 'bg-gray-500/20' : `bg-gradient-to-br ${currentPersona.color}`}`}>
                        {feature.locked ? <Lock className="w-6 h-6 text-gray-500" /> : <Icon className="w-6 h-6 text-white" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <h4 className={`font-black text-base ${isDark ? 'text-white' : 'text-gray-900'}`}>{feature.nameAr}</h4>
                          <span className={`text-[9px] opacity-50 ${isDark ? 'text-white/40' : 'text-gray-400'}`}>{feature.agentName}</span>
                          {feature.exclusive && !feature.locked && (
                            <span className="text-[8px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 font-black flex items-center gap-0.5 w-fit"><Star style={{width:"8px",height:"8px",fill:"currentColor"}} /> حصري</span>
                          )}
                          {feature.locked && (
                            <span className="text-[9px] px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 font-black flex items-center gap-0.5 w-fit"><Lock style={{width:"8px",height:"8px"}} /> يتطلب ترقية</span>
                          )}
                        </div>
                        <p className={`text-xs font-medium leading-relaxed ${isDark ? 'text-white/60' : 'text-gray-500'}`}>{feature.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}

              {/* CTA */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: features.length * 0.07 + 0.1 }}
                className={`mt-4 p-6 rounded-3xl text-center relative overflow-hidden ${isDark ? 'glass-strong border border-white/10' : 'bg-gradient-to-br from-gray-900 to-gray-800'}`}
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/20 rounded-full blur-3xl" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-purple-500/20 rounded-full blur-3xl" />
                <h3 className="text-xl font-black mb-2 text-white">ابدأ رحلتك الآن</h3>
                <p className="text-xs mb-4 text-gray-300">قم بترقية حسابك للاستفادة من كامل قدرات الذكاء الاصطناعي</p>
                <button className={`w-full py-3 rounded-xl font-bold shadow-lg transition-transform active:scale-95 text-white ${
                  tierCTA.active
                    ? "bg-gradient-to-r from-emerald-500 to-teal-500"
                    : `bg-gradient-to-r ${currentPersona.color}`
                }`}>
                  <span className="flex items-center justify-center gap-2">{tierCTA.active ? <CheckCircle className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}{tierCTA.label}</span>
                </button>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
