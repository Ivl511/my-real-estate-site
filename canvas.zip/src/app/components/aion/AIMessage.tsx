import { Sparkles, User } from "lucide-react";

interface AIMessageProps {
  message: string;
  isUser: boolean;
  timestamp?: string;
}

export function AIMessage({ message, isUser, timestamp }: AIMessageProps) {
  return (
    <div className={`flex gap-3 mb-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* الأفاتار */}
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
        isUser 
          ? 'bg-[var(--aion-gray-200)]' 
          : 'bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)]'
      }`}>
        {isUser ? (
          <User className="w-5 h-5 text-[var(--aion-gray-700)]" />
        ) : (
          <Sparkles className="w-5 h-5 text-white" />
        )}
      </div>
      
      {/* الرسالة */}
      <div className={`flex flex-col max-w-[75%] ${isUser ? 'items-end' : 'items-start'}`}>
        <div className={`rounded-2xl px-4 py-3 ${
          isUser
            ? 'bg-[var(--aion-navy)] text-white rounded-tr-sm'
            : 'bg-white text-[var(--aion-gray-800)] rounded-tl-sm'
        }`} style={!isUser ? { boxShadow: 'var(--aion-shadow-md)' } : {}}>
          <p className="text-sm leading-relaxed whitespace-pre-wrap">{message}</p>
        </div>
        {timestamp && (
          <span className="text-xs text-[var(--aion-gray-400)] mt-1 px-1">{timestamp}</span>
        )}
      </div>
    </div>
  );
}
