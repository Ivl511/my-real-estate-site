import { motion, AnimatePresence } from "motion/react";
import { X, Mic, Send, Sparkles, TrendingUp, MapPin, DollarSign, Home as HomeIcon } from "lucide-react";
import { useState } from "react";

interface AIONOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const quickQuestions = [
  { text: "Show me villas under 2M SAR?", icon: HomeIcon },
  { text: "Analyze this area's ROI?", icon: TrendingUp },
  { text: "Best swap deals in Riyadh?", icon: DollarSign },
  { text: "Properties near schools?", icon: MapPin },
];

export function AIONOverlay({ isOpen, onClose }: AIONOverlayProps) {
  const [isListening, setIsListening] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: "user" | "ai"; content: string; propertyCard?: any }>>([]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40"
          />

          {/* Bottom Sheet */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 z-50 h-[85vh] bg-gradient-to-b from-[#0D1221] to-[#0A0E1A] rounded-t-[40px] overflow-hidden"
          >
            {/* Drag Handle */}
            <div className="absolute top-3 left-1/2 -translate-x-1/2 w-12 h-1.5 bg-white/20 rounded-full" />

            {/* Header */}
            <div className="flex items-center justify-between px-6 pt-8 pb-4 border-b border-white/10">
              <motion.button
                onClick={onClose}
                whileTap={{ scale: 0.9 }}
                className="w-10 h-10 glass rounded-full flex items-center justify-center"
              >
                <X className="w-5 h-5 text-white" />
              </motion.button>

              <div className="text-center">
                <h2 className="text-white text-xl font-black mb-1">ڤال Brain</h2>
                <div className="flex items-center gap-2 justify-center">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                    className="w-2 h-2 bg-cyan-400 rounded-full"
                  />
                  <p className="text-cyan-400 text-xs font-bold">Listening...</p>
                </div>
              </div>

              <div className="w-10" />
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto px-6 py-6">
              {messages.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6"
                >
                  {/* AI Avatar */}
                  <div className="flex justify-center mb-8">
                    <motion.div
                      animate={{
                        scale: [1, 1.1, 1],
                        rotate: [0, 360],
                      }}
                      transition={{
                        scale: { duration: 2, repeat: Infinity },
                        rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                      }}
                      className="relative"
                    >
                      <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 blur-2xl opacity-50" />
                      <div className="relative w-24 h-24 rounded-full holographic flex items-center justify-center">
                        <Sparkles className="w-12 h-12 text-white" />
                      </div>
                    </motion.div>
                  </div>

                  {/* Welcome Message */}
                  <div className="text-center mb-8">
                    <h3 className="text-white text-2xl font-black mb-3">مرحباً بك في ڤال</h3>
                    <p className="text-white/60 text-sm">كيف أستطيع مساعدتك اليوم؟</p>
                  </div>

                  {/* Quick Questions */}
                  <div className="space-y-3">
                    {quickQuestions.map((q, i) => {
                      const Icon = q.icon;
                      return (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.1 }}
                          whileTap={{ scale: 0.98 }}
                          className="w-full glass-strong rounded-2xl p-4 flex items-center gap-3 text-right hover:border-cyan-500/50 transition-all cursor-pointer"
                        >
                          <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-500 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-5 h-5 text-white" />
                          </div>
                          <p className="flex-1 text-white/90 text-sm font-medium">{q.text}</p>
                        </motion.div>
                      );
                    })}
                  </div>
                </motion.div>
              ) : (
                <div className="space-y-4">
                  {messages.map((msg, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${msg.role === "user" ? "justify-start" : "justify-end"}`}
                    >
                      <div className={`max-w-[80%] ${msg.role === "user" ? "glass" : "glass-strong"} rounded-2xl p-4`}>
                        <p className="text-white/90 text-sm">{msg.content}</p>
                        
                        {/* Property Card in Chat */}
                        {msg.propertyCard && (
                          <div className="mt-3 glass rounded-xl overflow-hidden">
                            <img src={msg.propertyCard.image} alt="" className="w-full h-32 object-cover" />
                            <div className="p-3">
                              <p className="text-white font-bold text-sm mb-1">{msg.propertyCard.title}</p>
                              <p className="text-cyan-400 font-black">{msg.propertyCard.price}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Voice Wave Indicator */}
            <div className="px-6 py-4 border-t border-white/10">
              <div className="flex items-center justify-center gap-1 mb-4 voice-wave">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
              </div>

              {/* Input Area */}
              <div className="flex items-center gap-3">
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  className="w-12 h-12 glass rounded-full flex items-center justify-center"
                >
                  <Send className="w-5 h-5 text-cyan-400" />
                </motion.button>

                <input
                  type="text"
                  placeholder="اكتب سؤالك..."
                  className="flex-1 glass rounded-2xl px-4 py-3 text-white placeholder:text-white/40 text-sm outline-none text-right"
                />

                <motion.button
                  onClick={() => setIsListening(!isListening)}
                  whileTap={{ scale: 0.9 }}
                  animate={isListening ? { scale: [1, 1.1, 1] } : {}}
                  transition={{ duration: 0.5, repeat: Infinity }}
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    isListening ? "bg-gradient-to-r from-red-500 to-pink-500" : "glass"
                  }`}
                >
                  <Mic className="w-5 h-5 text-white" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}