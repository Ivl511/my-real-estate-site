import { Menu, Bell } from "lucide-react";
import { motion } from "motion/react";
import { useTheme } from "../../context/ThemeContext";

interface GlobalHeaderProps {
  title: string;
  onMenuClick?: () => void;
  onNotificationClick?: () => void;
  notificationCount?: number;
}

export function GlobalHeader({ 
  title, 
  onMenuClick, 
  onNotificationClick, 
  notificationCount = 0 
}: GlobalHeaderProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <div className={`fixed top-0 left-0 right-0 z-30 px-5 pt-12 pb-4 ${
      isDark ? 'bg-gradient-to-b from-[#0A0E1A] via-[#0A0E1A]/95 to-transparent' : 'bg-gradient-to-b from-gray-50 via-gray-50/95 to-transparent'
    }`}>
      <div className="flex items-center justify-between">
        {/* Right: Notification Bell */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onNotificationClick}
          className={`w-11 h-11 rounded-2xl flex items-center justify-center relative ${
            isDark ? 'glass-premium' : 'bg-white shadow-lg'
          }`}
        >
          <Bell className={`w-5 h-5 ${isDark ? 'text-white' : 'text-gray-900'}`} />
          {notificationCount > 0 && (
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center border-2 border-[#0A0E1A]">
              <span className="text-white text-[10px] font-black">{notificationCount}</span>
            </div>
          )}
        </motion.button>

        {/* Center: Title */}
        <h1 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
          {title}
        </h1>

        {/* Left: Hamburger Menu */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onMenuClick}
          className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
            isDark ? 'glass-premium' : 'bg-white shadow-lg'
          }`}
        >
          <Menu className={`w-5 h-5 ${isDark ? 'text-white' : 'text-gray-900'}`} />
        </motion.button>
      </div>
    </div>
  );
}
