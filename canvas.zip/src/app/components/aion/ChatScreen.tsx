import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Send, Sparkles, Mic, Image as ImageIcon, MapPin, Plus, Zap, TrendingUp, Home, DollarSign } from "lucide-react";

interface ChatScreenProps {
  onBack: () => void;
}

interface Message {
  id: string;
  text?: string;
  isUser: boolean;
  timestamp: string;
  type?: "text" | "property" | "suggestions";
  propertyData?: {
    image: string;
    title: string;
    price: string;
    location: string;
    aiScore: number;
  };
  suggestions?: string[];
}

const initialMessages: Message[] = [
  {
    id: "1",
    text: "مرحباً بك في أيون! 👋\n\nأنا مساعدك الذكي المتخصص في العقارات.\n\nكيف أستطيع مساعدتك اليوم؟",
    isUser: false,
    timestamp: "الآن",
    type: "text",
  },
];

const quickActions = [
  { id: "1", text: "فيلا فاخرة", icon: Home, gradient: "from-blue-500 to-blue-600" },
  { id: "2", text: "استثمار 2M", icon: TrendingUp, gradient: "from-emerald-500 to-emerald-600" },
  { id: "3", text: "سعر المتر", icon: DollarSign, gradient: "from-purple-500 to-purple-600" },
  { id: "4", text: "شمال الرياض", icon: MapPin, gradient: "from-orange-500 to-orange-600" },
];

const detailedSuggestions = [
  {
    title: "أبحث عن فيلا",
    description: "في شمال الرياض بميزانية 3 مليون",
    icon: "🏡",
  },
  {
    title: "أفضل حي للاستثمار",
    description: "مع تحليل العائد المتوقع",
    icon: "📈",
  },
  {
    title: "شقة قريبة من المدارس",
    description: "العالمية في الرياض",
    icon: "🏫",
  },
];

export function ChatScreen({ onBack }: ChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const handleSend = (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      text: messageText,
      isUser: true,
      timestamp: new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" }),
      type: "text",
    };

    setMessages((prev) => [...prev, newMessage]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "ممتاز! 🎯 وجدت 127 عقار يطابق معاييرك.\n\nإليك أفضل الخيارات المتاحة:",
        isUser: false,
        timestamp: new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" }),
        type: "text",
      };

      const propertyCard: Message = {
        id: (Date.now() + 2).toString(),
        isUser: false,
        timestamp: new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" }),
        type: "property",
        propertyData: {
          image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80",
          title: "فيلا فاخرة بتصميم معماري استثنائي",
          price: "3,200,000",
          location: "حي الملقا، الرياض",
          aiScore: 96,
        },
      };

      setMessages((prev) => [...prev, aiResponse, propertyCard]);
      setIsTyping(false);
    }, 2500);
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-slate-50 via-white to-blue-50/20 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.03, 0.06, 0.03],
          }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-emerald-500 to-blue-500 rounded-full blur-3xl"
        />
      </div>

      {/* Premium Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative z-10 glass-effect border-b border-gray-200/50 px-5 py-4"
      >
        <div className="flex items-center gap-4">
          <motion.button
            onClick={onBack}
            whileTap={{ scale: 0.9 }}
            className="w-11 h-11 bg-white rounded-2xl flex items-center justify-center shadow-lg shadow-black/5 border border-gray-100"
          >
            <ArrowRight className="w-5 h-5 text-slate-700" />
          </motion.button>

          <div className="relative">
            <motion.div
              animate={{
                rotate: [0, 10, -10, 0],
                scale: [1, 1.05, 1],
              }}
              transition={{ duration: 4, repeat: Infinity }}
              className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-xl shadow-emerald-500/40"
            >
              <Sparkles className="w-6 h-6 text-white" />
            </motion.div>
            <motion.div
              animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 bg-emerald-400 rounded-2xl"
            />
          </div>

          <div className="flex-1 text-right">
            <h2 className="font-black text-slate-900 text-lg" style={{ fontFamily: 'Cairo' }}>
              مساعد أيون الذكي
            </h2>
            <div className="flex items-center gap-2 justify-end">
              <motion.div
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="flex items-center gap-1.5"
              >
                <span className="text-xs text-emerald-600 font-bold">نشط الآن</span>
                <div className="w-2 h-2 bg-emerald-500 rounded-full" />
              </motion.div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-5 py-6 relative z-10">
        <AnimatePresence mode="popLayout">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: "spring", bounce: 0.3 }}
              className={`mb-5 flex ${message.isUser ? "justify-start" : "justify-end"}`}
            >
              <div className={`max-w-[85%] ${message.isUser ? "order-2" : "order-1"}`}>
                {/* AI Header */}
                {!message.isUser && message.type === "text" && (
                  <motion.div
                    initial={{ scale: 0, x: 20 }}
                    animate={{ scale: 1, x: 0 }}
                    className="flex items-center gap-2 mb-2 justify-end"
                  >
                    <span className="text-xs text-emerald-600 font-black">أيون AI</span>
                    <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                  </motion.div>
                )}

                {/* Text Message */}
                {message.type === "text" && (
                  <motion.div
                    whileHover={{ scale: 1.01, y: -2 }}
                    className={`rounded-3xl px-6 py-4 shadow-xl ${
                      message.isUser
                        ? "bg-gradient-to-r from-slate-900 to-slate-700 text-white rounded-tr-md"
                        : "bg-white text-slate-900 rounded-tl-md border border-gray-100"
                    }`}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap font-medium" style={{ fontFamily: 'Cairo' }}>
                      {message.text}
                    </p>
                  </motion.div>
                )}

                {/* Property Card */}
                {message.type === "property" && message.propertyData && (
                  <motion.div
                    whileHover={{ scale: 1.02, y: -4 }}
                    className="bg-white rounded-3xl overflow-hidden shadow-2xl border border-gray-100"
                  >
                    <div className="relative h-52">
                      <img
                        src={message.propertyData.image}
                        alt={message.propertyData.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      
                      {/* AI Score */}
                      <div className="absolute top-3 right-3">
                        <div className="bg-white/95 backdrop-blur-xl rounded-xl px-3 py-2 flex items-center gap-2 shadow-xl">
                          <div className="text-center">
                            <span className="text-xl font-black bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent leading-none block">
                              {message.propertyData.aiScore}
                            </span>
                            <span className="text-xs font-black text-slate-500">AI</span>
                          </div>
                          <Sparkles className="w-4 h-4 text-emerald-600" />
                        </div>
                      </div>

                      {/* Price */}
                      <div className="absolute bottom-3 right-3">
                        <p className="text-white text-2xl font-black drop-shadow-2xl">
                          {message.propertyData.price} ر.س
                        </p>
                      </div>
                    </div>

                    <div className="p-5">
                      <h3 className="font-black text-slate-900 mb-2 text-right text-base leading-tight" style={{ fontFamily: 'Cairo' }}>
                        {message.propertyData.title}
                      </h3>
                      <p className="flex items-center gap-1.5 text-slate-500 text-sm font-semibold justify-end mb-4">
                        <span>{message.propertyData.location}</span>
                        <MapPin className="w-4 h-4" />
                      </p>
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 text-white py-3 rounded-2xl text-sm font-black shadow-lg shadow-emerald-500/30"
                      >
                        عرض التفاصيل
                      </motion.button>
                    </div>
                  </motion.div>
                )}

                <span className="text-xs text-slate-400 mt-2 block font-medium">
                  {message.timestamp}
                </span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-5 flex justify-end"
          >
            <div className="max-w-[85%]">
              <div className="flex items-center gap-2 mb-2 justify-end">
                <span className="text-xs text-emerald-600 font-black">أيون AI</span>
                <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
              </div>
              <div className="bg-white rounded-3xl rounded-tl-md px-6 py-4 shadow-xl border border-gray-100">
                <div className="flex gap-2">
                  {[0, 1, 2].map((i) => (
                    <motion.span
                      key={i}
                      animate={{ y: [0, -10, 0] }}
                      transition={{
                        duration: 0.6,
                        repeat: Infinity,
                        delay: i * 0.15,
                      }}
                      className="w-2.5 h-2.5 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-full"
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Initial Suggestions */}
        {messages.length === 1 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-6 space-y-5"
          >
            {/* Quick Actions */}
            <div>
              <p className="text-xs text-slate-500 font-black text-right mb-3">إجابات سريعة:</p>
              <div className="grid grid-cols-2 gap-3">
                {quickActions.map((action, i) => {
                  const Icon = action.icon;
                  return (
                    <motion.button
                      key={action.id}
                      onClick={() => handleSend(action.text)}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5 + i * 0.05 }}
                      whileHover={{ scale: 1.03, y: -2 }}
                      whileTap={{ scale: 0.97 }}
                      className="relative overflow-hidden rounded-2xl p-4 shadow-lg"
                    >
                      <div className={`absolute inset-0 bg-gradient-to-br ${action.gradient} opacity-10`} />
                      <div className="relative">
                        <div className={`w-12 h-12 mx-auto mb-2 rounded-xl bg-gradient-to-br ${action.gradient} flex items-center justify-center shadow-lg`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <p className="text-sm font-black text-slate-900" style={{ fontFamily: 'Cairo' }}>
                          {action.text}
                        </p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Detailed Suggestions */}
            <div>
              <p className="text-xs text-slate-500 font-black text-right mb-3">اقتراحات مفصلة:</p>
              <div className="space-y-3">
                {detailedSuggestions.map((suggestion, i) => (
                  <motion.button
                    key={i}
                    onClick={() => handleSend(`${suggestion.title} - ${suggestion.description}`)}
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + i * 0.1 }}
                    whileHover={{ x: -5, scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-white border border-gray-200 rounded-2xl p-4 shadow-lg hover:shadow-xl hover:border-emerald-500/50 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex-1 text-right">
                        <p className="font-black text-slate-900 mb-1" style={{ fontFamily: 'Cairo' }}>
                          {suggestion.title}
                        </p>
                        <p className="text-sm text-slate-500 font-medium">
                          {suggestion.description}
                        </p>
                      </div>
                      <div className="text-3xl">{suggestion.icon}</div>
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Premium Input Area */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", bounce: 0.2 }}
        className="relative z-10 glass-effect border-t border-gray-200/50 px-5 py-4"
      >
        <div className="flex items-end gap-3">
          {/* Send Button */}
          <motion.button
            onClick={() => handleSend()}
            disabled={!input.trim() && !isRecording}
            whileTap={{ scale: 0.9 }}
            className="relative"
          >
            <motion.div
              animate={input.trim() || isRecording ? { scale: [1, 1.05, 1] } : {}}
              transition={{ duration: 1, repeat: Infinity }}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                input.trim() || isRecording
                  ? "bg-gradient-to-r from-emerald-500 to-emerald-600 shadow-emerald-500/40"
                  : "bg-white border border-gray-200 shadow-black/5"
              }`}
            >
              <Send className={`w-5 h-5 ${input.trim() || isRecording ? "text-white" : "text-slate-400"}`} />
            </motion.div>
          </motion.button>

          {/* Input Container */}
          <div className="flex-1 bg-white border border-gray-200 rounded-2xl px-4 py-3.5 shadow-lg">
            <div className="flex items-center gap-3">
              {/* Action Buttons */}
              <div className="flex gap-2">
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  className="text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  className="text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <ImageIcon className="w-5 h-5" />
                </motion.button>
                <motion.button
                  onClick={() => setIsRecording(!isRecording)}
                  whileTap={{ scale: 0.9 }}
                  animate={isRecording ? { scale: [1, 1.1, 1] } : {}}
                  transition={{ duration: 0.5, repeat: Infinity }}
                  className={`transition-colors ${
                    isRecording ? "text-red-500" : "text-slate-400 hover:text-slate-600"
                  }`}
                >
                  <Mic className="w-5 h-5" />
                </motion.button>
              </div>

              {/* Input Field */}
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                placeholder={isRecording ? "جاري التسجيل..." : "اكتب رسالتك هنا..."}
                disabled={isRecording}
                className="flex-1 bg-transparent outline-none text-sm text-slate-900 placeholder:text-slate-400 text-right font-medium"
                style={{ fontFamily: 'Cairo' }}
              />
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
