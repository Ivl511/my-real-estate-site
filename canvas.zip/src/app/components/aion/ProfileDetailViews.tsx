import { useState } from "react";
import { motion } from "motion/react";
import { ArrowRight, BarChart3, Users, Building, AlertCircle, CheckCircle, TrendingUp, TrendingDown, DollarSign, Calendar, Filter, Plus, Edit, Trash, Share2, Eye, MessageSquare, Zap, Shield, FileText, Key, Briefcase, ArrowRightLeft, Search, Info, MapPin, SortAsc, SortDesc, Clock } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

// ==========================================
// 1. LISTINGS (EXISTING)
// ==========================================
function MyListingsView({ isDark }: { isDark: boolean }) {
    return (
        <div className="space-y-4">
            <button className="w-full py-3 rounded-xl border-2 border-dashed border-gray-500/30 text-gray-500 text-sm font-bold flex items-center justify-center gap-2 hover:bg-white/5 transition-colors">
                <Plus className="w-4 h-4" /> إضافة عقار جديد
            </button>

            {[1, 2, 3].map((i) => (
                <div key={i} className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
                    <div className="flex gap-3">
                        <div className="w-20 h-20 rounded-xl bg-gray-500/20 shrink-0" />
                        <div className="flex-1">
                            <div className="flex justify-between items-start mb-1">
                                <h3 className={`font-bold text-sm ${isDark ? 'text-white' : 'text-gray-900'}`}>فيلا مودرن بالرياض</h3>
                                <span className="px-2 py-0.5 rounded bg-green-500/10 text-green-500 text-[10px] font-bold">نشط</span>
                            </div>
                            <p className="text-xs text-gray-500 mb-2">حي النرجس • 450م² • 5 غرف</p>
                            <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>2,500,000 ريال</p>
                        </div>
                    </div>
                    <div className="flex gap-2 mt-3 pt-3 border-t border-dashed border-gray-500/20">
                         <button className="flex-1 py-2 rounded-lg bg-gray-500/10 text-xs font-bold flex items-center justify-center gap-1 hover:bg-gray-500/20"><Edit className="w-3 h-3" /> تعديل</button>
                         <button className="flex-1 py-2 rounded-lg bg-blue-500/10 text-blue-500 text-xs font-bold flex items-center justify-center gap-1 hover:bg-blue-500/20"><Share2 className="w-3 h-3" /> مشاركة</button>
                         <button className="flex-1 py-2 rounded-lg bg-purple-500/10 text-purple-500 text-xs font-bold flex items-center justify-center gap-1 hover:bg-purple-500/20"><BarChart3 className="w-3 h-3" /> إحصائيات</button>
                    </div>
                </div>
            ))}
        </div>
    )
}

// ==========================================
// 2. INVENTORY VIEW (NEW - OFF MARKET)
// ==========================================
function InventoryView({ isDark }: { isDark: boolean }) {
    return (
        <div className="space-y-4">
            
            {/* THE SPECIAL MESSAGE */}
            <div className={`p-4 rounded-2xl border flex items-start gap-3 ${isDark ? 'bg-amber-900/10 border-amber-500/20' : 'bg-amber-50 border-amber-200'}`}>
                <Info className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
                <div>
                    <h4 className={`text-sm font-bold mb-1 ${isDark ? 'text-amber-400' : 'text-amber-700'}`}>المخزون الخاص (OFF-MARKET)</h4>
                    <p className={`text-xs leading-5 ${isDark ? 'text-amber-200/70' : 'text-amber-800/70'}`}>
                        هنا يمكنك إضافة العقارات المعروضة لديك بدون نشرها للعامة. استخدم هذا القسم لإدارة الصفقات الخاصة والمخزون الداخلي.
                    </p>
                </div>
            </div>

            <button className="w-full py-3 rounded-xl border-2 border-dashed border-amber-500/30 text-amber-500 text-sm font-bold flex items-center justify-center gap-2 hover:bg-amber-500/10 transition-colors">
                <Plus className="w-4 h-4" /> إضافة للمخزون
            </button>

            {/* Empty State / Example Item */}
            <div className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
                <div className="flex justify-between items-start mb-2">
                     <span className="px-2 py-1 rounded bg-red-500/10 text-red-500 text-[10px] font-bold">غير منشور</span>
                     <button className="text-gray-400 hover:text-white"><Edit className="w-4 h-4" /></button>
                </div>
                <h3 className={`font-bold text-sm mb-1 ${isDark ? 'text-white' : 'text-gray-900'}`}>أرض تجارية - طريق الملك فهد</h3>
                <p className="text-xs text-gray-500 mb-2">المساحة: 2500م² • السوم: 15,000 للمتر</p>
                <div className="flex items-center gap-2 text-[10px] text-gray-400">
                    <Calendar className="w-3 h-3" />
                    <span>أضيفت قبل يومين</span>
                </div>
            </div>
        </div>
    )
}

// ==========================================
// 3. SALES TEAM VIEW
// ==========================================
function SalesTeamView({ isDark }: { isDark: boolean }) {
    return (
        <div className="space-y-4">
             <div className="grid grid-cols-2 gap-3 mb-4">
                <div className={`p-3 rounded-2xl ${isDark ? 'bg-[#151a2d]' : 'bg-white shadow-sm'}`}>
                    <span className="text-xs text-gray-500 block mb-1">إجمالي المبيعات</span>
                    <span className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>12.4M</span>
                </div>
                <div className={`p-3 rounded-2xl ${isDark ? 'bg-[#151a2d]' : 'bg-white shadow-sm'}`}>
                    <span className="text-xs text-gray-500 block mb-1">الصفقات المغلقة</span>
                    <span className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>8</span>
                </div>
             </div>
             
             <h3 className={`text-sm font-bold mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>أداء الفريق</h3>
             {[1, 2, 3].map((i) => (
                 <div key={i} className={`flex items-center gap-3 p-3 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
                     <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-xs">SA</div>
                     <div className="flex-1">
                         <div className="flex justify-between mb-1">
                             <span className={`text-sm font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>سارة أحمد</span>
                             <span className="text-xs text-emerald-500 font-bold">120%</span>
                         </div>
                         <div className="h-1.5 w-full bg-gray-700 rounded-full overflow-hidden">
                             <div className="h-full bg-emerald-500 w-[80%]" />
                         </div>
                     </div>
                 </div>
             ))}
        </div>
    )
}

// ==========================================
// 4. REQUESTS VIEW (UPDATED FILTERS & SORT)
// ==========================================
function MyRequestsView({ isDark }: { isDark: boolean }) {
    // Filter State
    const [transType, setTransType] = useState<"buy" | "rent" | "exchange">("buy");
    const [userTypeFilter, setUserTypeFilter] = useState<"broker" | "seeker" | "developer">("broker");
    const [sortOrder, setSortOrder] = useState<"recent" | "price_high" | "price_low">("recent");

    // UI State
    const [isFilterOpen, setIsFilterOpen] = useState(false);

    // Mock Data (Enriched for sorting)
    const requests = [
        { id: 1, type: "buy", userType: "seeker", title: "مطلوب فيلا شمال الرياض", budget: "2.5M - 3M", price: 2500000, date: '2023-10-01', status: "نشط", aiMatch: 3 },
        { id: 2, type: "rent", userType: "seeker", title: "مطلوب شقة عائلية", budget: "40k - 50k", price: 45000, date: '2023-10-05', status: "جديد", aiMatch: 0 },
        { id: 3, type: "exchange", userType: "broker", title: "بدل أرض في جدة بفيلا", budget: "فرق 200k", price: 200000, date: '2023-09-20', status: "نشط", aiMatch: 1 },
        { id: 4, type: "buy", userType: "developer", title: "مطلوب أرض خام", budget: "15M+", price: 15000000, date: '2023-10-06', status: "نشط", aiMatch: 5 },
        { id: 5, type: "buy", userType: "broker", title: "مطلوب عمائر تجارية", budget: "10M - 12M", price: 11000000, date: '2023-10-02', status: "عاجل", aiMatch: 2 },
    ];

    // Filter Logic
    let filtered = requests.filter(r => 
        r.userType === userTypeFilter && r.type === transType
    );

    // Sort Logic
    filtered = filtered.sort((a, b) => {
        if (sortOrder === 'price_high') return b.price - a.price;
        if (sortOrder === 'price_low') return a.price - b.price;
        return b.id - a.id; // Recent (mock ID as proxy for date)
    });

    return (
         <div className="space-y-4">
            <button className="w-full py-3 rounded-xl border-2 border-dashed border-gray-500/30 text-gray-500 text-sm font-bold flex items-center justify-center gap-2 hover:bg-white/5 transition-colors">
                <Plus className="w-4 h-4" /> إضافة طلب جديد
            </button>

            {/* HEADER ROW: TABS + SORT FILTER */}
            <div className="flex items-center gap-2">
                
                {/* 1. USER SOURCE TABS (Scrollable) */}
                <div className="flex-1 flex gap-2 overflow-x-auto no-scrollbar">
                    <button 
                        onClick={() => setUserTypeFilter("broker")}
                        className={`px-4 py-2.5 rounded-xl text-xs font-bold border transition-all whitespace-nowrap ${
                            userTypeFilter === "broker" 
                            ? "bg-amber-500 text-white border-amber-500 shadow-md shadow-amber-500/20" 
                            : isDark ? "border-white/10 text-gray-400 hover:bg-white/5" : "border-gray-200 text-gray-500 hover:bg-gray-50"
                        }`}
                    >
                        طلبات الوسطاء
                    </button>
                    <button 
                        onClick={() => setUserTypeFilter("seeker")}
                        className={`px-4 py-2.5 rounded-xl text-xs font-bold border transition-all whitespace-nowrap ${
                            userTypeFilter === "seeker" 
                            ? "bg-purple-500 text-white border-purple-500 shadow-md shadow-purple-500/20" 
                            : isDark ? "border-white/10 text-gray-400 hover:bg-white/5" : "border-gray-200 text-gray-500 hover:bg-gray-50"
                        }`}
                    >
                        طلبات الباحثين
                    </button>
                    <button 
                        onClick={() => setUserTypeFilter("developer")}
                        className={`px-4 py-2.5 rounded-xl text-xs font-bold border transition-all whitespace-nowrap ${
                            userTypeFilter === "developer" 
                            ? "bg-blue-500 text-white border-blue-500 shadow-md shadow-blue-500/20" 
                            : isDark ? "border-white/10 text-gray-400 hover:bg-white/5" : "border-gray-200 text-gray-500 hover:bg-gray-50"
                        }`}
                    >
                        طلبات المطورين
                    </button>
                </div>

                {/* 2. COMPACT SORT/FILTER BUTTON */}
                <div className="relative shrink-0">
                    <button 
                        onClick={() => setIsFilterOpen(!isFilterOpen)}
                        className={`h-[42px] px-3 rounded-xl border flex items-center gap-2 transition-all ${
                            isDark 
                            ? 'bg-[#151a2d] border-white/10 text-white hover:border-cyan-500/50' 
                            : 'bg-white border-gray-200 text-gray-700 hover:border-blue-500/50'
                        }`}
                    >
                        <Filter className="w-4 h-4 text-cyan-500" />
                        <span className="text-xs font-bold hidden sm:inline-block">ترتيب وتصفية</span>
                        <span className="text-xs font-bold sm:hidden">تصفية</span>
                    </button>

                    {/* DROPDOWN MENU */}
                    {isFilterOpen && (
                        <>
                            <div className="fixed inset-0 z-10" onClick={() => setIsFilterOpen(false)} />
                            <div className={`absolute left-0 top-full mt-2 w-48 rounded-xl border shadow-xl z-20 overflow-hidden ${isDark ? 'bg-[#1e293b] border-white/10 shadow-black/50' : 'bg-white border-gray-100 shadow-gray-200'}`}>
                                
                                {/* Section 1: Type */}
                                <div className="p-2 border-b border-dashed border-gray-500/20">
                                    <span className="text-[10px] font-bold text-gray-500 block mb-1 px-2">نوع الطلب</span>
                                    <button onClick={() => { setTransType("buy"); setIsFilterOpen(false); }} className={`w-full px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors ${transType === 'buy' ? 'bg-cyan-500/10 text-cyan-500' : 'text-gray-400 hover:bg-white/5'}`}>
                                        <Key className="w-3.5 h-3.5" /> طلبات شراء
                                        {transType === 'buy' && <CheckCircle className="w-3 h-3 mr-auto" />}
                                    </button>
                                    <button onClick={() => { setTransType("rent"); setIsFilterOpen(false); }} className={`w-full px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors ${transType === 'rent' ? 'bg-purple-500/10 text-purple-500' : 'text-gray-400 hover:bg-white/5'}`}>
                                        <Briefcase className="w-3.5 h-3.5" /> طلبات إيجار
                                        {transType === 'rent' && <CheckCircle className="w-3 h-3 mr-auto" />}
                                    </button>
                                    <button onClick={() => { setTransType("exchange"); setIsFilterOpen(false); }} className={`w-full px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors ${transType === 'exchange' ? 'bg-emerald-500/10 text-emerald-500' : 'text-gray-400 hover:bg-white/5'}`}>
                                        <ArrowRightLeft className="w-3.5 h-3.5" /> طلبات بدل
                                        {transType === 'exchange' && <CheckCircle className="w-3 h-3 mr-auto" />}
                                    </button>
                                </div>

                                {/* Section 2: Sort */}
                                <div className="p-2">
                                    <span className="text-[10px] font-bold text-gray-500 block mb-1 px-2">الترتيب</span>
                                    <button onClick={() => { setSortOrder("recent"); setIsFilterOpen(false); }} className={`w-full px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors ${sortOrder === 'recent' ? 'text-white bg-white/10' : 'text-gray-400 hover:bg-white/5'}`}>
                                        <Clock className="w-3.5 h-3.5" /> المضاف مؤخراً
                                    </button>
                                    <button onClick={() => { setSortOrder("price_high"); setIsFilterOpen(false); }} className={`w-full px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors ${sortOrder === 'price_high' ? 'text-white bg-white/10' : 'text-gray-400 hover:bg-white/5'}`}>
                                        <SortDesc className="w-3.5 h-3.5" /> السعر: الأعلى
                                    </button>
                                    <button onClick={() => { setSortOrder("price_low"); setIsFilterOpen(false); }} className={`w-full px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors ${sortOrder === 'price_low' ? 'text-white bg-white/10' : 'text-gray-400 hover:bg-white/5'}`}>
                                        <SortAsc className="w-3.5 h-3.5" /> السعر: الأقل
                                    </button>
                                </div>

                            </div>
                        </>
                    )}
                </div>
            </div>

            {/* RESULTS LIST */}
            {filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center border-2 border-dashed border-gray-500/10 rounded-3xl">
                    <div className="w-12 h-12 rounded-full bg-gray-500/10 flex items-center justify-center mb-3">
                        <Search className="w-5 h-5 text-gray-400" />
                    </div>
                    <p className="text-sm font-bold text-gray-500">لا توجد طلبات مطابقة</p>
                    <p className="text-xs text-gray-400 mt-1">حاول تغيير الفلاتر أعلاه</p>
                </div>
            ) : filtered.map((req) => (
                <div key={req.id} className={`p-4 rounded-2xl border transition-all hover:border-cyan-500/30 ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
                    <div className="flex justify-between items-start mb-2">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                    req.userType === 'broker' ? 'bg-amber-500/10 text-amber-500' : 
                                    req.userType === 'developer' ? 'bg-blue-500/10 text-blue-500' : 'bg-purple-500/10 text-purple-500'
                                }`}>
                                    {req.userType === 'broker' ? 'وسيط' : req.userType === 'developer' ? 'مطور' : 'باحث'}
                                </span>
                                <h3 className={`font-bold text-sm ${isDark ? 'text-white' : 'text-gray-900'}`}>{req.title}</h3>
                            </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-500 text-[10px] font-bold">{req.status}</span>
                    </div>
                    <p className="text-xs text-gray-500 mb-3 font-mono">الميزانية: {req.budget}</p>
                    
                    {req.aiMatch > 0 && (
                        <div className="flex items-center gap-2 p-2 rounded-lg bg-blue-500/5 border border-blue-500/10">
                            <Zap className="w-4 h-4 text-blue-400 animate-pulse" />
                            <span className={`text-[10px] ${isDark ? 'text-blue-300' : 'text-blue-700'}`}>
                                وجد الذكاء الاصطناعي {req.aiMatch} عروض مطابقة
                            </span>
                            <ArrowRight className="w-3 h-3 text-blue-400 mr-auto rtl:ml-0 rtl:mr-auto ltr:ml-auto ltr:mr-0" />
                        </div>
                    )}
                </div>
            ))}
         </div>
    )
}

// ==========================================
// 5. MAIN EXPORT
// ==========================================
export function DetailViewContainer({ viewId, onBack }: { viewId: string; onBack: () => void }) {
    const { theme } = useTheme();
    const isDark = theme === "dark";

    return (
        <motion.div 
            initial={{ opacity: 0, y: 10 }} 
            animate={{ opacity: 1, y: 0 }} 
            className="pb-20"
        >
            {/* RENDER VIEW BASED ON ID */}
            {viewId === 'my_listings' && <MyListingsView isDark={isDark} />}
            {viewId === 'inventory_view' && <InventoryView isDark={isDark} />}
            {viewId === 'sales_team' && <SalesTeamView isDark={isDark} />}
            {viewId === 'my_requests' && <MyRequestsView isDark={isDark} />}
            {viewId === 'analytics' && <AnalyticsDetailView isDark={isDark} />}
            {viewId === 'contracts' && <ContractsDetailView isDark={isDark} />}
            
            {/* Fallback */}
            {!['my_listings', 'sales_team', 'my_requests', 'inventory_view', 'analytics', 'contracts'].includes(viewId) && (
                <div className="p-10 text-center text-gray-500">
                    <p>محتوى قيد التطوير: {viewId}</p>
                </div>
            )}
        </motion.div>
    );
}

// ==========================================
// 5. ANALYTICS VIEW (Broker / Developer)
// ==========================================
function AnalyticsDetailView({ isDark }: { isDark: boolean }) {
    const [period, setPeriod] = useState<"week" | "month" | "quarter">("month");
    const kpis = [
        { label: "مشاهدات الإعلانات", value: "12,480", change: "+18%", up: true },
        { label: "استفسارات واردة", value: "234", change: "+9%", up: true },
        { label: "معدل التحويل", value: "3.2%", change: "-0.4%", up: false },
        { label: "صفقات مغلقة", value: "8", change: "+3", up: true },
    ];
    const months = ["أغس", "سبت", "أكت", "نوف", "ديس", "يناير"];
    const bars   = [40, 65, 55, 80, 70, 95];
    const topListings = [
        { title: "فيلا النرجس 5 غرف", views: 1820, leads: 34 },
        { title: "شقة الملقا 3 غرف", views: 1240, leads: 21 },
        { title: "أرض الياسمين", views: 890, leads: 15 },
    ];
    return (
        <div className="space-y-5">
            <div className={`flex rounded-2xl p-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                {([["week","أسبوع"],["month","شهر"],["quarter","ربع سنة"]] as const).map(([id,label]) => (
                    <button key={id} onClick={() => setPeriod(id)} className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${period===id ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : "text-gray-400"}`}>{label}</button>
                ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
                {kpis.map((k, i) => (
                    <motion.div key={i} initial={{ opacity:0, y:6 }} animate={{ opacity:1, y:0 }} transition={{ delay: i*0.07 }}
                        className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                        <p className={`text-[9px] font-bold mb-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>{k.label}</p>
                        <p className={`text-xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>{k.value}</p>
                        <span className={`text-[9px] font-bold flex items-center gap-0.5 mt-1 ${k.up ? "text-emerald-400" : "text-red-400"}`}>
                            {k.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}{k.change}
                        </span>
                    </motion.div>
                ))}
            </div>
            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                <p className={`text-xs font-black mb-4 ${isDark ? "text-white/60" : "text-gray-600"}`}>المشاهدات الشهرية</p>
                <div className="flex items-end gap-2 h-20">
                    {bars.map((h, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center gap-1">
                            <motion.div initial={{ height:0 }} animate={{ height:`${h}%` }} transition={{ duration:0.6, delay:i*0.08 }}
                                className={`w-full rounded-t-lg ${i===bars.length-1 ? "bg-cyan-500" : isDark ? "bg-white/15" : "bg-gray-200"}`} style={{ height:`${h}%` }} />
                            <span className="text-[8px] opacity-40">{months[i]}</span>
                        </div>
                    ))}
                </div>
            </div>
            <div>
                <p className={`text-xs font-black mb-3 ${isDark ? "text-white/60" : "text-gray-600"}`}>أداء الإعلانات</p>
                <div className="space-y-2">
                    {topListings.map((l, i) => (
                        <div key={i} className={`p-3 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black text-white shrink-0 ${i===0?"bg-amber-500":i===1?"bg-blue-500":"bg-gray-500"}`}>{i+1}</div>
                            <div className="flex-1 min-w-0">
                                <p className={`text-xs font-black ${isDark?"text-white":"text-gray-900"} truncate`}>{l.title}</p>
                                <div className="flex gap-3 mt-0.5">
                                    <span className={`text-[9px] ${isDark?"text-white/40":"text-gray-400"}`}><Eye className="w-2.5 h-2.5 inline ml-0.5" />{l.views.toLocaleString("ar-SA")}</span>
                                    <span className={`text-[9px] ${isDark?"text-cyan-400":"text-cyan-600"}`}><MessageSquare className="w-2.5 h-2.5 inline ml-0.5" />{l.leads}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

// ==========================================
// 6. CONTRACTS VIEW (Landlord Offers/Legal)
// ==========================================
function ContractsDetailView({ isDark }: { isDark: boolean }) {
    const [contracts, setContracts] = useState([
        { id: 1, title: "عقد بيع - فيلا النرجس", party: "فيصل الدوسري", amount: "3,200,000", status: "نشط", date: "2026-01-15", type: "بيع" },
        { id: 2, title: "اتفاقية أولية - شقة الملقا", party: "ريم الشهري", amount: "1,050,000", status: "بانتظار التوقيع", date: "2026-01-20", type: "بيع" },
        { id: 3, title: "عقد توثيق - أرض الياسمين", party: "طلال المنصور", amount: "1,200,000", status: "مكتمل", date: "2025-12-10", type: "بيع" },
    ]);
    const statusCfg: Record<string, string> = {
        "نشط": isDark ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" : "bg-emerald-50 text-emerald-700 border-emerald-200",
        "بانتظار التوقيع": isDark ? "bg-amber-500/15 text-amber-400 border-amber-500/25" : "bg-amber-50 text-amber-700 border-amber-200",
        "مكتمل": isDark ? "bg-blue-500/15 text-blue-400 border-blue-500/25" : "bg-blue-50 text-blue-700 border-blue-200",
    };
    return (
        <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
                {[
                    { label: "إجمالي", value: String(contracts.length), color: isDark?"text-white":"text-gray-900" },
                    { label: "نشط", value: String(contracts.filter(c=>c.status==="نشط").length), color: "text-emerald-400" },
                    { label: "مكتمل", value: String(contracts.filter(c=>c.status==="مكتمل").length), color: "text-blue-400" },
                ].map((s,i) => (
                    <div key={i} className={`p-3 rounded-2xl text-center border ${isDark?"bg-[#151a2d] border-white/5":"bg-white border-gray-100 shadow-sm"}`}>
                        <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
                        <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
                    </div>
                ))}
            </div>
            <button className={`w-full py-3 rounded-xl border-2 border-dashed text-sm font-bold flex items-center justify-center gap-2 hover:bg-blue-500/5 transition-colors ${isDark?"border-blue-500/30 text-blue-400":"border-blue-300 text-blue-500"}`}>
                <Plus className="w-4 h-4" /> إنشاء عقد جديد
            </button>
            <div className="space-y-3">
                {contracts.map((c, i) => (
                    <motion.div key={c.id} initial={{ opacity:0, y:6 }} animate={{ opacity:1, y:0 }} transition={{ delay:i*0.07 }}
                        className={`p-4 rounded-2xl border ${isDark?"bg-[#151a2d] border-white/5":"bg-white border-gray-100 shadow-sm"}`}>
                        <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                                <FileText className={`w-5 h-5 ${isDark?"text-blue-400":"text-blue-600"}`} />
                                <div>
                                    <p className={`text-xs font-black ${isDark?"text-white":"text-gray-900"}`}>{c.title}</p>
                                    <p className={`text-[9px] opacity-50`}>{c.party} · {c.date}</p>
                                </div>
                            </div>
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${statusCfg[c.status]||""}`}>{c.status}</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className={`text-sm font-black ${isDark?"text-white":"text-gray-900"}`}>{c.amount} ريال</span>
                            <div className="flex gap-2">
                                <button className={`px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 ${isDark?"bg-white/5 text-white/60 hover:bg-white/10":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                                    <Eye className="w-3 h-3" /> عرض
                                </button>
                                <button className={`px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 ${isDark?"bg-blue-500/15 text-blue-400 hover:bg-blue-500/25":"bg-blue-50 text-blue-600 hover:bg-blue-100"}`}>
                                    <Share2 className="w-3 h-3" /> مشاركة
                                </button>
                            </div>
                        </div>
                    </motion.div>
                ))}
            </div>
        </div>
    );
}