import { useState } from "react";
import { motion } from "motion/react";
import { 
  Handshake, MessageSquare, Calendar, Phone, CheckCircle, Clock, AlertTriangle,
  Users, Building, Star, TrendingUp, BarChart3, DollarSign, Zap, Target,
  PenTool, Image, Sparkles, Shield, Eye, EyeOff, MapPin, FileText,
  Search, Heart, Bell, Filter, ArrowUpRight, Activity, Cpu, ChevronRight,
  Megaphone, Package, PieChart, Home, ArrowRight
} from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

// ============================================================================
// 1. NEGOTIATION AGENT VIEW (Broker)
// ============================================================================
export function NegotiationAgentView({ isDark }: { isDark: boolean }) {
  const [activeTab, setActiveTab] = useState<"active" | "scheduled" | "completed">("active");

  const negotiations = [
    { id: 1, client: "أحمد المنصور", property: "فيلا حي النرجس", price: "2.5M", status: "جاري التفاوض", progress: 60, lastMsg: "قدم عرض 2.3M", time: "منذ ساعة" },
    { id: 2, client: "سارة العتيبي", property: "شقة حي الياسمين", price: "800K", status: "عرض مقدم", progress: 40, lastMsg: "تطلب خصم 5%", time: "منذ 3 ساعات" },
    { id: 3, client: "محمد الشمري", property: "أرض تجارية", price: "5M", status: "قريب من الإغلاق", progress: 85, lastMsg: "وافق على الشروط", time: "منذ يوم" },
  ];

  const scheduled = [
    { id: 1, client: "نواف القحطاني", date: "الأحد 15 مارس", time: "10:00 ص", type: "معاينة", location: "حي العليا" },
    { id: 2, client: "ريم السالم", date: "الاثنين 16 مارس", time: "2:00 م", type: "توقيع", location: "المكتب الرئيسي" },
  ];

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className={`p-3 rounded-2xl text-center ${isDark ? 'bg-purple-500/10 border border-purple-500/20' : 'bg-purple-50 border border-purple-200'}`}>
          <p className="text-xl font-black text-purple-400">12</p>
          <p className="text-[10px] opacity-60">مفاوضة نشطة</p>
        </div>
        <div className={`p-3 rounded-2xl text-center ${isDark ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-emerald-50 border border-emerald-200'}`}>
          <p className="text-xl font-black text-emerald-400">5</p>
          <p className="text-[10px] opacity-60">صفقة مغلقة</p>
        </div>
        <div className={`p-3 rounded-2xl text-center ${isDark ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-amber-50 border border-amber-200'}`}>
          <p className="text-xl font-black text-amber-400">3</p>
          <p className="text-[10px] opacity-60">موعد قادم</p>
        </div>
      </div>

      {/* Tabs */}
      <div className={`flex gap-1 p-1 rounded-xl ${isDark ? 'bg-white/5' : 'bg-gray-100'}`}>
        {[
          { key: "active", label: "نشطة" },
          { key: "scheduled", label: "المواعيد" },
          { key: "completed", label: "مكتملة" },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === tab.key
                ? isDark ? 'bg-purple-500 text-white shadow-lg' : 'bg-purple-500 text-white'
                : isDark ? 'text-white/50' : 'text-gray-500'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Active Negotiations */}
      {activeTab === "active" && (
        <div className="space-y-3">
          {negotiations.map((n) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: n.id * 0.05 }}
              className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{n.client}</p>
                  <p className="text-[10px] opacity-60">{n.property} • {n.price} ريال</p>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                  n.progress > 80 ? 'bg-emerald-500/20 text-emerald-400' :
                  n.progress > 50 ? 'bg-amber-500/20 text-amber-400' :
                  'bg-blue-500/20 text-blue-400'
                }`}>{n.status}</span>
              </div>
              <div className={`flex items-center gap-2 p-2 rounded-lg mb-2 ${isDark ? 'bg-white/5' : 'bg-gray-50'}`}>
                <MessageSquare className="w-3 h-3 text-cyan-500" />
                <span className="text-[10px] opacity-70 flex-1">{n.lastMsg}</span>
                <span className="text-[9px] opacity-40">{n.time}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className={`flex-1 h-1.5 rounded-full ${isDark ? 'bg-white/10' : 'bg-gray-100'}`}>
                  <div className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full" style={{ width: `${n.progress}%` }} />
                </div>
                <span className="text-[9px] font-bold text-purple-400">{n.progress}%</span>
              </div>
              <div className="flex gap-2 mt-3">
                <button className={`flex-1 py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 ${isDark ? 'bg-purple-500/20 text-purple-400' : 'bg-purple-100 text-purple-600'}`}>
                  <MessageSquare className="w-3 h-3" /> متابعة
                </button>
                <button className={`flex-1 py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 ${isDark ? 'bg-white/5 text-white/60' : 'bg-gray-100 text-gray-600'}`}>
                  <Phone className="w-3 h-3" /> اتصال
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Scheduled */}
      {activeTab === "scheduled" && (
        <div className="space-y-3">
          {scheduled.map((s) => (
            <div key={s.id} className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isDark ? 'bg-cyan-500/20' : 'bg-cyan-100'}`}>
                  <Calendar className="w-5 h-5 text-cyan-500" />
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{s.client}</p>
                  <p className="text-[10px] opacity-60">{s.date} • {s.time}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-[9px] px-2 py-0.5 rounded-full ${isDark ? 'bg-cyan-500/20 text-cyan-400' : 'bg-cyan-100 text-cyan-600'}`}>{s.type}</span>
                    <span className="text-[9px] opacity-50 flex items-center gap-1"><MapPin className="w-2.5 h-2.5" /> {s.location}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Completed */}
      {activeTab === "completed" && (
        <div className="space-y-3">
          {[1, 2].map(i => (
            <div key={i} className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>صفقة فيلا حي الملقا</p>
                  <p className="text-[10px] opacity-60">تم الإغلاق بسعر 3.2M ريال</p>
                </div>
                <span className="text-[10px] text-emerald-500 font-bold">+2.5%</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 2. OWNERS MANAGEMENT VIEW (Broker)
// ============================================================================
export function OwnersManagementView({ isDark }: { isDark: boolean }) {
  const owners = [
    { id: 1, name: "سعد القحطاني", properties: 5, status: "نشط", lastContact: "اليوم", rating: 4.8, deals: 3 },
    { id: 2, name: "فهد المطيري", properties: 2, status: "جديد", lastContact: "أمس", rating: 0, deals: 0 },
    { id: 3, name: "عبدالرحمن الغامدي", properties: 8, status: "VIP", lastContact: "منذ 3 أيام", rating: 4.9, deals: 7 },
    { id: 4, name: "هند السبيعي", properties: 1, status: "متوقف", lastContact: "منذ أسبوع", rating: 3.5, deals: 1 },
  ];

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className={`p-4 rounded-2xl ${isDark ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-emerald-50 border border-emerald-200'}`}>
          <p className="text-2xl font-black text-emerald-400">16</p>
          <p className="text-[10px] opacity-60">إجمالي الملاك</p>
        </div>
        <div className={`p-4 rounded-2xl ${isDark ? 'bg-blue-500/10 border border-blue-500/20' : 'bg-blue-50 border border-blue-200'}`}>
          <p className="text-2xl font-black text-blue-400">42</p>
          <p className="text-[10px] opacity-60">عقار مُدار</p>
        </div>
      </div>

      {/* Owners List */}
      <div className="space-y-3">
        {owners.map((owner, i) => (
          <motion.div
            key={owner.id}
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.06 }}
            className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-white ${
                owner.status === 'VIP' ? 'bg-gradient-to-tr from-amber-500 to-yellow-400' :
                owner.status === 'نشط' ? 'bg-gradient-to-tr from-emerald-500 to-teal-500' :
                owner.status === 'جديد' ? 'bg-gradient-to-tr from-blue-500 to-cyan-500' :
                'bg-gradient-to-tr from-gray-500 to-gray-600'
              }`}>
                {owner.name.charAt(0)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{owner.name}</p>
                  {owner.status === "VIP" && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500 text-black font-black">VIP</span>}
                </div>
                <div className="flex items-center gap-3 text-[10px] opacity-60">
                  <span className="flex items-center gap-1"><Building className="w-3 h-3" /> {owner.properties} عقار</span>
                  <span className="flex items-center gap-1"><Handshake className="w-3 h-3" /> {owner.deals} صفقة</span>
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {owner.lastContact}</span>
                </div>
                {owner.rating > 0 && (
                  <div className="flex items-center gap-1 mt-1">
                    {[1, 2, 3, 4, 5].map(s => (
                      <Star key={s} className={`w-3 h-3 ${s <= Math.floor(owner.rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-600'}`} />
                    ))}
                    <span className="text-[9px] text-amber-400 font-bold mr-1">{owner.rating}</span>
                  </div>
                )}
              </div>
              <ChevronRight className="w-4 h-4 opacity-30" />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 3. GROWTH AGENT VIEW (Developer)
// ============================================================================
export function GrowthAgentView({ isDark }: { isDark: boolean }) {
  const campaigns = [
    { id: 1, name: "حملة مشروع النرجس", status: "نشطة", reach: "45.2K", clicks: "3.8K", leads: 124, budget: "15K", spent: "8.5K" },
    { id: 2, name: "إعلان واحة الياسمين", status: "مجدولة", reach: "0", clicks: "0", leads: 0, budget: "20K", spent: "0" },
  ];

  return (
    <div className="space-y-4">
      {/* Performance Summary */}
      <div className={`p-4 rounded-2xl border relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-emerald-950 to-teal-950 border-emerald-500/30' : 'bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200'}`}>
        <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[9px] font-black text-emerald-400">AI ACTIVE</span>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-6">
          <div className="text-center">
            <p className="text-2xl font-black text-emerald-400">+27%</p>
            <p className="text-[10px] opacity-60">نمو المبيعات</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-black text-cyan-400">340</p>
            <p className="text-[10px] opacity-60">عملاء محتملين</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-black text-amber-400">89%</p>
            <p className="text-[10px] opacity-60">معدل التحويل</p>
          </div>
        </div>
      </div>

      {/* AI Recommendations */}
      <div className={`p-3 rounded-2xl border ${isDark ? 'bg-blue-500/5 border-blue-500/20' : 'bg-blue-50 border-blue-200'}`}>
        <div className="flex items-center gap-2 mb-2">
          <Zap className="w-4 h-4 text-blue-400 animate-pulse" />
          <span className="text-xs font-black text-blue-400">توصيات الذكاء الاصطناعي</span>
        </div>
        <div className="space-y-2">
          <div className={`p-2 rounded-lg text-[10px] ${isDark ? 'bg-white/5' : 'bg-white'}`}>
            <span className="text-emerald-400 font-bold">↑ زيادة الميزانية</span> لحملة النرجس — أداء ممتاز، ROI 340%
          </div>
          <div className={`p-2 rounded-lg text-[10px] ${isDark ? 'bg-white/5' : 'bg-white'}`}>
            <span className="text-amber-400 font-bold">⚡ أفضل وقت للنشر</span> الأربعاء 8 مساءً — تفاعل أعلى بـ 60%
          </div>
        </div>
      </div>

      {/* Campaigns */}
      <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? 'text-white/70' : 'text-gray-600'}`}>
        <Megaphone className="w-4 h-4 text-emerald-400" /> الحملات التسويقية
      </h4>
      {campaigns.map((c) => (
        <div key={c.id} className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{c.name}</p>
              <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold mt-1 inline-block ${
                c.status === 'نشطة' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
              }`}>{c.status}</span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className={`p-2 rounded-lg text-center ${isDark ? 'bg-white/5' : 'bg-gray-50'}`}>
              <p className="text-xs font-black text-blue-400">{c.reach}</p>
              <p className="text-[9px] opacity-50">وصول</p>
            </div>
            <div className={`p-2 rounded-lg text-center ${isDark ? 'bg-white/5' : 'bg-gray-50'}`}>
              <p className="text-xs font-black text-cyan-400">{c.clicks}</p>
              <p className="text-[9px] opacity-50">نقرات</p>
            </div>
            <div className={`p-2 rounded-lg text-center ${isDark ? 'bg-white/5' : 'bg-gray-50'}`}>
              <p className="text-xs font-black text-emerald-400">{c.leads}</p>
              <p className="text-[9px] opacity-50">عملاء</p>
            </div>
          </div>
          <div className="flex items-center justify-between mt-3 text-[10px] opacity-60">
            <span>الميزانية: {c.budget} ريال</span>
            <span>المصروف: {c.spent} ريال</span>
          </div>
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// 4. EDITOR AGENT VIEW (Landlord)
// ============================================================================
export function EditorAgentView({ isDark }: { isDark: boolean }) {
  const [isEnhancing, setIsEnhancing] = useState(false);

  const beforeAfter = [
    { before: "شقة للبيع حي الملقا", after: "شقة فاخرة مطلة على الحديقة في قلب حي الملقا الراقي" },
    { before: "3 غرف و2 حمام ومطبخ", after: "3 غرف نوم واسعة • حمامان بتشطيب رخامي • مطبخ مفتوح بتجهيزات عصرية" },
  ];

  return (
    <div className="space-y-4">
      {/* AI Status */}
      <div className={`p-4 rounded-2xl border ${isDark ? 'bg-pink-500/10 border-pink-500/20' : 'bg-pink-50 border-pink-200'}`}>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-500 flex items-center justify-center">
            <PenTool className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>EditorAgent</p>
            <p className="text-[10px] opacity-60">يحسّن وصف إعلانك وصورك تلقائياً</p>
          </div>
        </div>
        <button
          onClick={() => setIsEnhancing(!isEnhancing)}
          className="w-full py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-lg hover:scale-[0.98] transition-transform"
        >
          {isEnhancing ? "⏳ جاري التحسين..." : "✨ تحسين إعلاني الآن"}
        </button>
      </div>

      {/* Before/After */}
      <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? 'text-white/70' : 'text-gray-600'}`}>
        <Sparkles className="w-4 h-4 text-pink-400" /> نماذج التحسين
      </h4>
      {beforeAfter.map((item, i) => (
        <div key={i} className={`rounded-2xl border overflow-hidden ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
          <div className={`p-3 border-b ${isDark ? 'bg-red-500/5 border-white/5' : 'bg-red-50 border-red-100'}`}>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 font-bold">قبل</span>
            </div>
            <p className="text-[11px] opacity-60 line-through">{item.before}</p>
          </div>
          <div className={`p-3 ${isDark ? 'bg-emerald-500/5' : 'bg-emerald-50'}`}>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">بعد التحسين</span>
            </div>
            <p className={`text-[11px] font-bold ${isDark ? 'text-emerald-300' : 'text-emerald-700'}`}>{item.after}</p>
          </div>
        </div>
      ))}

      {/* Photo Enhancement */}
      <div className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
        <div className="flex items-center gap-2 mb-3">
          <Image className="w-4 h-4 text-blue-400" />
          <span className="text-xs font-black">تحسين الصور</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {["إضاءة", "ألوان", "زوايا"].map((type, i) => (
            <div key={i} className={`p-3 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-gray-50'}`}>
              <div className={`w-8 h-8 rounded-lg mx-auto mb-1.5 flex items-center justify-center ${isDark ? 'bg-blue-500/20' : 'bg-blue-100'}`}>
                <Sparkles className="w-4 h-4 text-blue-400" />
              </div>
              <p className="text-[10px] font-bold">{type}</p>
              <p className="text-[9px] text-emerald-400">محسّن ✓</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 5. VALUATION AGENT VIEW (Landlord)
// ============================================================================
export function ValuationAgentView({ isDark }: { isDark: boolean }) {
  return (
    <div className="space-y-4">
      {/* Main Valuation Card */}
      <div className={`p-5 rounded-2xl border relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-emerald-950 to-teal-950 border-emerald-500/30' : 'bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200'}`}>
        <div className="text-center mb-4">
          <p className="text-[10px] opacity-60 mb-1">التقييم العادل لعقارك</p>
          <p className="text-4xl font-black text-emerald-400">2,150,000</p>
          <p className="text-xs opacity-60">ريال سعودي</p>
        </div>

        {/* Price Range */}
        <div className="relative h-3 rounded-full bg-gray-700 overflow-hidden mb-2 flex">
          <div className="w-1/4 bg-red-500 opacity-40" />
          <div className="w-1/2 bg-emerald-500 relative">
            <div className="absolute top-0 bottom-0 right-1/3 w-1.5 bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)] rounded-full" />
          </div>
          <div className="w-1/4 bg-orange-500 opacity-40" />
        </div>
        <div className="flex justify-between text-[9px] opacity-50 mb-4">
          <span>1.8M منخفض</span>
          <span>2.15M عادل</span>
          <span>2.5M مرتفع</span>
        </div>

        <div className={`p-3 rounded-xl ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
          <p className="text-[10px] opacity-70 text-center">مبني على تحليل <span className="font-bold text-emerald-400">247</span> صفقة حقيقية في نفس المنطقة</p>
        </div>
      </div>

      {/* Market Comparison */}
      <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? 'text-white/70' : 'text-gray-600'}`}>
        <BarChart3 className="w-4 h-4 text-emerald-400" /> مقارنة السوق
      </h4>
      <div className="space-y-2">
        {[
          { label: "متوسط أسعار المنطقة", value: "2.3M", diff: "+7%", color: "amber" },
          { label: "سعر المتر (المنطقة)", value: "4,300", diff: "متوسط", color: "blue" },
          { label: "صفقات آخر 30 يوم", value: "18", diff: "نشط", color: "emerald" },
          { label: "متوسط فترة البيع", value: "45 يوم", diff: "طبيعي", color: "purple" },
        ].map((item, i) => (
          <div key={i} className={`flex items-center justify-between p-3 rounded-xl ${isDark ? 'bg-[#151a2d] border border-white/5' : 'bg-white border border-gray-100'}`}>
            <span className="text-[11px] opacity-70">{item.label}</span>
            <div className="flex items-center gap-2">
              <span className={`text-xs font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{item.value}</span>
              <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${
                item.color === "emerald" ? "bg-emerald-500/20 text-emerald-400" :
                item.color === "amber" ? "bg-amber-500/20 text-amber-400" :
                item.color === "blue" ? "bg-blue-500/20 text-blue-400" :
                "bg-purple-500/20 text-purple-400"
              }`}>{item.diff}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Factors */}
      <div className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
        <p className="text-xs font-black mb-3">عوامل التقييم</p>
        {[
          { factor: "الموقع والمنطقة", score: 92, icon: MapPin },
          { factor: "المساحة والتصميم", score: 85, icon: Home },
          { factor: "حالة العقار", score: 78, icon: Shield },
          { factor: "الخدمات القريبة", score: 88, icon: Building },
        ].map((f, i) => (
          <div key={i} className="flex items-center gap-3 mb-2 last:mb-0">
            <f.icon className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[10px] flex-1 opacity-70">{f.factor}</span>
            <div className={`w-20 h-1.5 rounded-full ${isDark ? 'bg-white/10' : 'bg-gray-100'}`}>
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${f.score}%` }} />
            </div>
            <span className="text-[9px] font-bold text-emerald-400 w-8 text-left">{f.score}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 6. PERSONAL AGENT VIEW (Seeker - Mem0)
// ============================================================================
export function PersonalAgentView({ isDark }: { isDark: boolean }) {
  const [isListening, setIsListening] = useState(false);

  const memories = [
    { key: "الميزانية", value: "2M - 3M ريال", icon: DollarSign, color: "emerald" },
    { key: "المنطقة المفضلة", value: "شمال الرياض", icon: MapPin, color: "blue" },
    { key: "نوع العقار", value: "فيلا مودرن", icon: Home, color: "purple" },
    { key: "عدد الغرف", value: "5+ غرف", icon: Building, color: "amber" },
  ];

  const suggestions = [
    { text: "فيلا 6 غرف في حي النرجس — تطابق 95%", match: 95 },
    { text: "فيلا مودرن حي العارض — تطابق 88%", match: 88 },
    { text: "فيلا دوبلكس حي الملقا — تطابق 82%", match: 82 },
  ];

  return (
    <div className="space-y-4">
      {/* Agent Status */}
      <div className={`p-4 rounded-2xl border relative ${isDark ? 'bg-purple-500/10 border-purple-500/20' : 'bg-purple-50 border-purple-200'}`}>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500 to-fuchsia-500 flex items-center justify-center shadow-lg">
            <Cpu className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>وكيلك الشخصي</p>
            <p className="text-[10px] opacity-60">يتذكر تفضيلاتك ويبحث لك تلقائياً</p>
          </div>
          <div className="mr-auto flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[9px] font-black text-emerald-400">نشط</span>
          </div>
        </div>
        <button
          onClick={() => setIsListening(!isListening)}
          className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all ${
            isListening
              ? 'bg-red-500 text-white animate-pulse'
              : 'bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white shadow-lg'
          }`}
        >
          {isListening ? "🎙️ أنا أسمعك... تكلم الآن" : "🎤 تكلم مع وكيلك"}
        </button>
      </div>

      {/* Memory (What the agent knows) */}
      <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? 'text-white/70' : 'text-gray-600'}`}>
        <Activity className="w-4 h-4 text-purple-400" /> ذاكرة وكيلك
      </h4>
      <div className="grid grid-cols-2 gap-2">
        {memories.map((m, i) => (
          <div key={i} className={`p-3 rounded-xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100'}`}>
            <m.icon className={`w-4 h-4 mb-1.5 ${
              m.color === "emerald" ? "text-emerald-400" :
              m.color === "blue" ? "text-blue-400" :
              m.color === "purple" ? "text-purple-400" : "text-amber-400"
            }`} />
            <p className="text-[9px] opacity-50">{m.key}</p>
            <p className={`text-[11px] font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{m.value}</p>
          </div>
        ))}
      </div>

      {/* AI Suggestions */}
      <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? 'text-white/70' : 'text-gray-600'}`}>
        <Target className="w-4 h-4 text-cyan-400" /> اقتراحات ذكية لك
      </h4>
      <div className="space-y-2">
        {suggestions.map((s, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`flex items-center gap-3 p-3 rounded-xl border ${isDark ? 'bg-[#151a2d] border-white/5 hover:border-purple-500/30' : 'bg-white border-gray-100 hover:border-purple-200'} transition-colors cursor-pointer`}
          >
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isDark ? 'bg-purple-500/20' : 'bg-purple-100'}`}>
              <Home className="w-4 h-4 text-purple-400" />
            </div>
            <div className="flex-1">
              <p className="text-[11px] opacity-80">{s.text}</p>
            </div>
            <span className={`text-[10px] font-black ${s.match >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>{s.match}%</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 7. SEMANTIC SEARCH VIEW (Seeker)
// ============================================================================
export function SemanticSearchView({ isDark }: { isDark: boolean }) {
  const [query, setQuery] = useState("");

  const examples = [
    "ابي فيلا مودرن قريبة من مدارس شمال الرياض",
    "شقة عائلية بحديقة وموقف خاص",
    "أرض سكنية ميزانيتي مليون",
  ];

  const results = [
    { title: "فيلا مودرن حي النرجس", price: "2.5M", match: 97, area: "450م²", rooms: 5 },
    { title: "فيلا حي العارض الجديد", price: "2.2M", match: 91, area: "380م²", rooms: 4 },
    { title: "فيلا حي الملقا", price: "2.8M", match: 85, area: "500م²", rooms: 6 },
  ];

  return (
    <div className="space-y-4">
      {/* Search Input */}
      <div className={`p-4 rounded-2xl border ${isDark ? 'bg-blue-500/10 border-blue-500/20' : 'bg-blue-50 border-blue-200'}`}>
        <div className="flex items-center gap-2 mb-3">
          <Search className="w-5 h-5 text-blue-400" />
          <span className="text-xs font-black text-blue-400">البحث الدلالي بالذكاء الاصطناعي</span>
        </div>
        <div className={`flex items-center gap-2 p-3 rounded-xl ${isDark ? 'bg-black/30' : 'bg-white'}`}>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="اكتب بالعامية... مثال: ابي فيلا شرحه شمال الرياض"
            className="flex-1 bg-transparent text-xs outline-none"
          />
          <button className="p-2 rounded-lg bg-blue-500 text-white">
            <Search className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex flex-wrap gap-1.5 mt-3">
          {examples.map((ex, i) => (
            <button
              key={i}
              onClick={() => setQuery(ex)}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-bold transition-colors ${isDark ? 'bg-white/5 text-white/60 hover:bg-white/10' : 'bg-white text-gray-500 hover:bg-gray-100'}`}
            >
              {ex}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? 'text-white/70' : 'text-gray-600'}`}>
        <Zap className="w-4 h-4 text-blue-400" /> نتائج مطابقة
      </h4>
      {results.map((r, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.08 }}
          className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}
        >
          <div className="flex items-start justify-between mb-2">
            <div>
              <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{r.title}</p>
              <p className="text-[10px] opacity-60">{r.area} • {r.rooms} غرف</p>
            </div>
            <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full ${
              r.match >= 95 ? 'bg-emerald-500/20 text-emerald-400' : r.match >= 90 ? 'bg-blue-500/20 text-blue-400' : 'bg-amber-500/20 text-amber-400'
            }`}>
              <Target className="w-3 h-3" />
              <span className="text-[10px] font-black">{r.match}%</span>
            </div>
          </div>
          <p className={`text-sm font-black mb-2 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>{r.price} ريال</p>
          <div className="flex gap-2">
            <button className={`flex-1 py-2 rounded-xl text-[10px] font-bold ${isDark ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-100 text-blue-600'}`}>
              عرض التفاصيل
            </button>
            <button className={`py-2 px-4 rounded-xl text-[10px] font-bold ${isDark ? 'bg-white/5 text-white/60' : 'bg-gray-100 text-gray-600'}`}>
              <Heart className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

// ============================================================================
// 8. WISHLIST VIEW (Seeker)
// ============================================================================
export function WishlistView({ isDark }: { isDark: boolean }) {
  const [items, setItems] = useState([
    { id: 1, title: "فيلا مودرن حي النرجس", price: "2,500,000", type: "فيلا", status: "متاح", saved: "منذ 3 أيام" },
    { id: 2, title: "شقة فاخرة حي الياسمين", price: "800,000", type: "شقة", status: "متاح", saved: "منذ أسبوع" },
    { id: 3, title: "أرض سكنية حي العارض", price: "1,200,000", type: "أرض", status: "محجوز", saved: "منذ أسبوعين" },
    { id: 4, title: "فيلا دوبلكس حي الملقا", price: "3,100,000", type: "فيلا", status: "تم البيع", saved: "منذ شهر" },
  ]);

  return (
    <div className="space-y-4">
      {/* Header Stats */}
      <div className="flex gap-3">
        <div className={`flex-1 p-3 rounded-2xl text-center ${isDark ? 'bg-pink-500/10 border border-pink-500/20' : 'bg-pink-50 border border-pink-200'}`}>
          <Heart className="w-5 h-5 text-pink-500 mx-auto mb-1 fill-pink-500" />
          <p className="text-xl font-black text-pink-400">{items.length}</p>
          <p className="text-[10px] opacity-60">في المفضلة</p>
        </div>
        <div className={`flex-1 p-3 rounded-2xl text-center ${isDark ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-emerald-50 border border-emerald-200'}`}>
          <CheckCircle className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
          <p className="text-xl font-black text-emerald-400">{items.filter(i => i.status === "متاح").length}</p>
          <p className="text-[10px] opacity-60">لا يزال متاح</p>
        </div>
      </div>

      {/* Items */}
      {items.map((item, i) => (
        <motion.div
          key={item.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className={`p-4 rounded-2xl border ${
            item.status === 'تم البيع' ? 'opacity-50' : ''
          } ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}
        >
          <div className="flex gap-3">
            <div className={`w-16 h-16 rounded-xl flex items-center justify-center shrink-0 ${isDark ? 'bg-white/5' : 'bg-gray-100'}`}>
              <Home className="w-6 h-6 opacity-30" />
            </div>
            <div className="flex-1">
              <div className="flex items-start justify-between mb-1">
                <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{item.title}</p>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${
                  item.status === 'متاح' ? 'bg-emerald-500/20 text-emerald-400' :
                  item.status === 'محجوز' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-red-500/20 text-red-400'
                }`}>{item.status}</span>
              </div>
              <p className={`text-xs font-black mb-1 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>{item.price} ريال</p>
              <div className="flex items-center gap-2 text-[10px] opacity-50">
                <span>{item.type}</span>
                <span>•</span>
                <span>{item.saved}</span>
              </div>
            </div>
          </div>
          {item.status === 'متاح' && (
            <div className="flex gap-2 mt-3 pt-3 border-t border-dashed border-gray-500/20">
              <button className={`flex-1 py-2 rounded-xl text-[10px] font-bold ${isDark ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-100 text-blue-600'}`}>
                عرض التفاصيل
              </button>
              <button className={`flex-1 py-2 rounded-xl text-[10px] font-bold ${isDark ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-600'}`}>
                تواصل مع المالك
              </button>
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}

// ============================================================================
// 9. ANALYTICS VIEW (General)
// ============================================================================
export function AnalyticsView({ isDark }: { isDark: boolean }) {
  return (
    <div className="space-y-4">
      {/* Overview */}
      <div className={`p-4 rounded-2xl border ${isDark ? 'bg-indigo-500/10 border-indigo-500/20' : 'bg-indigo-50 border-indigo-200'}`}>
        <div className="flex items-center gap-2 mb-3">
          <BarChart3 className="w-5 h-5 text-indigo-400" />
          <span className="text-xs font-black text-indigo-400">تحليل السوق — المنطقة الحالية</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className={`p-3 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
            <p className="text-xl font-black text-indigo-400">4,200</p>
            <p className="text-[9px] opacity-60">سعر المتر (ر.س)</p>
          </div>
          <div className={`p-3 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
            <p className="text-xl font-black text-emerald-400">+12%</p>
            <p className="text-[9px] opacity-60">نمو سنوي</p>
          </div>
          <div className={`p-3 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
            <p className="text-xl font-black text-amber-400">856</p>
            <p className="text-[9px] opacity-60">صفقة (آخر 6 أشهر)</p>
          </div>
          <div className={`p-3 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
            <p className="text-xl font-black text-cyan-400">32</p>
            <p className="text-[9px] opacity-60">يوم (متوسط البيع)</p>
          </div>
        </div>
      </div>

      {/* Population/Demographics */}
      <div className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
        <p className="text-xs font-black mb-3">التركيبة السكانية</p>
        {[
          { label: "عائلات", percent: 45, color: "bg-blue-500" },
          { label: "أفراد", percent: 30, color: "bg-purple-500" },
          { label: "مستثمرين", percent: 25, color: "bg-amber-500" },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-3 mb-2">
            <span className="text-[10px] w-16 opacity-70">{item.label}</span>
            <div className={`flex-1 h-2 rounded-full ${isDark ? 'bg-white/10' : 'bg-gray-100'}`}>
              <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.percent}%` }} />
            </div>
            <span className="text-[10px] font-bold w-8 text-left">{item.percent}%</span>
          </div>
        ))}
      </div>

      {/* Trends */}
      <div className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
        <p className="text-xs font-black mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-400" /> التوقعات
        </p>
        <div className="space-y-2">
          <div className={`p-2.5 rounded-xl ${isDark ? 'bg-emerald-500/10' : 'bg-emerald-50'}`}>
            <p className="text-[10px] text-emerald-400 font-bold">↑ ارتفاع متوقع 8-12% خلال 6 أشهر</p>
            <p className="text-[9px] opacity-50 mt-0.5">مدعوم بمشاريع البنية التحتية القادمة</p>
          </div>
          <div className={`p-2.5 rounded-xl ${isDark ? 'bg-blue-500/10' : 'bg-blue-50'}`}>
            <p className="text-[10px] text-blue-400 font-bold">📊 طلب مرتفع على الفلل 300-500م²</p>
            <p className="text-[9px] opacity-50 mt-0.5">تمثل 62% من عمليات البحث</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 10. CONTRACTS VIEW
// ============================================================================
export function ContractsView({ isDark }: { isDark: boolean }) {
  const contracts = [
    { id: 1, title: "عقد بيع — فيلا حي النرجس", party: "أحمد المنصور", date: "15 مارس 2026", status: "نشط", value: "2.5M" },
    { id: 2, title: "عقد إيجار — شقة حي الورود", party: "سارة العتيبي", date: "1 فبراير 2026", status: "مكتمل", value: "45K/سنة" },
    { id: 3, title: "عقد بيع — أرض تجارية", party: "فهد المطيري", date: "10 يناير 2026", status: "قيد المراجعة", value: "5M" },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <div className={`p-3 rounded-2xl text-center ${isDark ? 'bg-emerald-500/10' : 'bg-emerald-50'}`}>
          <p className="text-xl font-black text-emerald-400">8</p>
          <p className="text-[10px] opacity-60">نشط</p>
        </div>
        <div className={`p-3 rounded-2xl text-center ${isDark ? 'bg-blue-500/10' : 'bg-blue-50'}`}>
          <p className="text-xl font-black text-blue-400">3</p>
          <p className="text-[10px] opacity-60">قيد المراجعة</p>
        </div>
        <div className={`p-3 rounded-2xl text-center ${isDark ? 'bg-gray-500/10' : 'bg-gray-50'}`}>
          <p className="text-xl font-black text-gray-400">24</p>
          <p className="text-[10px] opacity-60">مكتمل</p>
        </div>
      </div>

      {contracts.map((c, i) => (
        <motion.div
          key={c.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.06 }}
          className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}
        >
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center gap-2">
              <FileText className={`w-4 h-4 ${
                c.status === 'نشط' ? 'text-emerald-400' : c.status === 'قيد المراجعة' ? 'text-amber-400' : 'text-gray-400'
              }`} />
              <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{c.title}</p>
            </div>
            <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
              c.status === 'نشط' ? 'bg-emerald-500/20 text-emerald-400' :
              c.status === 'قيد المراجعة' ? 'bg-amber-500/20 text-amber-400' :
              'bg-gray-500/20 text-gray-400'
            }`}>{c.status}</span>
          </div>
          <div className="flex items-center gap-4 text-[10px] opacity-60">
            <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {c.party}</span>
            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {c.date}</span>
          </div>
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-dashed border-gray-500/20">
            <span className={`text-sm font-black ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>{c.value} ريال</span>
            <button className={`px-3 py-1.5 rounded-lg text-[10px] font-bold ${isDark ? 'bg-white/5 text-white/70' : 'bg-gray-100 text-gray-600'}`}>
              عرض العقد
            </button>
          </div>
        </motion.div>
      ))}
    </div>
  );
}