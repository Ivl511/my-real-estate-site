import { LucideIcon } from "lucide-react";

interface QuickActionButtonProps {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
}

export function QuickActionButton({ 
  icon: Icon, 
  label, 
  onClick,
  variant = 'secondary'
}: QuickActionButtonProps) {
  const baseClasses = "flex flex-col items-center justify-center gap-2 p-4 rounded-2xl transition-all active:scale-95";
  const variantClasses = variant === 'primary'
    ? "bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] text-white"
    : "bg-white text-[var(--aion-navy)] border-2 border-[var(--aion-gray-200)]";
  
  return (
    <button 
      onClick={onClick}
      className={`${baseClasses} ${variantClasses}`}
      style={{ boxShadow: 'var(--aion-shadow-md)' }}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
        variant === 'primary' ? 'bg-white/20' : 'bg-[var(--aion-navy)]/5'
      }`}>
        <Icon className="w-6 h-6" />
      </div>
      <span className="text-sm font-semibold">{label}</span>
    </button>
  );
}
