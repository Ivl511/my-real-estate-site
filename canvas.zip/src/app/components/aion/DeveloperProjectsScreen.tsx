import { motion, AnimatePresence } from "motion/react";
import {
  ArrowRight, MapPin, Building, CheckCircle, Star, Phone,
  MessageSquare, ChevronRight, Bed, Bath, Square, Ruler,
  Calendar, Shield, Award, Zap, Home, Tag, Users, Clock,
  TrendingUp, Heart, Share2, X, Check
} from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../context/ThemeContext";

// ── IMAGES ──
const IMG_PROJECT_1 = "https://images.unsplash.com/photo-1656158113009-c8f5b3268aca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1080&q=80";
const IMG_PROJECT_2 = "https://images.unsplash.com/photo-1764080400538-4487aa44172f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1080&q=80";
const IMG_PROJECT_3 = "https://images.unsplash.com/photo-1758193431355-54df41421657?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1080&q=80";
const IMG_INTERIOR  = "https://images.unsplash.com/photo-1757262798623-a215e869d708?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1080&q=80";
const IMG_PLAN      = "https://images.unsplash.com/photo-1721244653580-79577d2822a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1080&q=80";

// ── TYPES ──
interface Unit {
  id: string;
  code: string;
  type: string;
  subType: string;
  floor: string;
  landArea: number;
  builtArea: number;
  beds: number;
  baths: number;
  price: number;
  status: "available" | "reserved" | "sold";
  features: string[];
  facing: string;
  streets: number;
  deliveryReady: boolean;
  description?: string;
}

interface Project {
  id: string;
  name: string;
  developer: { name: string; logo: string; since: string; verified: boolean; phone: string };
  location: string;
  district: string;
  city: string;
  category: string;
  totalUnits: number;
  priceRange: { min: number; max: number };
  image: string;
  images: string[];
  description: string;
  amenities: string[];
  wafi: boolean;
  deliveryDate: string;
  completion: number;
  license: string;
  units: Unit[];
  badge: string;
  badgeColor: string;
}

// ── DATA ──
const DEVELOPER_PROJECTS: Project[] = [
  {
    id: "p1",
    name: "مشروع النخيل",
    developer: { name: "شركة رتال للتطوير العمراني", logo: "ر", since: "2010", verified: true, phone: "0114567890" },
    location: "الرياض، حي النرجس",
    district: "النرجس",
    city: "الرياض",
    category: "فلل سكنية",
    totalUnits: 10,
    priceRange: { min: 2800000, max: 4500000 },
    image: IMG_PROJECT_1,
    images: [IMG_PROJECT_1, IMG_INTERIOR, IMG_PLAN],
    description: "مشروع سكني فاخر يتكون من 10 فلل سكنية مودرن في قلب حي النرجس المميز. تتميز الفلل بتصاميم معمارية عصرية، تشطيبات عالية الجودة، وضمانات هيكلية شاملة لمدة 10 سنوات. موقع استراتيجي بالقرب من طريق الملك سلمان ومركز التسوق.",
    amenities: ["مسبح مشترك", "أمن 24/7", "حديقة مركزية", "غرفة حارس", "كاميرات مراقبة", "صالة رياضية"],
    wafi: true,
    deliveryDate: "ديسمبر 2025",
    completion: 75,
    license: "وافي-2024-1234",
    badge: "وافي ✓",
    badgeColor: "bg-blue-600",
    units: [
      { id: "u1", code: "A01", type: "فيلا", subType: "درج صالة", floor: "أرضي + أول", landArea: 450, builtArea: 560, beds: 5, baths: 4, price: 3200000, status: "available", features: ["مسبح خاص", "مصعد مؤسس", "مطبخ مجهز", "غرفة سائق"], facing: "شمال", streets: 2, deliveryReady: false, description: "نموذج A01 هو الأرقى في المشروع بتصميم درج صالة فاخر يمنح الخصوصية التامة للطابق الأول. الواجهة الشمالية توفر إضاءة طبيعية مثالية طوال اليوم. تشطيبات VIP بالكامل مع أجهزة سيمنز في المطبخ، مسبح خاص في الحديقة الخلفية، ومصعد مؤسس للمستقبل." },
      { id: "u2", code: "A02", type: "فيلا", subType: "درج داخلي", floor: "أرضي + أول", landArea: 400, builtArea: 480, beds: 5, baths: 3, price: 2900000, status: "available", features: ["تكييف مركزي", "واجهة حجر", "غرفة خادمة"], facing: "جنوب", streets: 1, deliveryReady: false, description: "نموذج A02 بتصميم الدرج الداخلي يوفر تدفقاً عملياً بين الأدوار وخصوصية عالية. الواجهة الجنوبية مكسوة بحجر طبيعي فاخر. تكييف مركزي بالكامل، وغرفة خادمة مستقلة. مناسب للعائلات الصغيرة والمتوسطة." },
      { id: "u3", code: "B01", type: "فيلا", subType: "درج صالة", floor: "أرضي + أول", landArea: 500, builtArea: 620, beds: 6, baths: 5, price: 4200000, status: "reserved", features: ["مسبح خاص", "مصعد", "ملاعب أطفال", "مجلس منفصل"], facing: "شمال شرق", streets: 3, deliveryReady: false, description: "نموذج B01 هو الأكبر مساحةً في المشروع بموقعه على 3 شوارع. يضم مجلس رجال منفصل بمدخل مستقل، مجلس نساء مجهز، ومسبح خاص. الإطلالة الشمالية الشرقية من أفضل الإطلالات في المشروع." },
      { id: "u4", code: "B02", type: "فيلا", subType: "درج صالة", floor: "أرضي + أول + سطح", landArea: 520, builtArea: 660, beds: 6, baths: 5, price: 4500000, status: "available", features: ["روف تيراس", "مسبح خاص", "مصعد", "غرفتا سائق"], facing: "شمال غرب", streets: 2, deliveryReady: false, description: "نموذج B02 مع سطح الدور الثالث (روف تيراس) المجهز كاملاً يمنح رفاهية لا مثيل لها. أكبر مساحة بناء في المشروع مع مسبح خاص وغرفتي سائق مستقلتين. مثالي للعائلات الكبيرة." },
      { id: "u5", code: "C01", type: "فيلا", subType: "درج داخلي", floor: "أرضي + أول", landArea: 380, builtArea: 440, beds: 4, baths: 3, price: 2800000, status: "sold", features: ["تكييف مركزي", "واجهة حجر"], facing: "شرق", streets: 1, deliveryReady: true, description: "نموذج C01 بتصميم عصري مدروس يجمع بين الوظيفية والبساطة الراقية. تكييف مركزي وواجهة حجر طبيعي. جاهز للتسليم الفوري. تم بيعه — نموذج مطلوب بكثرة." },
      { id: "u6", code: "C02", type: "فيلا", subType: "درج داخلي", floor: "أرضي + أول", landArea: 380, builtArea: 440, beds: 4, baths: 3, price: 2850000, status: "available", features: ["تكييف مركزي", "واجهة حجر", "مجلس ديوانية"], facing: "غرب", streets: 1, deliveryReady: false, description: "نموذج C02 مشابه لـ C01 لكنه يضيف ديوانية مستقلة في الدور الأرضي للضيافة الخاصة. الواجهة الغربية تطل على المساحات الخضراء للمشروع. الخيار المثالي لمن يريد التوازن بين السعر والمساحة." },
    ],
  },
  {
    id: "p2",
    name: "مشروع الأمواج",
    developer: { name: "ابتكار للتطوير العقاري", logo: "ا", since: "2018", verified: true, phone: "0125678901" },
    location: "الرياض، حي حطين",
    district: "حطين",
    city: "الرياض",
    category: "تاون هاوس",
    totalUnits: 16,
    priceRange: { min: 1600000, max: 2400000 },
    image: IMG_PROJECT_2,
    images: [IMG_PROJECT_2, IMG_INTERIOR, IMG_PLAN],
    description: "مجمع تاون هاوس متكامل يتكون من 16 وحدة سكنية فاخرة في حي حطين الراقي. يتميز بالتصميم المودرن والمناطق المشتركة المتكاملة ومنظومة أمن ذكية. قريب من المدارس الدولية والخدمات الأساسية.",
    amenities: ["نادي رياضي", "حديقة مشتركة", "أمن 24/7", "ملاعب أطفال", "مسبح مشترك"],
    wafi: true,
    deliveryDate: "مارس 2026",
    completion: 45,
    license: "وافي-2024-5678",
    badge: "وافي ✓",
    badgeColor: "bg-blue-600",
    units: [
      { id: "u7", code: "T01", type: "تاون هاوس", subType: "دوبلكس", floor: "أرضي + أول", landArea: 220, builtArea: 280, beds: 4, baths: 3, price: 1750000, status: "available", features: ["حديقة خاصة", "موقف سيارتين", "تكييف مركزي"], facing: "شمال", streets: 2, deliveryReady: false, description: "نموذج T01 الدوبلكس يتميز بحديقة خاصة أمامية وخلفية توفر مساحة ترفيهية للأسرة. الواجهة الشمالية على شارعين تضمن الإضاءة الطبيعية والتهوية الممتازة. تكييف مركزي بالكامل." },
      { id: "u8", code: "T02", type: "تاون هاوس", subType: "دوبلكس", floor: "أرضي + أول", landArea: 220, builtArea: 280, beds: 4, baths: 3, price: 1700000, status: "available", features: ["حديقة خاصة", "موقف سيارتين"], facing: "جنوب", streets: 1, deliveryReady: false, description: "نموذج T02 يوفر نفس مزايا T01 بسعر أكثر تنافسية. الحديقة الخلفية الخاصة توفر خصوصية مثالية. مناسب للعائلات الصغيرة والشباب المتزوج الباحث عن منزل عصري بسعر معقول." },
      { id: "u9", code: "T03", type: "تاون هاوس", subType: "ترى بلكس", floor: "أرضي + أول + سطح", landArea: 250, builtArea: 320, beds: 5, baths: 4, price: 2200000, status: "reserved", features: ["روف تيراس", "حديقة", "موقف ثلاث سيارات"], facing: "شمال شرق", streets: 2, deliveryReady: false, description: "نموذج T03 الترى بلكس هو تاج المشروع بثلاثة أدوار، يضم روف تيراس مجهزة كاملاً تصلح للتجمعات العائلية. الموقع على شارعين بواجهة شمالية شرقية يمنح إطلالة رائعة وخصوصية ممتازة." },
      { id: "u10", code: "T04", type: "تاون هاوس", subType: "دوبلكس", floor: "أرضي + أول", landArea: 230, builtArea: 290, beds: 4, baths: 3, price: 1850000, status: "available", features: ["حديقة", "موقفين", "غرفة خادمة"], facing: "غرب", streets: 1, deliveryReady: false, description: "نموذج T04 مع غرفة خادمة مستقلة يوفر الراحة للعائلات التي تحتاج مساعدة منزلية. الحديقة الغربية توفر ظلاً ممتعاً في فترات المساء. موقف سيارتين مغطى." },
      { id: "u11", code: "T05", type: "تاون هاوس", subType: "دوبلكس", floor: "أرضي + أول", landArea: 210, builtArea: 265, beds: 4, baths: 3, price: 1650000, status: "sold", features: ["حديقة", "موقفين"], facing: "شرق", streets: 1, deliveryReady: false, description: "نموذج T05 بالمساحة الأنسب في المشروع جمع بين الاقتصادية والجودة العالية. الحديقة الشرقية تمنح ضوءاً صباحياً رائعاً. تم بيعه — كان الأكثر مبيعاً في المشروع." },
      { id: "u12", code: "T06", type: "تاون هاوس", subType: "ترى بلكس بانورامي", floor: "أرضي + أول + سطح", landArea: 260, builtArea: 340, beds: 5, baths: 4, price: 2400000, status: "available", features: ["بانوراما", "روف كاملة", "جاكوزي", "موقف ثلاثة"], facing: "شمال غرب", streets: 3, deliveryReady: false, description: "نموذج T06 هو الأرقى في مشروع الأمواج بإطلالة بانورامية 270 درجة على الحي. يضم جاكوزي على الروف وموقف 3 سيارات وأكبر مساحة في المشروع. الخيار الأول لمن يبحث عن الفخامة الحقيقية." },
    ],
  },
  {
    id: "p3",
    name: "برج المدار",
    developer: { name: "عروض الديار للتطوير", logo: "ع", since: "2012", verified: true, phone: "0138901234" },
    location: "جدة، حي الشاطئ",
    district: "الشاطئ",
    city: "جدة",
    category: "شقق فاخرة",
    totalUnits: 24,
    priceRange: { min: 980000, max: 2800000 },
    image: IMG_PROJECT_3,
    images: [IMG_PROJECT_3, IMG_INTERIOR, IMG_PLAN],
    description: "برج سكني فاخر في أرقى أحياء جدة الشاطئية، يضم 24 شقة فاخرة من الاستوديو إلى 5 غرف. إطلالات بانورامية على البحر، تشطيبات أوروبية، وخدمات فندقية متكاملة.",
    amenities: ["مسبح لا نهائي", "نادي صحي", "كونسيرج 24/7", "موقف مظلل", "حضانة أطفال", "مطعم"],
    wafi: false,
    deliveryDate: "يونيو 2026",
    completion: 30,
    license: "عقارات-2024-9012",
    badge: "حصري",
    badgeColor: "bg-purple-600",
    units: [
      { id: "u13", code: "F01", type: "شقة", subType: "ثلاث غرف", floor: "الدور الأول", landArea: 0, builtArea: 190, beds: 3, baths: 2, price: 1200000, status: "available", features: ["إطلالة بحر جزئية", "موقف مظلل", "مخزن"], facing: "شمال", streets: 0, deliveryReady: false, description: "شقة F01 من الدور الأول توفر إطلالة بحر جزئية مع تراس خارجي مريح. التشطيبات أوروبية المستوى ومطبخ مفتوح يطل على غرفة المعيشة. موقف مظلل ومخزن خاص. مثالية للعائلات الصغيرة." },
      { id: "u14", code: "F02", type: "شقة", subType: "أربع غرف", floor: "الدور الثاني", landArea: 0, builtArea: 250, beds: 4, baths: 3, price: 1800000, status: "available", features: ["إطلالة بحر كاملة", "موقفين", "مخزن"], facing: "شمال غرب", streets: 0, deliveryReady: false, description: "شقة F02 من الدور الثاني تمنح إطلالة بحر كاملة من جميع الغرف الرئيسية. الواجهة الشمالية الغربية تجمع بين الإضاءة الطبيعية والإطلالة البحرية المستمرة. موقفين مغطيين ومخزن واسع." },
      { id: "u15", code: "F03", type: "بنتهاوس", subType: "خمس غرف", floor: "الدور الأخير", landArea: 0, builtArea: 420, beds: 5, baths: 4, price: 2800000, status: "reserved", features: ["بانوراما 360°", "مسبح خاص", "روف تيراس", "خادمة وسائق"], facing: "بانوراما", streets: 0, deliveryReady: false, description: "بنتهاوس F03 يعرّف الفخامة من جديد، بمسبح خاص على الروف وإطلالة 360° على البحر والمدينة. غرفة خادمة وسائق مستقلتان، تشطيبات إيطالية من أرقى الماركات. الوحيد في جدة بهذه المواصفات." },
      { id: "u16", code: "F04", type: "شقة", subType: "غرفتان", floor: "الدور الأول", landArea: 0, builtArea: 130, beds: 2, baths: 2, price: 980000, status: "available", features: ["موقف مظلل", "مخزن"], facing: "جنوب", streets: 0, deliveryReady: false, description: "شقة F04 هي أكثر وحدات البرج اقتصادية مع الحفاظ على نفس مستوى التشطيبات الأوروبية. مثالية للعزاب والأزواج الشباب والمستثمرين الباحثين عن عائد تأجيري مرتفع." },
      { id: "u17", code: "F05", type: "شقة", subType: "ثلاث غرف مع تراس", floor: "الدور الثالث", landArea: 0, builtArea: 210, beds: 3, baths: 2, price: 1450000, status: "available", features: ["تراس 40م²", "إطلالة بحر", "موقف"], facing: "شمال شرق", streets: 0, deliveryReady: false, description: "شقة F05 مميزة بتراس 40م² خاص يطل مباشرة على البحر. التراس مجهز بتمديدات الكهرباء والمياه لجلسة خارجية فاخرة. من الدور الثالث تكون الإطلالة البحرية في أجمل زاوية." },
    ],
  },
];

// ── FORMATTER ──
const fmt = (n: number) => n.toLocaleString("ar-SA");

// ============================================================================
// MAIN EXPORT - Developer Projects Screen
// ============================================================================
export function DeveloperProjectsScreen({ onBack, initialProjectId }: { onBack: () => void; initialProjectId?: string | null }) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const initialProject = initialProjectId ? DEVELOPER_PROJECTS.find(p => p.id === initialProjectId) || null : null;
  const [selectedProject, setSelectedProject] = useState<Project | null>(initialProject);
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null);
  const filtered = DEVELOPER_PROJECTS;

  // Unit Detail View
  if (selectedUnit && selectedProject) {
    return (
      <UnitDetailView
        unit={selectedUnit}
        project={selectedProject}
        isDark={isDark}
        onBack={() => setSelectedUnit(null)}
      />
    );
  }

  // Project Detail View
  if (selectedProject) {
    return (
      <ProjectDetailView
        project={selectedProject}
        isDark={isDark}
        onBack={() => {
          // If opened from home with a specific project, go back to home directly
          if (initialProjectId && selectedProject.id === initialProjectId) {
            onBack();
          } else {
            setSelectedProject(null);
          }
        }}
        onUnitSelect={setSelectedUnit}
      />
    );
  }

  // Projects List
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={`h-full flex flex-col overflow-hidden ${isDark ? "bg-[#0f172a]" : "bg-gray-50"}`}
    >
      {/* Header */}
      <div className={`px-5 pt-5 pb-4 sticky top-0 z-20 ${isDark ? "bg-[#0f172a]/95 backdrop-blur-md border-b border-white/5" : "bg-white/95 backdrop-blur-md border-b border-gray-100"}`}>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className={`w-9 h-9 rounded-xl flex items-center justify-center ${isDark ? "bg-white/5 text-white" : "bg-gray-100 text-gray-700"}`}>
            <ArrowRight className="w-5 h-5" />
          </button>
          <div>
            <h1 className={`font-black text-lg ${isDark ? "text-white" : "text-gray-900"}`}>عقارات المطورين</h1>
            <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>{DEVELOPER_PROJECTS.length} مشاريع متاحة</p>
          </div>
          <div className="mr-auto flex items-center gap-1 px-2 py-1 rounded-lg bg-blue-500/20 border border-blue-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
            <span className="text-[9px] font-black text-blue-400">LIVE</span>
          </div>
        </div>

      </div>

      {/* Project Cards */}
      <div className="flex-1 overflow-y-auto px-5 py-4 pb-32 space-y-5">
        {filtered.map((project, i) => (
          <motion.div key={project.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <ProjectCard project={project} isDark={isDark} onPress={() => setSelectedProject(project)} />
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

// ── PROJECT CARD (List View) ──────────────────────────────────────────────────
function ProjectCard({ project, isDark, onPress }: { project: Project; isDark: boolean; onPress: () => void }) {
  const available = project.units.filter(u => u.status === "available").length;
  const reserved = project.units.filter(u => u.status === "reserved").length;

  return (
    <motion.button whileTap={{ scale: 0.98 }} onClick={onPress} className="w-full text-right">
      <div className={`rounded-3xl overflow-hidden border transition-all ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
        {/* Hero Image */}
        <div className="relative h-52 overflow-hidden">
          <img src={project.image} alt={project.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          {/* Badges top */}
          <div className="absolute top-3 right-3 flex gap-1.5">
            <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black text-white ${project.badgeColor}`}>{project.badge}</span>
            {project.wafi && <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-black/50 backdrop-blur text-white border border-white/20">🔒 وافي</span>}
          </div>

          {/* Developer logo top-left */}
          <div className="absolute top-3 left-3 flex items-center gap-2 bg-black/50 backdrop-blur px-2.5 py-1.5 rounded-xl border border-white/10">
            <div className="w-5 h-5 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-[10px] font-black text-white">{project.developer.logo}</div>
            <span className="text-[9px] font-bold text-white/80">{project.developer.name.split(" ").slice(0,2).join(" ")}</span>
            {project.developer.verified && <CheckCircle className="w-3 h-3 text-emerald-400 fill-emerald-400 shrink-0" />}
          </div>

          {/* Bottom info overlay */}
          <div className="absolute bottom-0 right-0 left-0 p-4">
            <h2 className="text-xl font-black text-white mb-0.5">{project.name}</h2>
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3 h-3 text-white/60" style={{ width: '11px', height: '11px' }} />
              <span className="text-[11px] text-white/70">{project.location}</span>
            </div>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-4">
          {/* Price Range */}
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>نطاق الأسعار</p>
              <p className={`text-base font-black ${isDark ? "text-white" : "text-gray-900"}`}>
                {fmt(project.priceRange.min / 1000000)}M — {fmt(project.priceRange.max / 1000000)}M <span className={`text-[10px] font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>ريال</span>
              </p>
            </div>
            <div className="text-right">
              <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>نوع المشروع</p>
              <p className={`text-sm font-black ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{project.category}</p>
            </div>
          </div>

          {/* Units Status */}
          <div className={`flex gap-2 mb-3 p-3 rounded-2xl ${isDark ? "bg-white/4 border border-white/5" : "bg-gray-50 border border-gray-100"}`}>
            <div className="flex-1 text-center">
              <p className="text-lg font-black text-emerald-500">{available}</p>
              <p className="text-[9px] opacity-50">متاح</p>
            </div>
            <div className={`w-px ${isDark ? "bg-white/5" : "bg-gray-200"}`} />
            <div className="flex-1 text-center">
              <p className="text-lg font-black text-amber-500">{reserved}</p>
              <p className="text-[9px] opacity-50">محجوز</p>
            </div>
            <div className={`w-px ${isDark ? "bg-white/5" : "bg-gray-200"}`} />
            <div className="flex-1 text-center">
              <p className="text-lg font-black text-red-400">{project.units.filter(u => u.status === "sold").length}</p>
              <p className="text-[9px] opacity-50">مباع</p>
            </div>
            <div className={`w-px ${isDark ? "bg-white/5" : "bg-gray-200"}`} />
            <div className="flex-1 text-center">
              <p className={`text-lg font-black ${isDark ? "text-white" : "text-gray-900"}`}>{project.totalUnits}</p>
              <p className="text-[9px] opacity-50">إجمالي</p>
            </div>
          </div>

          {/* Completion + Delivery */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex-1 ml-4">
              <div className="flex justify-between text-[9px] mb-1">
                <span className={isDark ? "text-white/40" : "text-gray-400"}>نسبة الإنجاز</span>
                <span className={`font-black ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{project.completion}%</span>
              </div>
              <div className={`h-1.5 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                <motion.div initial={{ width: 0 }} animate={{ width: `${project.completion}%` }} transition={{ duration: 1, delay: 0.3 }}
                  className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full" />
              </div>
            </div>
            <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-right ${isDark ? "bg-white/5 border-white/5" : "bg-white border-gray-200"}`}>
              <Calendar className="w-3 h-3 text-amber-500 shrink-0" style={{ width: '11px', height: '11px' }} />
              <div>
                <p className="text-[8px] opacity-40">التسليم</p>
                <p className={`text-[10px] font-black ${isDark ? "text-white" : "text-gray-900"}`}>{project.deliveryDate}</p>
              </div>
            </div>
          </div>

          {/* Amenities */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            {project.amenities.slice(0, 4).map((a, i) => (
              <span key={i} className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-gray-50 text-gray-500 border-gray-200"}`}>{a}</span>
            ))}
            {project.amenities.length > 4 && (
              <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${isDark ? "border-white/5 text-white/30" : "border-gray-200 text-gray-400"}`}>+{project.amenities.length - 4}</span>
            )}
          </div>

          {/* CTA */}
          <div className="flex items-center justify-between">
            <span className={`text-[10px] font-bold flex items-center gap-1 ${isDark ? "text-white/30" : "text-gray-400"}`}>
              <Shield className="w-3 h-3" style={{ width: '11px', height: '11px' }} />
              {project.license}
            </span>
            <div className="flex items-center gap-1 text-blue-500 font-black text-xs">
              عرض الوحدات <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </div>
    </motion.button>
  );
}

// ── PROJECT DETAIL VIEW ───────────────────────────────────────────────────────
function ProjectDetailView({
  project, isDark, onBack, onUnitSelect
}: {
  project: Project; isDark: boolean; onBack: () => void; onUnitSelect: (u: Unit) => void;
}) {
  const [activeImg, setActiveImg] = useState(0);
  const [unitFilter, setUnitFilter] = useState<"all" | "available" | "reserved">("all");
  const [liked, setLiked] = useState(false);

  const filteredUnits = project.units.filter(u => {
    if (unitFilter === "available") return u.status === "available";
    if (unitFilter === "reserved") return u.status === "reserved";
    return true;
  });

  const statusCfg: Record<string, any> = {
    available: { label: "متاح", color: isDark ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" : "bg-emerald-50 text-emerald-600 border-emerald-200", dot: "bg-emerald-500" },
    reserved:  { label: "محجوز", color: isDark ? "bg-amber-500/15 text-amber-400 border-amber-500/25" : "bg-amber-50 text-amber-600 border-amber-200", dot: "bg-amber-500" },
    sold:      { label: "مباع", color: isDark ? "bg-red-500/15 text-red-400 border-red-500/25" : "bg-red-50 text-red-600 border-red-200", dot: "bg-red-500" },
  };

  return (
    <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} className={`h-full flex flex-col overflow-hidden ${isDark ? "bg-[#0f172a]" : "bg-gray-50"}`}>
      <div className="flex-1 overflow-y-auto pb-32">

        {/* ── HERO IMAGE GALLERY ── */}
        <div className="relative h-72 overflow-hidden bg-gray-900">
          <motion.img key={activeImg} initial={{ opacity: 0 }} animate={{ opacity: 1 }} src={project.images[activeImg]} alt={project.name}
            className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />

          {/* Nav back + actions */}
          <div className="absolute top-5 right-5 left-5 flex items-center justify-between">
            <button onClick={onBack} className="w-9 h-9 rounded-xl bg-black/50 backdrop-blur flex items-center justify-center border border-white/10">
              <ArrowRight className="w-5 h-5 text-white" />
            </button>
            <div className="flex gap-2">
              <button onClick={() => setLiked(!liked)} className="w-9 h-9 rounded-xl bg-black/50 backdrop-blur flex items-center justify-center border border-white/10">
                <Heart className={`w-4 h-4 ${liked ? "text-red-400 fill-red-400" : "text-white"}`} />
              </button>
              <button className="w-9 h-9 rounded-xl bg-black/50 backdrop-blur flex items-center justify-center border border-white/10">
                <Share2 className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {/* Thumbnail strip */}
          <div className="absolute bottom-4 left-4 flex gap-2">
            {project.images.map((img, i) => (
              <button key={i} onClick={() => setActiveImg(i)} className={`w-12 h-8 rounded-lg overflow-hidden border-2 transition-all ${activeImg === i ? "border-white" : "border-white/30 opacity-60"}`}>
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>

          {/* Wafi badge */}
          {project.wafi && (
            <div className="absolute bottom-4 right-4 flex items-center gap-1.5 bg-blue-600 px-2.5 py-1.5 rounded-xl border border-blue-400/30">
              <Shield className="w-3 h-3 text-white" style={{ width: '11px', height: '11px' }} />
              <span className="text-[9px] font-black text-white">وافي مسجل</span>
            </div>
          )}
        </div>

        <div className="px-5 space-y-5 pt-5">
          {/* ── PROJECT INFO ── */}
          <div>
            {/* Title + badge */}
            <div className="flex items-start justify-between mb-2">
              <div>
                <h1 className={`text-2xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>{project.name}</h1>
                <div className="flex items-center gap-1.5 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-red-400" style={{ width: '13px', height: '13px' }} />
                  <span className={`text-xs ${isDark ? "text-white/60" : "text-gray-500"}`}>{project.location}</span>
                </div>
              </div>
              <span className={`text-[10px] font-black px-2.5 py-1 rounded-lg text-white ${project.badgeColor}`}>{project.badge}</span>
            </div>

            {/* Developer Info Card */}
            <div className={`flex items-center gap-3 p-3.5 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center text-xl font-black text-white shadow-lg shadow-blue-500/25">
                {project.developer.logo}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{project.developer.name}</p>
                  {project.developer.verified && <CheckCircle className="w-4 h-4 text-emerald-400 fill-emerald-400 shrink-0" />}
                </div>
                <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>مطور عقاري منذ {project.developer.since}</p>
              </div>
              <div className="flex gap-2">
                <button className={`w-9 h-9 rounded-xl flex items-center justify-center ${isDark ? "bg-emerald-500/15 text-emerald-400" : "bg-emerald-50 text-emerald-600"}`}>
                  <Phone className="w-4 h-4" />
                </button>
                <button className={`w-9 h-9 rounded-xl flex items-center justify-center ${isDark ? "bg-blue-500/15 text-blue-400" : "bg-blue-50 text-blue-600"}`}>
                  <MessageSquare className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { label: "الوحدات", value: project.totalUnits, color: isDark ? "text-white" : "text-gray-900" },
              { label: "متاح", value: project.units.filter(u => u.status === "available").length, color: "text-emerald-500" },
              { label: "الإنجاز", value: `${project.completion}%`, color: "text-cyan-500" },
              { label: "التسليم", value: project.deliveryDate.split(" ")[0], color: "text-amber-500" },
            ].map((s, i) => (
              <div key={i} className={`p-2.5 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                <p className={`text-base font-black ${s.color}`}>{s.value}</p>
                <p className="text-[8px] opacity-40 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Description */}
          <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-[10px] font-black uppercase tracking-widest mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>عن المشروع</p>
            <p className={`text-sm leading-7 ${isDark ? "text-white/70" : "text-gray-600"}`}>{project.description}</p>
          </div>

          {/* Amenities */}
          <div>
            <p className={`text-[10px] font-black uppercase tracking-widest mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>مرافق المشروع</p>
            <div className="grid grid-cols-2 gap-2">
              {project.amenities.map((a, i) => (
                <div key={i} className={`flex items-center gap-2 p-2.5 rounded-xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                  <div className="w-5 h-5 rounded-lg bg-blue-500/20 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-blue-400" style={{ width: '10px', height: '10px' }} />
                  </div>
                  <span className={`text-[11px] font-bold ${isDark ? "text-white/70" : "text-gray-600"}`}>{a}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── UNITS SECTION ── */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className={`text-[10px] font-black uppercase tracking-widest ${isDark ? "text-white/30" : "text-gray-400"}`}>وحدات المشروع</p>
              <span className={`text-[10px] font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>{project.units.length} وحدة</span>
            </div>

            {/* Unit Status Filter */}
            <div className={`flex rounded-xl p-1 mb-3 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
              {[{ id: "all" as const, label: "الكل" }, { id: "available" as const, label: "المتاحة" }, { id: "reserved" as const, label: "المحجوزة" }].map(f => (
                <button key={f.id} onClick={() => setUnitFilter(f.id)}
                  className={`flex-1 py-1.5 rounded-lg text-[10px] font-black transition-all ${unitFilter === f.id ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : "text-gray-400"}`}>
                  {f.label}
                </button>
              ))}
            </div>

            {/* Units List */}
            <div className="space-y-2.5">
              {filteredUnits.map((unit, i) => {
                const sc = statusCfg[unit.status];
                const isDisabled = unit.status === "sold";
                return (
                  <motion.button key={unit.id} onClick={() => !isDisabled && onUnitSelect(unit)}
                    initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                    className={`w-full p-4 rounded-2xl border text-right transition-all ${isDisabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"} ${isDark ? "bg-[#151a2d] border-white/5 hover:bg-white/5" : "bg-white border-gray-100 shadow-sm hover:shadow-md"}`}>
                    <div className="flex items-center gap-3">
                      {/* Unit Code Badge */}
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm shrink-0 ${isDisabled ? isDark ? "bg-white/5 text-white/20" : "bg-gray-100 text-gray-300" : isDark ? "bg-blue-500/15 text-blue-400" : "bg-blue-50 text-blue-600"}`}>
                        {unit.code}
                      </div>

                      <div className="flex-1 min-w-0">
                        {/* Type + Status */}
                        <div className="flex items-center gap-2 mb-1">
                          <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{unit.type}</p>
                          <span className="text-[9px] text-gray-500">•</span>
                          <p className={`text-[11px] ${isDark ? "text-white/50" : "text-gray-500"}`}>{unit.subType}</p>
                          <span className={`mr-auto text-[9px] font-black px-2 py-0.5 rounded-lg border flex items-center gap-1 ${sc.color}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />{sc.label}
                          </span>
                        </div>

                        {/* Specs row */}
                        <div className="flex items-center gap-3 flex-wrap">
                          <span className={`text-[10px] flex items-center gap-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>
                            <Ruler className="w-2.5 h-2.5" style={{ width: '9px', height: '9px' }} /> {unit.builtArea}م²
                          </span>
                          <span className={`text-[10px] flex items-center gap-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>
                            <Bed className="w-2.5 h-2.5" style={{ width: '9px', height: '9px' }} /> {unit.beds} غرف
                          </span>
                          <span className={`text-[10px] flex items-center gap-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>
                            <Bath className="w-2.5 h-2.5" style={{ width: '9px', height: '9px' }} /> {unit.baths} حمام
                          </span>
                          <span className={`text-[10px] font-black mr-auto ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>
                            {fmt(unit.price)} ريال
                          </span>
                        </div>
                      </div>

                      <ChevronRight className={`w-4 h-4 shrink-0 ${isDisabled ? "opacity-10" : "opacity-30"}`} />
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* License */}
          <div className={`p-3 rounded-xl border flex items-center gap-2 ${isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-200"}`}>
            <Shield className="w-4 h-4 text-blue-400 shrink-0" />
            <div>
              <p className="text-[9px] opacity-40">رقم الترخيص</p>
              <p className={`text-[11px] font-black ${isDark ? "text-white/60" : "text-gray-600"}`}>{project.license}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed CTA */}
      <div className={`absolute bottom-0 left-0 right-0 p-4 border-t ${isDark ? "bg-[#0f172a]/95 border-white/5 backdrop-blur-md" : "bg-white/95 border-gray-100 backdrop-blur-md"}`}>
        <div className="flex gap-3">
          <button className={`flex-1 py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 ${isDark ? "bg-white/5 text-white/70 border border-white/5" : "bg-gray-100 text-gray-700"}`}>
            <Phone className="w-4 h-4" /> تواصل مع المطور
          </button>
          <button className="flex-1 py-3.5 rounded-2xl font-black text-sm bg-gradient-to-r from-blue-600 to-cyan-600 text-white flex items-center justify-center gap-2 shadow-lg shadow-blue-500/25">
            <MessageSquare className="w-4 h-4" /> تواصل واتساب
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// ── UNIT DETAIL VIEW ──────────────────────────────────────────────────────────
function UnitDetailView({ unit, project, isDark, onBack }: { unit: Unit; project: Project; isDark: boolean; onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<"specs" | "plan" | "payment">("specs");

  const pricePerM = Math.round(unit.price / unit.builtArea);

  const paymentPlans = [
    { label: "نقداً (خصم 5%)", total: Math.round(unit.price * 0.95), down: Math.round(unit.price * 0.95), monthly: 0, months: 0 },
    { label: "20% مقدم + 36 شهر", total: unit.price, down: Math.round(unit.price * 0.2), monthly: Math.round((unit.price * 0.8) / 36), months: 36 },
    { label: "30% مقدم + 24 شهر", total: unit.price, down: Math.round(unit.price * 0.3), monthly: Math.round((unit.price * 0.7) / 24), months: 24 },
  ];

  return (
    <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} className={`h-full flex flex-col overflow-hidden ${isDark ? "bg-[#0f172a]" : "bg-gray-50"}`}>
      <div className="flex-1 overflow-y-auto pb-32">

        {/* ── HERO ── */}
        <div className="relative h-60 overflow-hidden bg-gray-900">
          <img src={project.images[1] || project.image} alt={unit.code} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          <div className="absolute top-5 right-5 left-5 flex items-center justify-between">
            <button onClick={onBack} className="w-9 h-9 rounded-xl bg-black/50 backdrop-blur flex items-center justify-center border border-white/10">
              <ArrowRight className="w-5 h-5 text-white" />
            </button>
            <div className={`px-3 py-1.5 rounded-xl text-[10px] font-black text-white ${unit.status === "available" ? "bg-emerald-500/80" : "bg-amber-500/80"} backdrop-blur`}>
              {unit.status === "available" ? "✓ متاح للحجز" : "محجوز"}
            </div>
          </div>

          <div className="absolute bottom-4 right-4">
            <div className="flex items-center gap-2 mb-1">
              <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black bg-blue-600/80 backdrop-blur text-white`}>{project.name}</span>
              <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black bg-black/50 backdrop-blur text-white border border-white/10`}>وحدة {unit.code}</span>
            </div>
            <p className="text-white font-black text-xl">{unit.type} — {unit.subType}</p>
          </div>
        </div>

        <div className="px-5 space-y-4 pt-4">
          {/* Price Row */}
          <div className={`p-4 rounded-3xl border ${isDark ? "bg-gradient-to-br from-emerald-900/20 to-teal-900/20 border-emerald-500/20" : "bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200"}`}>
            <div className="flex items-center justify-between">
              <div>
                <p className={`text-[10px] ${isDark ? "text-emerald-400/60" : "text-emerald-600/60"}`}>سعر الوحدة</p>
                <p className="text-3xl font-black text-emerald-500">{fmt(unit.price)}</p>
                <p className={`text-xs ${isDark ? "text-white/40" : "text-gray-400"}`}>ريال سعودي</p>
              </div>
              <div className={`text-right p-3 rounded-2xl ${isDark ? "bg-white/5" : "bg-white/80"}`}>
                <p className="text-[9px] opacity-40">سعر المتر</p>
                <p className={`text-lg font-black ${isDark ? "text-white" : "text-gray-900"}`}>{fmt(pricePerM)}</p>
                <p className="text-[9px] opacity-40">ريال/م²</p>
              </div>
            </div>
          </div>

          {/* ── PRIMARY SPECS: نوع الوحدة / الدور / مساحة البناء ── */}
          <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>البيانات الأساسية للنموذج</p>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "نوع الوحدة", value: unit.type, icon: Home, color: isDark ? "text-blue-400" : "text-blue-600", bg: isDark ? "bg-blue-500/10" : "bg-blue-50" },
                { label: "الدور", value: unit.floor, icon: Building, color: isDark ? "text-amber-400" : "text-amber-600", bg: isDark ? "bg-amber-500/10" : "bg-amber-50" },
                { label: "مساحة البناء", value: `${unit.builtArea}م²`, icon: Ruler, color: isDark ? "text-emerald-400" : "text-emerald-600", bg: isDark ? "bg-emerald-500/10" : "bg-emerald-50" },
              ].map((s, i) => {
                const Icon = s.icon;
                return (
                  <div key={i} className={`p-3 rounded-2xl text-center border ${s.bg} ${isDark ? "border-white/5" : "border-transparent"}`}>
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center mx-auto mb-2 ${s.bg}`}>
                      <Icon className={`w-4 h-4 ${s.color}`} />
                    </div>
                    <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{s.value}</p>
                    <p className="text-[9px] opacity-40 mt-0.5">{s.label}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── DESCRIPTION ── */}
          {unit.description && (
            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>وصف عام عن النموذج</p>
              <p className={`text-sm leading-7 ${isDark ? "text-white/70" : "text-gray-600"}`}>{unit.description}</p>
            </div>
          )}

          {/* ── FEATURES ── */}
          {unit.features.length > 0 && (
            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>المميزات الإضافية</p>
              <div className="grid grid-cols-2 gap-2">
                {unit.features.map((f, i) => (
                  <div key={i} className={`flex items-center gap-2 p-2.5 rounded-xl border ${isDark ? "bg-emerald-500/5 border-emerald-500/15" : "bg-emerald-50 border-emerald-100"}`}>
                    <div className="w-4 h-4 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 text-emerald-400" style={{ width: '8px', height: '8px' }} />
                    </div>
                    <span className={`text-[11px] font-bold ${isDark ? "text-white/70" : "text-gray-700"}`}>{f}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tabs */}
          <div className={`flex rounded-2xl p-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
            {[{ id: "specs" as const, label: "تفاصيل إضافية" }, { id: "plan" as const, label: "المخطط" }, { id: "payment" as const, label: "خطة الدفع" }].map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`flex-1 py-2 rounded-xl text-[11px] font-black transition-all ${activeTab === t.id ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : "text-gray-400"}`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* Tab: Specs */}
          <AnimatePresence mode="wait">
            {activeTab === "specs" && (
              <motion.div key="specs" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: "التصميم", value: unit.subType, icon: Building },
                    ...(unit.landArea > 0 ? [{ label: "مساحة الأرض", value: `${unit.landArea} م²`, icon: Square }] : []),
                    { label: "غرف النوم", value: `${unit.beds} غرف`, icon: Bed },
                    { label: "دورات المياه", value: `${unit.baths} حمامات`, icon: Bath },
                    { label: "الاتجاه", value: unit.facing, icon: MapPin },
                    ...(unit.streets > 0 ? [{ label: "عدد الشوارع", value: `${unit.streets} شوارع`, icon: Tag }] : []),
                  ].map((s, i) => {
                    const Icon = s.icon;
                    return (
                      <div key={i} className={`p-3 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                        <div className="flex items-center gap-1.5 mb-1">
                          <Icon className="w-3 h-3 opacity-30" style={{ width: '10px', height: '10px' }} />
                          <p className="text-[9px] opacity-40">{s.label}</p>
                        </div>
                        <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{s.value}</p>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* Tab: Floor Plan */}
            {activeTab === "plan" && (
              <motion.div key="plan" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className={`rounded-2xl overflow-hidden border ${isDark ? "border-white/5" : "border-gray-100"}`}>
                  <img src={IMG_PLAN} alt="مخطط الوحدة" className="w-full object-cover" style={{ maxHeight: "320px", objectFit: "cover" }} />
                </div>
                <p className={`text-center text-[10px] mt-2 opacity-40`}>مخطط وحدة {unit.code} — {unit.subType}</p>
              </motion.div>
            )}

            {/* Tab: Payment */}
            {activeTab === "payment" && (
              <motion.div key="payment" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-3">
                {paymentPlans.map((plan, i) => (
                  <div key={i} className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                    <div className="flex items-center justify-between mb-3">
                      <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{plan.label}</p>
                      {i === 0 && <span className="text-[9px] font-black px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/20">موصى به</span>}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className={`p-2.5 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                        <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{fmt(plan.down)}</p>
                        <p className="text-[8px] opacity-40">المقدم</p>
                      </div>
                      <div className={`p-2.5 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                        <p className={`text-sm font-black ${plan.monthly > 0 ? "text-cyan-500" : isDark ? "text-white/20" : "text-gray-300"}`}>
                          {plan.monthly > 0 ? fmt(plan.monthly) : "—"}
                        </p>
                        <p className="text-[8px] opacity-40">شهرياً</p>
                      </div>
                      <div className={`p-2.5 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                        <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{fmt(plan.total)}</p>
                        <p className="text-[8px] opacity-40">الإجمالي</p>
                      </div>
                    </div>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Fixed CTA */}
      <div className={`absolute bottom-0 left-0 right-0 p-4 border-t ${isDark ? "bg-[#0f172a]/95 border-white/5 backdrop-blur-md" : "bg-white/95 border-gray-100 backdrop-blur-md"}`}>
        <div className="flex gap-3">
          <button className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${isDark ? "bg-white/5 text-white" : "bg-gray-100 text-gray-700"}`}>
            <Phone className="w-4 h-4" />
          </button>
          <button className="flex-1 py-3.5 rounded-2xl font-black text-sm bg-gradient-to-r from-blue-600 to-cyan-600 text-white flex items-center justify-center gap-2 shadow-lg shadow-blue-500/25">
            <MessageSquare className="w-4 h-4" /> احجز الوحدة الآن
          </button>
        </div>
      </div>
    </motion.div>
  );
}
