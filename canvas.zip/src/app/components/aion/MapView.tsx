import { motion, AnimatePresence } from "motion/react";
import { X, MapPin, TrendingUp, TrendingDown, Filter, Layers, Locate, Navigation, ChevronLeft } from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../context/ThemeContext";

interface MapViewProps {
  onClose: () => void;
}

// Districts with their positions on the SVG canvas and listing data
const DISTRICTS = [
  { id: "n1", name: "النرجس", x: 295, y: 72, listings: 12, avgPrice: "2.8M", priceM2: "6,200", type: "hot", radius: 32 },
  { id: "n2", name: "حطين", x: 220, y: 105, listings: 8, avgPrice: "3.5M", priceM2: "7,800", type: "hot", radius: 26 },
  { id: "n3", name: "الياسمين", x: 355, y: 95, listings: 6, avgPrice: "2.1M", priceM2: "5,400", type: "warm", radius: 22 },
  { id: "n4", name: "الملقا", x: 268, y: 148, listings: 15, avgPrice: "4.2M", priceM2: "9,100", type: "premium", radius: 36 },
  { id: "n5", name: "السليمانية", x: 205, y: 178, listings: 5, avgPrice: "3.1M", priceM2: "6,900", type: "warm", radius: 20 },
  { id: "n6", name: "المحمدية", x: 148, y: 155, listings: 9, avgPrice: "2.5M", priceM2: "5,800", type: "warm", radius: 27 },
  { id: "n7", name: "العليا", x: 210, y: 238, listings: 18, avgPrice: "5.8M", priceM2: "12,500", type: "premium", radius: 38 },
  { id: "n8", name: "التعاون", x: 155, y: 268, listings: 7, avgPrice: "2.2M", priceM2: "5,100", type: "cool", radius: 24 },
  { id: "n9", name: "الغدير", x: 115, y: 310, listings: 4, avgPrice: "1.9M", priceM2: "4,600", type: "cool", radius: 18 },
  { id: "n10", name: "الوادي", x: 90, y: 235, listings: 6, avgPrice: "2.0M", priceM2: "4,900", type: "cool", radius: 21 },
  { id: "n11", name: "الربوة", x: 270, y: 310, listings: 10, avgPrice: "3.2M", priceM2: "7,100", type: "warm", radius: 29 },
  { id: "n12", name: "الريان", x: 335, y: 210, listings: 3, avgPrice: "1.8M", priceM2: "4,200", type: "cool", radius: 15 },
  { id: "n13", name: "الصحافة", x: 165, y: 118, listings: 11, avgPrice: "2.9M", priceM2: "6,500", type: "warm", radius: 30 },
];

// Color coding by zone type
const ZONE_COLORS: Record<string, { fill: string; stroke: string; glow: string; badge: string; text: string }> = {
  premium: { fill: "rgba(234,179,8,0.18)", stroke: "#EAB308", glow: "#EAB308", badge: "bg-yellow-500/90 text-black", text: "text-yellow-300" },
  hot:     { fill: "rgba(239,68,68,0.15)", stroke: "#EF4444", glow: "#EF4444", badge: "bg-red-500/90 text-white", text: "text-red-300" },
  warm:    { fill: "rgba(249,115,22,0.13)", stroke: "#F97316", glow: "#F97316", badge: "bg-orange-500/90 text-white", text: "text-orange-300" },
  cool:    { fill: "rgba(6,182,212,0.12)", stroke: "#06B6D4", glow: "#06B6D4", badge: "bg-cyan-500/90 text-white", text: "text-cyan-300" },
};

const TYPE_LABELS: Record<string, string> = {
  premium: "بريميوم",
  hot: "ساخن",
  warm: "نشط",
  cool: "عادي",
};

// Road lines (approximate Riyadh grid)
const ROADS = [
  // Horizontal major roads
  { x1: 40, y1: 130, x2: 400, y2: 130, w: 1.5 },
  { x1: 40, y1: 220, x2: 400, y2: 220, w: 1.5 },
  { x1: 40, y1: 300, x2: 400, y2: 300, w: 1.0 },
  { x1: 40, y1: 175, x2: 400, y2: 175, w: 0.7 },
  // Vertical major roads
  { x1: 130, y1: 40, x2: 130, y2: 380, w: 1.5 },
  { x1: 240, y1: 40, x2: 240, y2: 380, w: 1.5 },
  { x1: 320, y1: 40, x2: 320, y2: 380, w: 1.0 },
  { x1: 185, y1: 40, x2: 185, y2: 380, w: 0.7 },
];

export function MapView({ onClose }: MapViewProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [selectedDistrict, setSelectedDistrict] = useState<typeof DISTRICTS[0] | null>(null);
  const [activeFilter, setActiveFilter] = useState<"all" | "premium" | "hot" | "warm" | "cool">("all");
  const [showLegend, setShowLegend] = useState(false);

  const visibleDistricts = activeFilter === "all"
    ? DISTRICTS
    : DISTRICTS.filter(d => d.type === activeFilter);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex flex-col"
      style={{ background: "linear-gradient(180deg, #070d1a 0%, #0a1120 60%, #0d1525 100%)" }}
    >
      {/* ── HEADER ── */}
      <div className="flex items-center justify-between px-4 pt-12 pb-3 z-10">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-xl bg-white/10 border border-white/10 flex items-center justify-center"
        >
          <X className="w-4 h-4 text-white" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#06b6d4]" />
          <span className="text-xs font-black text-white/80 tracking-widest">ڤال MAP</span>
        </div>

        <button
          onClick={() => setShowLegend(v => !v)}
          className="w-9 h-9 rounded-xl bg-white/10 border border-white/10 flex items-center justify-center"
        >
          <Layers className="w-4 h-4 text-white/70" />
        </button>
      </div>

      {/* ── FILTER CHIPS ── */}
      <div className="flex gap-2 px-4 pb-2 overflow-x-auto no-scrollbar">
        {(["all", "premium", "hot", "warm", "cool"] as const).map(f => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-black border transition-all ${
              activeFilter === f
                ? "bg-cyan-500 border-cyan-500 text-black"
                : "bg-white/5 border-white/10 text-white/50"
            }`}
          >
            {f === "all" ? "الكل" : TYPE_LABELS[f]}
          </button>
        ))}
        <div className="shrink-0 px-3 py-1.5 rounded-full text-[10px] font-black bg-white/5 border border-white/10 text-white/50 flex items-center gap-1">
          <Filter className="w-2.5 h-2.5" />
          فلتر
        </div>
      </div>

      {/* ── MAP CANVAS ── */}
      <div className="flex-1 relative overflow-hidden">
        <svg
          viewBox="0 0 430 400"
          className="w-full h-full"
          style={{ maxHeight: "100%" }}
          onClick={() => setSelectedDistrict(null)}
        >
          {/* Grid background */}
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(6,182,212,0.06)" strokeWidth="0.5" />
            </pattern>
            {/* Glow filters */}
            {Object.entries(ZONE_COLORS).map(([key, val]) => (
              <filter key={key} id={`glow-${key}`} x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            ))}
          </defs>

          {/* Background grid */}
          <rect width="430" height="400" fill="url(#grid)" />

          {/* City boundary (rough outline) */}
          <path
            d="M 50,50 L 390,50 L 400,350 L 40,370 Z"
            fill="rgba(6,182,212,0.03)"
            stroke="rgba(6,182,212,0.12)"
            strokeWidth="1"
            strokeDasharray="6,3"
          />

          {/* Road network */}
          {ROADS.map((r, i) => (
            <line
              key={i}
              x1={r.x1} y1={r.y1} x2={r.x2} y2={r.y2}
              stroke="rgba(255,255,255,0.07)"
              strokeWidth={r.w}
            />
          ))}

          {/* District zones */}
          {DISTRICTS.map(d => {
            const colors = ZONE_COLORS[d.type];
            const isVisible = activeFilter === "all" || d.type === activeFilter;
            const isSelected = selectedDistrict?.id === d.id;

            return (
              <g key={d.id} style={{ opacity: isVisible ? 1 : 0.15, transition: "opacity 0.3s" }}>
                {/* Zone glow circle */}
                <circle
                  cx={d.x} cy={d.y}
                  r={d.radius + (isSelected ? 6 : 0)}
                  fill={colors.fill}
                  stroke={colors.stroke}
                  strokeWidth={isSelected ? 1.5 : 0.8}
                  style={{ filter: isSelected ? `drop-shadow(0 0 8px ${colors.glow})` : undefined, transition: "all 0.2s" }}
                  onClick={e => { e.stopPropagation(); setSelectedDistrict(d); }}
                  className="cursor-pointer"
                />

                {/* Inner pulse ring for hot/premium */}
                {(d.type === "hot" || d.type === "premium") && (
                  <circle
                    cx={d.x} cy={d.y}
                    r={d.radius * 0.55}
                    fill="none"
                    stroke={colors.stroke}
                    strokeWidth="0.4"
                    opacity="0.5"
                  />
                )}

                {/* Listing count badge */}
                <circle cx={d.x} cy={d.y} r={12} fill={colors.stroke} opacity={0.9} onClick={e => { e.stopPropagation(); setSelectedDistrict(d); }} className="cursor-pointer" />
                <text x={d.x} y={d.y + 1} textAnchor="middle" dominantBaseline="middle" fill="white" fontSize="8" fontWeight="900" style={{ fontFamily: "Cairo" }}>
                  {d.listings}
                </text>

                {/* District name label */}
                <text
                  x={d.x} y={d.y + d.radius + 9}
                  textAnchor="middle"
                  fill={colors.stroke}
                  fontSize="6.5"
                  fontWeight="700"
                  opacity="0.9"
                  style={{ fontFamily: "Cairo" }}
                >
                  {d.name}
                </text>
              </g>
            );
          })}

          {/* Compass */}
          <g transform="translate(390,60)">
            <circle cx="0" cy="0" r="14" fill="rgba(0,0,0,0.5)" stroke="rgba(255,255,255,0.15)" strokeWidth="0.8" />
            <Navigation className="w-5 h-5" />
            <text x="0" y="-16" textAnchor="middle" fill="rgba(255,255,255,0.5)" fontSize="5" fontWeight="700">N</text>
            <line x1="0" y1="-10" x2="0" y2="10" stroke="rgba(255,255,255,0.4)" strokeWidth="0.6" />
            <line x1="-10" y1="0" x2="10" y2="0" stroke="rgba(255,255,255,0.2)" strokeWidth="0.6" />
            <polygon points="0,-9 -2,-1 0,1 2,-1" fill="#06B6D4" />
          </g>

          {/* Scale bar */}
          <g transform="translate(20,375)">
            <line x1="0" y1="0" x2="50" y2="0" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
            <line x1="0" y1="-3" x2="0" y2="3" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
            <line x1="50" y1="-3" x2="50" y2="3" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
            <text x="25" y="-5" textAnchor="middle" fill="rgba(255,255,255,0.4)" fontSize="5">5 كم</text>
          </g>
        </svg>

        {/* ── DISTRICT DETAIL CARD ── */}
        <AnimatePresence>
          {selectedDistrict && (
            <motion.div
              key={selectedDistrict.id}
              initial={{ y: 80, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 80, opacity: 0 }}
              transition={{ type: "spring", damping: 20 }}
              className="absolute bottom-4 left-4 right-4 rounded-2xl border border-white/10 overflow-hidden"
              style={{ background: "rgba(10,16,35,0.96)", backdropFilter: "blur(20px)" }}
            >
              <div className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black mb-1 ${ZONE_COLORS[selectedDistrict.type].badge}`}>
                      {TYPE_LABELS[selectedDistrict.type]}
                    </div>
                    <h3 className="text-white font-black">{selectedDistrict.name}</h3>
                    <p className="text-white/40 text-[10px] flex items-center gap-1 mt-0.5">
                      <MapPin className="w-2.5 h-2.5" /> الرياض
                    </p>
                  </div>
                  <button onClick={() => setSelectedDistrict(null)} className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center">
                    <X className="w-3.5 h-3.5 text-white/60" />
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-3">
                  <div className="rounded-xl bg-white/5 p-2.5 text-center">
                    <p className="text-white font-black text-sm">{selectedDistrict.listings}</p>
                    <p className="text-white/40 text-[9px] mt-0.5">إعلان</p>
                  </div>
                  <div className="rounded-xl bg-white/5 p-2.5 text-center">
                    <p className="text-white font-black text-sm">{selectedDistrict.avgPrice}</p>
                    <p className="text-white/40 text-[9px] mt-0.5">متوسط السعر</p>
                  </div>
                  <div className="rounded-xl bg-white/5 p-2.5 text-center">
                    <p className="text-white font-black text-sm">{selectedDistrict.priceM2}</p>
                    <p className="text-white/40 text-[9px] mt-0.5">ر.س / م²</p>
                  </div>
                </div>

                <button className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-black flex items-center justify-center gap-2">
                  <ChevronLeft className="w-3.5 h-3.5" />
                  عرض إعلانات {selectedDistrict.name}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── LEGEND ── */}
        <AnimatePresence>
          {showLegend && (
            <motion.div
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 100, opacity: 0 }}
              className="absolute top-2 right-2 rounded-xl border border-white/10 p-3 space-y-2"
              style={{ background: "rgba(10,16,35,0.95)", backdropFilter: "blur(12px)" }}
            >
              <p className="text-[9px] font-black text-white/50 tracking-widest mb-2">المناطق</p>
              {Object.entries(TYPE_LABELS).map(([key, label]) => (
                <div key={key} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: ZONE_COLORS[key].glow }} />
                  <span className="text-[10px] text-white/70">{label}</span>
                </div>
              ))}
              <div className="border-t border-white/10 pt-2 mt-1">
                <p className="text-[9px] text-white/40">الرقم = عدد الإعلانات</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── BOTTOM STATS BAR ── */}
      <div className="px-4 pb-8 pt-3 border-t border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[10px] text-emerald-400 font-bold">الأسعار ترتفع 8.4% سنوياً</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-[10px] text-white/40">{DISTRICTS.reduce((s, d) => s + d.listings, 0)} إعلان نشط</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}