import { motion, AnimatePresence } from "motion/react";
import {
  Search, MapPin, Bed, Bath, Square, Heart, Sparkles,
  ArrowRightLeft, Building, FileText, Phone, MessageCircle,
  Share2, ChevronRight,
  ChevronDown, RotateCcw, Mic, SendHorizonal,
  CheckCircle, XCircle,
  SlidersHorizontal, X, Tag, Briefcase, Home, Building2,
  Users, LayoutGrid, KeyRound, Warehouse,
  Landmark, TreePine, Store, Globe,
  ChevronUp, LocateFixed,
  Map, Star, Flag, BellPlus, TrendingDown, Eye,
  GraduationCap, ShoppingBag, Utensils, Activity, Percent,
  ArrowUpRight, ShieldCheck, Clock, MessageSquare, Target, Hash,
  ChevronLeft, DollarSign
} from "lucide-react";
import { useState, useEffect } from "react";
import { useTheme } from "../../context/ThemeContext";
import { MapView } from "./MapView";

// ==========================================
// TYPES
// ==========================================
type ListingType = "buy" | "rent" | "exchange";
type SourceType = "all" | "broker" | "landlord" | "developer";
type PropTypeId = "all" | "villa" | "apartment" | "floor" | "land" | "building" | "istirahah" | "farm";

// ==========================================
// CONSTANTS
// ==========================================
const PROPERTY_TYPES = [
  { id: "all" as PropTypeId, label: "الكل", Icon: LayoutGrid },
  { id: "villa" as PropTypeId, label: "فيلا", Icon: Home },
  { id: "apartment" as PropTypeId, label: "شقة", Icon: Building2 },
  { id: "floor" as PropTypeId, label: "دور", Icon: Building },
  { id: "land" as PropTypeId, label: "أرض", Icon: Square },
  { id: "building" as PropTypeId, label: "عمارة", Icon: Landmark },
  { id: "istirahah" as PropTypeId, label: "استراحة", Icon: TreePine },
  { id: "farm" as PropTypeId, label: "مزرعة", Icon: Warehouse },
];

const REGIONS_DATA: Record<string, string[]> = {
  "الرياض":    ["النرجس", "حطين", "الملقا", "العليا", "الياسمين", "الغدير", "التعاون", "الربوة", "المحمدية", "الوادي", "السليمانية"],
  "جدة":       ["الشاطئ", "أبحر الشمالية", "الروضة", "الحمراء", "الزهراء", "المحمدية", "الصفا", "الرحاب", "السلامة", "النزهة"],
  "مكة المكرمة": ["العزيزية", "الشيشة", "النسيم", "العوالي", "الحجون", "الزاهر"],
  "الدمام":    ["الراكة", "العزيزية", "الفيصلية", "النزهة", "الشاطئ", "الإسكان", "الفردوس"],
  "الخبر":     ["الكورنيش", "العزيزية", "الثقبة", "العنود", "التحلية", "الأمواج"],
  "المدينة":   ["العزيزية", "الحرة الشرقية", "المناخة", "شوران", "الإسكان"],
  "أبها":      ["الربوة", "المحمدية", "النزهة", "السلامة"],
  "تبوك":      ["الروضة", "النزهة", "المروة", "القادسية"],
};

const REGIONS = Object.keys(REGIONS_DATA);

// ==========================================
// IMAGES
// ==========================================
const IMG_VILLA =   "https://images.unsplash.com/photo-1700085060165-1ac17cf08286?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_APT =     "https://images.unsplash.com/photo-1758957530781-4ff54e09bee2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_PALACE =  "https://images.unsplash.com/photo-1710115129740-e882eb8c9e55?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_PENT =    "https://images.unsplash.com/photo-1760463921726-6da5d642805e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_VILLA2 =  "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_APT2 =    "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_LAND =    "https://images.unsplash.com/photo-1500382017468-9049fed747ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_BUILDING ="https://images.unsplash.com/photo-1486325212027-8081e485255e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_ISTIRAHAH="https://images.unsplash.com/photo-1566073771259-6a8506099945?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_VILLA3 =  "https://images.unsplash.com/photo-1613490493576-7fde63acd811?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";
const IMG_APT3 =    "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80";

// ==========================================
// LISTINGS DATA
// ==========================================
const STANDARD_LISTINGS = [
  // ── FOR SALE (بيع) ──────────────────────────────────────────────
  {
    id: 1, title: "فيلا مودرن فاخرة", price: "2,500,000",
    location: "الرياض، حي النرجس",
    region: "الرياض", neighborhood: "النرجس",
    transactionType: "buy" as ListingType,
    propType: "villa" as PropTypeId,
    specs: { beds: 5, baths: 4, area: 450, built: 520 },
    image: IMG_VILLA, source: "developer",
    badges: ["مطور معتمد", "ضمان وافي"], deed: true, bank: true,
    negotiable: true,
    aiRec: "سعر المتر أقل من متوسط الحي بـ 5%، فرصة استثمارية.",
    desc: "مشروع فلل النرجس، تصميم عصري، ضمانات شاملة على الهيكل والسباكة والكهرباء لمدة 10 سنوات.",
    views: 1247, adNumber: "4571823", priceDrop: null,
    advertiser: { name: "شركة رتال للتطوير", type: "developer", since: "2015", falNumber: "1000021453", rating: 4.7, ratingCount: 89 },
    priceHistory: [{ date: "أكتوبر 2024", price: "2,700,000", note: "السعر الأولي" }, { date: "يناير 2025", price: "2,500,000", note: "تخفيض 7%" }]
  },
  {
    id: 2, title: "قصر مصغر كلاسيك", price: "5,200,000",
    location: "الخبر، الحزام الذهبي",
    region: "الخبر", neighborhood: "الكورنيش",
    transactionType: "buy" as ListingType,
    propType: "villa" as PropTypeId,
    specs: { beds: 7, baths: 6, area: 900, built: 1100 },
    image: IMG_PALACE, source: "broker",
    badges: ["حصري"], deed: true, bank: true,
    negotiable: true,
    aiRec: "عقار مميز ونادر في المنطقة.",
    desc: "قصر بتصميم كلاسيكي، رخام إيطالي، مجالس واسعة، ملحق خارجي، حديقة كبيرة مع شلال.",
    views: 534, adNumber: "4571044", priceDrop: { from: "5,800,000", percent: 10 },
    advertiser: { name: "مكتب الإنجاز العقاري", type: "broker", since: "2010", falNumber: "1000008721", rating: 4.2, ratingCount: 134 },
    priceHistory: [{ date: "سبتمبر 2024", price: "5,800,000", note: "السعر الأولي" }, { date: "ديسمبر 2024", price: "5,200,000", note: "تخفيض 10%" }]
  },
  {
    id: 3, title: "شقة فاخرة بانورامية", price: "1,200,000",
    location: "جدة، حي الصفا",
    region: "جدة", neighborhood: "الصفا",
    transactionType: "buy" as ListingType,
    propType: "apartment" as PropTypeId,
    specs: { beds: 3, baths: 2, area: 195, built: 195 },
    image: IMG_APT, source: "landlord",
    badges: ["مباشر مع المالك"], deed: true, bank: true,
    negotiable: false,
    aiRec: "سعر منافس مقارنة بالمنطقة، عائد تأجيري 7.5%.",
    desc: "شقة فاخرة في برج راقٍ، إطلالة بحرية جزئية، تشطيب سوبر لوكس، موقف خاص.",
    views: 891, adNumber: "4573901", priceDrop: null,
    advertiser: { name: "ماجد العتيبي", type: "landlord", since: "2021", falNumber: null, rating: null, ratingCount: 0 },
    priceHistory: [{ date: "نوفمبر 2024", price: "1,200,000", note: "السعر الأولي" }]
  },
  {
    id: 4, title: "أرض سكنية مميزة", price: "800,000",
    location: "الرياض، حي الياسمين",
    region: "الرياض", neighborhood: "الياسمين",
    transactionType: "buy" as ListingType,
    propType: "land" as PropTypeId,
    specs: { beds: 0, baths: 0, area: 750, built: 0 },
    image: IMG_LAND, source: "landlord",
    badges: ["مباشر مع المالك", "شارعين"], deed: true, bank: false,
    negotiable: true,
    aiRec: "منطقة تطوير نشطة، أسعار الأراضي ترتفع 12% سنوياً.",
    desc: "أرض سكنية على شارعين، مخطط مميز، مسوّرة، قريبة من الخدمات والمدارس.",
    views: 378, adNumber: "4574512", priceDrop: null,
    advertiser: { name: "سلطان الحربي", type: "landlord", since: "2018", falNumber: null, rating: null, ratingCount: 0 },
    priceHistory: [{ date: "أكتوبر 2024", price: "850,000", note: "السعر الأولي" }, { date: "يناير 2025", price: "800,000", note: "تخفيض 6%" }]
  },
  {
    id: 5, title: "عمارة استثمارية 8 شقق", price: "3,800,000",
    location: "الدمام، حي العزيزية",
    region: "الدمام", neighborhood: "العزيزية",
    transactionType: "buy" as ListingType,
    propType: "building" as PropTypeId,
    specs: { beds: 24, baths: 16, area: 1200, built: 1400 },
    image: IMG_BUILDING, source: "broker",
    badges: ["استثماري", "مأجور"], deed: true, bank: true,
    negotiable: true,
    aiRec: "عائد إيجاري فعلي 9.2%، جميع الوحدات مؤجرة.",
    desc: "عمارة سكنية 4 أدوار + قبو، 8 شقق مؤجرة بالكامل، صيانة ممتازة، موقع تجاري مميز.",
    views: 2103, adNumber: "4570234", priceDrop: null,
    advertiser: { name: "مكتب الخليج العقاري", type: "broker", since: "2008", falNumber: "1000003342", rating: 4.8, ratingCount: 312 },
    priceHistory: [{ date: "أغسطس 2024", price: "3,800,000", note: "السعر الأولي" }]
  },
  {
    id: 6, title: "فيلا حديثة مع مسبح", price: "3,100,000",
    location: "الرياض، حي حطين",
    region: "الرياض", neighborhood: "حطين",
    transactionType: "buy" as ListingType,
    propType: "villa" as PropTypeId,
    specs: { beds: 6, baths: 5, area: 600, built: 750 },
    image: IMG_VILLA2, source: "broker",
    badges: ["مسبح", "مصعد"], deed: true, bank: true,
    negotiable: true,
    aiRec: "موقع استراتيجي، قريبة من العليا وطريق الملك فهد.",
    desc: "فيلا مودرن فاخرة، مسبح خاص، مصعد، تشطيبات VIP، تكييف مركزي، حديقة منسقة.",
    views: 672, adNumber: "4572817", priceDrop: { from: "3,400,000", percent: 9 },
    advertiser: { name: "مكتب بيوت الراقي", type: "broker", since: "2012", falNumber: "1000011892", rating: 4.5, ratingCount: 76 },
    priceHistory: [{ date: "يوليو 2024", price: "3,400,000", note: "السعر الأولي" }, { date: "نوفمبر 2024", price: "3,100,000", note: "تخفيض 9%" }]
  },

  // ── FOR RENT (إيجار) ──────────────────────────────────────────────
  {
    id: 7, title: "شقة بإطلالة بانورامية", price: "45,000 / سنة",
    location: "جدة، الشاطئ",
    region: "جدة", neighborhood: "الشاطئ",
    transactionType: "rent" as ListingType,
    propType: "apartment" as PropTypeId,
    specs: { beds: 3, baths: 2, area: 180, built: 180 },
    image: IMG_APT2, source: "landlord",
    badges: ["مباشر مع المالك"], deed: true, bank: true,
    negotiable: false,
    aiRec: "منطقة ذات طلب تأجيري عالي، العائد المتوقع 8%.",
    desc: "شقة فاخرة في برج المسرات، موقف خاص، دخول ذكي، نادي رياضي ومسبح مشترك.",
    views: 445, adNumber: "4575602", priceDrop: null,
    advertiser: { name: "خالد العبدالله", type: "landlord", since: "2023", falNumber: null, rating: null, ratingCount: 0 },
    priceHistory: [{ date: "ديسمبر 2024", price: "45,000 / سنة", note: "السعر الأولي" }]
  },
  {
    id: 8, title: "فيلا مفروشة فاخرة", price: "80,000 / سنة",
    location: "الرياض، حي التعاون",
    region: "الرياض", neighborhood: "التعاون",
    transactionType: "rent" as ListingType,
    propType: "villa" as PropTypeId,
    specs: { beds: 5, baths: 4, area: 500, built: 580 },
    image: IMG_VILLA3, source: "broker",
    badges: ["مفروشة كاملاً", "عائلي"], deed: false, bank: false,
    negotiable: true,
    aiRec: "فيلا مفروشة بمستوى فندقي، فرصة نادرة للإيجار.",
    desc: "فيلا مفروشة بالكامل بأثاث إيطالي فاخر، مطبخ مجهز، مسبح خاص، حارس أمن، كاميرات.",
    views: 1089, adNumber: "4571345", priceDrop: { from: "90,000 / سنة", percent: 11 },
    advertiser: { name: "مكتب الفيصل للتأجير", type: "broker", since: "2016", falNumber: "1000014567", rating: 4.0, ratingCount: 58 },
    priceHistory: [{ date: "أكتوبر 2024", price: "90,000 / سنة", note: "السعر الأولي" }, { date: "يناير 2025", price: "80,000 / سنة", note: "تخفيض 11%" }]
  },
  {
    id: 9, title: "استراحة فاخرة للإيجار", price: "25,000 / سنة",
    location: "الرياض، حي الغدير",
    region: "الرياض", neighborhood: "الغدير",
    transactionType: "rent" as ListingType,
    propType: "istirahah" as PropTypeId,
    specs: { beds: 3, baths: 2, area: 1200, built: 350 },
    image: IMG_ISTIRAHAH, source: "landlord",
    badges: ["مباشر مع المالك", "مسبح"], deed: false, bank: false,
    negotiable: true,
    aiRec: "مناسبة للعائلات والتجمعات، قريبة من الخدمات.",
    desc: "استراحة فاخرة بمسبح كبير، ملاعب أطفال، مظلات، بلكونة واسعة، موقع هادئ.",
    views: 234, adNumber: "4576891", priceDrop: null,
    advertiser: { name: "فيصل المطيري", type: "landlord", since: "2020", falNumber: null, rating: null, ratingCount: 0 },
    priceHistory: [{ date: "نوفمبر 2024", price: "25,000 / سنة", note: "السعر الأولي" }]
  },
  {
    id: 10, title: "دور علوي مفروش", price: "35,000 / سنة",
    location: "جدة، الروضة",
    region: "جدة", neighborhood: "الروضة",
    transactionType: "rent" as ListingType,
    propType: "floor" as PropTypeId,
    specs: { beds: 4, baths: 3, area: 220, built: 220 },
    image: IMG_APT3, source: "landlord",
    badges: ["مفروش جزئياً"], deed: false, bank: false,
    negotiable: false,
    aiRec: "منطقة هادئة وراقية، قريبة من المدارس والخدمات.",
    desc: "دور علوي في حي الروضة الراقي، مفروش بأثاث عصري، مدخل مستقل، سطح خاص.",
    views: 312, adNumber: "4574203", priceDrop: null,
    advertiser: { name: "أم علي المالكة", type: "landlord", since: "2022", falNumber: null, rating: null, ratingCount: 0 },
    priceHistory: [{ date: "ديسمبر 2024", price: "35,000 / سنة", note: "السعر الأولي" }]
  },
  {
    id: 11, title: "شقة عزاب مودرن", price: "18,000 / سنة",
    location: "الدمام، الراكة",
    region: "الدمام", neighborhood: "الراكة",
    transactionType: "rent" as ListingType,
    propType: "apartment" as PropTypeId,
    specs: { beds: 2, baths: 1, area: 110, built: 110 },
    image: IMG_APT, source: "broker",
    badges: ["مناسب للعزاب"], deed: false, bank: false,
    negotiable: true,
    aiRec: "موقع متميز قريب من الشواطئ والمطاعم.",
    desc: "شقة مودرن في حي الراكة، دور ثانٍ، مصعد، موقف سيارة، أمن على مدار الساعة.",
    views: 567, adNumber: "4573456", priceDrop: null,
    advertiser: { name: "مكتب المنارة العقارية", type: "broker", since: "2014", falNumber: "1000009234", rating: 3.9, ratingCount: 41 },
    priceHistory: [{ date: "سبتمبر 2024", price: "18,000 / سنة", note: "السعر الأولي" }]
  },
  {
    id: 12, title: "فيلا عائلية كبيرة", price: "60,000 / سنة",
    location: "الرياض، المحمدية",
    region: "الرياض", neighborhood: "المحمدية",
    transactionType: "rent" as ListingType,
    propType: "villa" as PropTypeId,
    specs: { beds: 7, baths: 5, area: 700, built: 850 },
    image: IMG_VILLA2, source: "landlord",
    badges: ["عائلي كبير", "غير مفروشة"], deed: false, bank: false,
    negotiable: true,
    aiRec: "حي هادئ وراقٍ، مناسب للعائلات الكبيرة.",
    desc: "فيلا كبيرة بحديقة واسعة، 7 غرف ماستر، مجلس مستقل، ملحق للسائق، كراجات.",
    views: 788, adNumber: "4572098", priceDrop: { from: "65,000 / سنة", percent: 8 },
    advertiser: { name: "عبدالرحمن الدوسري", type: "landlord", since: "2019", falNumber: null, rating: null, ratingCount: 0 },
    priceHistory: [{ date: "أغسطس 2024", price: "65,000 / سنة", note: "السعر الأولي" }, { date: "ديسمبر 2024", price: "60,000 / سنة", note: "تخفيض 8%" }]
  },
];

// ── EXCHANGE LISTINGS ──────────────────────────────────────────────
const EXCHANGE_LISTINGS = [
  {
    id: "ex1", postedDate: "منذ يومين",
    region: "الرياض", neighborhood: "الملقا",
    have: {
      type: "فيلا مودرن درج صالة",
      location: "الرياض، حي الملقا",
      area: "450م²", builtArea: "600م²",
      price: "3,500,000",
      rooms: 6, baths: 5,
      image: IMG_VILLA,
      deed: true, bank: true,
      desc: "فيلا مودرن فاخرة درج صالة، تشطيبات VIP، مسبح ومصعد مؤسس.",
      yearBuilt: "2021",
      features: ["مسبح", "مصعد", "تكييف مركزي", "حارس أمن", "واجهة حجرية"],
    },
    want: {
      type: "أرض سكنية",
      location: "جدة، أبحر الشمالية",
      specs: "مساحة لا تقل عن 900م² على شارعين",
      priceRange: "2.5M - 3.5M",
      note: "يطلب فرق 500,000 ريال نقداً عند إتمام الصفقة.",
      minArea: "900م²", streets: "شارعين فأكثر",
    },
    delta: "500,000", deltaType: "receive" as const,
    user: { name: "سعد القحطاني", type: "landlord", verified: true, phone: "05xxxxxxxx", since: "2019" }
  },
  {
    id: "ex2", postedDate: "منذ 5 أيام",
    region: "جدة", neighborhood: "السلامة",
    have: {
      type: "شقة بنتهاوس مطلة",
      location: "جدة، السلامة",
      area: "220م²", builtArea: "220م²",
      price: "4,200,000",
      rooms: 3, baths: 3,
      image: IMG_PENT,
      deed: true, bank: false,
      desc: "شقة فاخرة في برج شاهق، إطلالة كاملة على المدينة، مفروشة بالكامل بأثاث إيطالي.",
      yearBuilt: "2019",
      features: ["مفروشة كاملاً", "إطلالة مميزة", "موقفين", "نادي رياضي"],
    },
    want: {
      type: "فيلا مودرن مع مسبح",
      location: "الرياض، النرجس أو حطين",
      specs: "مودرن، مسبح، عمر لا يزيد عن 5 سنوات",
      priceRange: "3.5M - 4.5M",
      note: "رأس برأس — بدون فرق سعر.",
      minArea: "400م²", streets: "شارع واحد فأكثر",
    },
    delta: "Zero", deltaType: "equal" as const,
    user: { name: "شركة الأفق العقارية", type: "broker", verified: true, phone: "05xxxxxxxx", since: "2015" }
  },
  {
    id: "ex3", postedDate: "منذ أسبوع",
    region: "الدمام", neighborhood: "الفيصلية",
    have: {
      type: "عمارة 6 شقق استثمارية",
      location: "الدمام، الفيصلية",
      area: "900م²", builtArea: "1100م²",
      price: "2,800,000",
      rooms: 18, baths: 12,
      image: IMG_BUILDING,
      deed: true, bank: true,
      desc: "عمارة مؤجرة بالكامل، عائد 8.5% سنوياً، صيانة ممتازة.",
      yearBuilt: "2018",
      features: ["مؤجرة كاملاً", "صيانة سنوية", "موقع تجاري"],
    },
    want: {
      type: "أرض تجارية أو فيلا",
      location: "الرياض، الملز أو العليا",
      specs: "أرض تجارية أو فيلا فاخرة، تقبل بدل",
      priceRange: "2.5M - 3.2M",
      note: "يقبل فرق نقدي بسيط إن وجد. مفاوضة جدية.",
      minArea: "600م²", streets: "على شارع رئيسي",
    },
    delta: "200,000", deltaType: "pay" as const,
    user: { name: "محمد الزهراني", type: "landlord", verified: false, phone: "05xxxxxxxx", since: "2017" }
  },
  {
    id: "ex4", postedDate: "منذ 3 أيام",
    region: "الرياض", neighborhood: "الربوة",
    have: {
      type: "أرض سكنية على شارعين",
      location: "الرياض، حي الربوة",
      area: "1200م²", builtArea: "0م²",
      price: "1,800,000",
      rooms: 0, baths: 0,
      image: IMG_LAND,
      deed: true, bank: false,
      desc: "أرض مميزة في حي الربوة على شارعين عرض 20م، مخطط معتمد.",
      yearBuilt: "—",
      features: ["شارعين", "مخطط معتمد", "صك إلكتروني"],
    },
    want: {
      type: "شقة أو دور سكني",
      location: "الرياض، أي حي راقٍ",
      specs: "شقة 3+ غرف أو دور في حي راقٍ، مناسب للعائلة",
      priceRange: "1.5M - 2M",
      note: "يقبل فرق بسيط أو رأس برأس. التواصل جادون فقط.",
      minArea: "180م²", streets: "—",
    },
    delta: "100,000", deltaType: "receive" as const,
    user: { name: "عبدالله الغامدي", type: "landlord", verified: true, phone: "05xxxxxxxx", since: "2020" }
  },
];

// ── DEVELOPER TEASERS ──────────────────────────────────────────────
const DEV_TEASERS = [
  { id: "p1", projectId: "p1", name: "مشروع النخيل", developer: "شركة رتال للتطوير", location: "الرياض، حي النرجس", region: "الرياض", neighborhood: "النرجس", priceRange: "2.8M – 4.5M", units: 10, available: 4, image: "https://images.unsplash.com/photo-1656158113009-c8f5b3268aca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80", badge: "وافي ✓", completion: 75, transactionType: "buy" as ListingType },
  { id: "p2", projectId: "p2", name: "مشروع الأمواج", developer: "ابتكار للتطوير العقاري", location: "الرياض، حي حطين", region: "الرياض", neighborhood: "حطين", priceRange: "1.6M – 2.4M", units: 16, available: 4, image: "https://images.unsplash.com/photo-1764080400538-4487aa44172f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80", badge: "وافي ✓", completion: 45, transactionType: "buy" as ListingType },
  { id: "p3", projectId: "p3", name: "برج المدار", developer: "عروض الديار للتطوير", location: "جدة، حي الشاطئ", region: "جدة", neighborhood: "الشاطئ", priceRange: "980K – 2.8M", units: 24, available: 4, image: "https://images.unsplash.com/photo-1758193431355-54df41421657?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800&q=80", badge: "حصري", completion: 30, transactionType: "buy" as ListingType },
];

// ==========================================
// FILTER STATE
// ==========================================
interface FilterState {
  transactionType: ListingType;
  sourceFilter: SourceType;
  region: string;
  neighborhood: string;
  propType: PropTypeId;
  minBeds: number;
  priceRange: "all" | "under1M" | "1M-2M" | "2M-4M" | "over4M";
  areaRange: "all" | "under200" | "200-500" | "500-1000" | "over1000";
}

const DEFAULT_FILTERS: FilterState = {
  transactionType: "buy",
  sourceFilter: "all",
  region: "الكل",
  neighborhood: "الكل",
  propType: "all",
  minBeds: 0,
  priceRange: "all",
  areaRange: "all",
};

// Parse price string to number
function parsePrice(priceStr: string): number {
  const cleaned = priceStr.replace(/[^0-9]/g, "");
  return parseInt(cleaned) || 0;
}

// Count how many non-default filters are active
function countActiveFilters(f: FilterState): number {
  let count = 0;
  if (f.transactionType !== "buy") count++;
  if (f.sourceFilter !== "all") count++;
  if (f.region !== "الكل") count++;
  if (f.neighborhood !== "الكل") count++;
  if (f.propType !== "all") count++;
  if (f.minBeds > 0) count++;
  if (f.priceRange !== "all") count++;
  if (f.areaRange !== "all") count++;
  return count;
}

// ==========================================
// MAIN SCREEN
// ==========================================
export function HomeScreen({ onNavigate, onSelectDevProject }: any) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [showFilterPanel, setShowFilterPanel] = useState(false);
  const [aiQuery, setAiQuery] = useState("");
  const [aiActive, setAiActive] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<any>(null);
  const [selectedExchange, setSelectedExchange] = useState<any>(null);
  const [showMap, setShowMap] = useState(false);
  const [savedToast, setSavedToast] = useState(false);

  // Temp filter state (inside panel before applying)
  const [tempFilters, setTempFilters] = useState<FilterState>(DEFAULT_FILTERS);

  const activeCount = countActiveFilters(filters);

  function setFilter<K extends keyof FilterState>(key: K, value: FilterState[K]) {
    setFilters(prev => ({ ...prev, [key]: value }));
  }

  // ── FILTERING LOGIC ───────────────────────────────────────────────
  const filteredListings = STANDARD_LISTINGS.filter(item => {
    if (item.transactionType !== filters.transactionType) return false;
    if (filters.sourceFilter !== "all" && filters.sourceFilter !== "developer" && item.source !== filters.sourceFilter) return false;
    if (filters.sourceFilter === "developer" && item.source !== "developer") return false;
    if (filters.region !== "الكل" && item.region !== filters.region) return false;
    if (filters.neighborhood !== "الكل" && item.neighborhood !== filters.neighborhood) return false;
    if (filters.propType !== "all" && item.propType !== filters.propType) return false;
    // Bedroom filter
    if (filters.minBeds > 0 && item.specs.beds < filters.minBeds) return false;
    // Area filter
    if (filters.areaRange !== "all") {
      const area = item.specs.area;
      if (filters.areaRange === "under200" && area >= 200) return false;
      if (filters.areaRange === "200-500" && (area < 200 || area > 500)) return false;
      if (filters.areaRange === "500-1000" && (area < 500 || area > 1000)) return false;
      if (filters.areaRange === "over1000" && area < 1000) return false;
    }
    // Price filter (only for buy)
    if (filters.priceRange !== "all" && filters.transactionType === "buy") {
      const price = parsePrice(item.price);
      if (filters.priceRange === "under1M" && price >= 1000000) return false;
      if (filters.priceRange === "1M-2M" && (price < 1000000 || price > 2000000)) return false;
      if (filters.priceRange === "2M-4M" && (price < 2000000 || price > 4000000)) return false;
      if (filters.priceRange === "over4M" && price < 4000000) return false;
    }
    return true;
  });

  const filteredDevTeasers = filters.transactionType === "buy" && filters.sourceFilter !== "broker" && filters.sourceFilter !== "landlord"
    ? DEV_TEASERS.filter(item => {
        if (filters.region !== "الكل" && item.region !== filters.region) return false;
        if (filters.neighborhood !== "الكل" && item.neighborhood !== filters.neighborhood) return false;
        return true;
      })
    : [];

  const filteredExchange = EXCHANGE_LISTINGS.filter(item => {
    if (filters.region !== "الكل" && item.region !== filters.region) return false;
    if (filters.neighborhood !== "الكل" && item.neighborhood !== filters.neighborhood) return false;
    return true;
  });

  // Build combined feed
  type FeedItem = { kind: "listing"; data: any } | { kind: "devTeaser"; data: any };
  const combinedFeed: FeedItem[] = [];

  if (filters.transactionType === "exchange") {
    // exchange handled separately
  } else {
    const listingItems = filteredListings.filter(item => {
      if (filters.sourceFilter === "all") return item.source !== "developer";
      return true;
    }).map(d => ({ kind: "listing" as const, data: d }));

    const devItems = filteredDevTeasers.map(d => ({ kind: "devTeaser" as const, data: d }));

    const maxLen = Math.max(listingItems.length, devItems.length);
    for (let i = 0; i < maxLen; i++) {
      if (listingItems[i]) combinedFeed.push(listingItems[i]);
      if (devItems[i]) combinedFeed.push(devItems[i]);
    }
  }

  const exchangeFeed = filteredExchange;

  const totalResults = filters.transactionType === "exchange" ? exchangeFeed.length : combinedFeed.length;

  // ── NEIGHBORHOODS for selected region ─────────────────────────────
  const tempNeighborhoods = tempFilters.region !== "الكل" ? REGIONS_DATA[tempFilters.region] || [] : [];

  // ── QUICK FILTER OPTIONS for slide-down sub-bar ────────────────────
  const liveNeighborhoods = filters.region !== "الكل" ? REGIONS_DATA[filters.region] || [] : [];
  const filterOptions: Record<string, { id: string; label: string; Icon: any }[]> = {
    type: [
      { id: "buy", label: "للبيع", Icon: Tag },
      { id: "rent", label: "للإيجار", Icon: KeyRound },
      { id: "exchange", label: "للبدل", Icon: ArrowRightLeft },
    ],
    source: [
      { id: "all", label: "الكل", Icon: Globe },
      { id: "broker", label: "وسطاء", Icon: Briefcase },
      { id: "landlord", label: "ملاك", Icon: KeyRound },
      { id: "developer", label: "مطورين", Icon: Building2 },
    ],
    region: [{ id: "الكل", label: "الكل", Icon: Globe }, ...REGIONS.map(r => ({ id: r, label: r, Icon: MapPin }))],
    neighborhood: [{ id: "الكل", label: "الكل", Icon: Globe }, ...liveNeighborhoods.map(n => ({ id: n, label: n, Icon: LocateFixed }))],
    proptype: PROPERTY_TYPES.map(p => ({ id: p.id, label: p.label, Icon: p.Icon })),
  };
  const getActiveValue = (id: string) => {
    if (id === "type") return filters.transactionType;
    if (id === "source") return filters.sourceFilter;
    if (id === "region") return filters.region;
    if (id === "neighborhood") return filters.neighborhood;
    if (id === "proptype") return filters.propType;
    return "";
  };
  const handleFilterSelect = (filterId: string, optId: string) => {
    if (filterId === "type") { setFilter("transactionType", optId as ListingType); setFilter("sourceFilter", "all"); }
    else if (filterId === "source") setFilter("sourceFilter", optId as SourceType);
    else if (filterId === "region") { setFilter("region", optId); setFilter("neighborhood", "الكل"); }
    else if (filterId === "neighborhood") setFilter("neighborhood", optId);
    else if (filterId === "proptype") setFilter("propType", optId as PropTypeId);
    setOpenDropdown(null);
  };

  if (selectedProperty) {
    return <PropertyDetailScreen property={selectedProperty} onBack={() => setSelectedProperty(null)} isDark={isDark} />;
  }
  if (selectedExchange) {
    return <ExchangeDetailScreen exchange={selectedExchange} onBack={() => setSelectedExchange(null)} isDark={isDark} />;
  }

  return (
    <div className={`h-full flex flex-col overflow-hidden ${isDark ? "bg-[#0f172a]" : "bg-gray-50"}`}>
      {/* ── HEADER ── */}
      <div
        className={`px-4 pt-6 pb-0 z-20 sticky top-0 ${isDark ? "bg-[#0f172a]/95 backdrop-blur-md border-b border-white/5" : "bg-white/95 backdrop-blur-md border-b border-gray-100"}`}
      >
        {/* ── AI SEARCH BAR ── */}
        <div
          onClick={e => e.stopPropagation()}
          className={`relative mb-3 rounded-2xl border-2 transition-all duration-300 overflow-hidden ${
            aiActive
              ? isDark
                ? "border-cyan-500/70 shadow-[0_0_20px_rgba(6,182,212,0.25)]"
                : "border-blue-500/60 shadow-[0_0_20px_rgba(59,130,246,0.2)]"
              : isDark
                ? "border-white/8 bg-[#151a2d]"
                : "border-gray-200 bg-white shadow-sm"
          } ${isDark ? "bg-[#151a2d]" : "bg-white"}`}
        >
          {aiActive && (
            <motion.div
              className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
              animate={{ x: ["-100%", "100%"] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            />
          )}
          <div className="flex items-center gap-2 px-3 py-1">
            <motion.div
              animate={aiActive ? { rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] } : {}}
              transition={{ duration: 1.5, repeat: Infinity }}
              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                aiActive ? "bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30" : isDark ? "bg-white/5" : "bg-gray-100"
              }`}
            >
              <Sparkles className={`w-4.5 h-4.5 ${aiActive ? "text-white" : isDark ? "text-gray-400" : "text-gray-500"}`} style={{ width: "18px", height: "18px" }} />
            </motion.div>
            <input
              type="text"
              value={aiQuery}
              onChange={e => setAiQuery(e.target.value)}
              onFocus={() => setAiActive(true)}
              onBlur={() => setAiActive(false)}
              placeholder="اسألني... فيلا 5 غرف في شمال الرياض بأقل من 3 مليون"
              className={`flex-1 bg-transparent border-none outline-none py-3 text-sm ${isDark ? "text-white placeholder-gray-600" : "text-gray-900 placeholder-gray-400"}`}
              style={{ direction: "rtl" }}
            />
            <div className="flex items-center gap-1 shrink-0">
              <button className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${isDark ? "text-gray-500 hover:text-gray-300 hover:bg-white/5" : "text-gray-400 hover:text-gray-600 hover:bg-gray-100"}`}>
                <Mic className="w-4 h-4" />
              </button>
              <button className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${aiQuery.length > 0 ? "bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-md" : isDark ? "text-gray-600" : "text-gray-300"}`}>
                <SendHorizonal className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className={`absolute top-2 left-12 px-1.5 py-0.5 rounded-md text-[8px] font-black tracking-widest ${isDark ? "bg-cyan-500/15 text-cyan-400 border border-cyan-500/20" : "bg-blue-50 text-blue-500 border border-blue-200"}`}>AI</div>
        </div>

        {/* ── FILTER PILLS ROW ── */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 pb-2" style={{ scrollbarWidth: "none" }}>
          <FilterPill
            Icon={Tag}
            label={filters.transactionType === "buy" ? "للبيع" : filters.transactionType === "rent" ? "للإيجار" : "للبدل"}
            active={filters.transactionType !== "buy"}
            activeColor="bg-cyan-600 border-cyan-600 text-white"
            isOpen={openDropdown === "type"}
            isDark={isDark}
            onClick={() => setOpenDropdown(openDropdown === "type" ? null : "type")}
          />
          {filters.transactionType !== "exchange" && (
            <FilterPill
              Icon={Users}
              label={filters.sourceFilter === "all" ? "عقارات من" : filters.sourceFilter === "broker" ? "وسطاء" : filters.sourceFilter === "developer" ? "مطورين" : "ملاك"}
              active={filters.sourceFilter !== "all"}
              activeColor="bg-amber-500 border-amber-500 text-white"
              isOpen={openDropdown === "source"}
              isDark={isDark}
              onClick={() => setOpenDropdown(openDropdown === "source" ? null : "source")}
            />
          )}
          <FilterPill
            Icon={MapPin}
            label={filters.region === "الكل" ? "المنطقة" : filters.region}
            active={filters.region !== "الكل"}
            activeColor="bg-red-500 border-red-500 text-white"
            isOpen={openDropdown === "region"}
            isDark={isDark}
            onClick={() => setOpenDropdown(openDropdown === "region" ? null : "region")}
          />
          {filters.region !== "الكل" && REGIONS_DATA[filters.region]?.length > 0 && (
            <FilterPill
              Icon={LocateFixed}
              label={filters.neighborhood === "الكل" ? "الحي" : filters.neighborhood}
              active={filters.neighborhood !== "الكل"}
              activeColor="bg-orange-500 border-orange-500 text-white"
              isOpen={openDropdown === "neighborhood"}
              isDark={isDark}
              onClick={() => setOpenDropdown(openDropdown === "neighborhood" ? null : "neighborhood")}
            />
          )}
          <FilterPill
            Icon={Home}
            label={PROPERTY_TYPES.find(p => p.id === filters.propType)?.label ?? "نوع العقار"}
            active={filters.propType !== "all"}
            activeColor={isDark ? "bg-white border-white text-black" : "bg-gray-900 border-gray-900 text-white"}
            isOpen={openDropdown === "proptype"}
            isDark={isDark}
            onClick={() => setOpenDropdown(openDropdown === "proptype" ? null : "proptype")}
          />
          <button
            onClick={() => { setTempFilters(filters); setShowFilterPanel(true); setOpenDropdown(null); }}
            className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-black whitespace-nowrap border transition-all shrink-0 ${
              activeCount > 0
                ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white border-transparent shadow-md"
                : isDark ? "bg-white/5 text-white/70 border-white/10" : "bg-white text-gray-700 border-gray-200 shadow-sm"
            }`}
          >
            <SlidersHorizontal style={{ width: "11px", height: "11px" }} />
            تصفية
            {activeCount > 0 && (
              <span className="absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-black flex items-center justify-center">{activeCount}</span>
            )}
          </button>
        </div>

        {/* ── SLIDE-DOWN OPTIONS BAR (outside overflow container!) ── */}
        <AnimatePresence>
          {openDropdown && filterOptions[openDropdown] && (
            <motion.div
              key={openDropdown}
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className={`overflow-hidden border-t ${isDark ? "border-white/5 bg-[#0f172a]/98" : "border-gray-100 bg-white/98"}`}
            >
              <div className="flex gap-2 overflow-x-auto px-4 py-2.5" style={{ scrollbarWidth: "none" }}>
                {filterOptions[openDropdown].map(opt => {
                  const OIcon = opt.Icon;
                  const isSelected = getActiveValue(openDropdown) === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => handleFilterSelect(openDropdown, opt.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black whitespace-nowrap border-2 transition-all shrink-0 ${
                        isSelected
                          ? "bg-cyan-500 border-cyan-500 text-white shadow-md shadow-cyan-500/30"
                          : isDark ? "bg-white/5 border-white/10 text-white/70 hover:bg-white/10" : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                      }`}
                    >
                      <OIcon style={{ width: "11px", height: "11px" }} />
                      {opt.label}
                      {isSelected && <CheckCircle style={{ width: "10px", height: "10px" }} />}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results count */}
        <div className="flex items-center justify-between px-1 py-2">
          <span className={`text-[10px] font-bold ${isDark ? "text-white/30" : "text-gray-400"}`}>
            {totalResults} نتيجة{totalResults > 0 ? ` · ${filters.transactionType === "buy" ? "للبيع" : filters.transactionType === "rent" ? "للإيجار" : "للبدل"}` : ""}
            {filters.region !== "الكل" ? ` · ${filters.region}` : ""}
            {filters.neighborhood !== "الكل" ? ` / ${filters.neighborhood}` : ""}
          </span>
          <div className="flex items-center gap-2">
            {activeCount > 0 && (
              <button onClick={() => setFilters(DEFAULT_FILTERS)} className={`text-[10px] font-black flex items-center gap-1 ${isDark ? "text-cyan-400" : "text-blue-600"}`}>
                <X style={{ width: "10px", height: "10px" }} /> إعادة ضبط
              </button>
            )}
            <button
              onClick={() => { setSavedToast(true); setTimeout(() => setSavedToast(false), 2500); }}
              className={`flex items-center gap-1 text-[10px] font-black px-2 py-1 rounded-lg transition-all ${isDark ? "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white" : "bg-gray-100 text-gray-400 hover:bg-gray-200 hover:text-gray-700"}`}
            >
              <BellPlus style={{ width: "10px", height: "10px" }} /> حفظ البحث
            </button>
          </div>
        </div>
      </div>

      {/* ── CONTENT AREA ── */}
      <div className="flex-1 overflow-y-auto p-5 pb-32" onClick={() => { if (openDropdown) setOpenDropdown(null); }}>
        {/* Exchange Mode Label */}
        {filters.transactionType === "exchange" && (
          <div className={`flex items-center gap-2 mb-4 px-4 py-2.5 rounded-2xl border ${isDark ? "bg-purple-500/10 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
            <RotateCcw className="w-4 h-4 text-purple-500" />
            <span className="text-xs font-black text-purple-500">سوق المقايضة العقارية</span>
            <span className={`text-[10px] mr-auto ${isDark ? "text-white/30" : "text-gray-400"}`}>{exchangeFeed.length} عروض نشطة</span>
          </div>
        )}

        {/* Empty State */}
        {totalResults === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className={`w-20 h-20 rounded-3xl flex items-center justify-center ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
              <Search className={`w-9 h-9 ${isDark ? "text-white/20" : "text-gray-300"}`} />
            </div>
            <p className={`font-black text-sm ${isDark ? "text-white/40" : "text-gray-400"}`}>لا توجد نتائج للفلاتر المحددة</p>
            <button
              onClick={() => setFilters(DEFAULT_FILTERS)}
              className={`px-5 py-2.5 rounded-xl text-xs font-black ${isDark ? "bg-white/10 text-white" : "bg-gray-900 text-white"}`}
            >
              إعادة ضبط الفلاتر
            </button>
          </div>
        )}

        <div className="flex flex-col gap-5">
          {filters.transactionType === "exchange"
            ? exchangeFeed.map(item => (
                <div key={item.id} onClick={() => setSelectedExchange(item)} className="cursor-pointer">
                  <ExchangeCard data={item} isDark={isDark} />
                </div>
              ))
            : combinedFeed.map(item =>
                item.kind === "listing" ? (
                  <div key={item.data.id} onClick={() => setSelectedProperty(item.data)} className="cursor-pointer">
                    <StandardCard data={item.data} isDark={isDark} />
                  </div>
                ) : (
                  <div key={item.data.id} onClick={() => onSelectDevProject?.(item.data.projectId)} className="cursor-pointer">
                    <DevTeaserCard data={item.data} isDark={isDark} />
                  </div>
                )
              )
          }
        </div>
      </div>

      {/* ── SAVED SEARCH TOAST ── */}
      <AnimatePresence>
        {savedToast && (
          <motion.div
            initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
            className="fixed bottom-28 left-1/2 -translate-x-1/2 z-[150] flex items-center gap-2 px-4 py-2.5 rounded-2xl shadow-xl bg-emerald-600 text-white text-xs font-black whitespace-nowrap"
          >
            <CheckCircle className="w-3.5 h-3.5" /> تم حفظ البحث · ستصلك تنبيهات فور نزول عقارات مطابقة
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── FLOATING MAP BUTTON ── */}
      <AnimatePresence>
        {!showMap && !selectedProperty && !selectedExchange && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.94 }}
            onClick={() => setShowMap(true)}
            className="fixed bottom-28 right-4 z-[99] w-14 h-14 rounded-full flex items-center justify-center shadow-2xl"
            style={{ background: "linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%)" }}
          >
            <div className="absolute inset-0 rounded-full bg-sky-400 opacity-25 blur-xl animate-pulse" />
            <Map className="w-6 h-6 text-white relative z-10" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* ── MAP VIEW OVERLAY ── */}
      <AnimatePresence>
        {showMap && <MapView onClose={() => setShowMap(false)} />}
      </AnimatePresence>

      {/* ── COMPREHENSIVE FILTER PANEL (centered dialog) ── */}
      <AnimatePresence>
        {showFilterPanel && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40"
              onClick={() => setShowFilterPanel(false)}
            />
            {/* Centered Dialog */}
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.92, y: 20 }}
              transition={{ type: "spring", damping: 28, stiffness: 350 }}
              className={`fixed inset-x-4 top-[8%] bottom-[8%] z-50 rounded-3xl shadow-2xl overflow-hidden flex flex-col mx-auto max-w-lg ${isDark ? "bg-[#0d1424] border border-white/10" : "bg-white border border-gray-200"}`}
            >
              {/* Handle */}
              <div className="flex justify-center pt-3 pb-1">
                <div className={`w-12 h-1 rounded-full ${isDark ? "bg-white/20" : "bg-gray-300"}`} />
              </div>

              {/* Header */}
              <div className={`flex items-center justify-between px-6 py-4 border-b ${isDark ? "border-white/5" : "border-gray-100"}`}>
                <div>
                  <h2 className={`font-black text-base ${isDark ? "text-white" : "text-gray-900"}`}>تصفية متقدمة</h2>
                  <p className={`text-[11px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>ضبط الفلاتر لعرض النتائج المناسبة</p>
                </div>
                <button
                  onClick={() => setShowFilterPanel(false)}
                  className={`w-9 h-9 rounded-xl flex items-center justify-center ${isDark ? "bg-white/5 text-white/60" : "bg-gray-100 text-gray-600"}`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">

                {/* نوع المعاملة */}
                <FilterSection title="نوع المعاملة" Icon={Tag} isDark={isDark}>
                  <div className="flex gap-2">
                    {[
                      { id: "buy", label: "للبيع", Icon: Tag, color: "cyan" },
                      { id: "rent", label: "للإيجار", Icon: KeyRound, color: "emerald" },
                      { id: "exchange", label: "للبدل", Icon: ArrowRightLeft, color: "purple" },
                    ].map(opt => {
                      const OIcon = opt.Icon;
                      return (
                        <button key={opt.id}
                          onClick={() => setTempFilters(prev => ({ ...prev, transactionType: opt.id as ListingType, sourceFilter: "all" }))}
                          className={`flex-1 py-3 rounded-2xl text-xs font-black flex flex-col items-center gap-2 border-2 transition-all ${
                            tempFilters.transactionType === opt.id
                              ? opt.color === "cyan" ? "bg-cyan-500/20 border-cyan-500 text-cyan-400" : opt.color === "emerald" ? "bg-emerald-500/20 border-emerald-500 text-emerald-400" : "bg-purple-500/20 border-purple-500 text-purple-400"
                              : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                          }`}
                        >
                          <OIcon className="w-5 h-5" />
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </FilterSection>

                {/* عقارات من */}
                {tempFilters.transactionType !== "exchange" && (
                  <FilterSection title="عقارات من" Icon={Users} isDark={isDark}>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: "all", label: "الكل", Icon: Globe, desc: "جميع المصادر" },
                        { id: "broker", label: "وسطاء", Icon: Briefcase, desc: "مكاتب عقارية" },
                        { id: "landlord", label: "ملاك", Icon: KeyRound, desc: "مباشر مع المالك" },
                        { id: "developer", label: "مطورين", Icon: Building2, desc: "مشاريع تطوير" },
                      ].map(opt => {
                        const OIcon = opt.Icon;
                        return (
                          <button key={opt.id}
                            onClick={() => setTempFilters(prev => ({ ...prev, sourceFilter: opt.id as SourceType }))}
                            className={`py-3 px-3 rounded-2xl text-xs font-black flex items-center gap-3 border-2 transition-all ${
                              tempFilters.sourceFilter === opt.id
                                ? isDark ? "bg-amber-500/20 border-amber-500 text-amber-300" : "bg-amber-50 border-amber-400 text-amber-700"
                                : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                            }`}
                          >
                            <OIcon className="w-5 h-5 shrink-0" />
                            <div className="text-right">
                              <div>{opt.label}</div>
                              <div className="text-[9px] opacity-60 font-normal mt-0.5">{opt.desc}</div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </FilterSection>
                )}

                {/* المنطقة — قائمة منسدلة */}
                <FilterSection title="المنطقة" Icon={MapPin} isDark={isDark}>
                  <PanelSelect
                    isDark={isDark}
                    value={tempFilters.region}
                    onChange={v => setTempFilters(prev => ({ ...prev, region: v, neighborhood: "الكل" }))}
                    options={[{ id: "الكل", label: "الكل" }, ...REGIONS.map(r => ({ id: r, label: r }))]}
                    placeholder="اختر المنطقة"
                    Icon={MapPin}
                  />
                </FilterSection>

                {/* الحي — قائمة منسدلة */}
                {tempFilters.region !== "الكل" && tempNeighborhoods.length > 0 && (
                  <FilterSection title={`أحياء ${tempFilters.region}`} Icon={LocateFixed} isDark={isDark}>
                    <PanelSelect
                      isDark={isDark}
                      value={tempFilters.neighborhood}
                      onChange={v => setTempFilters(prev => ({ ...prev, neighborhood: v }))}
                      options={[{ id: "الكل", label: "الكل" }, ...tempNeighborhoods.map(n => ({ id: n, label: n }))]}
                      placeholder="اختر الحي"
                      Icon={LocateFixed}
                    />
                  </FilterSection>
                )}

                {/* عدد الغرف */}
                {tempFilters.transactionType !== "exchange" && tempFilters.propType !== "land" && (
                  <FilterSection title="الحد الأدنى لعدد الغرف" Icon={Bed} isDark={isDark}>
                    <div className="flex gap-2 flex-wrap">
                      {[{ val: 0, label: "الكل" }, { val: 1, label: "+1" }, { val: 2, label: "+2" }, { val: 3, label: "+3" }, { val: 4, label: "+4" }, { val: 5, label: "+5" }].map(opt => (
                        <button key={opt.val}
                          onClick={() => setTempFilters(prev => ({ ...prev, minBeds: opt.val }))}
                          className={`flex-1 min-w-[50px] py-2.5 rounded-xl text-xs font-black border-2 transition-all ${tempFilters.minBeds === opt.val ? isDark ? "bg-cyan-500/20 border-cyan-500 text-cyan-300" : "bg-cyan-50 border-cyan-500 text-cyan-700" : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"}`}
                        >{opt.label}</button>
                      ))}
                    </div>
                  </FilterSection>
                )}

                {/* نطاق السعر */}
                {tempFilters.transactionType === "buy" && (
                  <FilterSection title="نطاق السعر" Icon={Percent} isDark={isDark}>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: "all", label: "الكل", sub: "جميع الأسعار" },
                        { id: "under1M", label: "أقل من 1M", sub: "أقل من مليون" },
                        { id: "1M-2M", label: "1M – 2M", sub: "من مليون لاثنين" },
                        { id: "2M-4M", label: "2M – 4M", sub: "من اثنين لأربعة" },
                        { id: "over4M", label: "أكثر من 4M", sub: "فوق أربعة ملايين" },
                      ].map(opt => (
                        <button key={opt.id}
                          onClick={() => setTempFilters(prev => ({ ...prev, priceRange: opt.id as any }))}
                          className={`py-3 px-3 rounded-2xl text-xs font-black text-right border-2 transition-all ${tempFilters.priceRange === opt.id ? isDark ? "bg-emerald-500/20 border-emerald-500 text-emerald-300" : "bg-emerald-50 border-emerald-500 text-emerald-700" : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"}`}
                        >
                          <div>{opt.label}</div>
                          <div className="text-[9px] opacity-60 font-normal mt-0.5">{opt.sub}</div>
                        </button>
                      ))}
                    </div>
                  </FilterSection>
                )}

                {/* نطاق المساحة */}
                {tempFilters.transactionType !== "exchange" && (
                  <FilterSection title="المساحة" Icon={Square} isDark={isDark}>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: "all", label: "الكل" },
                        { id: "under200", label: "أقل من 200م²" },
                        { id: "200-500", label: "200 – 500م²" },
                        { id: "500-1000", label: "500 – 1000م²" },
                        { id: "over1000", label: "أكثر من 1000م²" },
                      ].map(opt => (
                        <button key={opt.id}
                          onClick={() => setTempFilters(prev => ({ ...prev, areaRange: opt.id as any }))}
                          className={`py-2.5 px-3 rounded-xl text-xs font-black border-2 transition-all ${tempFilters.areaRange === opt.id ? isDark ? "bg-indigo-500/20 border-indigo-500 text-indigo-300" : "bg-indigo-50 border-indigo-500 text-indigo-700" : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"}`}
                        >{opt.label}</button>
                      ))}
                    </div>
                  </FilterSection>
                )}

                {/* نوع العقار */}
                {tempFilters.transactionType !== "exchange" && (
                  <FilterSection title="نوع العقار" Icon={Home} isDark={isDark}>
                    <div className="grid grid-cols-4 gap-2">
                      {PROPERTY_TYPES.map(pt => {
                        const PIcon = pt.Icon;
                        return (
                          <button key={pt.id}
                            onClick={() => setTempFilters(prev => ({ ...prev, propType: pt.id }))}
                            className={`py-3 px-1 rounded-2xl text-[10px] font-black flex flex-col items-center gap-1.5 border-2 transition-all ${
                              tempFilters.propType === pt.id
                                ? isDark ? "bg-white/15 border-white/50 text-white" : "bg-gray-900 border-gray-900 text-white"
                                : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                            }`}
                          >
                            <PIcon className="w-5 h-5" />
                            {pt.label}
                          </button>
                        );
                      })}
                    </div>
                  </FilterSection>
                )}

              </div>

              {/* Footer Buttons */}
              <div className={`shrink-0 px-6 pb-6 pt-4 border-t ${isDark ? "border-white/5 bg-[#0d1424]" : "border-gray-100 bg-white"}`}>
                <div className="flex gap-3">
                  <button
                    onClick={() => { setTempFilters(DEFAULT_FILTERS); }}
                    className={`flex-1 py-3.5 rounded-2xl text-sm font-black border-2 transition-all ${isDark ? "border-white/10 text-white/60 hover:bg-white/5" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}
                  >
                    إعادة ضبط
                  </button>
                  <button
                    onClick={() => { setFilters(tempFilters); setShowFilterPanel(false); }}
                    className="flex-1 py-3.5 rounded-2xl text-sm font-black bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20 transition-all hover:shadow-xl"
                  >
                    عرض النتائج
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

// ==========================================
// FILTER PILL (quick bar button only)
// ==========================================
function FilterPill({ Icon, label, active, activeColor, isOpen, isDark, onClick }: any) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-black whitespace-nowrap border-2 transition-all shrink-0 ${
        isOpen
          ? isDark ? "bg-white/10 border-cyan-500 text-white" : "bg-blue-50 border-blue-500 text-blue-700"
          : active
            ? activeColor
            : isDark ? "bg-white/5 text-white/70 border-white/10" : "bg-white text-gray-700 border-gray-200 shadow-sm"
      }`}
    >
      <Icon style={{ width: "12px", height: "12px" }} />
      {label}
      {isOpen
        ? <ChevronUp style={{ width: "10px", height: "10px", opacity: 0.8 }} />
        : <ChevronDown style={{ width: "10px", height: "10px", opacity: 0.6 }} />
      }
    </button>
  );
}

// ==========================================
// PANEL SELECT — dropdown list inside filter panel
// ==========================================
function PanelSelect({ isDark, value, onChange, options, placeholder, Icon: PIcon }: any) {
  const [open, setOpen] = useState(false);
  const selectedLabel = options.find((o: any) => o.id === value)?.label ?? placeholder;
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(v => !v)}
        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-sm font-black transition-all ${
          value && value !== "الكل"
            ? isDark ? "border-cyan-500 bg-cyan-500/10 text-white" : "border-blue-500 bg-blue-50 text-blue-800"
            : isDark ? "bg-white/5 border-white/10 text-white/60" : "bg-gray-50 border-gray-200 text-gray-500"
        }`}
      >
        <PIcon className="w-4 h-4 shrink-0" />
        <span className="flex-1 text-right">{selectedLabel}</span>
        {open ? <ChevronUp className="w-4 h-4 shrink-0" /> : <ChevronDown className="w-4 h-4 shrink-0" />}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className={`overflow-hidden rounded-xl border mt-1.5 ${isDark ? "bg-[#151a2d] border-white/10" : "bg-white border-gray-200"}`}
          >
            <div className="max-h-48 overflow-y-auto">
              {options.map((opt: any) => (
                <button key={opt.id}
                  onClick={() => { onChange(opt.id); setOpen(false); }}
                  className={`w-full text-right px-4 py-2.5 text-sm font-bold flex items-center gap-2 transition-colors ${
                    value === opt.id
                      ? isDark ? "bg-cyan-500/15 text-cyan-400" : "bg-blue-50 text-blue-700"
                      : isDark ? "text-white/70 hover:bg-white/5" : "text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  <span className="flex-1">{opt.label}</span>
                  {value === opt.id && <CheckCircle className="w-3.5 h-3.5" />}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ==========================================
// FILTER SECTION WRAPPER
// ==========================================
function FilterSection({ title, Icon: SIcon, isDark, children }: any) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <div className={`w-6 h-6 rounded-lg flex items-center justify-center ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
          <SIcon className={`w-3.5 h-3.5 ${isDark ? "text-white/70" : "text-gray-600"}`} />
        </div>
        <h3 className={`font-black text-sm ${isDark ? "text-white" : "text-gray-900"}`}>{title}</h3>
      </div>
      {children}
    </div>
  );
}

// ==========================================
// STANDARD CARD
// ==========================================
function StandardCard({ data, isDark }: any) {
  const sourceBg = data.source === "developer" ? "bg-blue-500" : data.source === "landlord" ? "bg-amber-500" : "bg-emerald-600";
  const SourceIcon = data.source === "developer" ? Building2 : data.source === "landlord" ? KeyRound : Briefcase;
  const sourceLabel = data.source === "developer" ? "مطور" : data.source === "landlord" ? "مالك" : "وسيط";
  const txLabel = data.transactionType === "rent" ? "للإيجار" : "للبيع";
  const txColor = data.transactionType === "rent" ? "bg-emerald-600" : "bg-blue-600";
  return (
    <div className={`group rounded-3xl overflow-hidden border transition-all hover:shadow-2xl ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
      <div className="relative h-56 overflow-hidden bg-gray-200">
        <img src={data.image} alt={data.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" onError={e => { (e.target as HTMLImageElement).src = "https://placehold.co/800x560/1e293b/94a3b8?text=عقار"; }} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
        <div className="absolute top-3 right-3 flex gap-1.5 flex-wrap">
          <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black ${sourceBg} text-white flex items-center gap-1`}><SourceIcon style={{width:"9px",height:"9px"}}/>{sourceLabel}</span>
          <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black ${txColor} text-white`}>{txLabel}</span>
          {data.deed && <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-black/40 backdrop-blur text-white border border-white/20 flex items-center gap-1"><ShieldCheck style={{width:"9px",height:"9px"}}/>صك</span>}
        </div>
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black backdrop-blur border flex items-center gap-1 ${data.negotiable ? "bg-emerald-500/80 text-white border-emerald-400/40" : "bg-red-500/80 text-white border-red-400/40"}`}>
            {data.negotiable ? <CheckCircle style={{ width: "10px", height: "10px" }} /> : <XCircle style={{ width: "10px", height: "10px" }} />}
            {data.negotiable ? "قابل للتفاوض" : "سعر نهائي"}
          </span>
          {data.priceDrop && (
            <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-rose-600/90 backdrop-blur text-white border border-rose-400/40 flex items-center gap-1">
              <TrendingDown style={{ width: "9px", height: "9px" }} /> خصم {data.priceDrop.percent}%
            </span>
          )}
        </div>
        {/* View count */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1 px-2 py-1 rounded-lg bg-black/50 backdrop-blur-md">
          <Eye style={{ width: "9px", height: "9px", color: "rgba(255,255,255,0.6)" }} />
          <span className="text-[9px] text-white/60">{data.views?.toLocaleString() ?? 0}</span>
        </div>
        {data.aiRec && (
          <div className="absolute bottom-3 right-3 left-12">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-black/50 backdrop-blur-md border border-purple-500/30">
              <Sparkles className="w-3 h-3 text-purple-400 shrink-0" />
              <p className="text-[9px] text-white/90 line-clamp-1">{data.aiRec}</p>
            </div>
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div className="flex-1 min-w-0">
            <h3 className={`font-black text-base mb-1 leading-tight ${isDark ? "text-white" : "text-gray-900"}`}>{data.title}</h3>
            <div className="flex items-center gap-1 text-gray-500 text-xs"><MapPin className="w-3 h-3 shrink-0" />{data.location}</div>
            {data.adNumber && (
              <div className="flex items-center gap-1 mt-1">
                <Hash style={{ width: "9px", height: "9px", color: "#94a3b8" }} />
                <span className="text-[9px] text-gray-400">إعلان {data.adNumber}</span>
              </div>
            )}
          </div>
          <div className="text-left shrink-0 ml-3">
            <span className={`block font-black text-lg ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{data.price}</span>
            {data.priceDrop && (
              <span className="text-[9px] line-through text-gray-400 block">{data.priceDrop.from}</span>
            )}
            <span className="text-[9px] text-gray-500">ريال</span>
          </div>
        </div>
        <div className={`flex gap-3 mt-3 pt-3 border-t border-dashed border-gray-500/20 text-gray-500 flex-wrap`}>
          {data.specs.beds > 0 && <>
            <span className="text-xs flex items-center gap-1"><Bed className="w-3.5 h-3.5" /> {data.specs.beds} غرف</span>
            <span className="text-xs flex items-center gap-1"><Bath className="w-3.5 h-3.5" /> {data.specs.baths} حمام</span>
          </>}
          <span className="text-xs flex items-center gap-1"><Square className="w-3.5 h-3.5" /> {data.specs.area}م²</span>
          {/* FAL badge */}
          {data.advertiser?.falNumber && (
            <span className={`mr-auto text-[9px] flex items-center gap-1 px-1.5 py-0.5 rounded-md border ${isDark ? "bg-amber-500/10 border-amber-500/20 text-amber-400" : "bg-amber-50 border-amber-200 text-amber-700"}`}>
              <ShieldCheck style={{ width: "8px", height: "8px" }} /> فال
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// DEV TEASER CARD
// ==========================================
function DevTeaserCard({ data, isDark }: any) {
  return (
    <div className={`group rounded-3xl overflow-hidden border transition-all hover:shadow-2xl ${isDark ? "bg-[#151a2d] border-blue-500/20" : "bg-white border-blue-100 shadow-sm"}`}>
      <div className="relative h-48 overflow-hidden bg-gray-200">
        <img src={data.image} alt={data.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
        <div className="absolute top-3 right-3 flex gap-1.5">
          <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-blue-600 text-white flex items-center gap-1"><Building2 style={{width:"9px",height:"9px"}}/>مشروع مطور</span>
          <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-black/40 backdrop-blur text-white border border-white/20">{data.badge}</span>
        </div>
        <div className="absolute bottom-3 right-3 left-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[9px] text-white/70">نسبة الإنجاز</span>
            <span className="text-[9px] font-black text-emerald-400">{data.completion}%</span>
          </div>
          <div className="h-1 bg-white/20 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-full" style={{ width: `${data.completion}%` }} />
          </div>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className={`font-black text-base mb-0.5 ${isDark ? "text-white" : "text-gray-900"}`}>{data.name}</h3>
            <p className={`text-[10px] font-bold mb-1 ${isDark ? "text-blue-400" : "text-blue-600"}`}>{data.developer}</p>
            <div className="flex items-center gap-1 text-gray-500 text-xs"><MapPin className="w-3 h-3" />{data.location}</div>
          </div>
          <div className="text-left">
            <span className={`block font-black text-sm ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{data.priceRange}</span>
            <span className="text-[9px] text-gray-500">ريال</span>
          </div>
        </div>
        <div className="flex gap-3 mt-3 pt-3 border-t border-dashed border-gray-500/20">
          <span className={`text-xs flex items-center gap-1 ${isDark ? "text-white/50" : "text-gray-500"}`}><Building style={{ width: "13px", height: "13px" }} /> {data.units} وحدة</span>
          <span className="text-xs flex items-center gap-1 text-emerald-500"><CheckCircle style={{ width: "13px", height: "13px" }} /> {data.available} متاح</span>
          <span className={`text-xs flex items-center gap-1 mr-auto ${isDark ? "text-blue-400" : "text-blue-600"}`}>عرض المشروع <ChevronRight style={{ width: "13px", height: "13px" }} /></span>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// EXCHANGE CARD
// ==========================================
function ExchangeCard({ data, isDark }: any) {
  const deltaConfig = {
    receive: { bg: isDark ? "bg-amber-500/15 border-amber-500/30 text-amber-400" : "bg-amber-50 border-amber-200 text-amber-700", text: `يطلب فرق ${data.delta} ريال` },
    pay: { bg: isDark ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400" : "bg-emerald-50 border-emerald-200 text-emerald-700", text: `يدفع فرق ${data.delta} ريال` },
    equal: { bg: isDark ? "bg-purple-500/15 border-purple-500/30 text-purple-400" : "bg-purple-50 border-purple-200 text-purple-700", text: "رأس برأس — بدون فرق سعر" },
  };
  const dc = deltaConfig[data.deltaType as keyof typeof deltaConfig];
  return (
    <div className={`rounded-3xl overflow-hidden border ${isDark ? "bg-[#151a2d] border-purple-500/20" : "bg-white border-purple-100 shadow-lg"}`}>
      <div className="h-1 bg-gradient-to-r from-purple-500 via-pink-400 to-purple-500" />
      <div className={`px-4 pt-3 pb-2.5 flex items-center justify-between border-b ${isDark ? "border-white/5" : "border-gray-100"}`}>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center font-black text-white text-xs">
            {data.user.name[0]}
          </div>
          <div>
            <div className="flex items-center gap-1">
              <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{data.user.name}</p>
              {data.user.verified && <CheckCircle style={{width:"10px",height:"10px"}} className="text-cyan-500" />}
            </div>
            <p className="text-[9px] opacity-40">{data.postedDate}</p>
          </div>
        </div>
        <div className={`flex items-center gap-1.5 px-3 py-1 rounded-xl border ${isDark ? "bg-purple-500/10 border-purple-500/20 text-purple-400" : "bg-purple-50 border-purple-200 text-purple-600"}`}>
          <RotateCcw className="w-3 h-3" />
          <span className="text-[9px] font-black">بدل عقاري</span>
        </div>
      </div>
      <div className="p-4">
        <div className="flex gap-3 items-stretch">
          <div className="flex-1 min-w-0">
            <span className={`text-[8px] font-black px-2 py-0.5 rounded-md inline-block mb-2 ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700"}`}>ما لديه</span>
            <div className="h-28 rounded-2xl overflow-hidden relative mb-2">
              <img src={data.have.image} alt={data.have.type} className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).src = "https://placehold.co/400x300/1e293b/94a3b8?text=عقار"; }} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
              <div className="absolute bottom-2 right-2">
                <span className="text-[9px] font-black text-white bg-black/50 backdrop-blur px-1.5 py-0.5 rounded-lg">{data.have.price} ريال</span>
              </div>
            </div>
            <p className={`text-xs font-black leading-tight mb-0.5 ${isDark ? "text-white" : "text-gray-900"}`}>{data.have.type}</p>
            <p className="text-[9px] opacity-50 flex items-center gap-1"><MapPin className="w-2.5 h-2.5" />{data.have.location}</p>
            <div className="flex gap-2 mt-1">
              {data.have.rooms > 0 && <span className="text-[9px] opacity-40 flex items-center gap-0.5"><Bed className="w-2.5 h-2.5" />{data.have.rooms}</span>}
              <span className="text-[9px] opacity-40">{data.have.area}</span>
            </div>
          </div>
          <div className="flex items-center justify-center pt-8">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-md ${isDark ? "bg-purple-500/20 border border-purple-500/30" : "bg-purple-100 border border-purple-200"}`}>
              <ArrowRightLeft className="w-4 h-4 text-purple-500" />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <span className={`text-[8px] font-black px-2 py-0.5 rounded-md inline-block mb-2 ${isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"}`}>ما يريده</span>
            <div className={`h-28 rounded-2xl flex flex-col items-center justify-center p-3 mb-2 border-2 border-dashed ${isDark ? "bg-purple-500/5 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
              <Building className="w-8 h-8 text-purple-400 opacity-40 mb-1.5" />
              <p className={`text-[10px] font-black text-center leading-tight ${isDark ? "text-purple-300" : "text-purple-700"}`}>{data.want.type}</p>
            </div>
            <p className={`text-xs font-black leading-tight mb-0.5 ${isDark ? "text-white" : "text-gray-900"}`}>{data.want.type}</p>
            <p className="text-[9px] opacity-50 flex items-center gap-1"><MapPin className="w-2.5 h-2.5" />{data.want.location}</p>
            <p className="text-[9px] opacity-40 mt-1 line-clamp-2">{data.want.specs}</p>
          </div>
        </div>
        <div className={`mt-3 flex items-center gap-2 px-3 py-2 rounded-xl border ${dc.bg}`}>
          <p className="text-[10px] font-black flex-1">{dc.text}</p>
          <span className="text-[9px] opacity-60">{data.want.priceRange}</span>
        </div>
      </div>
      <div className="px-4 pb-4 flex gap-2">
        <button className={`flex-1 py-2.5 rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 transition-colors ${isDark ? "bg-purple-500/20 text-purple-300 hover:bg-purple-500/30" : "bg-purple-600 text-white hover:bg-purple-700"}`}>
          <MessageCircle className="w-3.5 h-3.5" /> تقديم عرض بدل
        </button>
        <button className={`px-4 py-2.5 rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 border transition-colors ${isDark ? "border-white/10 text-white/60 hover:bg-white/5" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
          <Search className="w-3.5 h-3.5" /> تفاصيل
        </button>
      </div>
    </div>
  );
}



// ==========================================
// PROPERTY DETAIL SCREEN
// ==========================================
function PropertyDetailScreen({ property, onBack, isDark }: any) {
  const [showOfferInput, setShowOfferInput] = useState(false);
  const [offerPrice, setOfferPrice] = useState("");
  const [offerSent, setOfferSent] = useState(false);
  const [isFav, setIsFav] = useState(false);
  const [reported, setReported] = useState(false);
  // Mock existing bids (only min/max shown to users — full list locked by advertiser)
  const mockBids = [2100000, 2300000];
  const allBids = offerSent && offerPrice ? [...mockBids, Number(offerPrice)] : mockBids;
  const maxBid = Math.max(...allBids);
  const minBid = Math.min(...allBids);

  const sourceBg = property.source === "developer" ? "bg-blue-600" : property.source === "landlord" ? "bg-amber-500" : "bg-emerald-600";
  const SourceIcon2 = property.source === "developer" ? Building2 : property.source === "landlord" ? KeyRound : Briefcase;
  const sourceLabel = property.source === "developer" ? "مطور" : property.source === "landlord" ? "مالك" : "وسيط";
  const PropIconMap: Record<string, any> = { villa: Home, apartment: Building2, floor: Building, land: Square, building: Landmark, istirahah: TreePine, farm: Warehouse };
  const PropIcon = PropIconMap[property.propType] || Home;
  const propLabel: Record<string, string> = { villa:"فيلا", apartment:"شقة", floor:"دور", land:"أرض", building:"عمارة", istirahah:"استراحة", farm:"مزرعة" };

  // Neighborhood services (per neighborhood)
  const neighborhoodServices = [
    { icon: Building, label: "مسجد", dist: "180م" },
    { icon: GraduationCap, label: "مدرسة", dist: "500م" },
    { icon: ShoppingBag, label: "مركز تسوق", dist: "1.2 كم" },
    { icon: Utensils, label: "مطاعم", dist: "300م" },
    { icon: Activity, label: "مستشفى", dist: "2.5 كم" },
    { icon: TreePine, label: "حديقة", dist: "700م" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
      className={`h-full flex flex-col overflow-y-auto ${isDark ? "bg-[#0f172a]" : "bg-gray-50"}`}
    >
      {/* Hero */}
      <div className="relative h-72 shrink-0">
        <img src={property.image} alt={property.title} className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).src = "https://placehold.co/800x560/1e293b/94a3b8?text=عقار"; }} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
        <div className="absolute top-0 left-0 right-0 p-5 flex justify-between items-start pt-8">
          <button onClick={onBack} className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/30 transition-colors">
            <ChevronRight className="w-6 h-6" />
          </button>
          <div className="flex gap-2">
            <button className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/30 transition-colors"><Share2 className="w-5 h-5" /></button>
            <motion.button whileTap={{ scale: 0.85 }} onClick={() => setIsFav(v => !v)} className={`w-10 h-10 rounded-xl backdrop-blur-md flex items-center justify-center transition-colors ${isFav ? "bg-rose-500 text-white" : "bg-white/20 text-white hover:bg-white/30"}`}>
              <Heart className={`w-5 h-5 ${isFav ? "fill-white" : ""}`} />
            </motion.button>
          </div>
        </div>
        <div className="absolute bottom-5 right-5 text-white">
          <div className="flex gap-2 mb-2 flex-wrap">
            <span className={`px-2 py-1 rounded-lg text-[10px] font-black ${property.transactionType === "rent" ? "bg-emerald-600" : "bg-blue-600"}`}>{property.transactionType === "rent" ? "للإيجار" : "للبيع"}</span>
            <span className={`px-2 py-1 rounded-lg text-[10px] font-black ${sourceBg} flex items-center gap-1`}><SourceIcon2 style={{width:"9px",height:"9px"}}/>{sourceLabel}</span>
            {property.deed && <span className="px-2 py-1 rounded-lg bg-black/50 backdrop-blur text-[10px] font-black flex items-center gap-1 border border-white/20"><FileText className="w-3 h-3" /> صك ✓</span>}
          </div>
          <h1 className="text-2xl font-black">{property.title}</h1>
          <p className="text-sm text-white/70 flex items-center gap-1 mt-1"><MapPin className="w-4 h-4" /> {property.location}</p>
        </div>
      </div>

      <div className="flex-1 pb-32 space-y-4 p-5">

        {/* REGA Ad Number + Views */}
        <div className={`flex items-center justify-between px-4 py-2.5 rounded-xl border ${isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-100"}`}>
          <div className="flex items-center gap-1.5">
            <Hash className={`w-3.5 h-3.5 ${isDark ? "text-white/30" : "text-gray-400"}`} />
            <span className={`text-[10px] font-black ${isDark ? "text-white/40" : "text-gray-400"}`}>رقم الإعلان: {property.adNumber ?? "—"}</span>
          </div>
          <div className="flex items-center gap-3">
            {property.advertiser?.falNumber && (
              <div className={`flex items-center gap-1 px-2 py-0.5 rounded-lg border ${isDark ? "bg-amber-500/10 border-amber-500/20" : "bg-amber-50 border-amber-200"}`}>
                <ShieldCheck className="w-3 h-3 text-amber-500" />
                <span className={`text-[9px] font-black ${isDark ? "text-amber-400" : "text-amber-700"}`}>فال {property.advertiser.falNumber}</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Eye className={`w-3.5 h-3.5 ${isDark ? "text-white/25" : "text-gray-300"}`} />
              <span className={`text-[10px] ${isDark ? "text-white/30" : "text-gray-400"}`}>{property.views?.toLocaleString() ?? 0} مشاهدة</span>
            </div>
          </div>
        </div>

        {/* Price + Negotiable */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-cyan-900/20 to-blue-900/20 border-cyan-500/20" : "bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200"}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-[10px] mb-1 ${isDark ? "text-cyan-400/60" : "text-blue-500/60"}`}>السعر المطلوب</p>
              <div className="flex items-end gap-1">
                <span className={`text-3xl font-black ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{property.price}</span>
                <span className={`text-sm mb-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>ريال</span>
              </div>
              {property.priceDrop && (
                <div className="flex items-center gap-1.5 mt-1">
                  <TrendingDown className="w-3.5 h-3.5 text-rose-500" />
                  <span className="text-[10px] line-through text-gray-400">{property.priceDrop.from}</span>
                  <span className="text-[10px] font-black text-rose-500">خصم {property.priceDrop.percent}%</span>
                </div>
              )}
            </div>
            <div className="text-right">
              <div className={`px-3 py-2 rounded-xl border flex items-center gap-1.5 ${property.negotiable ? isDark ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400" : "bg-emerald-50 border-emerald-200 text-emerald-700" : isDark ? "bg-red-500/15 border-red-500/30 text-red-400" : "bg-red-50 border-red-200 text-red-700"}`}>
                {property.negotiable ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                <span className="text-xs font-black">{property.negotiable ? "قابل للتفاوض" : "سعر نهائي"}</span>
              </div>
            </div>
          </div>
        </div>

        {/* AI Insight */}
        {property.aiRec && (
          <div className={`flex items-start gap-2.5 px-4 py-3 rounded-2xl border ${isDark ? "bg-purple-500/10 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
            <Sparkles className="w-4 h-4 text-purple-500 shrink-0 mt-0.5" />
            <p className={`text-xs leading-relaxed ${isDark ? "text-purple-300" : "text-purple-700"}`}>{property.aiRec}</p>
          </div>
        )}

        {/* Key Specs Grid */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>مواصفات العقار</p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: "نوع العقار", value: propLabel[property.propType] || property.propType, Icon: PropIcon },
              { label: "المنطقة", value: property.region, Icon: MapPin },
              { label: "الحي", value: property.neighborhood, Icon: LocateFixed },
              ...(property.specs?.beds > 0 ? [{ label: "غرف النوم", value: `${property.specs.beds} غرف`, Icon: Bed }] : []),
              ...(property.specs?.baths > 0 ? [{ label: "دورات المياه", value: `${property.specs.baths} حمام`, Icon: Bath }] : []),
              { label: "المساحة", value: `${property.specs?.area}م²`, Icon: Square },
            ].map((item, i) => {
              const ItemIcon = item.Icon;
              return (
                <div key={i} className={`p-3 rounded-xl border flex items-center gap-2 ${isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-100"}`}>
                  <ItemIcon className={`w-3.5 h-3.5 shrink-0 ${isDark ? "text-white/30" : "text-gray-400"}`} />
                  <div>
                    <p className="text-[9px] opacity-40 mb-0.5">{item.label}</p>
                    <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{item.value}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Legal Info */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>المعلومات القانونية</p>
          <div className={`grid ${property.transactionType === "rent" ? "grid-cols-1 max-w-xs" : "grid-cols-2"} gap-2`}>
            <div className={`flex items-center gap-2 p-2.5 rounded-xl border ${property.deed ? isDark ? "bg-emerald-500/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200" : isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-200"}`}>
              <FileText className={`w-4 h-4 ${property.deed ? "text-emerald-500" : isDark ? "text-white/20" : "text-gray-300"}`} />
              <div>
                <p className="text-[8px] opacity-40">صك ملكية</p>
                <p className={`text-[11px] font-black ${property.deed ? isDark ? "text-emerald-400" : "text-emerald-700" : isDark ? "text-white/30" : "text-gray-400"}`}>{property.deed ? "متوفر ✓" : "غير متوفر"}</p>
              </div>
            </div>
            {property.transactionType !== "rent" && (
              <div className={`flex items-center gap-2 p-2.5 rounded-xl border ${property.bank ? isDark ? "bg-blue-500/10 border-blue-500/20" : "bg-blue-50 border-blue-200" : isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-200"}`}>
                <Building className={`w-4 h-4 ${property.bank ? "text-blue-500" : isDark ? "text-white/20" : "text-gray-300"}`} />
                <div>
                  <p className="text-[8px] opacity-40">تمويل بنكي</p>
                  <p className={`text-[11px] font-black ${property.bank ? isDark ? "text-blue-400" : "text-blue-700" : isDark ? "text-white/30" : "text-gray-400"}`}>{property.bank ? "مقبول ✓" : "كاش فقط"}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Advertiser */}
        {property.advertiser && (
          <div className={`p-3.5 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-11 h-11 rounded-2xl flex items-center justify-center text-lg font-black text-white shadow-md ${sourceBg}`}>
                {property.advertiser.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{property.advertiser.name}</p>
                  {property.advertiser.falNumber && <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />}
                </div>
                <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>{sourceLabel} · عضو منذ {property.advertiser.since}</p>
                {property.advertiser.rating && (
                  <div className="flex items-center gap-1 mt-1">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} style={{ width: "10px", height: "10px" }} className={i <= Math.round(property.advertiser.rating) ? "text-amber-400 fill-amber-400" : "text-gray-300"} />
                    ))}
                    <span className={`text-[9px] font-black ${isDark ? "text-white/50" : "text-gray-500"}`}>{property.advertiser.rating} ({property.advertiser.ratingCount} تقييم)</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex gap-2">
              <button className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black transition-colors ${isDark ? "bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25" : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"}`}>
                <Phone className="w-3.5 h-3.5" /> اتصال
              </button>
              <button className="flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black bg-[#25D366] text-white hover:bg-[#1ebd5a] transition-colors">
                <ArrowUpRight className="w-3.5 h-3.5" /> واتساب
              </button>
              <button className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black transition-colors ${isDark ? "bg-blue-500/15 text-blue-400 hover:bg-blue-500/25" : "bg-blue-50 text-blue-600 hover:bg-blue-100"}`}>
                <MessageCircle className="w-3.5 h-3.5" /> رسالة
              </button>
            </div>
          </div>
        )}

        {/* Description */}
        {property.desc && (
          <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>وصف العقار</p>
            <p className={`text-sm leading-7 ${isDark ? "text-white/70" : "text-gray-600"}`}>{property.desc}</p>
          </div>
        )}



        {/* Neighborhood Services */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-[10px] font-black mb-3 flex items-center gap-1.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>
            <MapPin className="w-3.5 h-3.5" /> الخدمات القريبة من {property.neighborhood}
          </p>
          <div className="grid grid-cols-3 gap-2">
            {neighborhoodServices.map((svc, i) => {
              const SvcIcon = svc.icon;
              return (
                <div key={i} className={`p-2.5 rounded-xl flex flex-col items-center gap-1 text-center ${isDark ? "bg-white/3 border border-white/5" : "bg-gray-50 border border-gray-100"}`}>
                  <SvcIcon className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-blue-500"}`} />
                  <p className={`text-[9px] font-black ${isDark ? "text-white/70" : "text-gray-700"}`}>{svc.label}</p>
                  <p className={`text-[8px] ${isDark ? "text-white/30" : "text-gray-400"}`}>{svc.dist}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Badges */}
        {property.badges?.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {property.badges.map((b: string, i: number) => (
              <span key={i} className={`text-[11px] font-black px-3 py-1.5 rounded-xl border ${isDark ? "bg-white/5 border-white/10 text-white/60" : "bg-white border-gray-200 text-gray-700 shadow-sm"}`}>{b}</span>
            ))}
          </div>
        )}

        {/* Private Bid System */}
        {property.negotiable && (
          <div className={`p-4 rounded-2xl border ${isDark ? "bg-purple-500/8 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className={`text-xs font-black ${isDark ? "text-purple-300" : "text-purple-800"}`}>تقديم عرض سعر رسمي</p>
                <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>سيصل عرضك مباشرة للمعلن</p>
              </div>
              <Target className="w-5 h-5 text-purple-500" />
            </div>

            {/* Bid Stats — Only min/max visible to users */}
            <div className={`p-3 rounded-xl mb-3 border ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200"}`}>
              <div className="flex items-center justify-between mb-2.5">
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-lg ${isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"}`}>{allBids.length} عرض مقدَّم</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm">🔒</span>
                  <span className={`text-[9px] font-black ${isDark ? "text-white/30" : "text-gray-400"}`}>قائمة العروض مقفلة · يتحكم المعلن في الظهور</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className={`p-2.5 rounded-lg ${isDark ? "bg-emerald-500/10 border border-emerald-500/20" : "bg-emerald-50 border border-emerald-100"}`}>
                  <p className={`text-[9px] mb-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>أعلى عرض</p>
                  <p className={`text-sm font-black ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>{maxBid.toLocaleString()} <span className="text-[9px] font-normal">ر.س</span></p>
                </div>
                <div className={`p-2.5 rounded-lg ${isDark ? "bg-rose-500/10 border border-rose-500/20" : "bg-rose-50 border border-rose-100"}`}>
                  <p className={`text-[9px] mb-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>أقل عرض</p>
                  <p className={`text-sm font-black ${isDark ? "text-rose-400" : "text-rose-700"}`}>{minBid.toLocaleString()} <span className="text-[9px] font-normal">ر.س</span></p>
                </div>
              </div>
            </div>

            {!offerSent ? (
              <>
                {showOfferInput ? (
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={offerPrice}
                      onChange={e => setOfferPrice(e.target.value)}
                      placeholder="أدخل عرضك بالريال"
                      className={`flex-1 px-3 py-2 rounded-xl border text-xs font-black outline-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/20 focus:border-purple-500" : "bg-white border-gray-200 text-gray-900 placeholder-gray-300 focus:border-purple-500"}`}
                    />
                    <button
                      onClick={() => { if (offerPrice) setOfferSent(true); }}
                      className="px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-black"
                    >إرسال</button>
                  </div>
                ) : (
                  <button onClick={() => setShowOfferInput(true)} className="w-full py-2.5 rounded-xl bg-purple-600 text-white text-xs font-black flex items-center justify-center gap-2">
                    <MessageSquare className="w-4 h-4" /> تقديم عرضي
                  </button>
                )}
              </>
            ) : (
              <div className="flex flex-col items-center gap-1.5 py-2.5">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-black text-emerald-400">تم إرسال عرضك بـ {Number(offerPrice).toLocaleString()} ريال</span>
                </div>
                <p className={`text-[9px] ${isDark ? "text-white/25" : "text-gray-400"}`}>ستصلك إشعار عند رد المعلن على عرضك</p>
              </div>
            )}
          </div>
        )}

        {/* CTA */}
        <div className="flex gap-3 pt-2">
          <button className="flex-1 py-3.5 rounded-2xl text-sm font-black flex items-center justify-center gap-2 bg-[#25D366] text-white shadow-lg shadow-green-500/20">
            <ArrowUpRight className="w-4 h-4" /> واتساب
          </button>
          <button className="flex-1 py-3.5 rounded-2xl text-sm font-black flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-blue-500/20">
            <Phone className="w-4 h-4" /> اتصال
          </button>
        </div>

        {/* Report listing */}
        <div className="flex justify-center pt-1 pb-4">
          {!reported ? (
            <button onClick={() => setReported(true)} className={`flex items-center gap-1.5 text-[10px] px-3 py-1.5 rounded-lg transition-colors ${isDark ? "text-white/20 hover:text-red-400 hover:bg-red-500/10" : "text-gray-300 hover:text-red-500 hover:bg-red-50"}`}>
              <Flag className="w-3 h-3" /> الإبلاغ عن هذا الإعلان
            </button>
          ) : (
            <span className="text-[10px] text-emerald-500 flex items-center gap-1"><CheckCircle className="w-3 h-3" /> تم استلام بلاغك · شكراً</span>
          )}
        </div>
      </div>

    </motion.div>
  );
}

// ==========================================
// EXCHANGE DETAIL SCREEN — Full property details + what they want
// ==========================================
function ExchangeDetailScreen({ exchange, onBack, isDark }: any) {
  const [isFav, setIsFav] = useState(false);
  const have = exchange.have;
  const want = exchange.want;
  const user = exchange.user;

  const deltaConfig = {
    receive: { color: isDark ? "text-amber-400" : "text-amber-700", bg: isDark ? "bg-amber-500/10 border-amber-500/20" : "bg-amber-50 border-amber-200", text: `يطلب فرق نقدي ${exchange.delta} ريال` },
    pay: { color: isDark ? "text-emerald-400" : "text-emerald-700", bg: isDark ? "bg-emerald-500/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200", text: `يدفع فرق نقدي ${exchange.delta} ريال` },
    equal: { color: isDark ? "text-purple-400" : "text-purple-700", bg: isDark ? "bg-purple-500/10 border-purple-500/20" : "bg-purple-50 border-purple-200", text: "رأس برأس — بدون فرق سعر" },
  };
  const dc = deltaConfig[exchange.deltaType as keyof typeof deltaConfig];

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
      className={`h-full flex flex-col overflow-y-auto ${isDark ? "bg-[#0f172a]" : "bg-gray-50"}`}
    >
      {/* Hero Image */}
      <div className="relative h-72 shrink-0">
        <img src={have.image} alt={have.type} className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).src = "https://placehold.co/800x560/1e293b/94a3b8?text=عقار"; }} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
        <div className="absolute top-0 left-0 right-0 p-5 flex justify-between items-start pt-8">
          <button onClick={onBack} className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/30 transition-colors">
            <ChevronRight className="w-6 h-6" />
          </button>
          <motion.button whileTap={{ scale: 0.85 }} onClick={() => setIsFav(v => !v)} className={`w-10 h-10 rounded-xl backdrop-blur-md flex items-center justify-center transition-colors ${isFav ? "bg-rose-500 text-white" : "bg-white/20 text-white hover:bg-white/30"}`}>
            <Heart className={`w-5 h-5 ${isFav ? "fill-white" : ""}`} />
          </motion.button>
        </div>
        <div className="absolute bottom-5 right-5 text-white">
          <div className="flex gap-2 mb-2 flex-wrap">
            <span className="px-2 py-1 rounded-lg bg-purple-600 text-[10px] font-black flex items-center gap-1"><ArrowRightLeft className="w-3 h-3" /> بدل عقاري</span>
            {user.verified && <span className="px-2 py-1 rounded-lg bg-black/50 backdrop-blur text-[10px] font-black border border-white/20 flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> موثق</span>}
          </div>
          <h1 className="text-2xl font-black">{have.type}</h1>
          <p className="text-sm text-white/70 flex items-center gap-1 mt-1"><MapPin className="w-4 h-4" /> {have.location}</p>
        </div>
      </div>

      <div className="flex-1 pb-32 space-y-4 p-5">

        {/* Price + Delta */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/20" : "bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200"}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-[10px] mb-1 ${isDark ? "text-purple-400/60" : "text-purple-500/70"}`}>تقييم العقار</p>
              <div className="flex items-end gap-1">
                <span className={`text-3xl font-black ${isDark ? "text-purple-400" : "text-purple-700"}`}>{have.price}</span>
                <span className={`text-sm mb-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>ريال</span>
              </div>
            </div>
            <div className={`px-4 py-2.5 rounded-xl border text-center ${dc.bg}`}>
              <p className={`text-[9px] mb-0.5 opacity-60`}>فرق البدل</p>
              <p className={`text-xs font-black ${dc.color}`}>{dc.text}</p>
            </div>
          </div>
        </div>

        {/* Key Specs Grid */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>مواصفات العقار</p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: "نوع العقار", value: have.type, Icon: Home },
              { label: "الموقع", value: have.location, Icon: MapPin },
              { label: "مساحة الأرض", value: have.area, Icon: Square },
              { label: "مساحة البناء", value: have.builtArea, Icon: Building },
              ...(have.rooms > 0 ? [{ label: "غرف النوم", value: `${have.rooms} غرف`, Icon: Bed }] : []),
              ...(have.baths > 0 ? [{ label: "دورات المياه", value: `${have.baths} حمام`, Icon: Bath }] : []),
              { label: "سنة البناء", value: have.yearBuilt, Icon: Clock },
            ].map((item, i) => {
              const ItemIcon = item.Icon;
              return (
                <div key={i} className={`p-3 rounded-xl border flex items-center gap-2 ${isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-100"}`}>
                  <ItemIcon className={`w-3.5 h-3.5 shrink-0 ${isDark ? "text-purple-400" : "text-purple-500"}`} />
                  <div>
                    <p className="text-[9px] opacity-40 mb-0.5">{item.label}</p>
                    <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{item.value}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Legal Info */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>المعلومات القانونية</p>
          <div className="grid grid-cols-2 gap-2">
            <div className={`flex items-center gap-2 p-2.5 rounded-xl border ${have.deed ? isDark ? "bg-emerald-500/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200" : isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-200"}`}>
              <FileText className={`w-4 h-4 ${have.deed ? "text-emerald-500" : isDark ? "text-white/20" : "text-gray-300"}`} />
              <div>
                <p className="text-[8px] opacity-40">صك ملكية</p>
                <p className={`text-[11px] font-black ${have.deed ? isDark ? "text-emerald-400" : "text-emerald-700" : isDark ? "text-white/30" : "text-gray-400"}`}>{have.deed ? "متوفر ✓" : "غير متوفر"}</p>
              </div>
            </div>
            <div className={`flex items-center gap-2 p-2.5 rounded-xl border ${have.bank ? isDark ? "bg-blue-500/10 border-blue-500/20" : "bg-blue-50 border-blue-200" : isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-200"}`}>
              <Building className={`w-4 h-4 ${have.bank ? "text-blue-500" : isDark ? "text-white/20" : "text-gray-300"}`} />
              <div>
                <p className="text-[8px] opacity-40">تمويل بنكي</p>
                <p className={`text-[11px] font-black ${have.bank ? isDark ? "text-blue-400" : "text-blue-700" : isDark ? "text-white/30" : "text-gray-400"}`}>{have.bank ? "مقبول ✓" : "كاش فقط"}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>وصف العقار</p>
          <p className={`text-sm leading-7 ${isDark ? "text-white/70" : "text-gray-600"}`}>{have.desc}</p>
          {have.features?.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-dashed border-white/10">
              {have.features.map((f: string, i: number) => (
                <span key={i} className={`text-[11px] font-black px-3 py-1.5 rounded-xl border ${isDark ? "bg-white/5 border-white/10 text-white/60" : "bg-gray-50 border-gray-200 text-gray-700"}`}>{f}</span>
              ))}
            </div>
          )}
        </div>

        {/* Owner Info */}
        <div className={`p-3.5 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-lg font-black text-white shadow-md">
              {user.name[0]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{user.name}</p>
                {user.verified && <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />}
              </div>
              <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>{user.type === "broker" ? "وسيط" : "مالك"} · عضو منذ {user.since}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black transition-colors ${isDark ? "bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25" : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"}`}>
              <Phone className="w-3.5 h-3.5" /> اتصال
            </button>
            <button className="flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black bg-[#25D366] text-white hover:bg-[#1ebd5a] transition-colors">
              <ArrowUpRight className="w-3.5 h-3.5" /> واتساب
            </button>
            <button className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black transition-colors ${isDark ? "bg-blue-500/15 text-blue-400 hover:bg-blue-500/25" : "bg-blue-50 text-blue-600 hover:bg-blue-100"}`}>
              <MessageCircle className="w-3.5 h-3.5" /> رسالة
            </button>
          </div>
        </div>

        {/* ── WHAT THEY WANT SECTION ── */}
        <div className="h-px bg-gradient-to-r from-transparent via-purple-500/40 to-transparent" />
        <div className={`p-4 rounded-2xl border-2 ${isDark ? "bg-purple-500/8 border-purple-500/30" : "bg-purple-50 border-purple-300"}`}>
          <div className="flex items-center gap-2 mb-4">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isDark ? "bg-purple-500/20" : "bg-purple-100"}`}>
              <Target className="w-4 h-4 text-purple-500" />
            </div>
            <div>
              <p className={`text-sm font-black ${isDark ? "text-purple-300" : "text-purple-800"}`}>ما يريده في المقابل</p>
              <p className={`text-[10px] ${isDark ? "text-white/30" : "text-gray-400"}`}>عقار البدل المطلوب</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className={`p-3 rounded-xl border flex items-center gap-2 ${isDark ? "bg-white/3 border-white/10" : "bg-white border-gray-200"}`}>
              <Home className={`w-4 h-4 shrink-0 ${isDark ? "text-purple-400" : "text-purple-500"}`} />
              <div>
                <p className="text-[9px] opacity-40 mb-0.5">نوع العقار المطلوب</p>
                <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{want.type}</p>
              </div>
            </div>
            <div className={`p-3 rounded-xl border flex items-center gap-2 ${isDark ? "bg-white/3 border-white/10" : "bg-white border-gray-200"}`}>
              <MapPin className={`w-4 h-4 shrink-0 ${isDark ? "text-cyan-400" : "text-cyan-500"}`} />
              <div>
                <p className="text-[9px] opacity-40 mb-0.5">الموقع المفضل</p>
                <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{want.location}</p>
              </div>
            </div>
            <div className={`p-3 rounded-xl border flex items-center gap-2 ${isDark ? "bg-white/3 border-white/10" : "bg-white border-gray-200"}`}>
              <Square className={`w-4 h-4 shrink-0 ${isDark ? "text-orange-400" : "text-orange-500"}`} />
              <div>
                <p className="text-[9px] opacity-40 mb-0.5">المواصفات</p>
                <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{want.specs}</p>
              </div>
            </div>
            <div className={`p-3 rounded-xl border flex items-center gap-2 ${isDark ? "bg-white/3 border-white/10" : "bg-white border-gray-200"}`}>
              <DollarSign className={`w-4 h-4 shrink-0 ${isDark ? "text-emerald-400" : "text-emerald-500"}`} />
              <div>
                <p className="text-[9px] opacity-40 mb-0.5">نطاق السعر</p>
                <p className={`text-xs font-black ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>{want.priceRange} ريال</p>
              </div>
            </div>
            {want.note && (
              <div className={`p-3 rounded-xl border ${isDark ? "bg-amber-500/10 border-amber-500/20" : "bg-amber-50 border-amber-200"}`}>
                <p className={`text-[9px] mb-1 opacity-60`}>ملاحظة</p>
                <p className={`text-xs font-bold italic ${isDark ? "text-amber-300" : "text-amber-800"}`}>{want.note}</p>
              </div>
            )}
          </div>
        </div>

        {/* CTA */}
        <div className="flex gap-3 pt-2">
          <button className="flex-1 py-3.5 rounded-2xl text-sm font-black flex items-center justify-center gap-2 bg-purple-600 text-white shadow-lg shadow-purple-500/20">
            <ArrowRightLeft className="w-4 h-4" /> تقديم عرض بدل
          </button>
          <button className={`px-5 py-3.5 rounded-2xl text-sm font-black flex items-center justify-center gap-2 border ${isDark ? "border-white/10 text-white hover:bg-white/5" : "border-gray-200 text-gray-700 hover:bg-gray-50"}`}>
            <Phone className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
