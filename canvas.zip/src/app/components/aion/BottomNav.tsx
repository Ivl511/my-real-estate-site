import { motion } from "motion/react";
import { Home, ClipboardList, Plus, MessageCircle, User } from "lucide-react";
import type { Screen } from "../../App";
import { useTheme } from "../../context/ThemeContext";

interface BottomNavProps {
  currentScreen: Screen;
  onNavigate: (screen: Screen) => void;
  onOpenAddMenu: () => void;
}

export function BottomNav({ currentScreen, onNavigate, onOpenAddMenu }: BottomNavProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const isActive = (screen: Screen) => currentScreen === screen;

  return (
    <div className="fixed bottom-0 left-0 right-0 pb-6 px-4 z-[9999] pointer-events-none">
      <div className={`rounded-[32px] px-6 py-4 flex items-center justify-around relative shadow-2xl pointer-events-auto ${
        isDark ? 'glass-strong' : 'bg-white'
      }`}>
        {/* الرئيسية - Home */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => onNavigate("home")}
          className="flex flex-col items-center gap-1.5"
        >
          <Home className={`w-6 h-6 ${
            isActive("home")
              ? isDark ? 'text-white' : 'text-gray-900'
              : isDark ? 'text-white/40' : 'text-gray-400'
          }`} />
          <span className={`text-[10px] font-bold ${
            isActive("home")
              ? isDark ? 'text-white' : 'text-gray-900'
              : isDark ? 'text-white/40' : 'text-gray-400'
          }`}>الرئيسية</span>
          {isActive("home") && (
            <div className={`w-1.5 h-1.5 rounded-full shadow-lg ${
              isDark ? 'bg-cyan-400 shadow-cyan-400/50' : 'bg-blue-600 shadow-blue-600/50'
            }`} />
          )}
        </motion.button>

        {/* الطلبات - Requests */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => onNavigate("requests")}
          className="flex flex-col items-center gap-1.5"
        >
          <ClipboardList className={`w-6 h-6 ${
            isActive("requests")
              ? isDark ? 'text-white' : 'text-gray-900'
              : isDark ? 'text-white/40' : 'text-gray-400'
          }`} />
          <span className={`text-[10px] font-bold ${
            isActive("requests")
              ? isDark ? 'text-white' : 'text-gray-900'
              : isDark ? 'text-white/40' : 'text-gray-400'
          }`}>الطلبات</span>
          {isActive("requests") && (
            <div className={`w-1.5 h-1.5 rounded-full shadow-lg ${
              isDark ? 'bg-cyan-400 shadow-cyan-400/50' : 'bg-blue-600 shadow-blue-600/50'
            }`} />
          )}
        </motion.button>

        {/* إضافة - Add Button - CENTER */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onOpenAddMenu}
          className="w-16 h-16 rounded-full flex items-center justify-center -mt-8 shadow-[0_0_30px_rgba(6,182,212,0.6)] relative overflow-hidden group"
          style={{
            background: 'linear-gradient(135deg, #06b6d4, #3b82f6)',
          }}
        >
          <div className="absolute inset-0 bg-white/20 group-hover:bg-white/30 transition-colors" />
          <div className="absolute inset-0 animate-pulse bg-cyan-400/30 blur-xl" />
          {/* Holographic Gem Effect */}
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-tr from-transparent via-white/30 to-transparent opacity-50" />
          
          <div className="relative z-10 bg-black/10 p-1 rounded-full backdrop-blur-sm">
             <Plus className="w-8 h-8 text-white drop-shadow-md" />
          </div>
        </motion.button>

        {/* المحادثات - Chats */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => onNavigate("inbox")}
          className="flex flex-col items-center gap-1.5"
        >
          <MessageCircle className={`w-6 h-6 ${
            isActive("inbox")
              ? isDark ? 'text-white' : 'text-gray-900'
              : isDark ? 'text-white/40' : 'text-gray-400'
          }`} />
          <span className={`text-[10px] font-bold ${
            isActive("inbox")
              ? isDark ? 'text-white' : 'text-gray-900'
              : isDark ? 'text-white/40' : 'text-gray-400'
          }`}>المحادثات</span>
          {isActive("inbox") && (
            <div className={`w-1.5 h-1.5 rounded-full shadow-lg ${
              isDark ? 'bg-cyan-400 shadow-cyan-400/50' : 'bg-blue-600 shadow-blue-600/50'
            }`} />
          )}
        </motion.button>

        {/* حسابي - Profile */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => onNavigate("profile")}
          className="flex flex-col items-center gap-1.5"
        >
          <div className="relative">
            <User className={`w-6 h-6 ${
              isActive("profile")
                ? isDark ? 'text-white' : 'text-gray-900'
                : isDark ? 'text-white/40' : 'text-gray-400'
            }`} />
            <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 ${
              isDark ? 'bg-emerald-500 border-[#0F0F0F]' : 'bg-emerald-500 border-white'
            }`} />
          </div>
          <span className={`text-[10px] font-bold ${
            isActive("profile")
              ? isDark ? 'text-white' : 'text-gray-900'
              : isDark ? 'text-white/40' : 'text-gray-400'
          }`}>حسابي</span>
          {isActive("profile") && (
            <div className={`w-1.5 h-1.5 rounded-full shadow-lg ${
              isDark ? 'bg-cyan-400 shadow-cyan-400/50' : 'bg-blue-600 shadow-blue-600/50'
            }`} />
          )}
        </motion.button>
      </div>
    </div>
  );
}
