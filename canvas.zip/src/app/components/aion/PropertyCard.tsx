import { MapPin, Bed, Bath, Maximize, Sparkles } from "lucide-react";

interface PropertyCardProps {
  id: string;
  image: string;
  title: string;
  price: string;
  location: string;
  bedrooms: number;
  bathrooms: number;
  area: string;
  aiInsight: string;
  priceStatus: 'fair' | 'good' | 'excellent';
  onClick: () => void;
}

export function PropertyCard({
  image,
  title,
  price,
  location,
  bedrooms,
  bathrooms,
  area,
  aiInsight,
  priceStatus,
  onClick
}: PropertyCardProps) {
  const statusColors = {
    fair: 'bg-yellow-500',
    good: 'bg-[var(--aion-green)]',
    excellent: 'bg-blue-500'
  };
  
  const statusLabels = {
    fair: 'سعر عادل',
    good: 'سعر جيد',
    excellent: 'فرصة ممتازة'
  };
  
  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-2xl overflow-hidden cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
      style={{ boxShadow: 'var(--aion-shadow-lg)' }}
    >
      {/* الصورة */}
      <div className="relative h-48 bg-[var(--aion-gray-200)]">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-cover"
        />
        {/* شارة رأي AI */}
        <div className="absolute top-3 right-3 bg-gradient-to-br from-[var(--aion-navy)] to-[var(--aion-navy-light)] text-white px-3 py-1.5 rounded-full flex items-center gap-1.5 text-xs font-semibold backdrop-blur-sm">
          <Sparkles className="w-3.5 h-3.5" />
          <span>رأي AI</span>
        </div>
        {/* حالة السعر */}
        <div className={`absolute top-3 left-3 ${statusColors[priceStatus]} text-white px-3 py-1.5 rounded-full text-xs font-semibold`}>
          {statusLabels[priceStatus]}
        </div>
      </div>
      
      {/* المحتوى */}
      <div className="p-4">
        <h3 className="font-bold text-[var(--aion-navy)] mb-2 text-lg">{title}</h3>
        
        {/* السعر */}
        <div className="text-2xl font-bold text-[var(--aion-green)] mb-3">
          {price} <span className="text-sm font-normal text-[var(--aion-gray-500)]">ريال</span>
        </div>
        
        {/* الموقع */}
        <div className="flex items-center gap-2 text-[var(--aion-gray-600)] mb-3">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{location}</span>
        </div>
        
        {/* المواصفات */}
        <div className="flex items-center gap-4 mb-3 pb-3 border-b border-[var(--aion-gray-200)]">
          <div className="flex items-center gap-1.5">
            <Bed className="w-4 h-4 text-[var(--aion-gray-500)]" />
            <span className="text-sm text-[var(--aion-gray-700)]">{bedrooms}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Bath className="w-4 h-4 text-[var(--aion-gray-500)]" />
            <span className="text-sm text-[var(--aion-gray-700)]">{bathrooms}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Maximize className="w-4 h-4 text-[var(--aion-gray-500)]" />
            <span className="text-sm text-[var(--aion-gray-700)]">{area}</span>
          </div>
        </div>
        
        {/* رؤية AI */}
        <div className="bg-gradient-to-br from-[var(--aion-green)]/5 to-[var(--aion-green)]/10 rounded-xl p-3">
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-[var(--aion-green)] mt-0.5 flex-shrink-0" />
            <p className="text-xs text-[var(--aion-gray-700)] leading-relaxed">{aiInsight}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
