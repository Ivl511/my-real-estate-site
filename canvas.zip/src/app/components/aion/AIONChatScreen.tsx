import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowRight,
  Send,
  Sparkles,
  Mic,
  MicOff,
  X,
  Volume2,
  Home,
  TrendingUp,
  MapPin,
  DollarSign,
} from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

interface AIONChatScreenProps {
  onBack: () => void;
  persona?: "seeker" | "broker" | "developer" | "landlord";
}

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: string;
  isVoice?: boolean;
}

// ── Saudi-dialect AI responses ─────────────────────────────────────────────
const saudiResponses: Record<string, string> = {
  default:
    "والله يا حبيبي، بخدمتك! 😊\nوش اللي تبي أساعدك فيه؟ سواء كان عقار أو استثمار أو تقييم، أنا موجود.",
  villa:
    "ممتاز يا بعد عمري! 🏡\nعندي كذا فيلا حلوة بشمال الرياض.\nأبشر، أكثر شي طالعلك هو حي الملقا والنرجس — أسعارها منطقية ومناطقها راقية.",
  price:
    "ها حساب السعر للك:\nسعر المتر المربع في هالمنطقة يتراوح بين ٨٠٠٠ ريال لـ ١٢٠٠٠ ريال حسب القُربة من الخدمات.\nإذا تبي تقييم دقيق، ابعثلي تفاصيل العقار. 📊",
  invest:
    "طبعاً يا عزيزي! الاستثمار العقاري في الرياض حالياً من أفضل الخيارات. 📈\nالمناطق الواعدة: حي النرجس، العليا، ومحيط نيوم.\nالعائد الإيجاري يوصل لـ ٧٪ سنوياً في بعض الأحياء.",
  riyadh:
    "الرياض كلها حلوة بصراحة! 😄\nبس لو تسأل عن الأفضل هالحين:\n• للسكن الراقي: حي الملقا والنرجس\n• للعوايل: الرانة ومحيط ذلك\n• للاستثمار: قرب مراكز التجارة",
  buy: "قرار شراء صح يا حبيبي! 💪\nخليني أسألك بس:\n١. وش ميزانيتك؟\n٢. تبي تسكن أو تستثمر؟\n٣. أنت وين تسكن الحين؟\nوعلى هالأساس أقدر أرشحلك الأنسب.",
  rent: "للإيجار عندنا خيارات كثيرة ✅\nمن شقق بدءاً من ٢٠ ألف، لفلل فاخرة بأكثر من ٢٠٠ ألف سنوياً.\nقولي المنطقة اللي تبيها وميزانيتك وابشر!",
};

function getAIResponse(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes("فيلا") || lower.includes("villa")) return saudiResponses.villa;
  if (lower.includes("سعر") || lower.includes("كم") || lower.includes("تقييم"))
    return saudiResponses.price;
  if (lower.includes("استثمار") || lower.includes("invest")) return saudiResponses.invest;
  if (lower.includes("رياض") || lower.includes("riyadh")) return saudiResponses.riyadh;
  if (lower.includes("شراء") || lower.includes("أشتري") || lower.includes("ابي"))
    return saudiResponses.buy;
  if (lower.includes("إيجار") || lower.includes("أجار")) return saudiResponses.rent;
  return saudiResponses.default;
}

const quickSuggestions = [
  { id: "1", text: "ابي فيلا بشمال الرياض", icon: Home },
  { id: "2", text: "أفضل حي للاستثمار", icon: TrendingUp },
  { id: "3", text: "كم سعر المتر في الملقا", icon: DollarSign },
  { id: "4", text: "شقق للإيجار قريب المدارس", icon: MapPin },
];

export function AIONChatScreen({ onBack, persona = "seeker" }: AIONChatScreenProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      text: "هلا والله! 👋\nأنا أيون، مساعدك العقاري الذكي.\n\nقولي وش تحتاج، سواء بالكتابة أو الصوت — وأنا بخدمتك!",
      isUser: false,
      timestamp: "الآن",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [showSuggestions, setShowSuggestions] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Recording timer
  useEffect(() => {
    if (isRecording) {
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration((d) => d + 1);
      }, 1000);
    } else {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      setRecordingDuration(0);
    }
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    };
  }, [isRecording]);

  const formatDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const handleSend = (text?: string) => {
    const messageText = (text || input).trim();
    if (!messageText) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: messageText,
      isUser: true,
      timestamp: new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);
    setShowSuggestions(false);

    const delay = 1200 + Math.random() * 800;
    setTimeout(() => {
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(messageText),
        isUser: false,
        timestamp: new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, delay);
  };

  const handleVoiceToggle = () => {
    if (isRecording) {
      // Stop recording → simulate voice message
      setIsRecording(false);
      const duration = recordingDuration;
      const voiceMsg: Message = {
        id: Date.now().toString(),
        text: `🎙️ رسالة صوتية (${formatDuration(duration)})`,
        isUser: true,
        isVoice: true,
        timestamp: new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, voiceMsg]);
      setIsTyping(true);
      setShowSuggestions(false);

      setTimeout(() => {
        const aiMsg: Message = {
          id: (Date.now() + 1).toString(),
          text: "سمعتك! 🎧\nفهمت طلبك — خليني أدور لك وأرجعلك بأفضل الخيارات المتاحة.\nوش تبي بالضبط؟ قولي أكثر عشان أضيّق لك النتايج! 😊",
          isUser: false,
          timestamp: new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" }),
        };
        setMessages((prev) => [...prev, aiMsg]);
        setIsTyping(false);
      }, 1500);
    } else {
      setIsRecording(true);
      setInput("");
    }
  };

  const personaGrad =
    persona === "seeker"
      ? "from-purple-500 to-cyan-500"
      : persona === "landlord"
      ? "from-emerald-500 to-teal-500"
      : persona === "broker"
      ? "from-amber-500 to-orange-500"
      : "from-blue-600 to-indigo-600";

  const personaColor =
    persona === "seeker"
      ? "text-purple-500"
      : persona === "landlord"
      ? "text-emerald-500"
      : persona === "broker"
      ? "text-amber-500"
      : "text-blue-500";

  const bg = isDark ? "bg-[#0f1117]" : "bg-gray-50";
  const headerBg = isDark ? "bg-[#1a1f2e]/95 border-white/10" : "bg-white/95 border-gray-200/80";
  const msgAiBg = isDark ? "bg-[#1e2535] border-white/10" : "bg-white border-gray-100";
  const msgUserBg = isDark
    ? "bg-gradient-to-r from-[#1e3a5f] to-[#1e2f4a] border-blue-500/20"
    : "bg-gradient-to-r from-slate-900 to-slate-700";
  const inputBg = isDark
    ? "bg-[#1a1f2e]/95 border-white/10"
    : "bg-white/95 border-gray-200/80";
  const inputFieldBg = isDark ? "bg-[#252b3b] border-white/10 text-white" : "bg-gray-100 border-transparent text-gray-900";

  return (
    <div className={`fixed inset-0 flex flex-col z-[200] ${bg}`} dir="rtl">
      {/* Ambient background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className={`absolute -top-32 -right-32 w-96 h-96 rounded-full blur-3xl opacity-10 bg-gradient-to-br ${personaGrad}`}
        />
        <div
          className={`absolute -bottom-32 -left-32 w-80 h-80 rounded-full blur-3xl opacity-10 bg-gradient-to-br ${personaGrad}`}
        />
      </div>

      {/* ── Header ── */}
      <motion.div
        initial={{ y: -60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", bounce: 0.3 }}
        className={`relative z-10 flex items-center gap-3 px-4 py-3 backdrop-blur-xl border-b ${headerBg}`}
      >
        {/* Back */}
        <motion.button
          onClick={onBack}
          whileTap={{ scale: 0.9 }}
          className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
            isDark ? "bg-white/10 hover:bg-white/15" : "bg-gray-100 hover:bg-gray-200"
          } transition-colors`}
        >
          <ArrowRight className={`w-5 h-5 ${isDark ? "text-white" : "text-gray-700"}`} />
        </motion.button>

        {/* Avatar */}
        <div className="relative shrink-0">
          <motion.div
            animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.04, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
            className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${personaGrad} flex items-center justify-center shadow-lg`}
          >
            <Sparkles className="w-5 h-5 text-white" />
          </motion.div>
          {/* Online dot */}
          <motion.div
            animate={{ scale: [1, 1.4, 1], opacity: [1, 0.4, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -bottom-0.5 -left-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-current"
            style={{ borderColor: isDark ? "#0f1117" : "#f9fafb" }}
          />
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <h2
            className={`font-black text-base leading-tight ${isDark ? "text-white" : "text-gray-900"}`}
            style={{ fontFamily: "Cairo, sans-serif" }}
          >
            مساعد أيون الذكي
          </h2>
          <motion.p
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-xs text-emerald-500 font-bold"
          >
            متصل الآن • جاهز للمساعدة
          </motion.p>
        </div>

        {/* Voice indicator label */}
        <div
          className={`text-xs px-3 py-1.5 rounded-full font-bold border ${
            isDark ? "bg-white/5 border-white/10 text-white/50" : "bg-gray-100 border-gray-200 text-gray-400"
          }`}
        >
          نص · صوت
        </div>
      </motion.div>

      {/* ── Messages ── */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 relative z-10">
        <AnimatePresence mode="popLayout">
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: "spring", bounce: 0.25 }}
              className={`flex ${msg.isUser ? "justify-start" : "justify-end"}`}
            >
              {/* AI avatar (right side for RTL) */}
              {!msg.isUser && (
                <div className="flex flex-col items-end gap-1 max-w-[80%]">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs font-black ${personaColor}`}>أيون AI</span>
                    <div
                      className={`w-6 h-6 rounded-xl bg-gradient-to-br ${personaGrad} flex items-center justify-center`}
                    >
                      <Sparkles className="w-3.5 h-3.5 text-white" />
                    </div>
                  </div>
                  <div
                    className={`rounded-3xl rounded-tr-md px-5 py-3.5 border shadow-lg ${msgAiBg}`}
                  >
                    <p
                      className={`text-sm leading-relaxed whitespace-pre-wrap font-medium ${
                        isDark ? "text-white/90" : "text-gray-800"
                      }`}
                      style={{ fontFamily: "Cairo, sans-serif" }}
                    >
                      {msg.text}
                    </p>
                  </div>
                  {/* AI voice play button */}
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-full mt-0.5 ${
                      isDark
                        ? "bg-white/5 text-white/40 hover:text-white/60"
                        : "bg-gray-100 text-gray-400 hover:text-gray-600"
                    } transition-colors`}
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>استمع</span>
                  </motion.button>
                  <span className={`text-xs ${isDark ? "text-white/30" : "text-gray-400"} font-medium`}>
                    {msg.timestamp}
                  </span>
                </div>
              )}

              {/* User message (left side for RTL) */}
              {msg.isUser && (
                <div className="flex flex-col items-start gap-1 max-w-[78%]">
                  <div
                    className={`rounded-3xl rounded-tl-md px-5 py-3.5 border shadow-lg ${msgUserBg}`}
                  >
                    {msg.isVoice ? (
                      <div className="flex items-center gap-3">
                        <div className="flex gap-0.5 items-end h-5">
                          {[3, 5, 4, 6, 3, 5, 4, 3, 6, 4].map((h, i) => (
                            <motion.div
                              key={i}
                              animate={{ scaleY: [1, 1.5, 1] }}
                              transition={{ duration: 0.4, repeat: Infinity, delay: i * 0.05 }}
                              className="w-0.5 bg-white/70 rounded-full"
                              style={{ height: `${h * 3}px` }}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-white font-medium" style={{ fontFamily: "Cairo" }}>
                          {msg.text}
                        </span>
                      </div>
                    ) : (
                      <p
                        className="text-sm leading-relaxed whitespace-pre-wrap font-medium text-white"
                        style={{ fontFamily: "Cairo, sans-serif" }}
                      >
                        {msg.text}
                      </p>
                    )}
                  </div>
                  <span className={`text-xs ${isDark ? "text-white/30" : "text-gray-400"} font-medium`}>
                    {msg.timestamp}
                  </span>
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex justify-end"
            >
              <div className="flex flex-col items-end gap-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs font-black ${personaColor}`}>أيون AI</span>
                  <div
                    className={`w-6 h-6 rounded-xl bg-gradient-to-br ${personaGrad} flex items-center justify-center`}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-white" />
                  </div>
                </div>
                <div className={`rounded-3xl rounded-tr-md px-5 py-4 border shadow-lg ${msgAiBg}`}>
                  <div className="flex gap-1.5 items-center">
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={i}
                        animate={{ y: [0, -6, 0] }}
                        transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.12 }}
                        className={`w-2 h-2 rounded-full bg-gradient-to-br ${personaGrad}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick suggestions */}
        <AnimatePresence>
          {showSuggestions && messages.length === 1 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ delay: 0.5 }}
              className="mt-2"
            >
              <p
                className={`text-xs font-black mb-3 text-right ${isDark ? "text-white/40" : "text-gray-400"}`}
              >
                اقتراحات سريعة:
              </p>
              <div className="grid grid-cols-2 gap-2">
                {quickSuggestions.map((s, i) => {
                  const Icon = s.icon;
                  return (
                    <motion.button
                      key={s.id}
                      onClick={() => handleSend(s.text)}
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.6 + i * 0.07 }}
                      whileHover={{ scale: 1.03, y: -2 }}
                      whileTap={{ scale: 0.97 }}
                      className={`flex items-center gap-2 p-3 rounded-2xl border text-right transition-all ${
                        isDark
                          ? "bg-white/5 border-white/10 hover:bg-white/10 text-white/80"
                          : "bg-white border-gray-200 hover:border-purple-300 hover:bg-purple-50/50 text-gray-700"
                      } shadow-sm`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${personaColor}`} />
                      <span
                        className="text-xs font-bold leading-tight"
                        style={{ fontFamily: "Cairo, sans-serif" }}
                      >
                        {s.text}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* ── Recording overlay ── */}
      <AnimatePresence>
        {isRecording && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-20 flex flex-col items-center justify-center pointer-events-none"
            style={{ background: isDark ? "rgba(15,17,23,0.85)" : "rgba(249,250,251,0.85)" }}
          >
            {/* Wave rings */}
            {[1, 2, 3].map((ring) => (
              <motion.div
                key={ring}
                animate={{ scale: [1, 1 + ring * 0.25], opacity: [0.4, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: ring * 0.3 }}
                className={`absolute w-36 h-36 rounded-full bg-gradient-to-br ${personaGrad} opacity-20`}
              />
            ))}
            <motion.div
              animate={{ scale: [1, 1.08, 1] }}
              transition={{ duration: 0.8, repeat: Infinity }}
              className={`relative w-24 h-24 rounded-full bg-gradient-to-br ${personaGrad} flex items-center justify-center shadow-2xl z-10`}
            >
              <Mic className="w-10 h-10 text-white" />
            </motion.div>
            <p
              className={`mt-8 text-lg font-black z-10 ${isDark ? "text-white" : "text-gray-900"}`}
              style={{ fontFamily: "Cairo, sans-serif" }}
            >
              جاري التسجيل...
            </p>
            <p className={`text-2xl font-black mt-1 z-10 ${isDark ? "text-white/60" : "text-gray-500"}`}>
              {formatDuration(recordingDuration)}
            </p>
            <p
              className={`text-sm mt-2 z-10 ${isDark ? "text-white/40" : "text-gray-400"}`}
              style={{ fontFamily: "Cairo, sans-serif" }}
            >
              اضغط زر الميكروفون مرة ثانية للإرسال
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Input Bar ── */}
      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", bounce: 0.2, delay: 0.1 }}
        className={`relative z-10 px-4 py-3 backdrop-blur-xl border-t ${inputBg}`}
      >
        <div className="flex items-end gap-2">
          {/* Voice button */}
          <motion.button
            onClick={handleVoiceToggle}
            whileTap={{ scale: 0.88 }}
            animate={
              isRecording
                ? { scale: [1, 1.1, 1], boxShadow: ["0 0 0 0px rgba(239,68,68,0.4)", "0 0 0 8px rgba(239,68,68,0)", "0 0 0 0px rgba(239,68,68,0.4)"] }
                : {}
            }
            transition={{ duration: 0.8, repeat: isRecording ? Infinity : 0 }}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-lg transition-all ${
              isRecording
                ? "bg-red-500 shadow-red-500/40"
                : isDark
                ? "bg-white/10 hover:bg-white/15 border border-white/10"
                : "bg-gray-100 hover:bg-gray-200 border border-gray-200"
            }`}
          >
            {isRecording ? (
              <MicOff className="w-5 h-5 text-white" />
            ) : (
              <Mic className={`w-5 h-5 ${isDark ? "text-white/70" : "text-gray-500"}`} />
            )}
          </motion.button>

          {/* Text field */}
          <div
            className={`flex-1 flex items-center gap-2 rounded-2xl px-4 py-3 border transition-all ${inputFieldBg} ${
              isRecording ? "opacity-40 pointer-events-none" : ""
            }`}
          >
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="اكتب رسالتك بالعامية..."
              disabled={isRecording}
              className="flex-1 bg-transparent outline-none text-sm placeholder:opacity-40 text-right min-w-0"
              style={{ fontFamily: "Cairo, sans-serif" }}
            />
            {input && (
              <motion.button
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                onClick={() => setInput("")}
                className={`shrink-0 ${isDark ? "text-white/30 hover:text-white/60" : "text-gray-300 hover:text-gray-500"}`}
              >
                <X className="w-4 h-4" />
              </motion.button>
            )}
          </div>

          {/* Send button */}
          <motion.button
            onClick={() => handleSend()}
            disabled={!input.trim() || isRecording}
            whileTap={{ scale: 0.88 }}
            animate={input.trim() && !isRecording ? { scale: [1, 1.04, 1] } : {}}
            transition={{ duration: 1.2, repeat: Infinity }}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-lg transition-all ${
              input.trim() && !isRecording
                ? `bg-gradient-to-br ${personaGrad} shadow-purple-500/30`
                : isDark
                ? "bg-white/5 border border-white/10"
                : "bg-gray-100 border border-gray-200"
            }`}
          >
            <Send
              className={`w-5 h-5 ${
                input.trim() && !isRecording ? "text-white" : isDark ? "text-white/20" : "text-gray-300"
              }`}
            />
          </motion.button>
        </div>

        {/* Disclaimer */}
        <p
          className={`text-center text-[10px] mt-2 ${isDark ? "text-white/20" : "text-gray-300"}`}
          style={{ fontFamily: "Cairo, sans-serif" }}
        >
          أيون مساعد ذكي — لا يعوّض استشارة قانونية أو مالية متخصصة
        </p>
      </motion.div>
    </div>
  );
}
