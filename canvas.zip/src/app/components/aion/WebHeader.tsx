import { motion } from "motion/react";
import { Search, Bell, User, Menu, Home, Heart, MessageSquare, Plus, LogIn } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

interface WebHeaderProps {
  onNavigate: (screen: any) => void;
  currentScreen: string;
}

export function WebHeader({ onNavigate, currentScreen }: WebHeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  const navItems = [
    { id: "home", label: "الرئيسية", icon: Home },
    { id: "search", label: "بحث", icon: Search },
    { id: "requests", label: "الطلبات", icon: MessageSquare },
    { id: "favorites", label: "المفضلة", icon: Heart },
  ];

  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`hidden md:flex h-20 items-center justify-between px-8 sticky top-0 z-50 backdrop-blur-xl border-b transition-colors ${
        isDark ? "bg-[#050505]/80 border-white/10" : "bg-white/80 border-gray-200"
      }`}
    >
      {/* Logo Area */}
      <div className="flex items-center gap-12">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate("home")}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
                <span className="text-white font-black text-xl">A</span>
            </div>
            <div>
                <h1 className={`text-2xl font-black tracking-tighter ${isDark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: 'Cairo' }}>
                    أيون <span className="text-amber-500">العقارية</span>
                </h1>
            </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="flex items-center gap-1 bg-white/5 p-1 rounded-full border border-white/5">
            {navItems.map((item) => (
                <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`relative px-6 py-2 rounded-full text-sm font-bold transition-all ${
                        currentScreen === item.id 
                        ? "text-black bg-white shadow-lg" 
                        : isDark ? "text-white/60 hover:text-white hover:bg-white/5" : "text-gray-500 hover:text-gray-900"
                    }`}
                >
                    <div className="flex items-center gap-2">
                        <item.icon className="w-4 h-4" />
                        <span>{item.label}</span>
                    </div>
                </button>
            ))}
        </nav>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-4">
        
        <button className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${isDark ? "bg-white/5 hover:bg-white/10 text-white" : "bg-gray-100 hover:bg-gray-200 text-gray-700"}`}>
            <Bell className="w-5 h-5" />
        </button>

        <button 
            onClick={toggleTheme}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${isDark ? "bg-white/5 hover:bg-white/10 text-white" : "bg-gray-100 hover:bg-gray-200 text-gray-700"}`}
        >
            {isDark ? "🌙" : "☀️"}
        </button>

        <div className="h-8 w-px bg-white/10 mx-2" />

        <button 
            onClick={() => onNavigate("home")} // Mock add property
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-bold text-sm shadow-lg shadow-amber-500/20 hover:shadow-amber-500/40 transition-all hover:-translate-y-0.5"
        >
            <Plus className="w-4 h-4" />
            <span>إضافة عقار</span>
        </button>

        <button 
            onClick={() => onNavigate("profile")}
            className="flex items-center gap-3 pl-1 pr-4 py-1 rounded-full bg-white/5 border border-white/10 hover:border-amber-500/50 transition-all group"
        >
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 border-2 border-white/20" />
            <div className="text-right hidden lg:block">
                <p className={`text-xs font-bold ${isDark ? "text-white" : "text-gray-900"}`}>عبدالله العتيبي</p>
                <p className="text-[10px] text-amber-500">وسيط عقاري (PRO)</p>
            </div>
        </button>
      </div>
    </motion.header>
  );
}
