import { motion } from "motion/react";
import { ArrowRight, Sparkles, TrendingUp, DollarSign, MapPin, Award, Phone, Mail, FileCheck, Building, Landmark, CheckCircle, Ruler } from "lucide-react";
import { useState } from "react";

interface PropertyDetailsProps {
  propertyId: string;
  onBack: () => void;
}

export function PropertyDetails({ propertyId, onBack }: PropertyDetailsProps) {
  const [currentImage, setCurrentImage] = useState(0);

  const images = [
    "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80",
    "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80",
    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80",
  ];

  return (
    <div className="h-full bg-gradient-to-b from-[#0A0E1A] to-[#0D1221] overflow-y-auto">
      {/* Immersive Image Gallery */}
      <div className="relative h-96">
        <motion.img
          key={currentImage}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          src={images[currentImage]}
          alt="Property"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0E1A] via-transparent to-transparent" />

        {/* Back Button */}
        <button
          onClick={onBack}
          className="absolute top-12 right-5 w-10 h-10 glass rounded-full flex items-center justify-center"
        >
          <ArrowRight className="w-5 h-5 text-white" />
        </button>

        {/* Image Indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {images.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentImage(i)}
              className={`h-1.5 rounded-full transition-all ${
                i === currentImage ? "w-8 bg-cyan-400" : "w-1.5 bg-white/30"
              }`}
            />
          ))}
        </div>
      </div>

      <div className="px-5 py-6 space-y-6 pb-32">
        {/* AI Smart Insight Box - TOP PRIORITY */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-strong rounded-3xl p-5 neon-cyan"
        >
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <h3 className="text-white font-black text-lg">التحليل الذكي EON</h3>
          </div>

          {/* Fair Price Meter */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-white/60 text-sm">السعر العادل</span>
              <span className="text-emerald-400 font-black">ممتاز</span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: "85%" }}
                transition={{ duration: 1, delay: 0.3 }}
                className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400"
              />
            </div>
          </div>

          {/* ROI Calculator */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="glass rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span className="text-white/60 text-xs">العائد المتوقع</span>
              </div>
              <p className="text-white font-black text-2xl">9.2%</p>
            </div>
            <div className="glass rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <DollarSign className="w-4 h-4 text-cyan-400" />
                <span className="text-white/60 text-xs">القيمة السوقية</span>
              </div>
              <p className="text-white font-black text-2xl">+12%</p>
            </div>
          </div>

          {/* Swap Match (If Applicable) */}
          <div className="glass rounded-xl p-3 bg-gradient-to-r from-purple-600/20 to-orange-600/20 border border-purple-500/30">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-lg">🔄</span>
              </div>
              <p className="flex-1 text-white text-sm font-bold text-right">
                هذا المالك يقبل التبديل مع أرض في الرياض
              </p>
            </div>
          </div>
        </motion.div>

        {/* RULE 1: REFACTORED Title Block - Type + Location Combined */}
        <div className="glass-strong rounded-3xl p-5">
          <h2 className="text-white font-black text-2xl mb-2 text-right leading-tight">
            Luxury Villa - Al Malqa District
          </h2>
          <h3 className="text-cyan-400 font-black text-xl mb-4 text-right" style={{ fontFamily: 'Cairo' }}>
            فيلا فاخرة - حي الملقا
          </h3>
          <div className="flex items-center gap-2 mb-4 justify-end">
            <span className="text-white/60 text-sm">الرياض، المملكة العربية السعودية</span>
            <MapPin className="w-4 h-4 text-cyan-400" />
          </div>

          {/* Basic Stats Grid */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="glass rounded-xl p-3 text-center">
              <p className="text-white text-xl font-black mb-1">6</p>
              <p className="text-white/60 text-xs">غرف النوم</p>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <p className="text-white text-xl font-black mb-1">5</p>
              <p className="text-white/60 text-xs">الحمامات</p>
            </div>
            <div className="glass rounded-xl p-3 text-center">
              <p className="text-white text-xl font-black mb-1">450</p>
              <p className="text-white/60 text-xs">م²</p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-emerald-600 to-yellow-500 rounded-2xl p-4 text-center">
            <p className="text-white/80 text-sm mb-1">السعر</p>
            <p className="text-white text-3xl font-black">3,200,000 ر.س</p>
          </div>
        </div>

        {/* RULE 2: Legal & Technical Data Grid - VERIFIED INFORMATION */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-strong rounded-3xl p-5 border-2 border-emerald-500/30"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-xl flex items-center justify-center">
              <FileCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <h3 className="text-white font-black text-lg flex-1 text-right">المعلومات القانونية والفنية</h3>
            <div className="px-3 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/30">
              <span className="text-xs font-black text-emerald-400">موثق ✓</span>
            </div>
          </div>

          {/* RULE 3: 2x3 Data Grid with Icons */}
          <div className="grid grid-cols-2 gap-3">
            {/* Data Point 1: Sak (Deed) Available */}
            <div className="glass rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <FileCheck className="w-5 h-5 text-emerald-400" />
                <span className="text-white/60 text-xs font-bold">الصك</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <div>
                  <p className="text-white font-black text-sm">متوفر</p>
                  <p className="text-emerald-400 text-xs font-bold">✓ موثق</p>
                </div>
              </div>
            </div>

            {/* Data Point 2: Bank Accepted */}
            <div className="glass rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Landmark className="w-5 h-5 text-cyan-400" />
                <span className="text-white/60 text-xs font-bold">التمويل البنكي</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-cyan-400" />
                <div>
                  <p className="text-white font-black text-sm">مؤهل</p>
                  <p className="text-cyan-400 text-xs font-bold">✓ معتمد</p>
                </div>
              </div>
            </div>

            {/* Data Point 3: Land Area */}
            <div className="glass rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Ruler className="w-5 h-5 text-purple-400" />
                <span className="text-white/60 text-xs font-bold">مساحة الأرض</span>
              </div>
              <div>
                <p className="text-white font-black text-2xl">450</p>
                <p className="text-purple-400 text-xs font-bold">متر مربع</p>
              </div>
            </div>

            {/* Data Point 4: Built-up Area */}
            <div className="glass rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Building className="w-5 h-5 text-orange-400" />
                <span className="text-white/60 text-xs font-bold">مساحة البناء</span>
              </div>
              <div>
                <p className="text-white font-black text-2xl">600</p>
                <p className="text-orange-400 text-xs font-bold">متر مربع</p>
              </div>
            </div>
          </div>

          {/* Additional Legal Info */}
          <div className="mt-4 pt-4 border-t border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-yellow-400" />
                <span className="text-white/80 text-sm font-bold">موثق من قبل هيئة فال العقارية</span>
              </div>
              <span className="text-xs text-yellow-400 font-black">معتمد</span>
            </div>
          </div>
        </motion.div>

        {/* POINT 3: Property Description (CRITICAL - Full Paragraph) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="glass-strong rounded-3xl p-5"
        >
          <h3 className="text-white font-black text-lg mb-4 text-right">الوصف</h3>
          <div className="space-y-3 text-right">
            <p className="text-white/80 text-sm leading-relaxed" style={{ fontFamily: 'Cairo' }}>
              فيلا فاخرة مصممة بأحدث المواصفات العصرية، تقع في حي الملقا الراقي. تتميز بنظام المنزل الذكي المتكامل الذي يتيح التحكم في الإضاءة، التكييف، والأمن من خلال تطبيق واحد.
            </p>
            <p className="text-white/70 text-sm leading-relaxed" style={{ fontFamily: 'Cairo' }}>
              تحتوي الفيلا على مسبح خاص بنظام تحكم تلقائي في درجة الحرارة وإضاءة LED للترفيه المسائي. التشطيبات الفاخرة بأرضيات رخام إيطالي في الطابق الأرضي، وباركيه خشب أوروبي في غرف النوم، ومطبخ مصمم خصيصاً بأجهزة ألمانية.
            </p>
            <p className="text-white/70 text-sm leading-relaxed" style={{ fontFamily: 'Cairo' }}>
              تتضمن الفيلا أيضاً حديقة بنظام ري تلقائي، موقف سيارات مغطى لـ 4 سيارات، وغرفة خادمة منفصلة مع حمام خاص.
            </p>
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex flex-wrap gap-2 justify-end">
                <span className="px-3 py-1.5 rounded-lg glass-premium text-xs font-bold text-cyan-400">
                  🏊 مسبح خاص
                </span>
                <span className="px-3 py-1.5 rounded-lg glass-premium text-xs font-bold text-purple-400">
                  🏡 منزل ذكي
                </span>
                <span className="px-3 py-1.5 rounded-lg glass-premium text-xs font-bold text-emerald-400">
                  🌳 حديقة منسقة
                </span>
                <span className="px-3 py-1.5 rounded-lg glass-premium text-xs font-bold text-orange-400">
                  🚗 موقف 4 سيارات
                </span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Broker Pro Card */}
        <div className="glass-strong rounded-3xl p-5 bg-gradient-to-br from-yellow-600/20 to-black/50 border border-yellow-600/30">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-yellow-700 rounded-2xl flex items-center justify-center">
              <Award className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1 text-right">
              <h3 className="text-white font-black text-lg mb-1">محمد بن عبدالله</h3>
              <p className="text-yellow-400 text-sm font-bold">وسيط عقاري معتمد</p>
              <p className="text-white/60 text-xs">رخصة فال: 7001234567</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button className="glass rounded-xl py-3 flex items-center justify-center gap-2">
              <Phone className="w-4 h-4 text-cyan-400" />
              <span className="text-white text-sm font-bold">اتصال</span>
            </button>
            <button className="glass rounded-xl py-3 flex items-center justify-center gap-2">
              <Mail className="w-4 h-4 text-cyan-400" />
              <span className="text-white text-sm font-bold">واتساب</span>
            </button>
          </div>
        </div>

        {/* CTA Button */}
        <motion.button
          whileTap={{ scale: 0.98 }}
          className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 rounded-2xl py-4 text-white font-black text-lg neon-cyan"
        >
          حجز موعد معاينة
        </motion.button>
      </div>
    </div>
  );
}