import { motion, AnimatePresence } from "motion/react";
import {
  ArrowRight, Search, SlidersHorizontal, Sparkles, Tag, KeyRound,
  ArrowRightLeft, Home, Building2, Square, Bed, Percent, MapPin,
  X, CheckCircle, Mic, SendHorizonal, LocateFixed
} from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../context/ThemeContext";

interface SearchScreenProps {
  onBack: () => void;
}

const TRANSACTION_TYPES = [
  { id: "sale", label: "للبيع", Icon: Tag },
  { id: "rent", label: "للإيجار", Icon: KeyRound },
  { id: "exchange", label: "للبدل", Icon: ArrowRightLeft },
];

const PROPERTY_TYPES = [
  { id: "all", label: "الكل", Icon: Home },
  { id: "villa", label: "فيلا", Icon: Home },
  { id: "apartment", label: "شقة", Icon: Building2 },
  { id: "land", label: "أرض", Icon: Square },
  { id: "building", label: "عمارة", Icon: Building2 },
];

const PRICE_RANGES = [
  { id: "all", label: "الكل" },
  { id: "under1M", label: "أقل من 1M" },
  { id: "1M-2M", label: "1M – 2M" },
  { id: "2M-4M", label: "2M – 4M" },
  { id: "over4M", label: "أكثر من 4M" },
];

const REGIONS = ["الرياض", "جدة", "الدمام", "الخبر", "المدينة", "مكة", "أبها"];

export function SearchScreen({ onBack }: SearchScreenProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const [txType, setTxType] = useState("sale");
  const [propType, setPropType] = useState("all");
  const [minBeds, setMinBeds] = useState(0);
  const [priceRange, setPriceRange] = useState("all");
  const [region, setRegion] = useState("");
  const [aiQuery, setAiQuery] = useState("");
  const [aiActive, setAiActive] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = () => { if (aiQuery.trim() || propType !== "all") setSearched(true); };

  return (
    <div className={`h-full flex flex-col overflow-hidden ${isDark ? "bg-[#0a0f1e]" : "bg-gray-50"}`}>

      {/* Header */}
      <div className={`px-4 pt-6 pb-4 border-b ${isDark ? "bg-[#0a0f1e] border-white/5" : "bg-white border-gray-100"}`}>
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className={`w-10 h-10 rounded-xl flex items-center justify-center ${isDark ? "bg-white/5 text-white" : "bg-gray-100 text-gray-900"}`}>
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className={`font-black flex-1 text-right ${isDark ? "text-white" : "text-gray-900"}`}>البحث المتقدم</h2>
        </div>

        {/* AI Search Bar */}
        <div
          className={`relative rounded-2xl border-2 transition-all duration-300 overflow-hidden mb-4 ${
            aiActive
              ? isDark ? "border-cyan-500/70 shadow-[0_0_20px_rgba(6,182,212,0.2)]" : "border-blue-500/60 shadow-[0_0_16px_rgba(59,130,246,0.15)]"
              : isDark ? "border-white/8 bg-[#151a2d]" : "border-gray-200 bg-white shadow-sm"
          } ${isDark ? "bg-[#151a2d]" : "bg-white"}`}
        >
          {aiActive && (
            <motion.div
              className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
              animate={{ x: ["-100%", "100%"] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            />
          )}
          <div className="flex items-center gap-2 px-3 py-1">
            <motion.div
              animate={aiActive ? { rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] } : {}}
              transition={{ duration: 1.5, repeat: Infinity }}
              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                aiActive ? "bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30" : isDark ? "bg-white/5" : "bg-gray-100"
              }`}
            >
              <Sparkles className={`w-4 h-4 ${aiActive ? "text-white" : isDark ? "text-gray-400" : "text-gray-500"}`} />
            </motion.div>
            <input
              type="text"
              value={aiQuery}
              onChange={e => setAiQuery(e.target.value)}
              onFocus={() => setAiActive(true)}
              onBlur={() => setAiActive(false)}
              onKeyDown={e => e.key === "Enter" && handleSearch()}
              placeholder="مثال: فيلا 5 غرف في شمال الرياض بأقل من 3 مليون..."
              className={`flex-1 bg-transparent border-none outline-none py-3 text-sm ${isDark ? "text-white placeholder-gray-600" : "text-gray-900 placeholder-gray-400"}`}
              style={{ direction: "rtl" }}
            />
            <div className="flex items-center gap-1 shrink-0">
              <button className={`w-8 h-8 rounded-lg flex items-center justify-center ${isDark ? "text-gray-500 hover:text-gray-300" : "text-gray-400 hover:text-gray-600"}`}>
                <Mic className="w-4 h-4" />
              </button>
              <button
                onClick={handleSearch}
                className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                  aiQuery.length > 0 ? "bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-md" : isDark ? "text-gray-600" : "text-gray-300"
                }`}
              >
                <SendHorizonal className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className={`absolute top-2 left-12 px-1.5 py-0.5 rounded-md text-[8px] font-black tracking-widest ${isDark ? "bg-cyan-500/15 text-cyan-400 border border-cyan-500/20" : "bg-blue-50 text-blue-500 border border-blue-200"}`}>AI</div>
        </div>

        {/* Transaction Type */}
        <div className="flex gap-2 mb-4">
          {TRANSACTION_TYPES.map(t => {
            const TIcon = t.Icon;
            return (
              <button
                key={t.id}
                onClick={() => setTxType(t.id)}
                className={`flex-1 py-2.5 rounded-xl text-xs font-black flex flex-col items-center gap-1.5 border-2 transition-all ${
                  txType === t.id
                    ? isDark ? "bg-cyan-500/20 border-cyan-500 text-cyan-300" : "bg-blue-50 border-blue-500 text-blue-700"
                    : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                }`}
              >
                <TIcon className="w-4 h-4" />
                {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrollable Filters */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5">

        {/* Property Type */}
        <div>
          <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>نوع العقار</p>
          <div className="flex gap-2 flex-wrap">
            {PROPERTY_TYPES.map(pt => {
              const PIcon = pt.Icon;
              return (
                <button
                  key={pt.id}
                  onClick={() => setPropType(pt.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black border-2 transition-all ${
                    propType === pt.id
                      ? isDark ? "bg-white/15 border-white/50 text-white" : "bg-gray-900 border-gray-900 text-white"
                      : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                  }`}
                >
                  <PIcon className="w-3.5 h-3.5" />
                  {pt.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bedrooms (not for land) */}
        {propType !== "land" && (
          <div>
            <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>الحد الأدنى لعدد الغرف</p>
            <div className="flex gap-2">
              {[{ val: 0, label: "الكل" }, { val: 1, label: "+1" }, { val: 2, label: "+2" }, { val: 3, label: "+3" }, { val: 4, label: "+4" }, { val: 5, label: "+5" }].map(opt => (
                <button
                  key={opt.val}
                  onClick={() => setMinBeds(opt.val)}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-black border-2 transition-all ${
                    minBeds === opt.val
                      ? isDark ? "bg-purple-500/20 border-purple-500 text-purple-300" : "bg-purple-50 border-purple-500 text-purple-700"
                      : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Price Range (only for buy) */}
        {txType === "sale" && (
          <div>
            <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>نطاق السعر</p>
            <div className="grid grid-cols-3 gap-2">
              {PRICE_RANGES.map(pr => (
                <button
                  key={pr.id}
                  onClick={() => setPriceRange(pr.id)}
                  className={`py-2.5 px-2 rounded-xl text-[11px] font-black border-2 transition-all ${
                    priceRange === pr.id
                      ? isDark ? "bg-emerald-500/20 border-emerald-500 text-emerald-300" : "bg-emerald-50 border-emerald-500 text-emerald-700"
                      : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                  }`}
                >
                  {pr.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Region */}
        <div>
          <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>المنطقة</p>
          <div className="flex gap-2 flex-wrap">
            {["الكل", ...REGIONS].map(r => (
              <button
                key={r}
                onClick={() => setRegion(r === "الكل" ? "" : r)}
                className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-black border-2 transition-all ${
                  (region === r) || (r === "الكل" && !region)
                    ? isDark ? "bg-red-500/20 border-red-500 text-red-300" : "bg-red-50 border-red-500 text-red-700"
                    : isDark ? "bg-white/3 border-white/10 text-white/50" : "bg-gray-50 border-gray-200 text-gray-500"
                }`}
              >
                {r !== "الكل" && <MapPin className="w-3 h-3" />}
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Search Button */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={handleSearch}
          className="w-full py-4 rounded-2xl text-sm font-black bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
        >
          <Search className="w-5 h-5" />
          بحث
        </motion.button>

        {/* Active Filters Summary */}
        {(txType !== "sale" || propType !== "all" || minBeds > 0 || priceRange !== "all" || region) && (
          <div className={`p-3 rounded-xl border ${isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-100"}`}>
            <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>الفلاتر المفعّلة</p>
            <div className="flex flex-wrap gap-1.5">
              {txType !== "sale" && <span className={`text-[10px] px-2 py-1 rounded-lg font-black ${isDark ? "bg-cyan-500/15 text-cyan-400" : "bg-blue-50 text-blue-700"}`}>{TRANSACTION_TYPES.find(t => t.id === txType)?.label}</span>}
              {propType !== "all" && <span className={`text-[10px] px-2 py-1 rounded-lg font-black ${isDark ? "bg-white/10 text-white/70" : "bg-gray-200 text-gray-700"}`}>{PROPERTY_TYPES.find(p => p.id === propType)?.label}</span>}
              {minBeds > 0 && <span className={`text-[10px] px-2 py-1 rounded-lg font-black ${isDark ? "bg-purple-500/15 text-purple-400" : "bg-purple-50 text-purple-700"}`}>+{minBeds} غرف</span>}
              {priceRange !== "all" && <span className={`text-[10px] px-2 py-1 rounded-lg font-black ${isDark ? "bg-emerald-500/15 text-emerald-400" : "bg-emerald-50 text-emerald-700"}`}>{PRICE_RANGES.find(p => p.id === priceRange)?.label}</span>}
              {region && <span className={`text-[10px] px-2 py-1 rounded-lg font-black ${isDark ? "bg-red-500/15 text-red-400" : "bg-red-50 text-red-700"}`}>{region}</span>}
            </div>
          </div>
        )}

        {/* Empty / Result placeholder */}
        {!searched ? (
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <div className={`w-20 h-20 rounded-3xl flex items-center justify-center ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
              <Search className={`w-9 h-9 ${isDark ? "text-white/20" : "text-gray-300"}`} />
            </div>
            <p className={`font-black text-sm ${isDark ? "text-white/30" : "text-gray-400"}`}>اضبط الفلاتر وابدأ البحث</p>
            <p className={`text-[11px] text-center ${isDark ? "text-white/20" : "text-gray-300"}`}>
              يمكنك البحث بالكلام العادي مثل:<br />"فيلا 5 غرف بمسبح في الملقا"
            </p>
          </div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`p-4 rounded-2xl border text-center ${isDark ? "bg-purple-500/10 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
            <Sparkles className="w-6 h-6 text-purple-500 mx-auto mb-2" />
            <p className={`text-xs font-black ${isDark ? "text-purple-300" : "text-purple-800"}`}>يعالج EON طلبك...</p>
            <p className={`text-[10px] mt-1 ${isDark ? "text-white/30" : "text-gray-400"}`}>سيظهر هنا أفضل العقارات المطابقة لطلبك</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
