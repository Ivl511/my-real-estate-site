import { Menu, Bell, User } from "lucide-react";

interface AionHeaderProps {
  onMenuClick?: () => void;
  showNotifications?: boolean;
}

export function AionHeader({ onMenuClick, showNotifications = true }: AionHeaderProps) {
  return (
    <header className="bg-[var(--aion-navy)] text-white px-5 py-4 sticky top-0 z-50" style={{ boxShadow: 'var(--aion-shadow-lg)' }}>
      <div className="flex items-center justify-between max-w-md mx-auto">
        <button 
          onClick={onMenuClick}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          <Menu className="w-6 h-6" />
        </button>
        
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)] flex items-center justify-center font-bold text-sm">
            AI
          </div>
          <h1 className="text-xl font-bold">أيون العقاري</h1>
        </div>
        
        <div className="flex items-center gap-2">
          {showNotifications && (
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[var(--aion-green)] rounded-full"></span>
            </button>
          )}
          <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            <User className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
}
