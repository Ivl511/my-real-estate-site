import { motion } from "motion/react";
import { ArrowRight, Sparkles, SlidersHorizontal } from "lucide-react";

interface SearchResultsProps {
  onBack: () => void;
}

export function SearchResults({ onBack }: SearchResultsProps) {
  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-[#0A0E27] via-[#0F1333] to-[#1A1F3A]">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-b from-white/5 to-transparent backdrop-blur-xl border-b border-white/10 px-5 py-4"
      >
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.9 }}
            className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center"
          >
            <SlidersHorizontal className="w-5 h-5 text-white/70" />
          </motion.button>
          
          <h2 className="text-white font-black text-lg">نتائج البحث</h2>

          <motion.button
            onClick={onBack}
            whileTap={{ scale: 0.9 }}
            className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center"
          >
            <ArrowRight className="w-5 h-5 text-white/70" />
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
