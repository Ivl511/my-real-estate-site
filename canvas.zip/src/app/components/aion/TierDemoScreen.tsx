import { motion } from "motion/react";
import { 
  Lock, 
  TrendingUp, 
  Users, 
  Building2, 
  FileText, 
  MapPin, 
  AlertCircle,
  CheckCircle,
  Briefcase,
  Home,
  Zap,
  BarChart3,
  Shield,
  Calendar,
  DollarSign,
  Award,
  Sparkles,
  ArrowRight,
  Target,
  ListTodo
} from "lucide-react";
import { useState } from "react";

interface TierDemoScreenProps {
  onBack: () => void;
}

type Persona = "broker" | "developer" | "landlord" | "seeker";
type BrokerTier = "starter" | "nomad" | "pro";
type DeveloperTier = "starter" | "business" | "enterprise";
type LandlordTier = "free" | "premium";
type SeekerTier = "guest" | "vip";

// Bento Card Component Props
interface BentoCardProps {
  icon: any;
  emoji: string;
  title: string;
  titleAr: string;
  value: string;
  subtitle: string;
  subtitleAr: string;
  color: string;
  isLocked: boolean;
  upgradeMessage?: string;
  badge?: string;
}

export function TierDemoScreen({ onBack }: TierDemoScreenProps) {
  const [persona, setPersona] = useState<Persona>("broker");
  const [brokerTier, setBrokerTier] = useState<BrokerTier>("starter");
  const [developerTier, setDeveloperTier] = useState<DeveloperTier>("starter");
  const [landlordTier, setLandlordTier] = useState<LandlordTier>("free");
  const [seekerTier, setSeekerTier] = useState<SeekerTier>("guest");

  // Persona configurations
  const personas = [
    { id: "broker" as Persona, label: "وسيط", icon: "👔", emoji: "👔" },
    { id: "developer" as Persona, label: "مطور", icon: "🏗️", emoji: "🏗️" },
    { id: "landlord" as Persona, label: "مالك", icon: "🔑", emoji: "🔑" },
    { id: "seeker" as Persona, label: "باحث", icon: "🔍", emoji: "🔍" },
  ];

  // Tier configurations for each persona
  const brokerTiers = [
    { id: "starter" as BrokerTier, label: "Starter", color: "emerald" },
    { id: "nomad" as BrokerTier, label: "Nomad", color: "purple" },
    { id: "pro" as BrokerTier, label: "PRO", color: "yellow" },
  ];

  const developerTiers = [
    { id: "starter" as DeveloperTier, label: "Starter", color: "blue" },
    { id: "business" as DeveloperTier, label: "Business", color: "indigo" },
    { id: "enterprise" as DeveloperTier, label: "Enterprise", color: "slate" },
  ];

  const landlordTiers = [
    { id: "free" as LandlordTier, label: "Free", color: "gray" },
    { id: "premium" as LandlordTier, label: "Premium", color: "yellow" },
  ];

  const seekerTiers = [
    { id: "guest" as SeekerTier, label: "Guest", color: "blue" },
    { id: "vip" as SeekerTier, label: "VIP", color: "purple" },
  ];

  // Get current tier based on persona
  const getCurrentTier = () => {
    switch (persona) {
      case "broker":
        return brokerTier;
      case "developer":
        return developerTier;
      case "landlord":
        return landlordTier;
      case "seeker":
        return seekerTier;
    }
  };

  // Get tier options based on persona
  const getTierOptions = () => {
    switch (persona) {
      case "broker":
        return brokerTiers;
      case "developer":
        return developerTiers;
      case "landlord":
        return landlordTiers;
      case "seeker":
        return seekerTiers;
    }
  };

  // Set tier based on persona
  const setTier = (tier: string) => {
    switch (persona) {
      case "broker":
        setBrokerTier(tier as BrokerTier);
        break;
      case "developer":
        setDeveloperTier(tier as DeveloperTier);
        break;
      case "landlord":
        setLandlordTier(tier as LandlordTier);
        break;
      case "seeker":
        setSeekerTier(tier as SeekerTier);
        break;
    }
  };

  // Get subscription days left
  const getSubscriptionDaysLeft = () => {
    switch (persona) {
      case "broker":
        return brokerTier === "starter" ? 30 : brokerTier === "nomad" ? 25 : 15;
      case "developer":
        return developerTier === "starter" ? 30 : developerTier === "business" ? 22 : 18;
      case "landlord":
        return landlordTier === "free" ? "∞" : 20;
      case "seeker":
        return seekerTier === "guest" ? "∞" : 28;
    }
  };

  return (
    <div className="h-full flex flex-col overflow-hidden noise-bg">
      {/* RULE 1: Floating Dev Toolbar - META-LAYER (Absolute Top y=0) */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-slate-800 via-slate-900 to-slate-800 border-b-2 border-yellow-500/30 shadow-2xl">
        <div className="px-4 py-2">
          <div className="flex items-center justify-between mb-2">
            {/* Back Button */}
            <button 
              onClick={onBack}
              className="w-8 h-8 rounded-lg bg-slate-700/50 hover:bg-slate-700 flex items-center justify-center transition-colors border border-white/10"
            >
              <ArrowRight className="w-4 h-4 text-white" />
            </button>

            {/* Meta Label */}
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
              <span className="text-[9px] font-black text-yellow-500 uppercase tracking-widest">DEV SIMULATION MODE</span>
            </div>
          </div>

          {/* Two Explicit Dropdown Selectors */}
          <div className="grid grid-cols-2 gap-3">
            {/* [A] Persona Dropdown */}
            <div className="bg-slate-950/50 rounded-lg p-2 border border-white/5">
              <label className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-1.5 block">
                [A] Persona:
              </label>
              <div className="grid grid-cols-2 gap-1">
                {personas.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setPersona(p.id)}
                    className={`py-1.5 px-2 rounded-md text-[10px] font-bold transition-all ${
                      persona === p.id
                        ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg"
                        : "bg-slate-800/50 text-white/30 hover:text-white/60 hover:bg-slate-800"
                    }`}
                  >
                    <div className="text-xs mb-0.5">{p.emoji}</div>
                    <div className="text-[9px]">{p.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* [B] Tier Dropdown */}
            <div className="bg-slate-950/50 rounded-lg p-2 border border-white/5">
              <label className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-1.5 block">
                [B] Tier:
              </label>
              <div className={`grid gap-1 ${getTierOptions().length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
                {getTierOptions().map((tier) => (
                  <button
                    key={tier.id}
                    onClick={() => setTier(tier.id)}
                    className={`py-1.5 px-1.5 rounded-md text-[9px] font-bold transition-all ${
                      getCurrentTier() === tier.id
                        ? "bg-gradient-to-r from-orange-500 to-red-600 text-white shadow-lg"
                        : "bg-slate-800/50 text-white/30 hover:text-white/60 hover:bg-slate-800"
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scrollable Content - HIERARCHY: Profile → Bento Grid → Footer */}
      <div className="flex-1 overflow-y-auto pb-24 pt-[140px] px-5">
        {/* MIDDLE: User Profile Header (ID Card) */}
        <IDCard
          persona={persona}
          brokerTier={brokerTier}
          developerTier={developerTier}
          landlordTier={landlordTier}
          seekerTier={seekerTier}
          personas={personas}
        />

        {/* CENTER: The 2x2 Bento Grid (Apple Style - Clean, No Lists) */}
        <div className="mt-6">
          <BentoGrid
            persona={persona}
            brokerTier={brokerTier}
            developerTier={developerTier}
            landlordTier={landlordTier}
            seekerTier={seekerTier}
          />
        </div>

        {/* BOTTOM: Subscription Banner */}
        <div className="mt-6 rounded-2xl glass-premium border border-white/10 p-4 text-center">
          <p className="text-xs text-white/60 mb-1">Subscription Status</p>
          <p className="text-xl font-black text-cyan-400">
            {getSubscriptionDaysLeft()} {typeof getSubscriptionDaysLeft() === 'number' ? 'Days Left' : ''}
          </p>
        </div>
      </div>
    </div>
  );
}

// ID Card Component
interface IDCardProps {
  persona: Persona;
  brokerTier: BrokerTier;
  developerTier: DeveloperTier;
  landlordTier: LandlordTier;
  seekerTier: SeekerTier;
  personas: Array<{id: Persona; label: string; icon: string; emoji: string}>;
}

function IDCard({ persona, brokerTier, developerTier, landlordTier, seekerTier, personas }: IDCardProps) {
  const getCardStyle = () => {
    switch (persona) {
      case "broker":
        switch (brokerTier) {
          case "starter":
            return {
              bg: "bg-gradient-to-br from-emerald-900/40 to-emerald-800/30",
              border: "border-emerald-500/30",
              glow: "bg-emerald-500/20",
              titleColor: "text-emerald-400",
              titleShadow: "0 0 20px rgba(16, 185, 129, 0.5)",
              subtitleColor: "text-white/60",
              labelColor: "text-white/50",
              idColor: "text-emerald-400",
              badgeBg: "bg-emerald-500/20",
              badgeColor: "text-emerald-400",
              iconOpacity: "opacity-20",
              topGlow: "bg-gradient-to-r from-transparent via-emerald-500 to-transparent",
            };
          case "nomad":
            return {
              bg: "bg-gradient-to-br from-purple-900/40 via-pink-900/30 to-cyan-900/30",
              border: "border-purple-500/40",
              glow: "bg-gradient-to-r from-purple-500/30 via-pink-500/30 to-cyan-500/30",
              titleColor: "text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400",
              titleShadow: "0 0 30px rgba(168, 85, 247, 0.6)",
              subtitleColor: "text-white/70",
              labelColor: "text-white/60",
              idColor: "text-purple-400",
              badgeBg: "bg-purple-500/20",
              badgeColor: "text-purple-300",
              iconOpacity: "opacity-30",
              topGlow: "bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500",
            };
          case "pro":
            return {
              bg: "bg-gradient-to-br from-slate-900 to-black metal-card",
              border: "border-yellow-500/40",
              glow: "bg-gradient-to-r from-yellow-500/30 via-yellow-400/20 to-yellow-500/30",
              titleColor: "text-yellow-500",
              titleShadow: "0 0 30px rgba(234, 179, 8, 0.7)",
              subtitleColor: "text-white/80",
              labelColor: "text-white/60",
              idColor: "text-yellow-500",
              badgeBg: "bg-yellow-500/20",
              badgeColor: "text-yellow-400",
              iconOpacity: "opacity-20",
              topGlow: "bg-gradient-to-r from-transparent via-yellow-500 to-transparent",
            };
        }
        break;
      
      case "developer":
        switch (developerTier) {
          case "starter":
            return {
              bg: "bg-gradient-to-br from-blue-900/40 to-blue-800/30",
              border: "border-blue-500/30",
              glow: "bg-blue-500/20",
              titleColor: "text-blue-400",
              titleShadow: "0 0 20px rgba(59, 130, 246, 0.5)",
              subtitleColor: "text-white/60",
              labelColor: "text-white/50",
              idColor: "text-blue-400",
              badgeBg: "bg-blue-500/20",
              badgeColor: "text-blue-400",
              iconOpacity: "opacity-20",
              topGlow: "bg-gradient-to-r from-transparent via-blue-500 to-transparent",
            };
          case "business":
            return {
              bg: "bg-gradient-to-br from-indigo-900/40 to-violet-900/30",
              border: "border-indigo-500/40",
              glow: "bg-indigo-500/30",
              titleColor: "text-indigo-400",
              titleShadow: "0 0 25px rgba(99, 102, 241, 0.6)",
              subtitleColor: "text-white/70",
              labelColor: "text-white/60",
              idColor: "text-indigo-400",
              badgeBg: "bg-indigo-500/20",
              badgeColor: "text-indigo-300",
              iconOpacity: "opacity-25",
              topGlow: "bg-gradient-to-r from-transparent via-indigo-500 to-transparent",
            };
          case "enterprise":
            return {
              bg: "bg-gradient-to-br from-slate-900 to-black metal-card",
              border: "border-slate-400/40",
              glow: "bg-gradient-to-r from-slate-400/20 via-white/10 to-slate-400/20",
              titleColor: "text-slate-300",
              titleShadow: "0 0 30px rgba(148, 163, 184, 0.5)",
              subtitleColor: "text-white/80",
              labelColor: "text-white/60",
              idColor: "text-slate-300",
              badgeBg: "bg-slate-500/20",
              badgeColor: "text-slate-300",
              iconOpacity: "opacity-20",
              topGlow: "bg-gradient-to-r from-transparent via-slate-400 to-transparent",
            };
        }
        break;

      case "landlord":
        switch (landlordTier) {
          case "free":
            return {
              bg: "bg-gradient-to-br from-orange-900/30 to-yellow-900/20",
              border: "border-orange-600/30",
              glow: "bg-orange-500/15",
              titleColor: "text-orange-400",
              titleShadow: "0 0 15px rgba(251, 146, 60, 0.4)",
              subtitleColor: "text-white/60",
              labelColor: "text-white/50",
              idColor: "text-orange-400",
              badgeBg: "bg-orange-500/20",
              badgeColor: "text-orange-400",
              iconOpacity: "opacity-20",
              topGlow: null,
            };
          case "premium":
            return {
              bg: "bg-gradient-to-br from-yellow-900/40 to-amber-900/30 metal-card",
              border: "border-yellow-500/40",
              glow: "bg-yellow-500/25",
              titleColor: "text-yellow-500",
              titleShadow: "0 0 25px rgba(234, 179, 8, 0.6)",
              subtitleColor: "text-white/70",
              labelColor: "text-white/60",
              idColor: "text-yellow-500",
              badgeBg: "bg-yellow-500/20",
              badgeColor: "text-yellow-400",
              iconOpacity: "opacity-25",
              topGlow: "bg-gradient-to-r from-transparent via-yellow-500 to-transparent",
            };
        }
        break;

      case "seeker":
        switch (seekerTier) {
          case "guest":
            return {
              bg: "bg-gradient-to-br from-blue-900/30 to-cyan-900/20",
              border: "border-blue-500/30",
              glow: "bg-blue-500/15",
              titleColor: "text-blue-400",
              titleShadow: "0 0 15px rgba(59, 130, 246, 0.4)",
              subtitleColor: "text-white/60",
              labelColor: "text-white/50",
              idColor: "text-blue-400",
              badgeBg: "bg-blue-500/20",
              badgeColor: "text-blue-400",
              iconOpacity: "opacity-20",
              topGlow: null,
            };
          case "vip":
            return {
              bg: "bg-gradient-to-br from-purple-900/40 via-fuchsia-900/30 to-purple-900/40",
              border: "border-purple-500/50",
              glow: "bg-gradient-to-r from-purple-500/30 via-fuchsia-500/30 to-purple-500/30",
              titleColor: "text-purple-400",
              titleShadow: "0 0 30px rgba(168, 85, 247, 0.7)",
              subtitleColor: "text-white/70",
              labelColor: "text-white/60",
              idColor: "text-purple-400",
              badgeBg: "bg-purple-500/20",
              badgeColor: "text-purple-300",
              iconOpacity: "opacity-30",
              topGlow: "bg-gradient-to-r from-purple-500 via-fuchsia-500 to-purple-500",
            };
        }
        break;
    }

    // Default fallback
    return {
      bg: "bg-slate-800/50",
      border: "border-slate-600/50",
      glow: "bg-slate-500/10",
      titleColor: "text-white",
      titleShadow: "none",
      subtitleColor: "text-white/60",
      labelColor: "text-white/50",
      idColor: "text-white",
      badgeBg: "bg-white/10",
      badgeColor: "text-white",
      iconOpacity: "opacity-20",
      topGlow: null,
    };
  };

  const getCardTierLabel = () => {
    switch (persona) {
      case "broker":
        return brokerTier === "starter" ? "STARTER TIER" : brokerTier === "nomad" ? "NOMAD TIER" : "PRO TIER";
      case "developer":
        return developerTier === "starter" ? "STARTER" : developerTier === "business" ? "BUSINESS" : "ENTERPRISE";
      case "landlord":
        return landlordTier === "free" ? "FREE ACCOUNT" : "PREMIUM OWNER";
      case "seeker":
        return seekerTier === "guest" ? "GUEST USER" : "VIP HUNTER";
    }
  };

  const getPersonaName = () => {
    switch (persona) {
      case "broker":
        return "محمد العتيبي";
      case "developer":
        return "شركة الرياض للتطوير";
      case "landlord":
        return "خالد الأحمد";
      case "seeker":
        return "سارة المطيري";
    }
  };

  const getPersonaID = () => {
    switch (persona) {
      case "broker":
        return "7001234567";
      case "developer":
        return "DEV9876543";
      case "landlord":
        return "OWN3456789";
      case "seeker":
        return "USR1122334";
    }
  };

  const cardStyles = getCardStyle();
  const getCurrentTier = () => {
    switch (persona) {
      case "broker": return brokerTier;
      case "developer": return developerTier;
      case "landlord": return landlordTier;
      case "seeker": return seekerTier;
    }
  };
  
  return (
    <motion.div
      key={`${persona}-${getCurrentTier()}`}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative"
    >
      {/* Glow Effect */}
      <div className={`absolute inset-0 rounded-3xl blur-2xl ${cardStyles.glow}`} />
      
      {/* Card */}
      <div className={`relative rounded-3xl p-6 border ${cardStyles.bg} ${cardStyles.border}`}>
        {/* Top Edge Glow */}
        {cardStyles.topGlow && (
          <div className={`absolute top-0 left-0 right-0 h-[2px] ${cardStyles.topGlow}`} />
        )}
        
        {/* Content */}
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-6">
            <div className="text-right flex-1">
              <h3 className={`text-3xl font-black mb-1 ${cardStyles.titleColor}`} style={{ 
                fontFamily: 'Cairo',
                letterSpacing: '2px',
                textShadow: cardStyles.titleShadow
              }}>
                ڤال
              </h3>
              <p className={`text-xs font-bold tracking-wider ${cardStyles.subtitleColor}`}>
                {getCardTierLabel()}
              </p>
            </div>
            <div className={`px-3 py-1.5 rounded-lg ${cardStyles.badgeBg}`}>
              <p className={`text-xs font-black ${cardStyles.badgeColor}`}>
                {personas.find(p => p.id === persona)?.emoji} {personas.find(p => p.id === persona)?.label}
              </p>
            </div>
          </div>

          <div className="mb-6">
            <p className={`text-xs font-semibold mb-1 ${cardStyles.labelColor}`}>USER NAME</p>
            <h2 className="text-white text-2xl font-black" style={{ fontFamily: 'Cairo' }}>
              {getPersonaName()}
            </h2>
          </div>

          <div className="flex items-end justify-between">
            <div>
              <p className={`text-xs font-semibold mb-1 ${cardStyles.labelColor}`}>ID NUMBER</p>
              <p className={`text-lg font-black tracking-wider ${cardStyles.idColor}`}>
                #{getPersonaID()}
              </p>
            </div>
            <div className={`text-4xl ${cardStyles.iconOpacity}`}>
              {personas.find(p => p.id === persona)?.emoji}
            </div>
          </div>

          {/* Authority Stamp for PRO/Enterprise */}
          {(brokerTier === "pro" || developerTier === "enterprise") && persona !== "landlord" && persona !== "seeker" && (
            <div className="absolute top-4 left-4">
              <div className="relative">
                <Award className="w-12 h-12 text-yellow-500" style={{ filter: 'drop-shadow(0 0 10px rgba(234, 179, 8, 0.5))' }} />
                <p className="text-[8px] font-black text-yellow-500 text-center mt-1">FAL</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// Bento Grid Component
interface BentoGridProps {
  persona: Persona;
  brokerTier: BrokerTier;
  developerTier: DeveloperTier;
  landlordTier: LandlordTier;
  seekerTier: SeekerTier;
}

function BentoGrid({ persona, brokerTier, developerTier, landlordTier, seekerTier }: BentoGridProps) {
  switch (persona) {
    case "broker":
      return <BrokerBentoGrid brokerTier={brokerTier} />;
    case "developer":
      return <DeveloperBentoGrid developerTier={developerTier} />;
    case "landlord":
      return <LandlordBentoGrid landlordTier={landlordTier} />;
    case "seeker":
      return <SeekerBentoGrid seekerTier={seekerTier} />;
  }
}

// Broker Bento Grid
function BrokerBentoGrid({ brokerTier }: { brokerTier: BrokerTier }) {
  const isStarter = brokerTier === "starter";

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Top-Left: My Landlords */}
      <BentoCard
        icon={Users}
        emoji="👥"
        title="My Landlords"
        titleAr="ملاكي"
        value="12"
        subtitle="Active Owners"
        subtitleAr="مالك نشط"
        color="emerald"
        isLocked={isStarter}
        upgradeMessage="Upgrade to NOMAD"
      />

      {/* Top-Right: My Listings */}
      <BentoCard
        icon={Building2}
        emoji="🏠"
        title="My Listings"
        titleAr="عقاراتي"
        value="43"
        subtitle="Properties"
        subtitleAr="عقار"
        color="cyan"
        isLocked={false}
      />

      {/* Bottom-Left: My Tasks */}
      <BentoCard
        icon={ListTodo}
        emoji="✅"
        title="My Tasks"
        titleAr="مهامي"
        value="3"
        subtitle="Pending Actions"
        subtitleAr="إجراءات معلقة"
        color="purple"
        isLocked={false}
      />

      {/* Bottom-Right: My Requests */}
      <BentoCard
        icon={FileText}
        emoji="📄"
        title="My Requests"
        titleAr="طلباتي"
        value="5"
        subtitle="New Orders"
        subtitleAr="طلب جديد"
        color="orange"
        isLocked={false}
      />
    </div>
  );
}

// Developer Bento Grid
function DeveloperBentoGrid({ developerTier }: { developerTier: DeveloperTier }) {
  const isStarter = developerTier === "starter";
  const isBusiness = developerTier === "business";
  const isEnterprise = developerTier === "enterprise";

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Top-Left: Projects */}
      <BentoCard
        icon={Building2}
        emoji="🏗️"
        title="Projects"
        titleAr="المشاريع"
        value={isStarter ? "1" : isBusiness ? "5" : "12"}
        subtitle="Active Projects"
        subtitleAr="مشروع نشط"
        color="blue"
        isLocked={false}
      />

      {/* Top-Right: Inventory */}
      <BentoCard
        icon={Home}
        emoji="🏘️"
        title="Inventory"
        titleAr="المخزون"
        value="78"
        subtitle="Available Units"
        subtitleAr="وحدة متاحة"
        color="emerald"
        isLocked={false}
      />

      {/* Bottom-Left: Sales Team */}
      <BentoCard
        icon={Users}
        emoji="👥"
        title="Sales Team"
        titleAr="فريق المبيعات"
        value="8"
        subtitle="Active Agents"
        subtitleAr="وكيل نشط"
        color="purple"
        isLocked={isStarter}
        upgradeMessage="Business Feature"
      />

      {/* Bottom-Right: Land Acquisition */}
      <BentoCard
        icon={MapPin}
        emoji="🗺️"
        title="Land Hunt"
        titleAr="اقتناص الأراضي"
        value="3"
        subtitle="AI Found Lands"
        subtitleAr="أرض خام"
        color="red"
        isLocked={!isEnterprise}
        upgradeMessage="Enterprise Only"
      />
    </div>
  );
}

// Landlord Bento Grid
function LandlordBentoGrid({ landlordTier }: { landlordTier: LandlordTier }) {
  const isFree = landlordTier === "free";
  const isPremium = landlordTier === "premium";

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Top-Left: My Assets */}
      <BentoCard
        icon={Home}
        emoji="🏠"
        title="My Assets"
        titleAr="أصولي"
        value="3"
        subtitle="Properties"
        subtitleAr="عقار"
        color="emerald"
        isLocked={false}
      />

      {/* Top-Right: Offers */}
      <BentoCard
        icon={DollarSign}
        emoji="💰"
        title="Offers"
        titleAr="العروض"
        value="7"
        subtitle="New Offers"
        subtitleAr="عرض جديد"
        color="cyan"
        isLocked={false}
      />

      {/* Bottom-Left: AI Guard */}
      <BentoCard
        icon={Shield}
        emoji="🛡️"
        title="AI Guard"
        titleAr="حارس AI"
        value={isPremium ? "15" : "0"}
        subtitle={isPremium ? "Filtered Chats" : "Manual Mode"}
        subtitleAr={isPremium ? "محادثة مصفاة" : "يدوي"}
        color="purple"
        isLocked={false}
        badge={isPremium ? "🟢 Active" : "⚪ Off"}
      />

      {/* Bottom-Right: Broker Match */}
      <BentoCard
        icon={Briefcase}
        emoji="💼"
        title="Broker Match"
        titleAr="مطابقة الوسطاء"
        value="3"
        subtitle="Broker Requests"
        subtitleAr="طلب وصول"
        color="orange"
        isLocked={isFree}
        upgradeMessage="Premium Feature"
      />
    </div>
  );
}

// Seeker Bento Grid
function SeekerBentoGrid({ seekerTier }: { seekerTier: SeekerTier }) {
  const isGuest = seekerTier === "guest";

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Top-Left: Wishlist */}
      <BentoCard
        icon={Home}
        emoji="❤️"
        title="Wishlist"
        titleAr="المفضلة"
        value="12"
        subtitle="Saved Properties"
        subtitleAr="عقار محفوظ"
        color="pink"
        isLocked={false}
      />

      {/* Top-Right: My Requests */}
      <BentoCard
        icon={FileText}
        emoji="📄"
        title="Requests"
        titleAr="طلباتي"
        value="2"
        subtitle="Active Requests"
        subtitleAr="طلب نشط"
        color="blue"
        isLocked={false}
      />

      {/* Bottom-Left: Fair Price */}
      <BentoCard
        icon={BarChart3}
        emoji="📊"
        title="Fair Price"
        titleAr="السعر العادل"
        value="-10%"
        subtitle="Under Market"
        subtitleAr="أقل من السوق"
        color="emerald"
        isLocked={isGuest}
        upgradeMessage="VIP Only"
      />

      {/* Bottom-Right: Early Alerts */}
      <BentoCard
        icon={Zap}
        emoji="⚡"
        title="Early Alerts"
        titleAr="تنبيهات مبكرة"
        value="5"
        subtitle="New Listings"
        subtitleAr="عقار جديد"
        color="purple"
        isLocked={isGuest}
        upgradeMessage="VIP Only"
      />
    </div>
  );
}

// Bento Card Component
function BentoCard({ 
  icon: Icon, 
  emoji,
  title, 
  titleAr,
  value, 
  subtitle, 
  subtitleAr,
  color, 
  isLocked, 
  upgradeMessage,
  badge
}: BentoCardProps) {
  const colorClasses = {
    cyan: "from-cyan-500 to-blue-600",
    purple: "from-purple-500 to-pink-600",
    emerald: "from-emerald-500 to-green-600",
    blue: "from-blue-500 to-indigo-600",
    red: "from-red-500 to-orange-600",
    orange: "from-orange-500 to-amber-600",
    pink: "from-pink-500 to-rose-600",
    yellow: "from-yellow-500 to-orange-500",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative rounded-3xl p-5 border ${
        isLocked 
          ? "glass-premium border-white/5 grayscale" 
          : "glass-strong border-white/10"
      }`}
      style={{ filter: isLocked ? "blur(0.5px)" : "none" }}
    >
      {/* Lock Overlay */}
      {isLocked && (
        <div className="absolute inset-0 rounded-3xl bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-10">
          <Lock className="w-12 h-12 text-white/40 mb-3" />
          <p className="text-xs font-bold text-white/80 text-center px-4">
            {upgradeMessage || "ميزة مقفلة"}
          </p>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br ${colorClasses[color as keyof typeof colorClasses] || colorClasses.cyan}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <h3 className="text-base font-black text-white flex-1 text-right mr-3">{title}</h3>
      </div>

      {/* Content */}
      <div className={isLocked ? "opacity-40" : ""}>
        <div className="text-center">
          <p className="text-3xl font-black text-white mb-1">{value}</p>
          <p className="text-xs text-white/60">{subtitle}</p>
        </div>
        {badge && (
          <div className="absolute top-4 right-4 text-xs font-bold">
            {badge}
          </div>
        )}
      </div>
    </motion.div>
  );
}