import { Sparkles } from "lucide-react";

export function TypingIndicator() {
  return (
    <div className="flex gap-3 mb-4">
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 bg-gradient-to-br from-[var(--aion-green)] to-[var(--aion-green-light)]">
        <Sparkles className="w-5 h-5 text-white" />
      </div>
      
      <div className="rounded-2xl rounded-tl-sm px-4 py-3 bg-white" style={{ boxShadow: 'var(--aion-shadow-md)' }}>
        <div className="flex gap-1.5">
          <span className="w-2 h-2 bg-[var(--aion-gray-400)] rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
          <span className="w-2 h-2 bg-[var(--aion-gray-400)] rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
          <span className="w-2 h-2 bg-[var(--aion-gray-400)] rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
        </div>
      </div>
    </div>
  );
}
