import { motion } from "motion/react";
import {
  ArrowRight, MapPin, DollarSign, Maximize, Compass, MessageCircle, Edit,
  Phone, Briefcase, Building2, Percent, CheckCircle, Zap, Clock,
  Users, Star, Shield, FileText, TrendingUp, Hash, AlertCircle,
  MessageSquare, ChevronRight
} from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../context/ThemeContext";

interface RequestDetailScreenProps {
  requestId: string;
  onBack: () => void;
}

// ── ALL REQUESTS DATA ──────────────────────────────────────────────
const searchRequestsData: Record<string, any> = {
  "1": {
    type: "search",
    id: "REQ-001",
    title: "وسيط يبحث عن فيلا فاخرة لعميل VIP",
    description: "عميل خليجي يبحث عن فيلا فاخرة في شمال الرياض، المواصفات: مودرن، مسبح خاص، مصعد، لا يقل عن 6 غرف، تشطيبات عالية الجودة، حي حطين أو النرجس أو الملقا. يشترط صك إلكتروني ويقبل التمويل البنكي. الدفع كاش أو تمويل مصرفي.",
    requestSubtype: "broker",
    purchaseType: "شراء",
    tags: ["شراء", "كاش/تمويل", "حصري", "عاجل"],
    budget: "8,000,000 - 12,000,000 ر.س",
    area: "500 م² فأكثر",
    direction: "شمالية أو شرقية",
    street: "20 متر فأكثر",
    location: "شمال الرياض (حطين، النرجس، الملقا)",
    postedBy: "مكتب الراقي العقاري",
    postedByType: "وسيط معتمد",
    falNumber: "1000023451",
    rating: 4.7,
    ratingCount: 89,
    postedDate: "منذ يومين",
    views: 342,
    offers: 4,
    urgent: true,
  },
  "2": {
    type: "search",
    id: "REQ-002",
    title: "عائلة تبحث عن منزل مريح في النرجس",
    description: "عائلة سعودية تبحث عن دور أرضي أو فيلا مريحة في حي النرجس، مناسبة للعائلات. المواصفات المطلوبة: لا تقل عن 4 غرف نوم، حديقة، كراجات، قريبة من المدارس. يفضل مفروشة جزئياً. الدفع عن طريق تمويل بنكي.",
    requestSubtype: "seeker",
    purchaseType: "شراء",
    tags: ["شراء", "تمويل بنكي", "عائلي"],
    budget: "2,000,000 - 3,000,000 ر.س",
    area: "300 م² فأكثر",
    direction: "أي اتجاه",
    street: "15 متر فأكثر",
    location: "حي النرجس، الرياض",
    postedBy: "أحمد المالكي",
    postedByType: "باحث",
    falNumber: null,
    rating: null,
    ratingCount: 0,
    postedDate: "منذ أسبوع",
    views: 198,
    offers: 8,
    urgent: false,
  },
  "3": {
    type: "search",
    id: "REQ-003",
    title: "مطور يبحث عن أرض استثمارية في الملقا",
    description: "شركة تطوير عقاري كبرى تبحث عن أرض تجارية أو سكنية كبيرة في حي الملقا أو المحيطين به. المساحة لا تقل عن 2000 م²، على شارع رئيسي لا يقل عن 30 م. الهدف إنشاء مشروع سكني متكامل أو برج تجاري.",
    requestSubtype: "developer",
    purchaseType: "شراء",
    tags: ["شراء", "كاش", "استثماري", "عاجل"],
    budget: "5,000,000 - 8,000,000 ر.س",
    area: "2000 م² فأكثر",
    direction: "شمالية",
    street: "30 متر فأكثر",
    location: "حي الملقا، الرياض",
    postedBy: "شركة رتال للتطوير",
    postedByType: "مطور معتمد",
    falNumber: "1000021453",
    rating: 4.9,
    ratingCount: 215,
    postedDate: "منذ 3 أيام",
    views: 521,
    offers: 2,
    urgent: true,
  },
};

const marketingRequestsData: Record<string, any> = {
  "4": {
    type: "marketing",
    id: "MKT-004",
    title: "مطلوب مسوق عقاري محترف",
    property: "برج تجاري في جدة — 24 طابق",
    propertyType: "برج تجاري",
    location: "جدة، حي الشاطئ",
    propertyValue: "45,000,000",
    commission: 2.5,
    contract: "حصري",
    contractDuration: "6 أشهر",
    description: "نبحث عن مسوق عقاري محترف لتسويق وحدات برج تجاري فاخر في قلب جدة. المشروع يضم 24 طابقاً من المكاتب والمحلات التجارية. نقدم عقداً حصرياً مع دعم تسويقي كامل، مواد ترويجية جاهزة، جلسات تعريفية أسبوعية.",
    requirements: ["رخصة فال سارية", "خبرة 3 سنوات فأكثر", "شبكة علاقات واسعة", "لديه تجربة ببيع عقارات تجارية"],
    benefits: ["عقد حصري ✓", "دعم تسويقي كامل", "مواد ترويجية جاهزة", "عمولة تُدفع فور إتمام الصفقة"],
    postedBy: "مجموعة الكيان للتطوير",
    postedByType: "مطور معتمد",
    postedDate: "منذ يومين",
    views: 412,
    applications: 3,
    urgent: false,
  },
  "5": {
    type: "marketing",
    id: "MKT-005",
    title: "مطلوب وسيط لبيع فيلا فاخرة",
    property: "فيلا فاخرة مودرن — حي الملقا",
    propertyType: "فيلا",
    location: "الرياض، حي الملقا",
    propertyValue: "3,500,000",
    commission: 3,
    contract: "عادي",
    contractDuration: "3 أشهر",
    description: "صاحب عقار يرغب في الاستعانة بوسيط لبيع فيلا مودرن فاخرة في حي الملقا. الفيلا جاهزة للمعاينة، مصورة احترافياً، مع صك إلكتروني. نقبل التمويل البنكي. نطلب وسيطاً جاداً لديه عملاء جاهزون.",
    requirements: ["رخصة فال سارية", "لديه عملاء جاهزون", "التزام بالمواعيد"],
    benefits: ["عمولة 3% من قيمة البيع", "صور احترافية جاهزة", "صك إلكتروني متوفر", "دعم تسويقي جزئي"],
    postedBy: "سعد القحطاني",
    postedByType: "مالك",
    postedDate: "منذ 5 أيام",
    views: 287,
    applications: 7,
    urgent: true,
  },
  "6": {
    type: "marketing",
    id: "MKT-006",
    title: "إطلاق مشروع مجمع الفلل الحصري",
    property: "مجمع 50 فيلا — شرق الرياض",
    propertyType: "مجمع فلل",
    location: "شرق الرياض",
    propertyValue: "120,000,000",
    commission: 5,
    contract: "حصري",
    contractDuration: "12 شهراً",
    description: "شركة تطوير رائدة تطلق مشروع مجمع فلل سكنية فاخر في شرق الرياض. المشروع يضم 50 فيلا متكاملة بتصاميم عصرية ومرافق مجتمعية شاملة. نبحث عن فريق تسويقي محترف للتسويق الحصري.",
    requirements: ["شركة أو مكتب عقاري معتمد", "رخصة فال سارية للجميع", "خبرة في تسويق المشاريع", "فريق من 3 وسطاء فأكثر"],
    benefits: ["عمولة 5% من كل وحدة مباعة", "مكافأة إضافية عند بيع 20 وحدة", "عقد حصري لمدة سنة", "دعم تسويقي ضخم", "مكتب ونماذج جاهزة في الموقع"],
    postedBy: "عروض الديار للتطوير",
    postedByType: "مطور معتمد",
    postedDate: "من�� أسبوع",
    views: 1204,
    applications: 12,
    urgent: true,
  },
};

// ── SEARCH REQUEST DETAIL ──────────────────────────────────────────
function SearchRequestDetail({ data, isDark, onBack }: any) {
  const [showContactOptions, setShowContactOptions] = useState(false);
  const subTypeColors: Record<string, string> = {
    broker: isDark ? "bg-emerald-500/20 border-emerald-500/30 text-emerald-400" : "bg-emerald-100 border-emerald-300 text-emerald-700",
    seeker: isDark ? "bg-blue-500/20 border-blue-500/30 text-blue-400" : "bg-blue-100 border-blue-300 text-blue-700",
    developer: isDark ? "bg-orange-500/20 border-orange-500/30 text-orange-400" : "bg-orange-100 border-orange-300 text-orange-700",
  };
  const subTypeLabel: Record<string, string> = {
    broker: "طلب وسيط", seeker: "طلب باحث", developer: "طلب مطور"
  };

  return (
    <div className={`h-full flex flex-col ${isDark ? "noise-bg" : "bg-gradient-to-br from-gray-50 to-gray-100"} overflow-y-auto`}>
      {/* Header */}
      <div className="px-5 pt-12 pb-4 relative z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className={`w-11 h-11 rounded-2xl flex items-center justify-center ${isDark ? "glass-premium" : "bg-white shadow-lg"}`}>
            <ArrowRight className={`w-5 h-5 ${isDark ? "text-white" : "text-gray-900"}`} />
          </button>
          <div>
            <h2 className={`text-lg font-black ${isDark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "Cairo" }}>
              تفاصيل الطلب
            </h2>
            <p className={`text-[10px] font-black ${isDark ? "text-white/30" : "text-gray-400"}`}>#{data.id}</p>
          </div>
        </div>
      </div>

      <div className="flex-1 px-5 pb-32 relative z-10 space-y-4">
        {/* Main Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className={`rounded-3xl p-6 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          {/* Tags Row */}
          <div className="flex items-center gap-2 flex-wrap mb-4">
            <div className={`rounded-lg px-3 py-1.5 border ${subTypeColors[data.requestSubtype]}`}>
              <span className="text-xs font-black">{subTypeLabel[data.requestSubtype]}</span>
            </div>
            {data.urgent && (
              <div className={`rounded-lg px-2 py-1 flex items-center gap-1 ${isDark ? "bg-orange-500/20 border border-orange-500/30" : "bg-orange-100 border border-orange-300"}`}>
                <Zap className={`w-3 h-3 ${isDark ? "text-orange-400" : "text-orange-600"}`} />
                <span className={`text-xs font-black ${isDark ? "text-orange-400" : "text-orange-600"}`}>عاجل</span>
              </div>
            )}
            {data.tags.map((tag: string, i: number) => (
              <span key={i} className={`rounded-lg px-2.5 py-1 text-xs font-bold ${isDark ? "bg-white/5 border border-white/10 text-white/50" : "bg-gray-100 border border-gray-200 text-gray-500"}`}>{tag}</span>
            ))}
          </div>

          {/* Title */}
          <h1 className={`text-xl font-black mb-4 text-right ${isDark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "Cairo" }}>
            {data.title}
          </h1>

          {/* Specs Grid */}
          <div className={`rounded-2xl p-4 mb-4 space-y-3 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Maximize className={`w-4 h-4 ${isDark ? "text-cyan-400" : "text-blue-600"}`} />
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{data.area}</span>
                </div>
                <span className={`text-xs font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>المساحة</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Compass className={`w-4 h-4 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{data.direction}</span>
                </div>
                <span className={`text-xs font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>الواجهة</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className={`w-4 h-4 ${isDark ? "text-orange-400" : "text-orange-600"}`} />
                  <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{data.street}</span>
                </div>
                <span className={`text-xs font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>الشارع</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <DollarSign className={`w-4 h-4 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                  <span className={`text-sm font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{data.purchaseType}</span>
                </div>
                <span className={`text-xs font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>نوع الطلب</span>
              </div>
            </div>
            {/* Budget */}
            <div className={`pt-3 border-t ${isDark ? "border-white/10" : "border-gray-200"}`}>
              <div className="flex items-center justify-between">
                <span className={`text-lg font-black ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{data.budget}</span>
                <span className={`text-xs font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>الميزانية</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="mb-4">
            <h3 className={`text-sm font-black mb-3 text-right ${isDark ? "text-white" : "text-gray-900"}`}>تفاصيل الطلب</h3>
            <p className={`text-sm leading-relaxed text-right ${isDark ? "text-white/70" : "text-gray-700"}`}>{data.description}</p>
          </div>

          {/* Location */}
          <div className={`rounded-2xl p-4 flex items-center gap-3 ${isDark ? "bg-cyan-500/10 border border-cyan-500/30" : "bg-cyan-50 border border-cyan-200"}`}>
            <MapPin className={`w-5 h-5 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
            <div className="flex-1 text-right">
              <p className={`text-xs font-bold mb-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>الموقع المطلوب</p>
              <p className={`text-sm font-black ${isDark ? "text-cyan-400" : "text-cyan-700"}`}>{data.location}</p>
            </div>
          </div>
        </motion.div>

        {/* Stats Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className={`rounded-3xl p-5 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className={`text-2xl font-black mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{data.views}</p>
              <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>مشاهدة</p>
            </div>
            <div className={`border-x ${isDark ? "border-white/10" : "border-gray-200"}`}>
              <p className={`text-2xl font-black mb-1 ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{data.offers}</p>
              <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>عرض</p>
            </div>
            <div>
              <p className={`text-sm font-bold mb-1 ${isDark ? "text-white/70" : "text-gray-700"}`}>{data.postedDate}</p>
              <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>تاريخ النشر</p>
            </div>
          </div>
        </motion.div>

        {/* Posted By — with Contact Buttons */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className={`rounded-3xl p-5 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <span className="text-white text-xl font-black">{data.postedBy.charAt(0)}</span>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1.5 justify-end">
                  <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{data.postedBy}</p>
                  {data.falNumber && <Shield className="w-3.5 h-3.5 text-amber-500" />}
                </div>
                <p className={`text-xs font-medium ${isDark ? "text-white/50" : "text-gray-500"}`}>{data.postedByType}</p>
                {data.falNumber && (
                  <p className={`text-[9px] font-black ${isDark ? "text-amber-400" : "text-amber-600"}`}>فال: {data.falNumber}</p>
                )}
                {data.rating && (
                  <div className="flex items-center gap-1 mt-0.5 justify-end">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} style={{ width: "9px", height: "9px" }} className={i <= Math.round(data.rating) ? "text-amber-400 fill-amber-400" : "text-gray-300"} />
                    ))}
                    <span className={`text-[9px] ${isDark ? "text-white/40" : "text-gray-400"}`}>({data.ratingCount})</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Contact Buttons */}
          <p className={`text-[10px] font-black mb-2 text-right ${isDark ? "text-white/30" : "text-gray-400"}`}>تواصل مع صاحب الطلب</p>
          <div className="flex gap-2">
            <button className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black transition-colors ${isDark ? "bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25" : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"}`}>
              <Phone className="w-4 h-4" /> اتصال
            </button>
            <button className="flex-1 py-3 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black bg-[#25D366] text-white hover:bg-[#1ebd5a] transition-colors">
              <MessageSquare className="w-4 h-4" /> واتساب
            </button>
            <button className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black transition-colors ${isDark ? "bg-blue-500/15 text-blue-400 hover:bg-blue-500/25" : "bg-blue-50 text-blue-700 hover:bg-blue-100"}`}>
              <MessageCircle className="w-4 h-4" /> محادثة
            </button>
          </div>
        </motion.div>
      </div>

      {/* Sticky Footer */}
      <div className={`fixed bottom-0 left-0 right-0 p-5 border-t ${isDark ? "bg-[#0A0E1A]/95 backdrop-blur-xl border-white/10" : "bg-white/95 backdrop-blur-xl border-gray-200"}`}>
        <div className="flex gap-3">
          <motion.button whileTap={{ scale: 0.98 }}
            className={`flex-1 rounded-2xl py-4 font-black flex items-center justify-center gap-2 ${isDark ? "bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-lg" : "bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-lg"}`}>
            <Edit className="w-5 h-5" />
            <span>تقديم عرض</span>
          </motion.button>
          <motion.button whileTap={{ scale: 0.98 }}
            className={`rounded-2xl px-6 py-4 font-black border-2 transition-colors ${isDark ? "bg-white/5 text-white border-white/20 hover:bg-white/10" : "bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100"}`}>
            <MessageCircle className="w-5 h-5" />
          </motion.button>
        </div>
      </div>
    </div>
  );
}

// ── MARKETING REQUEST DETAIL ───────────────────────────────────────
function MarketingRequestDetail({ data, isDark, onBack }: any) {
  const [applied, setApplied] = useState(false);

  const commissionAmount = Math.round((parseFloat(data.propertyValue.replace(/,/g, "")) * data.commission) / 100);

  return (
    <div className={`h-full flex flex-col ${isDark ? "noise-bg" : "bg-gradient-to-br from-gray-50 to-gray-100"} overflow-y-auto`}>
      {/* Header */}
      <div className="px-5 pt-12 pb-4 relative z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className={`w-11 h-11 rounded-2xl flex items-center justify-center ${isDark ? "glass-premium" : "bg-white shadow-lg"}`}>
            <ArrowRight className={`w-5 h-5 ${isDark ? "text-white" : "text-gray-900"}`} />
          </button>
          <div>
            <h2 className={`text-lg font-black ${isDark ? "text-white" : "text-gray-900"}`}>طلب تسويق عقاري</h2>
            <p className={`text-[10px] font-black ${isDark ? "text-white/30" : "text-gray-400"}`}>#{data.id}</p>
          </div>
        </div>
      </div>

      <div className="flex-1 px-5 pb-32 relative z-10 space-y-4">

        {/* Commission Hero Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className={`rounded-3xl overflow-hidden border-2 ${isDark ? "border-emerald-500/30 bg-gradient-to-br from-emerald-900/30 to-teal-900/20" : "border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50"}`}>
          {/* Top Banner */}
          <div className="h-2 bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-400" />
          <div className="p-5">
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  {data.urgent && (
                    <div className={`rounded-lg px-2 py-1 flex items-center gap-1 ${isDark ? "bg-orange-500/20 border border-orange-500/30" : "bg-orange-100 border border-orange-300"}`}>
                      <Zap className={`w-3 h-3 ${isDark ? "text-orange-400" : "text-orange-600"}`} />
                      <span className={`text-xs font-black ${isDark ? "text-orange-400" : "text-orange-600"}`}>عاجل</span>
                    </div>
                  )}
                  <span className={`text-xs font-black px-3 py-1 rounded-lg border ${data.contract === "حصري" ? isDark ? "bg-purple-500/20 border-purple-500/30 text-purple-400" : "bg-purple-100 border-purple-300 text-purple-700" : isDark ? "bg-blue-500/20 border-blue-500/30 text-blue-400" : "bg-blue-100 border-blue-300 text-blue-700"}`}>
                    {data.contract}
                  </span>
                </div>
                <h1 className={`text-xl font-black mb-1 text-right ${isDark ? "text-white" : "text-gray-900"}`}>{data.title}</h1>
                <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>{data.postedDate} · {data.views} مشاهدة</p>
              </div>
              {/* Commission Badge */}
              <div className={`flex flex-col items-center p-3 rounded-2xl border ${isDark ? "bg-emerald-500/20 border-emerald-500/30" : "bg-emerald-100 border-emerald-300"}`}>
                <p className={`text-[9px] font-black mb-0.5 ${isDark ? "text-emerald-400/70" : "text-emerald-600/70"}`}>العمولة</p>
                <p className={`text-3xl font-black ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>{data.commission}%</p>
                <p className={`text-[9px] ${isDark ? "text-emerald-400/50" : "text-emerald-600/60"}`}>من قيمة البيع</p>
              </div>
            </div>

            {/* Commission Amount Calculation */}
            <div className={`p-4 rounded-2xl border ${isDark ? "bg-black/30 border-white/10" : "bg-white border-gray-200"}`}>
              <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>حساب العمولة التقريبية</p>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className={`text-[9px] mb-1 ${isDark ? "text-white/30" : "text-gray-400"}`}>قيمة العقار</p>
                  <p className={`text-sm font-black ${isDark ? "text-white/70" : "text-gray-700"}`}>{data.propertyValue} ر.س</p>
                </div>
                <div className="flex items-center justify-center">
                  <div className={`flex flex-col items-center gap-0.5`}>
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isDark ? "bg-emerald-500/20" : "bg-emerald-100"}`}>
                      <Percent className="w-4 h-4 text-emerald-500" />
                    </div>
                    <span className={`text-[9px] font-black ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{data.commission}%</span>
                  </div>
                </div>
                <div>
                  <p className={`text-[9px] mb-1 ${isDark ? "text-white/30" : "text-gray-400"}`}>عمولتك</p>
                  <p className={`text-sm font-black ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>{commissionAmount.toLocaleString()} ر.س</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Property Details */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className={`rounded-3xl p-5 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>تفاصيل العقار المطلوب تسويقه</p>
          <div className="space-y-2">
            {[
              { label: "العقار", value: data.property, Icon: Building2, color: isDark ? "text-cyan-400" : "text-blue-600" },
              { label: "نوع العقار", value: data.propertyType, Icon: Hash, color: isDark ? "text-purple-400" : "text-purple-600" },
              { label: "الموقع", value: data.location, Icon: MapPin, color: isDark ? "text-orange-400" : "text-orange-600" },
              { label: "مدة العقد", value: data.contractDuration, Icon: Clock, color: isDark ? "text-amber-400" : "text-amber-600" },
              { label: "نوع العقد", value: data.contract, Icon: FileText, color: isDark ? "text-emerald-400" : "text-emerald-600" },
            ].map((item, i) => {
              const ItemIcon = item.Icon;
              return (
                <div key={i} className={`flex items-center justify-between p-3 rounded-xl border ${isDark ? "bg-white/3 border-white/5" : "bg-gray-50 border-gray-100"}`}>
                  <div className="flex items-center gap-2">
                    <ItemIcon className={`w-3.5 h-3.5 ${item.color}`} />
                    <span className={`text-xs font-black ${isDark ? "text-white/80" : "text-gray-800"}`}>{item.value}</span>
                  </div>
                  <span className={`text-[10px] font-bold ${isDark ? "text-white/30" : "text-gray-400"}`}>{item.label}</span>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Description */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className={`rounded-3xl p-5 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>تفاصيل الفرصة التسويقية</p>
          <p className={`text-sm leading-7 ${isDark ? "text-white/70" : "text-gray-600"}`}>{data.description}</p>
        </motion.div>

        {/* Requirements + Benefits */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className={`rounded-3xl p-5 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-center gap-1.5 mb-3">
                <AlertCircle className={`w-3.5 h-3.5 ${isDark ? "text-rose-400" : "text-rose-500"}`} />
                <p className={`text-[10px] font-black ${isDark ? "text-white/30" : "text-gray-400"}`}>المتطلبات</p>
              </div>
              <div className="space-y-1.5">
                {data.requirements.map((req: string, i: number) => (
                  <div key={i} className={`flex items-start gap-1.5 p-2 rounded-lg ${isDark ? "bg-rose-500/10 border border-rose-500/20" : "bg-rose-50 border border-rose-100"}`}>
                    <div className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                    <p className={`text-[10px] font-bold ${isDark ? "text-rose-300" : "text-rose-700"}`}>{req}</p>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-3">
                <CheckCircle className={`w-3.5 h-3.5 ${isDark ? "text-emerald-400" : "text-emerald-500"}`} />
                <p className={`text-[10px] font-black ${isDark ? "text-white/30" : "text-gray-400"}`}>المزايا</p>
              </div>
              <div className="space-y-1.5">
                {data.benefits.map((ben: string, i: number) => (
                  <div key={i} className={`flex items-start gap-1.5 p-2 rounded-lg ${isDark ? "bg-emerald-500/10 border border-emerald-500/20" : "bg-emerald-50 border border-emerald-100"}`}>
                    <CheckCircle className="w-3 h-3 text-emerald-500 mt-0.5 shrink-0" />
                    <p className={`text-[10px] font-bold ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>{ben}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
          className={`rounded-3xl p-5 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className={`text-2xl font-black mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{data.views}</p>
              <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>مشاهدة</p>
            </div>
            <div className={`border-x ${isDark ? "border-white/10" : "border-gray-200"}`}>
              <p className={`text-2xl font-black mb-1 ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{data.applications}</p>
              <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>تقديم</p>
            </div>
            <div>
              <p className={`text-sm font-bold mb-1 ${isDark ? "text-white/70" : "text-gray-700"}`}>{data.postedDate}</p>
              <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>النشر</p>
            </div>
          </div>
        </motion.div>

        {/* Posted By */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className={`rounded-3xl p-5 ${isDark ? "glass-strong" : "bg-white shadow-xl"}`}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
              <span className="text-white text-xl font-black">{data.postedBy.charAt(0)}</span>
            </div>
            <div className="flex-1 text-right">
              <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{data.postedBy}</p>
              <p className={`text-xs font-medium ${isDark ? "text-white/50" : "text-gray-500"}`}>{data.postedByType}</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Sticky Footer */}
      <div className={`fixed bottom-0 left-0 right-0 p-5 border-t ${isDark ? "bg-[#0A0E1A]/95 backdrop-blur-xl border-white/10" : "bg-white/95 backdrop-blur-xl border-gray-200"}`}>
        <div className="flex gap-3">
          {!applied ? (
            <motion.button whileTap={{ scale: 0.98 }}
              onClick={() => setApplied(true)}
              className={`flex-1 rounded-2xl py-4 font-black flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/20`}>
              <Briefcase className="w-5 h-5" />
              <span>قبول وتقديم طلب التسويق</span>
            </motion.button>
          ) : (
            <div className="flex-1 rounded-2xl py-4 flex items-center justify-center gap-2 bg-emerald-100 border-2 border-emerald-400">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              <span className="text-sm font-black text-emerald-700">تم تقديم طلبك بنجاح</span>
            </div>
          )}
          <motion.button whileTap={{ scale: 0.98 }}
            className={`rounded-2xl px-6 py-4 font-black border-2 transition-colors ${isDark ? "bg-white/5 text-white border-white/20 hover:bg-white/10" : "bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100"}`}>
            <MessageCircle className="w-5 h-5" />
          </motion.button>
        </div>
      </div>
    </div>
  );
}

// ── MAIN COMPONENT ────────────────────────────────────────────────
export function RequestDetailScreen({ requestId, onBack }: RequestDetailScreenProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  // Determine if this is a marketing or search request
  const isMarketing = ["4", "5", "6"].includes(requestId);

  if (isMarketing) {
    const data = marketingRequestsData[requestId];
    if (!data) return null;
    return <MarketingRequestDetail data={data} isDark={isDark} onBack={onBack} />;
  }

  const data = searchRequestsData[requestId] || searchRequestsData["1"];
  return <SearchRequestDetail data={data} isDark={isDark} onBack={onBack} />;
}
