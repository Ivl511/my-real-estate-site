import { motion, AnimatePresence } from "motion/react";
import {
  X, Home, Search, Repeat, Key, Megaphone, Building2, Briefcase,
  ChevronRight, ChevronLeft, CheckCircle, XCircle, Bell, Phone,
  User, DollarSign, MapPin, Ruler, Compass, FileText, Sparkles,
  Building, Maximize2, ArrowRightLeft, AlertCircle, Loader2,
  BellRing, BellOff, ToggleLeft, ToggleRight, Star, Zap,
  RefreshCw, Check, ArrowUp, ArrowDown, ArrowLeft,
  ArrowUpRight, ArrowUpLeft, CalendarDays, CalendarCheck,
  Sofa, Armchair, Scale, Coins, Users, ClipboardList,
  FileCheck, Flame, Clock, Tag
} from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { useTheme } from "../../context/ThemeContext";

interface AddMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

type Step = "main" | "property" | "request" | "sale_form" | "rent_form" | "exchange_form" | "marketing_form" | "search_form";
type UserRole = "broker" | "owner" | "developer";

// Fake AI-enhanced descriptions
const AI_DESCRIPTIONS: Record<string, string> = {
  sale: `يُطرح للبيع هذا العقار المميز الذي يجمع بين الرقي والموقع الاستراتيجي. يتميز العقار بتشطيبات عالية الجودة وتصميم معماري عصري يلبي أرقى الأذواق. يقع في موقع متميز يتيح سهولة الوصول إلى المرافق الحيوية والطرق الرئيسية. فرصة استثمارية لا تُعوَّض في منطقة ذات عائد إيجاري مرتفع وتنامٍ عقاري مستمر.`,
  rent: `عقار مميز للإيجار في موقع حيوي ومطلوب. يمتاز بالتصميم العصري والتشطيبات الفاخرة التي توفر أعلى مستوى من الراحة والأناقة. يشمل جميع المرافق الأساسية ويتميز بقربه من المدارس والمراكز التجارية والخدمات الحكومية. مثالي للعائلات والأفراد الباحثين عن الراحة والاستقرار.`,
  exchange: `عقار مميز مطروح للمقايضة العقارية. يتميز هذا العقار بموقعه الاستراتيجي وتشطيباته الفاخرة ومساحته الواسعة التي تلبي احتياجات كل الأسرة. تمتلك صكاً إلكترونياً واضحاً ومسجلاً لدى الجهات الرسمية. فرصة ذهبية لمن يرغب في التبادل العقاري بأعلى معايير الشفافية والأمان.`,
};

const REGIONS = ["الرياض", "جدة", "مكة المكرمة", "الدمام", "الخبر", "المدينة المنورة", "أبها", "تبوك", "القصيم", "حائل"];
const NEIGHBORHOODS: Record<string, string[]> = {
  "الرياض": ["النرجس", "الملقا", "حطين", "العليا", "الروابي", "الياسمين"],
  "جدة": ["الشاطئ", "أبحر الشمالية", "الزهراء", "الروضة", "السلامة"],
  "الدمام": ["الشاطئ", "العزيزية", "المزروعية"],
  "default": ["حي الأول", "حي الثاني", "حي المركز"],
};
const PROP_TYPES = ["فيلا", "شقة", "دور", "أرض", "عمارة", "استراحة", "مزرعة", "مكتب", "محل تجاري"];
const FACADES = [
  { id: "north", label: "شمالية", Icon: ArrowUp },
  { id: "south", label: "جنوبية", Icon: ArrowDown },
  { id: "east", label: "شرقية", Icon: ArrowUpRight },
  { id: "west", label: "غربية", Icon: ArrowLeft },
  { id: "north-east", label: "ش.شرقية", Icon: ArrowUpRight },
  { id: "north-west", label: "ش.غربية", Icon: ArrowUpLeft },
];

// ==========================================
// MAIN COMPONENT
// ==========================================
export function AddMenu({ isOpen, onClose }: AddMenuProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [step, setStep] = useState<Step>("main");
  const [userRole, setUserRole] = useState<UserRole>("broker"); // Simulated: broker by default

  const handleClose = () => {
    onClose();
    setTimeout(() => setStep("main"), 300);
  };

  const isFormMode = ["sale_form", "rent_form", "exchange_form", "marketing_form", "search_form"].includes(step);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[10000] flex items-end justify-center sm:items-center">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={!isFormMode ? handleClose : undefined}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
      />

      {/* Sheet / Full Screen */}
      <motion.div
        key={isFormMode ? "fullscreen" : "sheet"}
        initial={isFormMode ? { opacity: 0, y: 40 } : { y: "100%" }}
        animate={isFormMode ? { opacity: 1, y: 0 } : { y: 0 }}
        exit={isFormMode ? { opacity: 0, y: 40 } : { y: "100%" }}
        transition={{ type: "spring", damping: 26, stiffness: 300 }}
        className={`relative w-full overflow-hidden ${
          isFormMode
            ? "max-w-lg mx-auto h-[94vh] mt-auto rounded-t-[32px] sm:rounded-[32px] sm:my-auto sm:h-[90vh]"
            : "max-w-md mx-auto rounded-t-[32px] sm:rounded-[32px] pb-10"
        } ${isDark
          ? "bg-[#111827] border-t border-white/8"
          : "bg-white shadow-2xl"
        }`}
      >
        {/* Close Button */}
        <button
          onClick={handleClose}
          className={`absolute top-4 left-4 z-20 p-2 rounded-full transition-colors ${
            isDark ? "bg-white/8 hover:bg-white/15 text-white/70" : "bg-gray-100 hover:bg-gray-200 text-gray-500"
          }`}
        >
          <X className="w-5 h-5" />
        </button>

        {/* Handle bar (non-form mode) */}
        {!isFormMode && (
          <div className="flex justify-center pt-3 pb-1">
            <div className={`w-10 h-1 rounded-full ${isDark ? "bg-white/20" : "bg-gray-200"}`} />
          </div>
        )}

        <AnimatePresence mode="wait">
          {/* ── MAIN MENU ── */}
          {step === "main" && (
            <motion.div key="main" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="p-6 pt-8">
              <h2 className={`text-2xl font-black text-center mb-8 ${isDark ? "text-white" : "text-gray-900"}`}>
                ماذا تريد أن تضيف؟
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <MenuCard icon={Building2} title="إضافة عقار" subtitle="بيع، إيجار، أو بدل" color="cyan" onClick={() => setStep("property")} isDark={isDark} />
                <MenuCard icon={Briefcase} title="إضافة طلب" subtitle="تسويق أو بحث" color="purple" onClick={() => setStep("request")} isDark={isDark} />
              </div>
            </motion.div>
          )}

          {/* ── PROPERTY TYPE ── */}
          {step === "property" && (
            <motion.div key="property" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-6 pt-8">
              <div className="flex items-center justify-between mb-8">
                <h2 className={`text-2xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>نوع الإعلان</h2>
                <button onClick={() => setStep("main")} className={`text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-900"}`}>رجوع</button>
              </div>
              <div className="space-y-3">
                {[
                  { id: "sale_form" as Step, icon: Home, label: "للبيع", sub: "نشر عقارك للبيع", color: "emerald", gradient: "from-emerald-500 to-teal-600" },
                  { id: "rent_form" as Step, icon: Key, label: "للإيجار", sub: "نشر عقارك للإيجار", color: "blue", gradient: "from-blue-500 to-cyan-600" },
                  { id: "exchange_form" as Step, icon: Repeat, label: "للبدل", sub: "طرح عقارك للمقايضة", color: "purple", gradient: "from-purple-600 to-pink-600" },
                ].map((item, i) => (
                  <motion.button
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.07 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setStep(item.id)}
                    className={`w-full p-4 rounded-2xl flex items-center gap-4 border transition-all ${
                      isDark ? "bg-[#1a2035] border-white/5 hover:bg-[#1e2640]" : "bg-white border-gray-100 shadow-sm hover:shadow-md"
                    }`}
                  >
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-lg`}>
                      <item.icon className="w-7 h-7 text-white" />
                    </div>
                    <div className="text-right flex-1">
                      <p className={`font-black text-lg ${isDark ? "text-white" : "text-gray-900"}`}>{item.label}</p>
                      <p className={`text-xs mt-0.5 ${isDark ? "text-white/40" : "text-gray-500"}`}>{item.sub}</p>
                    </div>
                    <ChevronLeft className={`w-5 h-5 ${isDark ? "text-white/20" : "text-gray-300"}`} />
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* ── REQUEST TYPE ── */}
          {step === "request" && (
            <motion.div key="request" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-6 pt-8">
              <div className="flex items-center justify-between mb-8">
                <h2 className={`text-2xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>نوع الطلب</h2>
                <button onClick={() => setStep("main")} className={`text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-900"}`}>رجوع</button>
              </div>
              <div className="space-y-3">
                {[
                  { step: "marketing_form" as Step, icon: Megaphone, label: "طلب تسويق", sub: "اطلب من وسيط تسويق عقارك باحترافية", gradient: "from-pink-500 to-rose-600" },
                  { step: "search_form" as Step, icon: Search, label: "طلب بحث", sub: "اعرض مواصفات ما تبحث عنه بالتفصيل", gradient: "from-indigo-500 to-violet-600" },
                ].map((item, i) => (
                  <motion.button
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.07 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setStep(item.step)}
                    className={`w-full p-4 rounded-2xl flex items-center gap-4 border transition-all ${
                      isDark ? "bg-[#1a2035] border-white/5 hover:bg-[#1e2640]" : "bg-white border-gray-100 shadow-sm hover:shadow-md"
                    }`}
                  >
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-lg`}>
                      <item.icon className="w-7 h-7 text-white" />
                    </div>
                    <div className="text-right flex-1">
                      <p className={`font-black text-lg ${isDark ? "text-white" : "text-gray-900"}`}>{item.label}</p>
                      <p className={`text-xs mt-0.5 ${isDark ? "text-white/40" : "text-gray-500"}`}>{item.sub}</p>
                    </div>
                    <ChevronLeft className={`w-5 h-5 ${isDark ? "text-white/20" : "text-gray-300"}`} />
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* ── SALE FORM ── */}
          {step === "sale_form" && (
            <SaleForm
              key="sale_form"
              isDark={isDark}
              userRole={userRole}
              onBack={() => setStep("property")}
              onClose={handleClose}
              mode="sale"
            />
          )}

          {/* ── RENT FORM ── */}
          {step === "rent_form" && (
            <RentForm
              key="rent_form"
              isDark={isDark}
              userRole={userRole}
              onBack={() => setStep("property")}
              onClose={handleClose}
            />
          )}

          {/* ── EXCHANGE FORM ── */}
          {step === "exchange_form" && (
            <SaleForm
              key="exchange_form"
              isDark={isDark}
              userRole={userRole}
              onBack={() => setStep("property")}
              onClose={handleClose}
              mode="exchange"
            />
          )}

          {/* ── MARKETING REQUEST FORM ── */}
          {step === "marketing_form" && (
            <MarketingRequestForm
              key="marketing_form"
              isDark={isDark}
              onBack={() => setStep("request")}
              onClose={handleClose}
            />
          )}

          {/* ── SEARCH REQUEST FORM ── */}
          {step === "search_form" && (
            <SearchRequestForm
              key="search_form"
              isDark={isDark}
              onBack={() => setStep("request")}
              onClose={handleClose}
            />
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

// ==========================================
// SALE / EXCHANGE FORM
// ==========================================
function SaleForm({ isDark, userRole, onBack, onClose, mode }: any) {
  const isBroker = userRole === "broker";
  const isExchange = mode === "exchange";
  const totalSteps = isBroker ? (isExchange ? 4 : 3) : (isExchange ? 3 : 2);

  const [currentStep, setCurrentStep] = useState(1);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiDone, setAiDone] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Step 1 — Owner Info (Broker)
  const [ownerName, setOwnerName] = useState("");
  const [ownerPhone, setOwnerPhone] = useState("");
  const [notifySale, setNotifySale] = useState(true);
  const [notifyOffer, setNotifyOffer] = useState(true);
  const [notifyMsg, setNotifyMsg] = useState(false);

  // Step 2 — Property Details
  const [adTitle, setAdTitle] = useState("");
  const [propType, setPropType] = useState("فيلا");
  const [price, setPrice] = useState("");
  const [negotiable, setNegotiable] = useState<boolean | null>(null);
  const [hasDeed, setHasDeed] = useState<boolean | null>(null);
  const [bankAccepted, setBankAccepted] = useState<boolean | null>(null);
  const [landArea, setLandArea] = useState("");
  const [builtArea, setBuiltArea] = useState("");
  const [facade, setFacade] = useState("");
  const [region, setRegion] = useState("الرياض");
  const [neighborhood, setNeighborhood] = useState("");

  // Step 3 — Exchange Want
  const [wantType, setWantType] = useState("فيلا");
  const [wantRegion, setWantRegion] = useState("الرياض");
  const [wantNeighborhood, setWantNeighborhood] = useState("");
  const [wantMinArea, setWantMinArea] = useState("");
  const [wantPriceFrom, setWantPriceFrom] = useState("");
  const [wantPriceTo, setWantPriceTo] = useState("");
  const [deltaType, setDeltaType] = useState<"receive" | "pay" | "equal">("equal");
  const [deltaAmount, setDeltaAmount] = useState("");
  const [wantSpecs, setWantSpecs] = useState("");

  // Last Step — Description
  const [description, setDescription] = useState("");

  const descStep = isBroker ? (isExchange ? 4 : 3) : (isExchange ? 3 : 2);

  const scrollTop = () => { setTimeout(() => scrollRef.current?.scrollTo({ top: 0, behavior: 'smooth' }), 50); };

  const nextStep = () => { setCurrentStep(s => s + 1); scrollTop(); };
  const prevStep = () => { if (currentStep === 1) { onBack(); } else { setCurrentStep(s => s - 1); scrollTop(); } };

  const handleAIEnhance = () => {
    setAiLoading(true);
    setAiDone(false);
    setTimeout(() => {
      setDescription(isExchange ? AI_DESCRIPTIONS.exchange : AI_DESCRIPTIONS.sale);
      setAiLoading(false);
      setAiDone(true);
    }, 2200);
  };

  const handleSubmit = () => {
    setSubmitted(true);
  };

  if (submitted) {
    return <SuccessScreen isDark={isDark} onClose={onClose} label={isExchange ? "طلب البدل" : "عقار البيع"} />;
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col h-full">
      {/* Header */}
      <div className={`shrink-0 px-5 pt-5 pb-3 border-b ${isDark ? "border-white/5" : "border-gray-100"}`}>
        <div className="flex items-center justify-between mb-3">
          <button onClick={prevStep} className={`flex items-center gap-1.5 text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
            <ChevronRight className="w-4 h-4" /> رجوع
          </button>
          <div className="text-center">
            <h2 className={`font-black text-base flex items-center gap-1.5 ${isDark ? "text-white" : "text-gray-900"}`}>
              {isExchange ? <><ArrowRightLeft className="w-4 h-4 text-purple-400" /> إعلان بدل</> : <><Tag className="w-4 h-4 text-emerald-400" /> إعلان بيع</>}
            </h2>
            <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>خطوة {currentStep} من {totalSteps}</p>
          </div>
          <div className="w-16" />
        </div>
        {/* Progress */}
        <div className={`h-1.5 rounded-full ${isDark ? "bg-white/8" : "bg-gray-100"}`}>
          <motion.div
            className={`h-full rounded-full bg-gradient-to-r ${isExchange ? "from-purple-500 to-pink-500" : "from-emerald-500 to-teal-500"}`}
            animate={{ width: `${(currentStep / totalSteps) * 100}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>

      {/* Content */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4" style={{ scrollbarWidth: 'none' }}>
        <AnimatePresence mode="wait">

          {/* STEP 1: Owner Info (Broker Only) */}
          {currentStep === 1 && isBroker && (
            <FormStep key="owner">
              <StepTitle icon={User} title="معلومات المالك" sub="أدخل بيانات مالك العقار" isDark={isDark} color="blue" />
              <FormField label="اسم المالك" isDark={isDark}>
                <TextInput value={ownerName} onChange={setOwnerName} placeholder="مثال: عبدالله العتيبي" isDark={isDark} icon={User} />
              </FormField>
              <FormField label="رقم الجوال" isDark={isDark}>
                <TextInput value={ownerPhone} onChange={setOwnerPhone} placeholder="05xxxxxxxx" isDark={isDark} icon={Phone} type="tel" />
              </FormField>
              <FormField label="إشعارات المالك" isDark={isDark}>
                <div className={`p-4 rounded-2xl border space-y-3 ${isDark ? "bg-[#1a2035] border-white/5" : "bg-gray-50 border-gray-100"}`}>
                  <NotifToggle label="إشعار عند البيع" value={notifySale} onChange={setNotifySale} isDark={isDark} />
                  <NotifToggle label="إشعار عند ورود عرض" value={notifyOffer} onChange={setNotifyOffer} isDark={isDark} />
                  <NotifToggle label="إشعار عند رسائل جديدة" value={notifyMsg} onChange={setNotifyMsg} isDark={isDark} />
                </div>
              </FormField>
            </FormStep>
          )}

          {/* STEP: Property Details (step 2 if broker, step 1 if not) */}
          {currentStep === (isBroker ? 2 : 1) && (
            <FormStep key="details">
              <StepTitle icon={Building} title="تفاصيل العقار" sub="أدخل معلومات العقار بدقة" isDark={isDark} color="emerald" />

              <FormField label="عنوان الإعلان" isDark={isDark}>
                <TextInput value={adTitle} onChange={setAdTitle} placeholder="مثال: عمارة دورين في حي النرجس" isDark={isDark} icon={FileText} />
              </FormField>

              <FormField label="نوع العقار" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {PROP_TYPES.map(t => (
                    <button key={t} onClick={() => setPropType(t)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${propType === t
                        ? isDark ? "bg-emerald-500 text-white border-emerald-500" : "bg-emerald-600 text-white border-emerald-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5 hover:bg-white/10" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
                      }`}>{t}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="السعر المطلوب (ريال)" isDark={isDark}>
                <TextInput value={price} onChange={setPrice} placeholder="مثال: 1,200,000" isDark={isDark} icon={DollarSign} type="tel" />
              </FormField>

              <FormField label="قابل للتفاوض؟" isDark={isDark}>
                <YesNoToggle value={negotiable} onChange={setNegotiable} isDark={isDark}
                  yesLabel="قابل للتفاوض" noLabel="السعر نهائي"
                  yesColor="emerald" noColor="red" />
              </FormField>

              <FormField label="يمتلك صك؟" isDark={isDark}>
                <YesNoToggle value={hasDeed} onChange={setHasDeed} isDark={isDark}
                  yesLabel="نعم، يوجد صك" noLabel="لا يوجد صك"
                  yesColor="blue" noColor="gray" />
              </FormField>

              {hasDeed === true && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>
                  <FormField label="يقبل التمويل البنكي؟" isDark={isDark}>
                    <YesNoToggle value={bankAccepted} onChange={setBankAccepted} isDark={isDark}
                      yesLabel="يقبل البنك" noLabel="كاش فقط"
                      yesColor="green" noColor="amber" />
                  </FormField>
                </motion.div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <FormField label="مساحة الأرض (م²)" isDark={isDark}>
                  <TextInput value={landArea} onChange={setLandArea} placeholder="مثال: 600" isDark={isDark} icon={Maximize2} type="tel" />
                </FormField>
                <FormField label="مساحة البناء (م²)" isDark={isDark}>
                  <TextInput value={builtArea} onChange={setBuiltArea} placeholder="مثال: 450" isDark={isDark} icon={Ruler} type="tel" />
                </FormField>
              </div>

              <FormField label="الواجهة" isDark={isDark}>
                <div className="grid grid-cols-3 gap-2">
                  {FACADES.map(f => {
                    const FIcon = f.Icon;
                    return (
                      <button key={f.id} onClick={() => setFacade(f.id)}
                        className={`py-2 px-2 rounded-xl text-[11px] font-black border transition-all flex flex-col items-center gap-0.5 ${facade === f.id
                          ? isDark ? "bg-cyan-500 text-white border-cyan-500" : "bg-cyan-600 text-white border-cyan-600"
                          : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                        }`}>
                        <FIcon className="w-3.5 h-3.5" />
                        <span>{f.label}</span>
                      </button>
                    );
                  })}
                </div>
              </FormField>

              <FormField label="المنطقة" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {REGIONS.slice(0, 6).map(r => (
                    <button key={r} onClick={() => { setRegion(r); setNeighborhood(""); }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${region === r
                        ? isDark ? "bg-white text-black border-white" : "bg-gray-900 text-white border-gray-900"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{r}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="الحي" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {(NEIGHBORHOODS[region] || NEIGHBORHOODS["default"]).map(n => (
                    <button key={n} onClick={() => setNeighborhood(n)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${neighborhood === n
                        ? isDark ? "bg-amber-500 text-white border-amber-500" : "bg-amber-600 text-white border-amber-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{n}</button>
                  ))}
                </div>
              </FormField>
            </FormStep>
          )}

          {/* STEP: Exchange Want Details */}
          {isExchange && currentStep === (isBroker ? 3 : 2) && (
            <FormStep key="exchange_want">
              <StepTitle icon={ArrowRightLeft} title="ماذا تريد بالمقايضة؟" sub="حدد العقار المطلوب بدقة" isDark={isDark} color="purple" />

              <FormField label="نوع العقار المطلوب" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {PROP_TYPES.map(t => (
                    <button key={t} onClick={() => setWantType(t)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${wantType === t
                        ? isDark ? "bg-purple-500 text-white border-purple-500" : "bg-purple-600 text-white border-purple-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{t}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="المنطقة المفضلة" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {REGIONS.slice(0, 6).map(r => (
                    <button key={r} onClick={() => { setWantRegion(r); setWantNeighborhood(""); }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${wantRegion === r
                        ? isDark ? "bg-white text-black border-white" : "bg-gray-900 text-white border-gray-900"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{r}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="الحي المفضل" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {(NEIGHBORHOODS[wantRegion] || NEIGHBORHOODS["default"]).map(n => (
                    <button key={n} onClick={() => setWantNeighborhood(n)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${wantNeighborhood === n
                        ? isDark ? "bg-pink-500 text-white border-pink-500" : "bg-pink-600 text-white border-pink-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{n}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="الحد الأدنى للمساحة (م²)" isDark={isDark}>
                <TextInput value={wantMinArea} onChange={setWantMinArea} placeholder="مثال: 500" isDark={isDark} icon={Maximize2} type="tel" />
              </FormField>

              <FormField label="نطاق السعر المستهدف (ريال)" isDark={isDark}>
                <div className="grid grid-cols-2 gap-3">
                  <TextInput value={wantPriceFrom} onChange={setWantPriceFrom} placeholder="من: 2,000,000" isDark={isDark} icon={DollarSign} type="tel" />
                  <TextInput value={wantPriceTo} onChange={setWantPriceTo} placeholder="إلى: 4,000,000" isDark={isDark} icon={DollarSign} type="tel" />
                </div>
              </FormField>

              <FormField label="فرق السعر (الدفع الإضافي)" isDark={isDark}>
                <div className="grid grid-cols-3 gap-2 mb-3">
                  {[
                    { id: "receive" as const, label: "أطلب فرق", color: "amber", Icon: Coins },
                    { id: "pay" as const, label: "أدفع فرق", color: "green", Icon: CheckCircle },
                    { id: "equal" as const, label: "رأس برأس", color: "purple", Icon: Scale },
                  ].map(dt => (
                    <button key={dt.id} onClick={() => setDeltaType(dt.id)}
                      className={`py-2.5 px-2 rounded-xl text-[10px] font-black border transition-all flex flex-col items-center gap-1 ${deltaType === dt.id
                        ? dt.color === "amber" ? "bg-amber-500 text-white border-amber-500"
                          : dt.color === "green" ? "bg-emerald-500 text-white border-emerald-500"
                          : "bg-purple-500 text-white border-purple-500"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}><dt.Icon className="w-3.5 h-3.5" />{dt.label}</button>
                  ))}
                </div>
                {deltaType !== "equal" && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}>
                    <TextInput value={deltaAmount} onChange={setDeltaAmount} placeholder="مقدار الفرق (ريال)" isDark={isDark} icon={DollarSign} type="tel" />
                  </motion.div>
                )}
              </FormField>

              <FormField label="مواصفات إضافية مطلوبة" isDark={isDark}>
                <textarea
                  value={wantSpecs}
                  onChange={e => setWantSpecs(e.target.value)}
                  placeholder="مثال: مسبح، مصعد، لا يزيد عمره عن 5 سنوات، على شارعين..."
                  rows={3}
                  className={`w-full rounded-2xl border px-4 py-3 text-sm resize-none outline-none transition-all ${
                    isDark ? "bg-[#1a2035] border-white/8 text-white placeholder-white/20 focus:border-purple-500/50" : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400 focus:border-purple-400"
                  }`}
                  style={{ direction: 'rtl' }}
                />
              </FormField>
            </FormStep>
          )}

          {/* LAST STEP: Description + AI */}
          {currentStep === totalSteps && (
            <FormStep key="description">
              <StepTitle icon={Sparkles} title="وصف العقار" sub="اكتب وصفاً شاملاً أو دع الذكاء الاصطناعي يصيغه" isDark={isDark} color="cyan" />

              {/* AI Enhance Button */}
              <div className={`p-4 rounded-2xl border mb-4 ${isDark ? "bg-gradient-to-br from-cyan-900/20 to-blue-900/20 border-cyan-500/20" : "bg-gradient-to-br from-cyan-50 to-blue-50 border-cyan-200"}`}>
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>تحسين بالذكاء الاصطناعي</p>
                    <p className={`text-[11px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>سيُصيغ الذكاء الاصطناعي وصفاً احترافياً بناءً على المعلومات التي أدخلتها.</p>
                  </div>
                </div>
                <button
                  onClick={handleAIEnhance}
                  disabled={aiLoading}
                  className={`w-full py-3 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${
                    aiLoading
                      ? isDark ? "bg-white/5 text-white/30" : "bg-gray-100 text-gray-400"
                      : aiDone
                      ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg shadow-emerald-500/25"
                      : "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25 hover:shadow-xl"
                  }`}
                >
                  {aiLoading ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> جاري التحسين...</>
                  ) : aiDone ? (
                    <><Check className="w-4 h-4" /> تم التحسين بالذكاء الاصطناعي ✨</>
                  ) : (
                    <><Zap className="w-4 h-4" /> تحسين الوصف تلقائياً</>
                  )}
                </button>
              </div>

              {/* Description Textarea */}
              <FormField label="الوصف الكامل للعقار" isDark={isDark}>
                <div className="relative">
                  <textarea
                    value={description}
                    onChange={e => { setDescription(e.target.value); setAiDone(false); }}
                    placeholder="اكتب وصفاً تفصيلياً للعقار... أو اضغط على 'تحسين تلقائي' أعلاه ليكتبه الذكاء الاصطناعي نيابةً عنك."
                    rows={7}
                    className={`w-full rounded-2xl border px-4 py-3 text-sm resize-none outline-none transition-all leading-7 ${
                      aiDone
                        ? isDark ? "border-cyan-500/40 bg-cyan-500/5 text-white placeholder-white/20" : "border-cyan-400 bg-cyan-50 text-gray-900"
                        : isDark ? "bg-[#1a2035] border-white/8 text-white placeholder-white/20 focus:border-cyan-500/50" : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400 focus:border-cyan-400"
                    }`}
                    style={{ direction: 'rtl' }}
                  />
                  {aiDone && (
                    <div className="absolute top-2 left-2">
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-lg flex items-center gap-1 ${isDark ? "bg-cyan-500/20 text-cyan-400" : "bg-cyan-100 text-cyan-700"}`}>
                        <Sparkles className="w-2.5 h-2.5" /> AI
                      </span>
                    </div>
                  )}
                </div>
              </FormField>

              {/* Summary Chips */}
              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#1a2035] border-white/5" : "bg-gray-50 border-gray-100"}`}>
                <p className={`text-xs font-black mb-3 ${isDark ? "text-white/60" : "text-gray-500"}`}>ملخص الإعلان</p>
                <div className="flex flex-wrap gap-2">
                  {[
                    propType && { label: propType, color: "blue" },
                    price && { label: `${price} ريال`, color: "emerald" },
                    negotiable !== null && { label: negotiable ? "قابل للتفاوض" : "سعر نهائي", color: negotiable ? "green" : "red" },
                    hasDeed && { label: "صك ✓", color: "cyan" },
                    bankAccepted && { label: "يقبل البنك", color: "purple" },
                    region && { label: region, color: "amber" },
                    neighborhood && { label: neighborhood, color: "orange" },
                    landArea && { label: `أرض ${landArea}م²`, color: "teal" },
                    builtArea && { label: `بناء ${builtArea}م²`, color: "indigo" },
                  ].filter(Boolean).map((chip: any, i) => (
                    <span key={i} className={`text-[10px] font-black px-2.5 py-1 rounded-xl border ${
                      isDark ? "bg-white/5 text-white/60 border-white/5" : "bg-white text-gray-700 border-gray-200"
                    }`}>{chip.label}</span>
                  ))}
                </div>
              </div>
            </FormStep>
          )}
        </AnimatePresence>
      </div>

      {/* Action Button */}
      <div className={`shrink-0 p-4 border-t ${isDark ? "border-white/5 bg-[#111827]" : "border-gray-100 bg-white"}`}>
        {currentStep < totalSteps ? (
          <button
            onClick={nextStep}
            className={`w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
              isExchange
                ? "bg-gradient-to-r from-purple-600 to-pink-600 shadow-purple-500/25"
                : "bg-gradient-to-r from-emerald-500 to-teal-600 shadow-emerald-500/25"
            }`}
          >
            التالي <ChevronLeft className="w-5 h-5" />
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            className="w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/25 hover:shadow-xl transition-all"
          >
            <CheckCircle className="w-5 h-5" /> نشر الإعلان الآن
          </button>
        )}
      </div>
    </motion.div>
  );
}

// ==========================================
// RENT FORM
// ==========================================
function RentForm({ isDark, userRole, onBack, onClose }: any) {
  const isBroker = userRole === "broker";
  const totalSteps = isBroker ? 3 : 2;
  const [currentStep, setCurrentStep] = useState(1);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiDone, setAiDone] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Owner info
  const [ownerName, setOwnerName] = useState("");
  const [ownerPhone, setOwnerPhone] = useState("");
  const [notifySale, setNotifySale] = useState(true);
  const [notifyOffer, setNotifyOffer] = useState(true);
  const [notifyMsg, setNotifyMsg] = useState(false);

  // Property details
  const [adTitle, setAdTitle] = useState("");
  const [propType, setPropType] = useState("شقة");
  const [rentPeriod, setRentPeriod] = useState<"monthly" | "yearly">("yearly");
  const [rentPrice, setRentPrice] = useState("");
  const [depositMonths, setDepositMonths] = useState("1");
  const [paymentTerms, setPaymentTerms] = useState("شيك واحد");
  const [hasDeed, setHasDeed] = useState<boolean | null>(null);
  const [landArea, setLandArea] = useState("");
  const [builtArea, setBuiltArea] = useState("");
  const [furnishing, setFurnishing] = useState<"furnished" | "semi" | "unfurnished">("unfurnished");
  const [facade, setFacade] = useState("");
  const [region, setRegion] = useState("الرياض");
  const [neighborhood, setNeighborhood] = useState("");
  const [allowPets, setAllowPets] = useState<boolean | null>(null);
  const [allowFamilies, setAllowFamilies] = useState<boolean | null>(null);
  const [description, setDescription] = useState("");

  const scrollTop = () => { setTimeout(() => scrollRef.current?.scrollTo({ top: 0, behavior: 'smooth' }), 50); };
  const nextStep = () => { setCurrentStep(s => s + 1); scrollTop(); };
  const prevStep = () => { if (currentStep === 1) { onBack(); } else { setCurrentStep(s => s - 1); scrollTop(); } };

  const handleAIEnhance = () => {
    setAiLoading(true);
    setTimeout(() => {
      setDescription(AI_DESCRIPTIONS.rent);
      setAiLoading(false);
      setAiDone(true);
    }, 2200);
  };

  if (submitted) {
    return <SuccessScreen isDark={isDark} onClose={onClose} label="إعلان الإيجار" />;
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col h-full">
      {/* Header */}
      <div className={`shrink-0 px-5 pt-5 pb-3 border-b ${isDark ? "border-white/5" : "border-gray-100"}`}>
        <div className="flex items-center justify-between mb-3">
          <button onClick={prevStep} className={`flex items-center gap-1.5 text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
            <ChevronRight className="w-4 h-4" /> رجوع
          </button>
          <div className="text-center">
            <h2 className={`font-black text-base flex items-center gap-1.5 ${isDark ? "text-white" : "text-gray-900"}`}><Key className="w-4 h-4 text-blue-400" /> إعلان إيجار</h2>
            <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>خطوة {currentStep} من {totalSteps}</p>
          </div>
          <div className="w-16" />
        </div>
        <div className={`h-1.5 rounded-full ${isDark ? "bg-white/8" : "bg-gray-100"}`}>
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-500"
            animate={{ width: `${(currentStep / totalSteps) * 100}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>

      {/* Content */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4" style={{ scrollbarWidth: 'none' }}>
        <AnimatePresence mode="wait">

          {/* STEP 1: Owner Info (Broker) */}
          {currentStep === 1 && isBroker && (
            <FormStep key="rent_owner">
              <StepTitle icon={User} title="معلومات المالك" sub="أدخل بيانات مالك العقار" isDark={isDark} color="blue" />
              <FormField label="اسم المالك" isDark={isDark}>
                <TextInput value={ownerName} onChange={setOwnerName} placeholder="مثال: محمد الدوسري" isDark={isDark} icon={User} />
              </FormField>
              <FormField label="رقم الجوال" isDark={isDark}>
                <TextInput value={ownerPhone} onChange={setOwnerPhone} placeholder="05xxxxxxxx" isDark={isDark} icon={Phone} type="tel" />
              </FormField>
              <FormField label="إشعارات المالك" isDark={isDark}>
                <div className={`p-4 rounded-2xl border space-y-3 ${isDark ? "bg-[#1a2035] border-white/5" : "bg-gray-50 border-gray-100"}`}>
                  <NotifToggle label="إشعار عند التأجير" value={notifySale} onChange={setNotifySale} isDark={isDark} />
                  <NotifToggle label="إشعار عند ورود طلب" value={notifyOffer} onChange={setNotifyOffer} isDark={isDark} />
                  <NotifToggle label="إشعار عند رسائل جديدة" value={notifyMsg} onChange={setNotifyMsg} isDark={isDark} />
                </div>
              </FormField>
            </FormStep>
          )}

          {/* STEP 2: Property Details */}
          {currentStep === (isBroker ? 2 : 1) && (
            <FormStep key="rent_details">
              <StepTitle icon={Key} title="تفاصيل الإيجار" sub="أدخل شروط وتفاصيل الوحدة" isDark={isDark} color="blue" />

              <FormField label="عنوان الإعلان" isDark={isDark}>
                <TextInput value={adTitle} onChange={setAdTitle} placeholder="مثال: شقة 3 غرف في حي الروابي" isDark={isDark} icon={FileText} />
              </FormField>

              <FormField label="نوع العقار" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {PROP_TYPES.map(t => (
                    <button key={t} onClick={() => setPropType(t)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${propType === t
                        ? isDark ? "bg-blue-500 text-white border-blue-500" : "bg-blue-600 text-white border-blue-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{t}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="فترة الإيجار" isDark={isDark}>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "yearly" as const, label: "سنوي", Icon: CalendarDays },
                    { id: "monthly" as const, label: "شهري", Icon: CalendarCheck },
                  ].map(p => (
                    <button key={p.id} onClick={() => setRentPeriod(p.id)}
                      className={`py-3 rounded-xl text-sm font-black border transition-all flex items-center justify-center gap-1.5 ${rentPeriod === p.id
                        ? isDark ? "bg-blue-500 text-white border-blue-500" : "bg-blue-600 text-white border-blue-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}><p.Icon className="w-3.5 h-3.5" />{p.label}</button>
                  ))}
                </div>
              </FormField>

              <FormField label={`قيمة الإيجار ${rentPeriod === 'yearly' ? 'السنوي' : 'الشهري'} (ريال)`} isDark={isDark}>
                <TextInput value={rentPrice} onChange={setRentPrice} placeholder={rentPeriod === 'yearly' ? "مثال: 60,000" : "مثال: 5,000"} isDark={isDark} icon={DollarSign} type="tel" />
              </FormField>

              <FormField label="شروط الدفع" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {["شيك واحد", "شيكين", "4 شيكات", "شهري"].map(t => (
                    <button key={t} onClick={() => setPaymentTerms(t)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${paymentTerms === t
                        ? isDark ? "bg-cyan-500 text-white border-cyan-500" : "bg-cyan-600 text-white border-cyan-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{t}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="عدد أشهر التأمين" isDark={isDark}>
                <div className="flex gap-2">
                  {["0", "1", "2", "3"].map(m => (
                    <button key={m} onClick={() => setDepositMonths(m)}
                      className={`flex-1 py-2.5 rounded-xl text-sm font-black border transition-all ${depositMonths === m
                        ? isDark ? "bg-amber-500 text-white border-amber-500" : "bg-amber-600 text-white border-amber-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{m === "0" ? "بدون" : `${m} شهر`}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="التأثيث" isDark={isDark}>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "furnished" as const, label: "مفروش", Icon: Sofa },
                    { id: "semi" as const, label: "نصف مفروش", Icon: Armchair },
                    { id: "unfurnished" as const, label: "بدون أثاث", Icon: Home },
                  ].map(f => {
                    const FIcon = f.Icon;
                    return (
                      <button key={f.id} onClick={() => setFurnishing(f.id)}
                        className={`py-2 px-1 rounded-xl text-[10px] font-black border transition-all flex flex-col items-center gap-1 ${furnishing === f.id
                          ? isDark ? "bg-purple-500 text-white border-purple-500" : "bg-purple-600 text-white border-purple-600"
                          : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                        }`}><FIcon className="w-3.5 h-3.5" />{f.label}</button>
                    );
                  })}
                </div>
              </FormField>

              <FormField label="يصلح لـ" isDark={isDark}>
                <div className="space-y-2">
                  <YesNoToggle value={allowFamilies} onChange={setAllowFamilies} isDark={isDark} yesLabel="يصلح للعائلات" noLabel="لا يصلح للعائلات" yesColor="emerald" noColor="gray" />
                </div>
              </FormField>

              <div className="grid grid-cols-2 gap-3">
                <FormField label="مساحة الأرض (م²)" isDark={isDark}>
                  <TextInput value={landArea} onChange={setLandArea} placeholder="مثال: 300" isDark={isDark} icon={Maximize2} type="tel" />
                </FormField>
                <FormField label="مساحة البناء (م²)" isDark={isDark}>
                  <TextInput value={builtArea} onChange={setBuiltArea} placeholder="مثال: 200" isDark={isDark} icon={Ruler} type="tel" />
                </FormField>
              </div>

              <FormField label="الواجهة" isDark={isDark}>
                <div className="grid grid-cols-3 gap-2">
                  {FACADES.map(f => (
                    <button key={f.id} onClick={() => setFacade(f.id)}
                        className={`py-2 px-2 rounded-xl text-[11px] font-black border transition-all flex flex-col items-center gap-0.5 ${facade === f.id
                          ? isDark ? "bg-blue-500 text-white border-blue-500" : "bg-blue-600 text-white border-blue-600"
                          : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                        }`}>
                        <f.Icon className="w-3.5 h-3.5" /><span>{f.label}</span>
                    </button>
                  ))}
                </div>
              </FormField>

              <FormField label="المنطقة" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {REGIONS.slice(0, 6).map(r => (
                    <button key={r} onClick={() => { setRegion(r); setNeighborhood(""); }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${region === r
                        ? isDark ? "bg-white text-black border-white" : "bg-gray-900 text-white border-gray-900"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{r}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="الحي" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {(NEIGHBORHOODS[region] || NEIGHBORHOODS["default"]).map(n => (
                    <button key={n} onClick={() => setNeighborhood(n)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${neighborhood === n
                        ? isDark ? "bg-amber-500 text-white border-amber-500" : "bg-amber-600 text-white border-amber-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{n}</button>
                  ))}
                </div>
              </FormField>
            </FormStep>
          )}

          {/* LAST STEP: Description + AI */}
          {currentStep === totalSteps && (
            <FormStep key="rent_desc">
              <StepTitle icon={Sparkles} title="وصف الوحدة" sub="اكتب أو دع الذكاء الاصطناعي يصوغ وصفاً احترافياً" isDark={isDark} color="cyan" />
              <div className={`p-4 rounded-2xl border mb-4 ${isDark ? "bg-gradient-to-br from-blue-900/20 to-cyan-900/20 border-blue-500/20" : "bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200"}`}>
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>تحسين بالذكاء الاصطناعي</p>
                    <p className={`text-[11px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>سيصيغ الذكاء الاصطناعي وصفاً جذاباً يزيد من فرص الإيجار.</p>
                  </div>
                </div>
                <button onClick={handleAIEnhance} disabled={aiLoading}
                  className={`w-full py-3 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${
                    aiLoading ? isDark ? "bg-white/5 text-white/30" : "bg-gray-100 text-gray-400"
                    : aiDone ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg"
                    : "bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-lg hover:shadow-xl"
                  }`}>
                  {aiLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> جاري التحسين...</>
                    : aiDone ? <><Check className="w-4 h-4" /> تم التحسين ✨</>
                    : <><Zap className="w-4 h-4" /> تحسين الوصف تلقائياً</>}
                </button>
              </div>
              <FormField label="الوصف الكامل" isDark={isDark}>
                <textarea value={description} onChange={e => { setDescription(e.target.value); setAiDone(false); }}
                  placeholder="اكتب وصفاً تفصيلياً للوحدة..."
                  rows={7}
                  className={`w-full rounded-2xl border px-4 py-3 text-sm resize-none outline-none transition-all leading-7 ${
                    aiDone ? isDark ? "border-blue-500/40 bg-blue-500/5 text-white" : "border-blue-400 bg-blue-50 text-gray-900"
                    : isDark ? "bg-[#1a2035] border-white/8 text-white placeholder-white/20 focus:border-blue-500/50" : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400"
                  }`}
                  style={{ direction: 'rtl' }}
                />
              </FormField>
            </FormStep>
          )}
        </AnimatePresence>
      </div>

      {/* Action */}
      <div className={`shrink-0 p-4 border-t ${isDark ? "border-white/5 bg-[#111827]" : "border-gray-100 bg-white"}`}>
        {currentStep < totalSteps ? (
          <button onClick={nextStep}
            className="w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-600 shadow-lg shadow-blue-500/25">
            التالي <ChevronLeft className="w-5 h-5" />
          </button>
        ) : (
          <button onClick={() => setSubmitted(true)}
            className="w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/25">
            <CheckCircle className="w-5 h-5" /> نشر إعلان الإيجار
          </button>
        )}
      </div>
    </motion.div>
  );
}

// ==========================================
// MARKETING REQUEST FORM (طلب تسويق)
// ==========================================
function MarketingRequestForm({ isDark, onBack, onClose }: any) {
  const [marketType, setMarketType] = useState<"" | "sale" | "rent" | "exchange">("");
  const [currentStep, setCurrentStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Property fields
  const [propType, setPropType] = useState("فيلا");
  const [price, setPrice] = useState("");
  const [negotiable, setNegotiable] = useState<boolean | null>(null);
  const [hasDeed, setHasDeed] = useState<boolean | null>(null);
  const [bankAccepted, setBankAccepted] = useState<boolean | null>(null);
  const [landArea, setLandArea] = useState("");
  const [builtArea, setBuiltArea] = useState("");
  const [facade, setFacade] = useState("");
  const [region, setRegion] = useState("الرياض");
  const [neighborhood, setNeighborhood] = useState("");
  // Rent-specific
  const [rentPeriod, setRentPeriod] = useState<"yearly" | "monthly">("yearly");
  const [paymentTerms, setPaymentTerms] = useState("شيك واحد");
  // Exchange-specific
  const [wantType, setWantType] = useState("فيلا");
  const [wantRegion, setWantRegion] = useState("الرياض");
  const [deltaType, setDeltaType] = useState<"receive" | "pay" | "equal">("equal");
  const [deltaAmount, setDeltaAmount] = useState("");
  // Commission
  const [commissionPct, setCommissionPct] = useState("2.5");
  const [commissionPayer, setCommissionPayer] = useState<"owner" | "buyer" | "split">("buyer");
  // Description
  const [description, setDescription] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiDone, setAiDone] = useState(false);

  const totalSteps = marketType === "" ? 1 : 3;
  const scrollTop = () => { setTimeout(() => scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" }), 50); };
  const nextStep = () => { setCurrentStep(s => s + 1); scrollTop(); };
  const prevStep = () => {
    if (currentStep === 1) { onBack(); }
    else if (currentStep === 2 && marketType !== "") { setCurrentStep(1); scrollTop(); }
    else { setCurrentStep(s => s - 1); scrollTop(); }
  };
  const handleAI = () => {
    setAiLoading(true);
    setTimeout(() => {
      setDescription("عقار مميز يُطرح للتسويق الاحترافي. يتميز بموقعه الاستراتيجي وتشطيباته الفاخرة. يرغب المالك في إيجاد وسيط متميز قادر على تسويق العقار بالسرعة والاحترافية المطلوبتين. فرصة حقيقية للوسطاء الجادين.");
      setAiLoading(false);
      setAiDone(true);
    }, 2000);
  };

  if (submitted) return <SuccessScreen isDark={isDark} onClose={onClose} label="طلب التسويق" successMsg="سيتواصل معك الوسطاء المؤهلون خلال 24 ساعة." />;

  const typeConfig: Record<string, { label: string; color: string; Icon: any }> = {
    sale:     { label: "للبيع",    color: "emerald", Icon: Tag },
    rent:     { label: "للإيجار", color: "blue",    Icon: Key },
    exchange: { label: "للبدل",   color: "purple",  Icon: ArrowRightLeft },
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col h-full">
      {/* Header */}
      <div className={`shrink-0 px-5 pt-5 pb-3 border-b ${isDark ? "border-white/5" : "border-gray-100"}`}>
        <div className="flex items-center justify-between mb-3">
          <button onClick={prevStep} className={`flex items-center gap-1.5 text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
            <ChevronRight className="w-4 h-4" /> رجوع
          </button>
          <div className="text-center">
            <h2 className={`font-black text-base flex items-center gap-1.5 ${isDark ? "text-white" : "text-gray-900"}`}><Megaphone className="w-4 h-4 text-pink-400" /> طلب تسويق</h2>
            {marketType && <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>خطوة {currentStep} من {totalSteps}</p>}
          </div>
          <div className="w-16" />
        </div>
        {marketType && (
          <div className={`h-1.5 rounded-full ${isDark ? "bg-white/8" : "bg-gray-100"}`}>
            <motion.div className="h-full rounded-full bg-gradient-to-r from-pink-500 to-rose-500"
              animate={{ width: `${(currentStep / totalSteps) * 100}%` }} transition={{ duration: 0.4 }} />
          </div>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-4" style={{ scrollbarWidth: "none" }}>
        <AnimatePresence mode="wait">

          {/* STEP 1: Info + Select Type */}
          {currentStep === 1 && (
            <FormStep key="mkt_type">
              {/* Info Banner */}
              <div className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-pink-900/20 to-rose-900/20 border-pink-500/20" : "bg-gradient-to-br from-pink-50 to-rose-50 border-pink-200"}`}>
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center shrink-0 shadow-lg">
                    <Megaphone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className={`text-sm font-black mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>ما هو طلب التسويق؟</p>
                    <p className={`text-[11px] leading-5 ${isDark ? "text-white/60" : "text-gray-600"}`}>
                      هذا النموذج مخصص لأصحاب العقارات الذين <span className="font-black">لا يملكون رقم ترخيص إعلاني</span> ويودون أن يتولى وسيط تسويق عقارهم نيابةً عنهم.
                    </p>
                  </div>
                </div>
                <div className={`rounded-xl p-3 space-y-2 ${isDark ? "bg-white/5" : "bg-white/70"}`}>
                  {[
                    { icon: ClipboardList, text: "سيتواصل معك الوسيط ليأخذ منك المعلومات الكاملة" },
                    { icon: FileCheck, text: "سيُعد الوسيط عقد وساطة ويستخرج رقم الترخيص" },
                    { icon: Zap, text: "بإمكانك أيضاً استخراج الترخيص عبر منصة أيون مباشرة" },
                  ].map((point, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <point.icon className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${isDark ? "text-pink-400" : "text-pink-600"}`} />
                      <span className="text-xs">{point.text}</span>
                    </div>
                  ))}
                </div>
              </div>

              <StepTitle icon={Home} title="ماذا تريد تسويق عقارك؟" sub="اختر نوع التسويق المطلوب" isDark={isDark} color="amber" />
              <div className="grid grid-cols-1 gap-3">
                {[
                  { id: "sale", label: "للبيع", sub: "تريد بيع عقارك عبر وسيط", Icon: Tag, gradient: "from-emerald-500 to-teal-600" },
                  { id: "rent", label: "للإيجار", sub: "تريد تأجير عقارك عبر وسيط", Icon: Key, gradient: "from-blue-500 to-cyan-600" },
                  { id: "exchange", label: "للبدل", sub: "تريد مقايضة عقارك عبر وسيط", Icon: ArrowRightLeft, gradient: "from-purple-600 to-pink-600" },
                ].map(opt => (
                  <button key={opt.id}
                    onClick={() => setMarketType(opt.id as any)}
                    className={`w-full p-4 rounded-2xl flex items-center gap-4 border-2 transition-all ${
                      marketType === opt.id
                        ? isDark ? "border-pink-500 bg-pink-500/10" : "border-pink-500 bg-pink-50"
                        : isDark ? "bg-[#1a2035] border-white/5" : "bg-white border-gray-200"
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${opt.gradient} flex items-center justify-center shadow-md`}>
                      <opt.Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-right flex-1">
                      <p className={`font-black text-base ${isDark ? "text-white" : "text-gray-900"}`}>{opt.label}</p>
                      <p className={`text-xs ${isDark ? "text-white/40" : "text-gray-500"}`}>{opt.sub}</p>
                    </div>
                    {marketType === opt.id && <CheckCircle className="w-5 h-5 text-pink-500 shrink-0" />}
                  </button>
                ))}
              </div>
            </FormStep>
          )}

          {/* STEP 2: Property Details (based on marketType) */}
          {currentStep === 2 && marketType !== "" && (
            <FormStep key="mkt_details">
              <StepTitle icon={Building2} title="تفاصيل العقار" sub="أدخل معلومات العقار بدقة" isDark={isDark} color={marketType === "sale" ? "emerald" : marketType === "rent" ? "blue" : "purple"} />

              <FormField label="نوع العقار" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {PROP_TYPES.map(t => (
                    <button key={t} onClick={() => setPropType(t)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${propType === t
                        ? isDark ? "bg-pink-500 text-white border-pink-500" : "bg-pink-600 text-white border-pink-600"
                        : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                      }`}>{t}</button>
                  ))}
                </div>
              </FormField>

              {marketType === "rent" ? (
                <>
                  <FormField label="فترة الإيجار" isDark={isDark}>
                    <div className="grid grid-cols-2 gap-2">
                      {[{ id: "yearly" as const, label: "سنوي", Icon: CalendarDays }, { id: "monthly" as const, label: "شهري", Icon: CalendarCheck }].map(p => (
                        <button key={p.id} onClick={() => setRentPeriod(p.id)}
                          className={`py-3 rounded-xl text-sm font-black border transition-all flex items-center justify-center gap-1.5 ${rentPeriod === p.id ? "bg-blue-500 text-white border-blue-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}><p.Icon className="w-3.5 h-3.5" />{p.label}</button>
                      ))}
                    </div>
                  </FormField>
                  <FormField label={`قيمة الإيجار ${rentPeriod === "yearly" ? "السنوي" : "الشهري"} (ريال)`} isDark={isDark}>
                    <TextInput value={price} onChange={setPrice} placeholder={rentPeriod === "yearly" ? "مثال: 60,000" : "مثال: 5,000"} isDark={isDark} icon={DollarSign} type="tel" />
                  </FormField>
                  <FormField label="شروط الدفع" isDark={isDark}>
                    <div className="flex flex-wrap gap-2">
                      {["شيك واحد", "شيكين", "4 شيكات", "شهري"].map(t => (
                        <button key={t} onClick={() => setPaymentTerms(t)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${paymentTerms === t ? "bg-blue-500 text-white border-blue-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{t}</button>
                      ))}
                    </div>
                  </FormField>
                </>
              ) : marketType === "exchange" ? (
                <>
                  <FormField label="السعر التقريبي للعقار (ريال)" isDark={isDark}>
                    <TextInput value={price} onChange={setPrice} placeholder="مثال: 2,500,000" isDark={isDark} icon={DollarSign} type="tel" />
                  </FormField>
                  <FormField label="نوع العقار الذي تريده بالمقايضة" isDark={isDark}>
                    <div className="flex flex-wrap gap-2">
                      {PROP_TYPES.map(t => (
                        <button key={t} onClick={() => setWantType(t)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${wantType === t ? "bg-purple-500 text-white border-purple-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{t}</button>
                      ))}
                    </div>
                  </FormField>
                  <FormField label="منطقة العقار المرغوب" isDark={isDark}>
                    <div className="flex flex-wrap gap-2">
                      {REGIONS.slice(0, 6).map(r => (
                        <button key={r} onClick={() => setWantRegion(r)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${wantRegion === r ? isDark ? "bg-white text-black border-white" : "bg-gray-900 text-white border-gray-900" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{r}</button>
                      ))}
                    </div>
                  </FormField>
                  <FormField label="فرق السعر" isDark={isDark}>
                    <div className="grid grid-cols-3 gap-2 mb-2">
                      {[{ id: "receive" as const, label: "أطلب فرق", Icon: Coins }, { id: "pay" as const, label: "أدفع فرق", Icon: CheckCircle }, { id: "equal" as const, label: "رأس برأس", Icon: Scale }].map(dt => (
                        <button key={dt.id} onClick={() => setDeltaType(dt.id)}
                          className={`py-2.5 px-1 rounded-xl text-[10px] font-black border transition-all flex flex-col items-center gap-1 ${deltaType === dt.id ? "bg-purple-500 text-white border-purple-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}><dt.Icon className="w-3.5 h-3.5" />{dt.label}</button>
                      ))}
                    </div>
                    {deltaType !== "equal" && (
                      <TextInput value={deltaAmount} onChange={setDeltaAmount} placeholder="مقدار الفرق (ريال)" isDark={isDark} icon={DollarSign} type="tel" />
                    )}
                  </FormField>
                </>
              ) : (
                <>
                  <FormField label="السعر المطلوب (ريال)" isDark={isDark}>
                    <TextInput value={price} onChange={setPrice} placeholder="مثال: 2,000,000" isDark={isDark} icon={DollarSign} type="tel" />
                  </FormField>
                  <FormField label="قابل للتفاوض؟" isDark={isDark}>
                    <YesNoToggle value={negotiable} onChange={setNegotiable} isDark={isDark} yesLabel="قابل للتفاوض" noLabel="السعر نهائي" yesColor="emerald" noColor="red" />
                  </FormField>
                  <FormField label="يمتلك صك؟" isDark={isDark}>
                    <YesNoToggle value={hasDeed} onChange={setHasDeed} isDark={isDark} yesLabel="نعم، يوجد صك" noLabel="لا يوجد صك" yesColor="blue" noColor="gray" />
                  </FormField>
                  {hasDeed === true && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}>
                      <FormField label="يقبل التمويل البنكي؟" isDark={isDark}>
                        <YesNoToggle value={bankAccepted} onChange={setBankAccepted} isDark={isDark} yesLabel="يقبل البنك" noLabel="كاش فقط" yesColor="green" noColor="amber" />
                      </FormField>
                    </motion.div>
                  )}
                </>
              )}

              <div className="grid grid-cols-2 gap-3">
                <FormField label="مساحة الأرض (م²)" isDark={isDark}>
                  <TextInput value={landArea} onChange={setLandArea} placeholder="مثال: 600" isDark={isDark} icon={Maximize2} type="tel" />
                </FormField>
                <FormField label="مساحة البناء (م²)" isDark={isDark}>
                  <TextInput value={builtArea} onChange={setBuiltArea} placeholder="مثال: 450" isDark={isDark} icon={Ruler} type="tel" />
                </FormField>
              </div>

              <FormField label="الواجهة" isDark={isDark}>
                <div className="grid grid-cols-3 gap-2">
                  {FACADES.map(f => (
                    <button key={f.id} onClick={() => setFacade(f.id)}
                      className={`py-2 px-2 rounded-xl text-[11px] font-black border transition-all flex flex-col items-center gap-0.5 ${facade === f.id ? "bg-pink-500 text-white border-pink-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>
                      <span>{f.emoji}</span><span>{f.label}</span>
                    </button>
                  ))}
                </div>
              </FormField>

              <FormField label="المنطقة" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {REGIONS.slice(0, 6).map(r => (
                    <button key={r} onClick={() => { setRegion(r); setNeighborhood(""); }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${region === r ? isDark ? "bg-white text-black border-white" : "bg-gray-900 text-white border-gray-900" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{r}</button>
                  ))}
                </div>
              </FormField>

              <FormField label="الحي" isDark={isDark}>
                <div className="flex flex-wrap gap-2">
                  {(NEIGHBORHOODS[region] || NEIGHBORHOODS["default"]).map(n => (
                    <button key={n} onClick={() => setNeighborhood(n)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${neighborhood === n ? "bg-pink-500 text-white border-pink-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{n}</button>
                  ))}
                </div>
              </FormField>

              {/* Commission */}
              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#1a2035] border-pink-500/20" : "bg-pink-50 border-pink-200"}`}>
                <p className={`text-xs font-black mb-3 flex items-center gap-1.5 ${isDark ? "text-pink-400" : "text-pink-700"}`}><Coins className="w-3.5 h-3.5" /> نسبة السعي للوسيط</p>
                <FormField label="نسبة العمولة %" isDark={isDark}>
                  <div className="flex gap-2">
                    {["1.5", "2", "2.5", "3", "3.5", "5"].map(pct => (
                      <button key={pct} onClick={() => setCommissionPct(pct)}
                        className={`flex-1 py-2 rounded-xl text-xs font-black border transition-all ${commissionPct === pct ? "bg-pink-500 text-white border-pink-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{pct}%</button>
                    ))}
                  </div>
                </FormField>
                <FormField label="من يدفع السعي؟" isDark={isDark}>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: "buyer" as const, label: "المشتري", Icon: Users },
                      { id: "owner" as const, label: "المالك", Icon: Home },
                      { id: "split" as const, label: "مناصفة", Icon: Scale },
                    ].map(opt => (
                      <button key={opt.id} onClick={() => setCommissionPayer(opt.id)}
                        className={`py-3 rounded-xl text-[11px] font-black border transition-all flex flex-col items-center gap-1 ${commissionPayer === opt.id ? "bg-pink-500 text-white border-pink-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>
                        <opt.Icon className="w-4 h-4" />
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </FormField>
              </div>
            </FormStep>
          )}

          {/* STEP 3: Description */}
          {currentStep === 3 && (
            <FormStep key="mkt_desc">
              <StepTitle icon={Sparkles} title="وصف العقار" sub="اكتب وصفاً مختصراً أو دع الذكاء الاصطناعي يساعدك" isDark={isDark} color="cyan" />
              <div className={`p-4 rounded-2xl border mb-2 ${isDark ? "bg-gradient-to-br from-pink-900/20 to-rose-900/20 border-pink-500/20" : "bg-gradient-to-br from-pink-50 to-rose-50 border-pink-200"}`}>
                <button onClick={handleAI} disabled={aiLoading}
                  className={`w-full py-3 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${
                    aiLoading ? isDark ? "bg-white/5 text-white/30" : "bg-gray-100 text-gray-400"
                    : aiDone ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white"
                    : "bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-lg"
                  }`}>
                  {aiLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> جاري الصياغة...</>
                    : aiDone ? <><Check className="w-4 h-4" /> تم التحسين ✨</>
                    : <><Zap className="w-4 h-4" /> صياغة وصف بالذكاء الاصطناعي</>}
                </button>
              </div>
              <FormField label="وصف العقار المراد تسويقه" isDark={isDark}>
                <textarea value={description} onChange={e => { setDescription(e.target.value); setAiDone(false); }}
                  placeholder="اكتب وصفاً مختصراً للعقار يساعد الوسيط على فهم العقار والتواصل معك بفاعلية..."
                  rows={6}
                  className={`w-full rounded-2xl border px-4 py-3 text-sm resize-none outline-none transition-all leading-7 ${
                    aiDone ? isDark ? "border-pink-500/40 bg-pink-500/5 text-white" : "border-pink-400 bg-pink-50 text-gray-900"
                    : isDark ? "bg-[#1a2035] border-white/8 text-white placeholder-white/20" : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400"
                  }`}
                  style={{ direction: "rtl" }} />
              </FormField>

              {/* Summary */}
              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#1a2035] border-white/5" : "bg-gray-50 border-gray-100"}`}>
                <p className={`text-xs font-black mb-3 ${isDark ? "text-white/60" : "text-gray-500"}`}>ملخص الطلب</p>
                <div className="flex flex-wrap gap-2">
                  {[
                    marketType && typeConfig[marketType] && { label: typeConfig[marketType].label },
                    propType && { label: propType },
                    price && { label: `${price} ريال` },
                    region && { label: region },
                    { label: `سعي ${commissionPct}%` },
                    { label: commissionPayer === "buyer" ? "يدفع المشتري" : commissionPayer === "owner" ? "يدفع المالك" : "مناصفة" },
                  ].filter(Boolean).map((chip: any, i) => (
                    <span key={i} className={`text-[10px] font-black px-2.5 py-1 rounded-xl border ${isDark ? "bg-white/5 text-white/60 border-white/5" : "bg-white text-gray-700 border-gray-200"}`}>{chip.label}</span>
                  ))}
                </div>
              </div>
            </FormStep>
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <div className={`shrink-0 p-4 border-t ${isDark ? "border-white/5 bg-[#111827]" : "border-gray-100 bg-white"}`}>
        {currentStep === 1 ? (
          <button onClick={() => { if (marketType) nextStep(); }}
            disabled={!marketType}
            className={`w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
              marketType ? "bg-gradient-to-r from-pink-500 to-rose-600 shadow-pink-500/25" : "bg-gray-300 cursor-not-allowed"
            }`}>
            التالي <ChevronLeft className="w-5 h-5" />
          </button>
        ) : currentStep < totalSteps ? (
          <button onClick={nextStep}
            className="w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 bg-gradient-to-r from-pink-500 to-rose-600 shadow-lg shadow-pink-500/25">
            التالي <ChevronLeft className="w-5 h-5" />
          </button>
        ) : (
          <button onClick={() => setSubmitted(true)}
            className="w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 bg-gradient-to-r from-pink-500 to-rose-600 shadow-lg shadow-pink-500/25">
            <CheckCircle className="w-5 h-5" /> إرسال طلب التسويق
          </button>
        )}
      </div>
    </motion.div>
  );
}

// ==========================================
// SEARCH REQUEST FORM (طلب بحث)
// ==========================================
function SearchRequestForm({ isDark, onBack, onClose }: any) {
  const [submitted, setSubmitted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const [txType, setTxType] = useState<"buy" | "rent" | "exchange">("buy");
  const [propType, setPropType] = useState("فيلا");
  const [region, setRegion] = useState("الرياض");
  const [neighborhood, setNeighborhood] = useState("");
  const [budgetFrom, setBudgetFrom] = useState("");
  const [budgetTo, setBudgetTo] = useState("");
  const [beds, setBeds] = useState("");
  const [baths, setBaths] = useState("");
  const [minArea, setMinArea] = useState("");
  const [urgent, setUrgent] = useState<boolean | null>(null);
  const [notes, setNotes] = useState("");

  if (submitted) return <SuccessScreen isDark={isDark} onClose={onClose} label="طلب البحث" successMsg="سيتواصل معك الوسطاء والملاك المطابقون لطلبك قريباً." />;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col h-full">
      {/* Header */}
      <div className={`shrink-0 px-5 pt-5 pb-3 border-b ${isDark ? "border-white/5" : "border-gray-100"}`}>
        <div className="flex items-center justify-between mb-3">
          <button onClick={onBack} className={`flex items-center gap-1.5 text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
            <ChevronRight className="w-4 h-4" /> رجوع
          </button>
          <h2 className={`font-black text-base flex items-center gap-1.5 ${isDark ? "text-white" : "text-gray-900"}`}><Search className="w-4 h-4 text-indigo-400" /> طلب بحث</h2>
          <div className="w-16" />
        </div>
        <div className={`h-1.5 rounded-full ${isDark ? "bg-white/8" : "bg-gray-100"}`}>
          <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-600 w-full" />
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-4" style={{ scrollbarWidth: "none" }}>

        {/* نوع المعاملة */}
        <FormField label="نوع المعاملة" isDark={isDark}>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: "buy" as const, label: "للشراء", Icon: Tag },
              { id: "rent" as const, label: "للإيجار", Icon: Key },
              { id: "exchange" as const, label: "للبدل", Icon: ArrowRightLeft },
            ].map(opt => (
              <button key={opt.id} onClick={() => setTxType(opt.id)}
                className={`py-3 rounded-xl text-[11px] font-black border transition-all flex flex-col items-center gap-1 ${txType === opt.id
                  ? isDark ? "bg-indigo-500 text-white border-indigo-500" : "bg-indigo-600 text-white border-indigo-600"
                  : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                }`}>
                <opt.Icon className="w-4 h-4" />
                {opt.label}
              </button>
            ))}
          </div>
        </FormField>

        {/* نوع العقار */}
        <FormField label="نوع العقار المطلوب" isDark={isDark}>
          <div className="flex flex-wrap gap-2">
            {PROP_TYPES.map(t => (
              <button key={t} onClick={() => setPropType(t)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${propType === t
                  ? isDark ? "bg-violet-500 text-white border-violet-500" : "bg-violet-600 text-white border-violet-600"
                  : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                }`}>{t}</button>
            ))}
          </div>
        </FormField>

        {/* المنطقة */}
        <FormField label="المنطقة المفضلة" isDark={isDark}>
          <div className="flex flex-wrap gap-2">
            {REGIONS.map(r => (
              <button key={r} onClick={() => { setRegion(r); setNeighborhood(""); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${region === r
                  ? isDark ? "bg-white text-black border-white" : "bg-gray-900 text-white border-gray-900"
                  : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                }`}>{r}</button>
            ))}
          </div>
        </FormField>

        {/* الحي */}
        <FormField label="الحي المفضل (اختياري)" isDark={isDark}>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => setNeighborhood("")}
              className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${neighborhood === "" ? isDark ? "bg-indigo-500 text-white border-indigo-500" : "bg-indigo-600 text-white border-indigo-600" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>
              أي حي
            </button>
            {(NEIGHBORHOODS[region] || NEIGHBORHOODS["default"]).map(n => (
              <button key={n} onClick={() => setNeighborhood(n)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${neighborhood === n
                  ? isDark ? "bg-indigo-500 text-white border-indigo-500" : "bg-indigo-600 text-white border-indigo-600"
                  : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"
                }`}>{n}</button>
            ))}
          </div>
        </FormField>

        {/* الميزانية */}
        <FormField label={txType === "rent" ? "الميزانية السنوية (ريال)" : "نطاق الميزانية (ريال)"} isDark={isDark}>
          <div className="grid grid-cols-2 gap-3">
            <TextInput value={budgetFrom} onChange={setBudgetFrom} placeholder="من: 500,000" isDark={isDark} icon={DollarSign} type="tel" />
            <TextInput value={budgetTo} onChange={setBudgetTo} placeholder="إلى: 2,000,000" isDark={isDark} icon={DollarSign} type="tel" />
          </div>
        </FormField>

        {/* المواصفات */}
        <FormField label="المواصفات المطلوبة" isDark={isDark}>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <p className={`text-[10px] mb-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>غرف النوم</p>
              <div className="flex flex-col gap-1">
                {["1", "2", "3", "4", "5+"].map(n => (
                  <button key={n} onClick={() => setBeds(n)}
                    className={`py-1.5 rounded-lg text-[11px] font-black border transition-all ${beds === n ? "bg-indigo-500 text-white border-indigo-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{n}</button>
                ))}
              </div>
            </div>
            <div>
              <p className={`text-[10px] mb-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>دورات مياه</p>
              <div className="flex flex-col gap-1">
                {["1", "2", "3", "4+"].map(n => (
                  <button key={n} onClick={() => setBaths(n)}
                    className={`py-1.5 rounded-lg text-[11px] font-black border transition-all ${baths === n ? "bg-indigo-500 text-white border-indigo-500" : isDark ? "bg-white/5 text-white/50 border-white/5" : "bg-white text-gray-600 border-gray-200"}`}>{n}</button>
                ))}
              </div>
            </div>
            <div>
              <p className={`text-[10px] mb-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>أدنى مساحة</p>
              <TextInput value={minArea} onChange={setMinArea} placeholder="م²" isDark={isDark} icon={Ruler} type="tel" />
            </div>
          </div>
        </FormField>

        {/* الأولوية */}
        <FormField label="أولوية الطلب" isDark={isDark}>
          <YesNoToggle value={urgent} onChange={setUrgent} isDark={isDark}
            yesLabel="عاجل — أبحث الآن" noLabel="غير عاجل — بدون ضغط"
            yesColor="red" noColor="gray" />
        </FormField>

        {/* ملاحظات */}
        <FormField label="ملاحظات إضافية (اختياري)" isDark={isDark}>
          <textarea value={notes} onChange={e => setNotes(e.target.value)}
            placeholder="مثال: أفضل دور أرضي، مدخل مستقل، قريب من مدرسة دولية، لا أقبل الطابق الأول..."
            rows={4}
            className={`w-full rounded-2xl border px-4 py-3 text-sm resize-none outline-none transition-all leading-7 ${isDark ? "bg-[#1a2035] border-white/8 text-white placeholder-white/20 focus:border-indigo-500/50" : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400 focus:border-indigo-400"}`}
            style={{ direction: "rtl" }} />
        </FormField>

        {/* Summary Preview */}
        <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#1a2035] border-white/5" : "bg-indigo-50 border-indigo-100"}`}>
          <p className={`text-xs font-black mb-3 flex items-center gap-1.5 ${isDark ? "text-indigo-400" : "text-indigo-700"}`}><Search className="w-3.5 h-3.5" /> ملخص طلب البحث</p>
          <div className="flex flex-wrap gap-2">
            {[
              { label: txType === "buy" ? "للشراء" : txType === "rent" ? "للإيجار" : "للبدل" },
              { label: propType },
              { label: `${region}${neighborhood ? " / " + neighborhood : ""}` },
              budgetFrom && { label: `من ${budgetFrom}` },
              budgetTo && { label: `إلى ${budgetTo}` },
              beds && { label: `${beds} غرف` },
              baths && { label: `${baths} حمام` },
              minArea && { label: `${minArea}م²+` },
              urgent && { label: "عاجل" },
            ].filter(Boolean).map((chip: any, i) => (
              <span key={i} className={`text-[10px] font-black px-2.5 py-1 rounded-xl border ${isDark ? "bg-white/5 text-white/60 border-white/5" : "bg-white text-gray-700 border-indigo-200"}`}>{chip.label}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className={`shrink-0 p-4 border-t ${isDark ? "border-white/5 bg-[#111827]" : "border-gray-100 bg-white"}`}>
        <button onClick={() => setSubmitted(true)}
          className="w-full py-4 rounded-2xl font-black text-white text-sm flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-500 to-violet-600 shadow-lg shadow-indigo-500/25">
          <CheckCircle className="w-5 h-5" /> نشر طلب البحث
        </button>
      </div>
    </motion.div>
  );
}

// ==========================================
// SUCCESS SCREEN
// ==========================================
function SuccessScreen({ isDark, onClose, label, successMsg }: any) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center h-full p-8 text-center">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
        className="w-24 h-24 rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center mb-6 shadow-2xl shadow-emerald-500/40"
      >
        <CheckCircle className="w-12 h-12 text-white" />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <h2 className={`text-2xl font-black mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>تم بنجاح! 🎉</h2>
        <p className={`text-sm mb-2 ${isDark ? "text-white/50" : "text-gray-500"}`}>تم إرسال {label} بنجاح.</p>
        {successMsg && <p className={`text-xs mb-8 ${isDark ? "text-white/40" : "text-gray-400"}`}>{successMsg}</p>}
        <button onClick={onClose}
          className="w-full py-4 rounded-2xl font-black text-white bg-gradient-to-r from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/25">
          رائع، عودة للرئيسية
        </button>
      </motion.div>
    </motion.div>
  );
}

// ==========================================
// UTILITY COMPONENTS
// ==========================================

function MenuCard({ icon: Icon, title, subtitle, color, onClick, isDark }: any) {
  return (
    <motion.button whileTap={{ scale: 0.95 }} onClick={onClick}
      className={`relative p-6 rounded-3xl flex flex-col items-center text-center gap-4 transition-all group overflow-hidden border ${
        isDark ? "bg-[#1a2035] hover:bg-[#1e2640] border-white/5" : "bg-gray-50 hover:bg-gray-100 border-gray-200"
      }`}>
      <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg mb-2 ${
        color === "cyan" ? "bg-gradient-to-br from-cyan-500 to-blue-600" : "bg-gradient-to-br from-purple-500 to-pink-600"
      }`}>
        <Icon className="w-8 h-8 text-white" />
      </div>
      <div>
        <h3 className={`font-black text-lg mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{title}</h3>
        <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>{subtitle}</p>
      </div>
    </motion.button>
  );
}

function FormStep({ children }: { children: React.ReactNode }) {
  return (
    <motion.div key="step" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.25 }} className="space-y-4 pb-4">
      {children}
    </motion.div>
  );
}

function StepTitle({ icon: Icon, title, sub, isDark, color }: any) {
  const gradients: Record<string, string> = {
    blue: "from-blue-500 to-cyan-500",
    emerald: "from-emerald-500 to-teal-500",
    purple: "from-purple-600 to-pink-600",
    cyan: "from-cyan-500 to-blue-600",
    amber: "from-amber-500 to-orange-500",
  };
  return (
    <div className="flex items-start gap-3 mb-2">
      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${gradients[color] || gradients.blue} flex items-center justify-center shrink-0 shadow-lg`}>
        <Icon className="w-5 h-5 text-white" />
      </div>
      <div>
        <h3 className={`font-black text-base ${isDark ? "text-white" : "text-gray-900"}`}>{title}</h3>
        <p className={`text-[11px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>{sub}</p>
      </div>
    </div>
  );
}

function FormField({ label, children, isDark }: any) {
  return (
    <div>
      <label className={`block text-xs font-black mb-2 ${isDark ? "text-white/60" : "text-gray-600"}`}>{label}</label>
      {children}
    </div>
  );
}

function TextInput({ value, onChange, placeholder, isDark, icon: Icon, type = "text" }: any) {
  return (
    <div className={`flex items-center gap-2 rounded-2xl border px-4 py-1 transition-all ${
      isDark ? "bg-[#1a2035] border-white/8 focus-within:border-white/20" : "bg-white border-gray-200 shadow-sm focus-within:border-blue-400"
    }`}>
      {Icon && <Icon className={`w-4 h-4 shrink-0 ${isDark ? "text-white/20" : "text-gray-300"}`} style={{ width: '14px', height: '14px' }} />}
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className={`flex-1 bg-transparent border-none outline-none py-3 text-sm ${isDark ? "text-white placeholder-white/20" : "text-gray-900 placeholder-gray-400"}`}
        style={{ direction: 'rtl' }}
      />
    </div>
  );
}

function YesNoToggle({ value, onChange, isDark, yesLabel, noLabel, yesColor, noColor }: any) {
  const colorMap: Record<string, string> = {
    emerald: "bg-emerald-500 border-emerald-500",
    blue: "bg-blue-500 border-blue-500",
    green: "bg-green-500 border-green-500",
    red: "bg-red-500 border-red-500",
    amber: "bg-amber-500 border-amber-500",
    gray: isDark ? "bg-white/10 border-white/10 text-white/60" : "bg-gray-200 border-gray-200 text-gray-600",
    purple: "bg-purple-500 border-purple-500",
  };
  return (
    <div className="grid grid-cols-2 gap-2">
      <button onClick={() => onChange(true)}
        className={`py-3 rounded-xl text-xs font-black border transition-all ${
          value === true
            ? `${colorMap[yesColor] || colorMap.emerald} text-white`
            : isDark ? "bg-white/5 text-white/40 border-white/5" : "bg-white text-gray-500 border-gray-200"
        }`}>{yesLabel}</button>
      <button onClick={() => onChange(false)}
        className={`py-3 rounded-xl text-xs font-black border transition-all ${
          value === false
            ? noColor === 'gray' ? colorMap.gray : `${colorMap[noColor] || colorMap.red} text-white`
            : isDark ? "bg-white/5 text-white/40 border-white/5" : "bg-white text-gray-500 border-gray-200"
        }`}>{noLabel}</button>
    </div>
  );
}

function NotifToggle({ label, value, onChange, isDark }: any) {
  return (
    <div className="flex items-center justify-between">
      <span className={`text-xs font-bold ${isDark ? "text-white/70" : "text-gray-700"}`}>{label}</span>
      <button onClick={() => onChange(!value)} className="flex items-center gap-1.5">
        <span className={`text-[10px] font-black ${value ? "text-emerald-500" : isDark ? "text-white/30" : "text-gray-400"}`}>{value ? "مفعّل" : "متوقف"}</span>
        <div className={`w-12 h-6 rounded-full transition-all relative ${value ? "bg-emerald-500" : isDark ? "bg-white/10" : "bg-gray-200"}`}>
          <motion.div
            animate={{ right: value ? "2px" : "auto", left: value ? "auto" : "2px" }}
            className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
          />
        </div>
      </button>
    </div>
  );
}
