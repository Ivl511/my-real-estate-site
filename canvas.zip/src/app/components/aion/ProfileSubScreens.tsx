import { motion, AnimatePresence } from "motion/react";
import {
  MessageSquare, Calendar, Clock, Plus, Search, Mic, Heart,
  MapPin, DollarSign, TrendingDown, TrendingUp, Bell, Star,
  Trash2, ChevronRight, Sparkles, Copy, CheckCircle, Phone,
  Building, Home, User, Filter, Send, Image, Zap, ShieldCheck,
  Eye, EyeOff, BarChart3, X, Loader2, CheckSquare, AlarmClock,
  StickyNote, BrainCircuit, Tag, FileText, Key, Award, RefreshCcw,
  AlertTriangle, XCircle, Lightbulb, Landmark, Flame,
  Users, Lock, Handshake, Activity, ArrowUpRight,
  MessageCircle, Shield, ThumbsUp, ThumbsDown, BellOff, BellRing,
  UserPlus, Globe, Megaphone, Target, Layers, MousePointerClick,
  ChevronDown, ChevronUp, PlayCircle, PauseCircle, Cpu,
  Edit3, ToggleRight, ArrowUpDown,
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useTheme } from "../../context/ThemeContext";
import { PropertyValuationWidget } from "./PropertyValuationWidget";

// ============================================================================
// 1. NEGOTIATION AGENT VIEW — Broker (Secretary Mode) — INTERACTIVE
// ============================================================================
export function NegotiationAgentView({ isDark }: { isDark: boolean }) {
  const [conversations, setConversations] = useState([
    { id: 1, name: "أحمد ناصر", message: "ما هي مساحة الشقة بالضبط؟", time: "5 دق", urgent: true, status: "pending" },
    { id: 2, name: "سارة المحمد", message: "هل يمكن زيارة الوحدة غداً؟", time: "20 دق", urgent: false, status: "pending" },
    { id: 3, name: "خالد الشهري", message: "متى تكون متاحاً للرد؟", time: "ساعة", urgent: false, status: "pending" },
  ]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [replyText, setReplyText] = useState("");
  const [bookingFor, setBookingFor] = useState<any | null>(null);
  const [bookDate, setBookDate] = useState("");
  const [bookTime, setBookTime] = useState("");
  const [showNewAppt, setShowNewAppt] = useState(false);
  const [newApptName, setNewApptName] = useState("");
  const [newApptProp, setNewApptProp] = useState("");
  const [newApptDate, setNewApptDate] = useState("");
  const [newApptTime, setNewApptTime] = useState("");

  const quickReplies = ["المساحة 200م²", "يمكن الزيارة خلال أيام العمل", "السعر قابل للنقاش", "سأتواصل معك قريباً"];

  const sendReply = (id: number) => {
    if (!replyText.trim()) return;
    setConversations(prev => prev.map(c => c.id === id ? { ...c, status: "replied" } : c));
    setReplyingTo(null);
    setReplyText("");
  };

  const confirmBooking = () => {
    if (!bookingFor || !bookDate || !bookTime) return;
    setAppointments(prev => [...prev, {
      id: Date.now(), name: bookingFor.name,
      property: "العقار المطلوب", time: bookTime,
      date: bookDate, status: "بانتظار التأكيد",
    }]);
    setConversations(prev => prev.map(c => c.id === bookingFor.id ? { ...c, status: "booked" } : c));
    setBookingFor(null); setBookDate(""); setBookTime("");
  };

  const confirmAppt = (id: number) =>
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: "مؤكد" } : a));
  const deleteAppt = (id: number) =>
    setAppointments(prev => prev.filter(a => a.id !== id));

  const addManualAppt = () => {
    if (!newApptName.trim() || !newApptDate || !newApptTime) return;
    setAppointments(prev => [...prev, {
      id: Date.now(), name: newApptName,
      property: newApptProp || "—", time: newApptTime,
      date: newApptDate, status: "بانتظار التأكيد",
    }]);
    setNewApptName(""); setNewApptProp("");
    setNewApptDate(""); setNewApptTime(""); setShowNewAppt(false);
  };

  const pending = conversations.filter(c => c.status === "pending");

  return (
    <div className="space-y-5">
      {/* Secretary Mode Note */}
      <div className={`p-3 rounded-xl border ${isDark ? "bg-amber-500/10 border-amber-500/20" : "bg-amber-50 border-amber-200"}`}>
        <p className="text-[10px] font-black text-amber-500 flex items-center gap-1"><AlertTriangle className="w-3 h-3 shrink-0" /> وضع السكرتير — الرد على الأسئلة وحجز المواعيد فقط</p>
        <p className="text-[9px] opacity-60 mt-0.5">ممنوع التفاوض على السعر أو مطابقة العملاء آلياً</p>
      </div>

      {/* Booking Modal (from conversation) */}
      {bookingFor && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border ${isDark ? "bg-[#1a2035] border-emerald-500/30" : "bg-emerald-50 border-emerald-200"}`}>
          <p className={`text-xs font-black mb-3 flex items-center gap-1.5 ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>
            <Calendar className="w-3.5 h-3.5" /> حجز موعد مع {bookingFor.name}
          </p>
          <div className="grid grid-cols-2 gap-2 mb-3">
            <div>
              <p className={`text-[9px] font-bold mb-1 ${isDark ? "text-white/50" : "text-gray-500"}`}>التاريخ</p>
              <input type="date" value={bookDate} onChange={e => setBookDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-xs border ${isDark ? "bg-white/5 border-white/10 text-white" : "bg-white border-gray-200 text-gray-900"}`} />
            </div>
            <div>
              <p className={`text-[9px] font-bold mb-1 ${isDark ? "text-white/50" : "text-gray-500"}`}>الوقت</p>
              <input type="time" value={bookTime} onChange={e => setBookTime(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-xs border ${isDark ? "bg-white/5 border-white/10 text-white" : "bg-white border-gray-200 text-gray-900"}`} />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={confirmBooking} className="flex-1 py-2 rounded-xl text-xs font-bold bg-emerald-500 text-white hover:bg-emerald-600 transition-colors">تأكيد الحجز</button>
            <button onClick={() => setBookingFor(null)} className={`px-4 py-2 rounded-xl text-xs font-bold ${isDark ? "bg-white/8 text-white/50 hover:bg-white/15" : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}>إلغاء</button>
          </div>
        </motion.div>
      )}

      {/* Pending Conversations */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
            <MessageSquare className="w-4 h-4 text-cyan-400" />
            أسئلة بانتظار الرد
            {pending.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[9px] font-black flex items-center justify-center">{pending.length}</span>
            )}
          </h4>
        </div>
        <div className="space-y-2">
          {conversations.map((c, i) => (
            <motion.div key={c.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}>
              <div className={`p-3 rounded-xl border transition-opacity ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"} ${c.status !== "pending" ? "opacity-55" : ""}`}>
                <div className="flex items-start gap-2 mb-2">
                  <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-500 flex items-center justify-center shrink-0">
                    <span className="text-[9px] font-black text-white">{c.name[0]}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-800"}`}>{c.name}</p>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] opacity-50">{c.time}</span>
                        {c.status !== "pending" && (
                          <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-bold ${c.status === "replied" ? "bg-blue-500/20 text-blue-400" : "bg-emerald-500/20 text-emerald-400"}`}>
                            {c.status === "replied" ? "تم الرد" : "محجوز موعد"}
                          </span>
                        )}
                      </div>
                    </div>
                    <p className="text-[10px] opacity-60 mt-0.5">{c.message}</p>
                  </div>
                </div>

                {c.status === "pending" && (
                  replyingTo === c.id ? (
                    <div className="mt-2 space-y-2">
                      <textarea value={replyText} onChange={e => setReplyText(e.target.value)}
                        placeholder="اكتب ردك هنا..." rows={2}
                        className={`w-full px-3 py-2 rounded-xl text-[11px] border resize-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/30" : "bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400"}`} />
                      <div className="flex flex-wrap gap-1.5 mb-1">
                        {quickReplies.map((r, j) => (
                          <button key={j} onClick={() => setReplyText(r)}
                            className={`px-2 py-1 rounded-lg text-[9px] font-bold border transition-colors ${isDark ? "border-white/10 text-white/50 hover:bg-white/5" : "border-gray-200 text-gray-500 hover:bg-gray-50"}`}>
                            {r}
                          </button>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => sendReply(c.id)} className="flex-1 py-1.5 rounded-lg text-[10px] font-bold bg-cyan-500 text-white hover:bg-cyan-600 flex items-center justify-center gap-1">
                          <Send className="w-3 h-3" /> إرسال
                        </button>
                        <button onClick={() => { setReplyingTo(null); setReplyText(""); }}
                          className={`px-3 py-1.5 rounded-lg text-[10px] font-bold ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-400"}`}>إلغاء</button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-1.5">
                      <button onClick={() => setReplyingTo(c.id)}
                        className={`flex-1 py-1.5 rounded-lg text-[9px] font-bold flex items-center justify-center gap-1 ${isDark ? "bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30" : "bg-cyan-50 text-cyan-600 hover:bg-cyan-100"}`}>
                        <Send className="w-2.5 h-2.5" /> رد سريع
                      </button>
                      <button onClick={() => setBookingFor(c)}
                        className={`flex-1 py-1.5 rounded-lg text-[9px] font-bold flex items-center justify-center gap-1 ${isDark ? "bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30" : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"}`}>
                        <Calendar className="w-2.5 h-2.5" /> موعد
                      </button>
                      <button onClick={() => setConversations(prev => prev.map(cv => cv.id === c.id ? { ...cv, status: "replied" } : cv))}
                        className={`flex-1 py-1.5 rounded-lg text-[9px] font-bold flex items-center justify-center gap-1 ${isDark ? "bg-white/5 text-white/50 hover:bg-white/10" : "bg-gray-50 text-gray-400 hover:bg-gray-100"}`}>
                        تحويل
                      </button>
                    </div>
                  )
                )}
              </div>
            </motion.div>
          ))}
          {conversations.length === 0 && (
            <div className={`p-6 rounded-xl text-center ${isDark ? "bg-[#151a2d]" : "bg-gray-50"}`}>
              <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-400" />
              <p className={`text-xs font-bold ${isDark ? "text-white/40" : "text-gray-400"}`}>لا توجد محادثات معلقة</p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Reply Templates */}
      <div>
        <h4 className={`text-xs font-black mb-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>ردود جاهزة</h4>
        <div className="flex flex-wrap gap-2">
          {quickReplies.map((r, i) => (
            <button key={i} onClick={() => { setReplyText(r); }}
              className={`px-3 py-1.5 rounded-xl text-[10px] font-bold border transition-colors ${isDark ? "border-white/10 text-white/60 hover:bg-white/5" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
              {r}
            </button>
          ))}
          <button className={`px-3 py-1.5 rounded-xl text-[10px] font-bold border border-dashed transition-colors ${isDark ? "border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10" : "border-cyan-300 text-cyan-600 hover:bg-cyan-50"}`}>
            <Plus className="w-3 h-3 inline ml-1" />إضافة
          </button>
        </div>
      </div>

      {/* Appointments */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
            <Calendar className="w-4 h-4 text-emerald-400" />
            المواعيد المجدولة
            {appointments.length > 0 && (
              <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700"}`}>{appointments.length}</span>
            )}
          </h4>
          <button onClick={() => setShowNewAppt(!showNewAppt)}
            className={`text-[9px] font-bold px-2 py-1 rounded-lg flex items-center gap-1 ${isDark ? "bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30" : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"}`}>
            <Plus className="w-3 h-3" /> موعد جديد
          </button>
        </div>

        {/* Manual appointment form */}
        {showNewAppt && (
          <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}
            className={`p-3 rounded-xl border mb-3 ${isDark ? "bg-[#151a2d] border-white/8" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-[10px] font-bold mb-2 ${isDark ? "text-white/50" : "text-gray-500"}`}>إضافة موعد يدوي</p>
            <div className="space-y-2">
              <input value={newApptName} onChange={e => setNewApptName(e.target.value)} placeholder="اسم العميل"
                className={`w-full px-3 py-2 rounded-xl text-xs border ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/30" : "bg-gray-50 border-gray-200"}`} />
              <input value={newApptProp} onChange={e => setNewApptProp(e.target.value)} placeholder="اسم العقار (اختياري)"
                className={`w-full px-3 py-2 rounded-xl text-xs border ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/30" : "bg-gray-50 border-gray-200"}`} />
              <div className="grid grid-cols-2 gap-2">
                <input type="date" value={newApptDate} onChange={e => setNewApptDate(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs border ${isDark ? "bg-white/5 border-white/10 text-white" : "bg-gray-50 border-gray-200"}`} />
                <input type="time" value={newApptTime} onChange={e => setNewApptTime(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs border ${isDark ? "bg-white/5 border-white/10 text-white" : "bg-gray-50 border-gray-200"}`} />
              </div>
              <div className="flex gap-2">
                <button onClick={addManualAppt} className="flex-1 py-1.5 rounded-xl text-xs font-bold bg-emerald-500 text-white hover:bg-emerald-600 transition-colors">إضافة</button>
                <button onClick={() => setShowNewAppt(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-400"}`}>إلغاء</button>
              </div>
            </div>
          </motion.div>
        )}

        <div className="space-y-2">
          {appointments.map((a) => (
            <motion.div key={a.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
              className={`p-3 rounded-xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center shrink-0 ${isDark ? "bg-emerald-500/20" : "bg-emerald-50"}`}>
                  <p className={`text-[8px] font-black ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{a.date}</p>
                  <p className={`text-[8px] ${isDark ? "text-emerald-300/70" : "text-emerald-500/70"}`}>{a.time}</p>
                </div>
                <div className="flex-1">
                  <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-800"}`}>{a.name}</p>
                  <p className="text-[10px] opacity-50">{a.property}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${a.status === "مؤكد" ? isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700" : isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700"}`}>{a.status}</span>
                  {a.status !== "مؤكد" && (
                    <button onClick={() => confirmAppt(a.id)}
                      className={`w-6 h-6 rounded-lg flex items-center justify-center ${isDark ? "bg-emerald-500/20 hover:bg-emerald-500/30" : "bg-emerald-50 hover:bg-emerald-100"}`}>
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    </button>
                  )}
                  <button onClick={() => deleteAppt(a.id)}
                    className={`w-6 h-6 rounded-lg flex items-center justify-center ${isDark ? "bg-red-500/15 hover:bg-red-500/25" : "bg-red-50 hover:bg-red-100"}`}>
                    <Trash2 className="w-3 h-3 text-red-400" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
          {appointments.length === 0 && (
            <div className={`p-6 rounded-xl text-center border border-dashed ${isDark ? "border-white/10" : "border-gray-200"}`}>
              <Calendar className="w-7 h-7 mx-auto mb-2 opacity-30" />
              <p className={`text-xs ${isDark ? "text-white/30" : "text-gray-400"}`}>لا توجد مواعيد مجدولة</p>
              <p className="text-[9px] opacity-40 mt-0.5">احجز موعداً من المحادثات أو أضف يدوياً</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// TEAM MANAGEMENT VIEW — Corporate Broker (Advanced)
// ============================================================================
export function TeamManagementView({ isDark }: { isDark: boolean }) {
  const [members, setMembers] = useState([
    { id: 1, name: "سارة الزهراني", role: "وسيطة عقارية", listings: 12, deals: 5, avatar: "س" },
    { id: 2, name: "محمد العلي", role: "وسيط عقاري", listings: 8, deals: 3, avatar: "م" },
    { id: 3, name: "فاطمة الأحمد", role: "مسوقة عقارية", listings: 6, deals: 2, avatar: "ف" },
  ]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState("وسيط عقاري");
  const [showAISummary, setShowAISummary] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  const totalListings = members.reduce((s, m) => s + m.listings, 0);
  const totalDeals = members.reduce((s, m) => s + m.deals, 0);
  const topMember = [...members].sort((a, b) => b.deals - a.deals)[0];

  const addMember = () => {
    if (!newName.trim()) return;
    setMembers(prev => [...prev, { id: Date.now(), name: newName, role: newRole, listings: 0, deals: 0, avatar: newName[0] }]);
    setNewName(""); setNewRole("وسيط عقاري"); setShowAddForm(false);
  };
  const removeMember = (id: number) => setMembers(prev => prev.filter(m => m.id !== id));

  const generateSummary = () => {
    setShowAISummary(false);
    setAiLoading(true);
    setTimeout(() => { setAiLoading(false); setShowAISummary(true); }, 1800);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className={`p-4 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-gradient-to-br from-amber-900/20 to-orange-900/20 border-amber-500/25" : "bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200"}`}>
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center shadow-lg shrink-0">
          <Users className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>إدارة الفريق</p>
          <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>لوحة تحكم أداء الوسطاء والمبيعات</p>
        </div>
        <div className={`text-[9px] px-2 py-1 rounded-lg font-bold ${isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700"}`}>{members.length} أعضاء</div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "أعضاء الفريق", value: String(members.length), color: "text-amber-400" },
          { label: "إجمالي الإعلانات", value: String(totalListings), color: isDark ? "text-white" : "text-gray-900" },
          { label: "صفقات مغلقة", value: String(totalDeals), color: "text-emerald-400" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-lg font-black ${s.color}`}>{s.value}</p>
            <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Add Member Button */}
      <button onClick={() => setShowAddForm(!showAddForm)}
        className={`w-full py-3 rounded-2xl border border-dashed text-xs font-bold flex items-center justify-center gap-2 transition-colors ${isDark ? "border-amber-500/30 text-amber-400 hover:bg-amber-500/10" : "border-amber-300 text-amber-600 hover:bg-amber-50"}`}>
        <UserPlus className="w-4 h-4" /> إضافة عضو جديد
      </button>

      {/* Add Member Form */}
      {showAddForm && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/8" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-xs font-black mb-3 ${isDark ? "text-white/70" : "text-gray-700"}`}>بيانات العضو الجديد</p>
          <div className="space-y-2 mb-3">
            <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="الاسم الكامل"
              className={`w-full px-3 py-2.5 rounded-xl text-xs border ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/30" : "bg-gray-50 border-gray-200"}`} />
            <select value={newRole} onChange={e => setNewRole(e.target.value)}
              className={`w-full px-3 py-2.5 rounded-xl text-xs border ${isDark ? "bg-[#1a2035] border-white/10 text-white" : "bg-gray-50 border-gray-200 text-gray-900"}`}>
              <option>وسيط عقاري</option>
              <option>وسيطة عقارية</option>
              <option>مس��ق عقاري</option>
              <option>مسوقة عقارية</option>
              <option>مدير مبيعات</option>
              <option>محلل عقاري</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button onClick={addMember} className="flex-1 py-2 rounded-xl text-xs font-bold bg-amber-500 text-white hover:bg-amber-600 transition-colors">إضافة العضو</button>
            <button onClick={() => setShowAddForm(false)}
              className={`px-4 py-2 rounded-xl text-xs font-bold ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-400"}`}>إلغاء</button>
          </div>
        </motion.div>
      )}

      {/* Members List */}
      <div>
        <h4 className={`text-xs font-black mb-3 flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
          <Users className="w-4 h-4 text-amber-400" /> أعضاء الفريق
        </h4>
        <div className="space-y-2">
          {members.map((m, i) => (
            <motion.div key={m.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}
              className={`p-3 rounded-xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shrink-0">
                  <span className="text-sm font-black text-white">{m.avatar}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{m.name}</p>
                  <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>{m.role}</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-center">
                    <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{m.listings}</p>
                    <p className="text-[8px] opacity-40">إعلان</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-black text-emerald-400">{m.deals}</p>
                    <p className="text-[8px] opacity-40">صفقة</p>
                  </div>
                  <button onClick={() => removeMember(m.id)}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center ${isDark ? "bg-red-500/15 hover:bg-red-500/25" : "bg-red-50 hover:bg-red-100"}`}>
                    <Trash2 className="w-3.5 h-3.5 text-red-400" />
                  </button>
                </div>
              </div>
              <div className="mt-2">
                <div className={`h-1 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                  <div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all"
                    style={{ width: `${Math.min(100, totalDeals > 0 ? (m.deals / totalDeals) * 100 : 0)}%` }} />
                </div>
              </div>
            </motion.div>
          ))}
          {members.length === 0 && (
            <div className={`p-6 rounded-xl text-center border border-dashed ${isDark ? "border-white/10" : "border-gray-200"}`}>
              <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className={`text-xs ${isDark ? "text-white/30" : "text-gray-400"}`}>لا يوجد أعضاء في الفريق بعد</p>
            </div>
          )}
        </div>
      </div>

      {/* AI Summary Button */}
      <button onClick={generateSummary} disabled={aiLoading}
        className="w-full py-3.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white shadow-lg transition-all disabled:opacity-70">
        {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        {aiLoading ? "جاري التحليل..." : "تلخيص أداء الفريق بالذكاء الاصطناعي"}
      </button>

      {/* AI Summary Result */}
      {showAISummary && !aiLoading && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/20" : "bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200"}`}>
          <div className="flex items-center gap-2 mb-3">
            <BrainCircuit className="w-4 h-4 text-purple-400" />
            <span className={`text-xs font-black ${isDark ? "text-purple-400" : "text-purple-700"}`}>تلخيص AI لأداء الفريق</span>
          </div>
          <div className="space-y-2">
            {[
              { label: "أفضل موظف", value: topMember?.name || "—", color: "text-amber-400", icon: Award },
              { label: "إجمالي الإعلانات", value: `${totalListings} إعلان`, color: isDark ? "text-white" : "text-gray-900", icon: Building },
              { label: "الصفقات المغلقة", value: `${totalDeals} صفقة`, color: "text-emerald-400", icon: CheckCircle },
              { label: "متوسط الأداء", value: `${(totalDeals / Math.max(1, members.length)).toFixed(1)} صفقة/عضو`, color: "text-blue-400", icon: BarChart3 },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className={`flex items-center justify-between p-2.5 rounded-xl ${isDark ? "bg-white/5" : "bg-white/70"}`}>
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 opacity-50" />
                    <span className={`text-[10px] ${isDark ? "text-white/50" : "text-gray-500"}`}>{item.label}</span>
                  </div>
                  <span className={`text-xs font-black ${item.color}`}>{item.value}</span>
                </div>
              );
            })}
          </div>
          <p className={`text-[10px] leading-5 mt-3 ${isDark ? "text-white/60" : "text-gray-600"}`}>
            الفريق يعمل بكفاءة جيدة. <strong className="text-emerald-400">{topMember?.name}</strong> هو الأفضل أداءً بـ {topMember?.deals} صفقات. يُنصح بمتابعة باقي الأعضاء وتفعيل نظام الحوافز لرفع معدل الإغلاق.
          </p>
        </motion.div>
      )}
    </div>
  );
}

// ============================================================================
// MY REQUESTS VIEW — All Users (Published / Draft)
// ============================================================================
export function MyRequestsView({ isDark, isBroker = false, onNavigateToClients }: { isDark: boolean; isBroker?: boolean; onNavigateToClients?: () => void }) {
  const [activeTab, setActiveTab] = useState<"published" | "draft" | "client_requests">("published");
  const [requests, setRequests] = useState([
    { id: 1, title: "مطلوب شقة 3 غرف", type: "شراء", location: "الرياض - حي النرجس", priceMin: "800,000", priceMax: "1,200,000", date: "منذ يومين", status: "published", views: 42 },
    { id: 2, title: "مطلوب فيلا مع مسبح", type: "إيجار", location: "جدة - الشاطئ", priceMin: "15,000", priceMax: "25,000", date: "منذ أسبوع", status: "published", views: 18 },
    { id: 3, title: "مطلوب مكتب تجاري", type: "إيجار", location: "الرياض - العليا", priceMin: "50,000", priceMax: "80,000", date: "اليوم", status: "draft", views: 0 },
    { id: 4, title: "مطلوب أرض سكنية 500م²", type: "شراء", location: "الدمام", priceMin: "500,000", priceMax: "700,000", date: "أمس", status: "draft", views: 0 },
  ]);

  const [clientRequests] = useState([
    { id: 101, name: "فهد المطيري", avatar: "ف", propType: "فيلا", location: "حي النرجس، الرياض", priceMin: "2,000,000", priceMax: "3,500,000", purpose: "شراء", time: "منذ ساعتين", match: "منطقتك" },
    { id: 102, name: "نورة العتيبي", avatar: "ن", propType: "شقة 3 غرف", location: "حي الملقا، الرياض", priceMin: "700,000", priceMax: "950,000", purpose: "شراء", time: "منذ 5 ساعات", match: "منطقتك" },
    { id: 103, name: "سلطان الدوسري", avatar: "س", propType: "مكتب تجاري", location: "العليا، الرياض", priceMin: "60,000", priceMax: "100,000", purpose: "إيجار", time: "أمس", match: "قريب منك" },
    { id: 104, name: "هنادي الشهراني", avatar: "ه", propType: "دوبلكس", location: "حي الحمراء، الرياض", priceMin: "1,500,000", priceMax: "2,200,000", purpose: "شراء", time: "منذ يومين", match: "منطقتك" },
    { id: 105, name: "عبدالرحمن الغامدي", avatar: "ع", propType: "أرض سكنية", location: "شمال الرياض", priceMin: "800,000", priceMax: "1,400,000", purpose: "شراء", time: "منذ 3 أيام", match: "قريب منك" },
  ]);
  const [addedClients, setAddedClients] = useState<number[]>([104]);
  const [callingId, setCallingId] = useState<number | null>(null);
  const [navigatingId, setNavigatingId] = useState<number | null>(null);

  const filtered = requests.filter(r => r.status === (activeTab === "published" ? "published" : "draft"));
  const pubCount = requests.filter(r => r.status === "published").length;
  const draftCount = requests.filter(r => r.status === "draft").length;

  const toggleStatus = (id: number) =>
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: r.status === "published" ? "draft" : "published", views: r.status === "draft" ? 0 : r.views } : r));
  const deleteRequest = (id: number) =>
    setRequests(prev => prev.filter(r => r.id !== id));

  const handleCall = (id: number) => {
    setCallingId(id);
    setTimeout(() => setCallingId(null), 2200);
  };

  const handleAddToClients = (id: number) => {
    setAddedClients(prev => [...prev, id]);
    setNavigatingId(id);
    setTimeout(() => {
      setNavigatingId(null);
      if (onNavigateToClients) onNavigateToClients();
    }, 800);
  };

  const tabs = isBroker
    ? [
        { key: "published", label: "طلباتي المنشورة", count: pubCount, icon: Globe },
        { key: "client_requests", label: "طلبات العملاء", count: clientRequests.length, icon: Users },
      ]
    : [
        { key: "published", label: "الطلبات المنشورة", count: pubCount, icon: Globe },
        { key: "draft", label: "غير المنشورة", count: draftCount, icon: EyeOff },
      ];

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <div className={`flex rounded-2xl p-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
        {tabs.map(tab => {
          const Icon = tab.icon;
          const active = activeTab === tab.key;
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key as any)}
              className={`flex-1 py-2.5 px-2 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all ${active ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : isDark ? "text-white/40" : "text-gray-400"}`}>
              <Icon className="w-3.5 h-3.5" />
              {tab.label}
              <span className={`min-w-[18px] h-[18px] rounded-full text-[9px] font-black flex items-center justify-center px-1 ${active ? tab.key === "client_requests" ? "bg-emerald-500 text-white" : "bg-cyan-500 text-white" : isDark ? "bg-white/10 text-white/40" : "bg-gray-200 text-gray-400"}`}>{tab.count}</span>
            </button>
          );
        })}
      </div>

      {/* BROKER CLIENT REQUESTS TAB */}
      {activeTab === "client_requests" && isBroker && (
        <div className="space-y-3">
          {/* Info Banner */}
          <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${isDark ? "bg-cyan-500/10 border-cyan-500/20" : "bg-cyan-50 border-cyan-200"}`}>
            <Bell className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <p className={`text-[10px] font-black ${isDark ? "text-cyan-300" : "text-cyan-700"}`}>طلبات باحثين في نفس مناطق نشاطك</p>
              <p className={`text-[9px] mt-0.5 ${isDark ? "text-cyan-400/70" : "text-cyan-600/80"}`}>يمكنك التواصل مع الباحثين مباشرة أو إضافتهم لإدارة العملاء</p>
            </div>
          </div>

          {clientRequests.map((cr, i) => {
            const isAdded = addedClients.includes(cr.id);
            const isCalling = callingId === cr.id;
            const isNavigating = navigatingId === cr.id;
            return (
              <motion.div key={cr.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
                className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                {/* Header Row */}
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-500 flex items-center justify-center shrink-0">
                    <span className="text-sm font-black text-white">{cr.avatar}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{cr.name}</p>
                      <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-bold shrink-0 ${isDark ? "bg-cyan-500/20 text-cyan-400" : "bg-cyan-100 text-cyan-700"}`}>{cr.match}</span>
                    </div>
                    <p className={`text-[9px] mt-0.5 flex items-center gap-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>
                      <MapPin className="w-2.5 h-2.5" />{cr.location}
                    </p>
                  </div>
                </div>

                {/* Request Details */}
                <div className={`p-2.5 rounded-xl mb-3 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${cr.purpose === "شراء" ? isDark ? "bg-blue-500/20 text-blue-400" : "bg-blue-100 text-blue-700" : isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"}`}>{cr.purpose}</span>
                      <span className={`text-[9px] font-bold ${isDark ? "text-white/70" : "text-gray-700"}`}>{cr.propType}</span>
                    </div>
                    <span className={`text-[8px] ${isDark ? "text-white/30" : "text-gray-400"}`}>{cr.time}</span>
                  </div>
                  <p className={`text-[10px] font-bold flex items-center gap-0.5 ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>
                    <DollarSign className="w-3 h-3" />{cr.priceMin} — {cr.priceMax} ﷼
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCall(cr.id)}
                    className={`flex-1 py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1.5 transition-all ${isCalling ? "bg-emerald-500 text-white scale-95" : isDark ? "bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30" : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"}`}>
                    <Phone className="w-3 h-3" />
                    {isCalling ? "جاري الاتصال..." : "اتصال"}
                  </button>
                  <button
                    onClick={() => !isAdded && handleAddToClients(cr.id)}
                    disabled={isAdded}
                    className={`flex-1 py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1.5 transition-all ${isAdded ? isDark ? "bg-blue-500/20 text-blue-400 opacity-60 cursor-default" : "bg-blue-100 text-blue-600 opacity-60 cursor-default" : isDark ? "bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 active:scale-95" : "bg-blue-50 text-blue-600 hover:bg-blue-100 active:scale-95"}`}>
                    {isNavigating ? (
                      <><Loader2 className="w-3 h-3 animate-spin" /> جاري الانتقال...</>
                    ) : isAdded ? (
                      <><CheckCircle className="w-3 h-3" /> تمت الإضافة</>
                    ) : (
                      <><UserPlus className="w-3 h-3" /> إضافة لإدارة العملاء</>
                    )}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* NORMAL MY REQUESTS LIST */}
      {activeTab !== "client_requests" && (
        <div className="space-y-3">
          {filtered.map((r, i) => (
            <motion.div key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-black truncate ${isDark ? "text-white" : "text-gray-900"}`}>{r.title}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${r.type === "شراء" ? isDark ? "bg-blue-500/20 text-blue-400" : "bg-blue-100 text-blue-700" : isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"}`}>{r.type}</span>
                    <span className={`text-[9px] flex items-center gap-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}><MapPin className="w-2.5 h-2.5" />{r.location}</span>
                  </div>
                </div>
                <span className={`text-[8px] px-2 py-1 rounded-full font-bold shrink-0 ${r.status === "published" ? isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700" : isDark ? "bg-gray-500/20 text-gray-400" : "bg-gray-100 text-gray-500"}`}>
                  {r.status === "published" ? "منشور" : "مسودة"}
                </span>
              </div>
              <div className={`text-[10px] font-bold mb-2 flex items-center gap-0.5 ${isDark ? "text-cyan-400" : "text-cyan-600"}`}>
                <DollarSign className="w-3 h-3" />{r.priceMin} — {r.priceMax} ﷼
              </div>
              <div className={`flex items-center justify-between text-[9px] mb-3 ${isDark ? "text-white/30" : "text-gray-400"}`}>
                <span>{r.date}</span>
                {r.status === "published" && <span className="flex items-center gap-0.5"><Eye className="w-2.5 h-2.5" />{r.views} مشاهدة</span>}
              </div>
              <div className="flex gap-2">
                <button onClick={() => toggleStatus(r.id)}
                  className={`flex-1 py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition-colors ${r.status === "published" ? isDark ? "bg-amber-500/20 text-amber-400 hover:bg-amber-500/30" : "bg-amber-50 text-amber-600 hover:bg-amber-100" : "bg-emerald-500 text-white hover:bg-emerald-600"}`}>
                  {r.status === "published" ? <><EyeOff className="w-3 h-3" /> إلغاء النشر</> : <><Globe className="w-3 h-3" /> نشر الطلب</>}
                </button>
                <button onClick={() => deleteRequest(r.id)}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center ${isDark ? "bg-red-500/15 text-red-400 hover:bg-red-500/25" : "bg-red-50 text-red-500 hover:bg-red-100"}`}>
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          ))}
          {filtered.length === 0 && (
            <div className={`p-8 rounded-2xl text-center ${isDark ? "bg-[#151a2d]" : "bg-gray-50"}`}>
              <FileText className="w-10 h-10 mx-auto mb-3 opacity-20" />
              <p className={`text-xs font-bold ${isDark ? "text-white/30" : "text-gray-400"}`}>
                {activeTab === "published" ? "لا توجد طلبات منشورة" : "لا توجد طلبات في المسودة"}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// BROKER LISTINGS VIEW — Published Properties with Edit
// ============================================================================
export function BrokerListingsView({ isDark }: { isDark: boolean }) {
  const [listings, setListings] = useState([
    { id: 1, title: "فيلا مودرن النرجس", type: "فيلا", location: "حي النرجس، الرياض", price: "2,500,000", rooms: 5, status: "active", views: 284, inquiries: 12, img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&q=80" },
    { id: 2, title: "شقة العليا 3 غرف", type: "شقة", location: "حي العليا، الرياض", price: "850,000", rooms: 3, status: "active", views: 156, inquiries: 7, img: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400&q=80" },
    { id: 3, title: "أرض تجارية حطين", type: "أرض", location: "حطين، الرياض", price: "4,200,000", rooms: 0, status: "paused", views: 89, inquiries: 3, img: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&q=80" },
    { id: 4, title: "دوبلكس الملقا الراقي", type: "دوبلكس", location: "الملقا، الرياض", price: "1,800,000", rooms: 4, status: "active", views: 411, inquiries: 18, img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=400&q=80" },
  ]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editPrice, setEditPrice] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "paused">("all");
  const [showBulkModal, setShowBulkModal] = useState(false);

  const filtered = filter === "all" ? listings : listings.filter(l => l.status === filter);
  const activeCount = listings.filter(l => l.status === "active").length;
  const pausedCount = listings.filter(l => l.status === "paused").length;

  const toggleStatus = (id: number) => {
    setListings(prev => prev.map(l => l.id === id ? { ...l, status: l.status === "active" ? "paused" : "active" } : l));
  };
  const savePrice = (id: number) => {
    if (!editPrice.trim()) return;
    setListings(prev => prev.map(l => l.id === id ? { ...l, price: editPrice } : l));
    setEditingId(null);
    setEditPrice("");
  };
  const deleteListing = (id: number) => setListings(prev => prev.filter(l => l.id !== id));

  return (
    <div className="space-y-4">
      {/* Summary Row */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "إجمالي العروض", value: listings.length.toString(), color: "blue" },
          { label: "نشط", value: activeCount.toString(), color: "emerald" },
          { label: "موقوف", value: pausedCount.toString(), color: "amber" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`font-black text-base ${s.color === "blue" ? isDark ? "text-blue-400" : "text-blue-600" : s.color === "emerald" ? isDark ? "text-emerald-400" : "text-emerald-600" : isDark ? "text-amber-400" : "text-amber-600"}`}>{s.value}</p>
            <p className={`text-[9px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filter Tabs + Bulk Update Button */}
      <div className="flex items-center gap-2">
        <div className={`flex flex-1 rounded-xl p-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
          {(["all", "active", "paused"] as const).map(tab => (
            <button key={tab} onClick={() => setFilter(tab)}
              className={`flex-1 py-2 rounded-lg text-[11px] font-bold transition-all ${filter === tab ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : isDark ? "text-white/40" : "text-gray-400"}`}>
              {tab === "all" ? `الكل (${listings.length})` : tab === "active" ? `نشط (${activeCount})` : `موقوف (${pausedCount})`}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowBulkModal(true)}
          className={`shrink-0 px-3 py-2 rounded-xl text-[11px] font-black flex items-center gap-1.5 border transition-all ${isDark ? "bg-cyan-500/15 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/25" : "bg-cyan-50 border-cyan-200 text-cyan-600 hover:bg-cyan-100"}`}
        >
          <ArrowUpDown className="w-3.5 h-3.5" />
          تحديث جماعي
        </button>
      </div>

      {/* Bulk Update Modal */}
      <AnimatePresence>
        {showBulkModal && (
          <BulkUpdateModal isDark={isDark} listings={listings} onClose={() => setShowBulkModal(false)} />
        )}
      </AnimatePresence>

      {/* Listings */}
      <div className="space-y-3">
        {filtered.map((l, i) => (
          <motion.div key={l.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
            className={`rounded-2xl border overflow-hidden ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            {/* Image + Badge */}
            <div className="relative h-28 overflow-hidden">
              <img src={l.img} alt={l.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
              <div className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-[9px] font-black ${l.status === "active" ? "bg-emerald-500 text-white" : "bg-amber-500 text-white"}`}>
                {l.status === "active" ? "● نشط" : "⏸ موقوف"}
              </div>
              <div className={`absolute top-2 left-2 px-2 py-0.5 rounded-full text-[9px] font-bold ${isDark ? "bg-black/50 text-white/80" : "bg-white/90 text-gray-700"}`}>
                {l.type}
              </div>
              <div className="absolute bottom-2 right-2">
                <p className="text-white font-black text-sm drop-shadow-lg">{l.title}</p>
                <p className="text-white/70 text-[10px] flex items-center gap-0.5"><MapPin className="w-2.5 h-2.5" />{l.location}</p>
              </div>
            </div>

            {/* Content */}
            <div className="p-3 space-y-2">
              {/* Price Row */}
              <div className="flex items-center justify-between">
                {editingId === l.id ? (
                  <div className="flex items-center gap-1.5 flex-1 ml-2">
                    <input
                      type="text"
                      value={editPrice}
                      onChange={e => setEditPrice(e.target.value)}
                      placeholder={l.price}
                      className={`flex-1 text-xs px-2.5 py-1.5 rounded-xl border outline-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/30" : "bg-gray-50 border-gray-200 text-gray-900"}`}
                      autoFocus
                    />
                    <button onClick={() => savePrice(l.id)} className="px-2.5 py-1.5 rounded-xl bg-emerald-500 text-white text-[10px] font-black">حفظ</button>
                    <button onClick={() => setEditingId(null)} className={`px-2.5 py-1.5 rounded-xl text-[10px] font-bold ${isDark ? "bg-white/10 text-white/60" : "bg-gray-100 text-gray-500"}`}>إلغاء</button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className={`font-black text-sm ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{l.price} ﷼</span>
                    <button onClick={() => { setEditingId(l.id); setEditPrice(l.price); }}
                      className={`p-1 rounded-lg transition-colors ${isDark ? "hover:bg-white/10 text-white/40 hover:text-white" : "hover:bg-gray-100 text-gray-400 hover:text-gray-700"}`}>
                      <Edit3 className="w-3 h-3" />
                    </button>
                  </div>
                )}
                {editingId !== l.id && (
                  <div className={`flex items-center gap-2 text-[9px] ${isDark ? "text-white/30" : "text-gray-400"}`}>
                    <span className="flex items-center gap-0.5"><Eye className="w-2.5 h-2.5" />{l.views}</span>
                    <span className="flex items-center gap-0.5"><MessageSquare className="w-2.5 h-2.5" />{l.inquiries}</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-1.5">
                <button onClick={() => toggleStatus(l.id)}
                  className={`flex-1 py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition-colors ${l.status === "active" ? isDark ? "bg-amber-500/15 text-amber-400 hover:bg-amber-500/25" : "bg-amber-50 text-amber-600 hover:bg-amber-100" : "bg-emerald-500 text-white hover:bg-emerald-600"}`}>
                  {l.status === "active" ? <><EyeOff className="w-3 h-3" /> إيقاف</> : <><Eye className="w-3 h-3" /> تفعيل</>}
                </button>
                <button className={`flex-1 py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 ${isDark ? "bg-blue-500/15 text-blue-400 hover:bg-blue-500/25" : "bg-blue-50 text-blue-600 hover:bg-blue-100"}`}>
                  <Edit3 className="w-3 h-3" /> تعديل الإعلان
                </button>
                <button onClick={() => deleteListing(l.id)}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center ${isDark ? "bg-red-500/15 text-red-400 hover:bg-red-500/25" : "bg-red-50 text-red-500 hover:bg-red-100"}`}>
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// BULK UPDATE MODAL — embedded inside BrokerListingsView
// ============================================================================
function BulkUpdateModal({ isDark, listings, onClose }: { isDark: boolean; listings: any[]; onClose: () => void }) {
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [updateType, setUpdateType] = useState<"price" | "status" | "description" | null>(null);
  const [priceAction, setPriceAction] = useState<"increase" | "decrease">("decrease");
  const [pricePercent, setPricePercent] = useState("5");
  const [newStatus, setNewStatus] = useState<"active" | "paused">("active");
  const [descNote, setDescNote] = useState("");
  const [applied, setApplied] = useState(false);
  const [loading, setLoading] = useState(false);

  const toggleSelect = (id: number) => {
    setSelectedIds(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });
  };
  const selectAll = () => setSelectedIds(new Set(listings.map(l => l.id)));
  const clearAll = () => setSelectedIds(new Set());

  const handleApply = () => {
    if (selectedIds.size === 0 || !updateType) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); setApplied(true); }, 1500);
  };

  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[80]"
        onClick={onClose}
      />
      {/* Sheet */}
      <motion.div
        initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 60 }}
        transition={{ type: "spring", damping: 28, stiffness: 300 }}
        className={`fixed inset-x-0 bottom-0 z-[81] rounded-t-3xl flex flex-col max-h-[85vh] border-t ${isDark ? "bg-[#0d1424] border-white/10" : "bg-white border-gray-200"}`}
      >
        {/* Handle + Header */}
        <div className="px-5 pt-4 pb-3 shrink-0">
          <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isDark ? "bg-cyan-500/20" : "bg-cyan-100"}`}>
                <ArrowUpDown className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>تحديث جماعي</p>
                <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>حدّث كل عروضك دفعة واحدة</p>
              </div>
            </div>
            <button onClick={onClose} className={`w-8 h-8 rounded-xl flex items-center justify-center ${isDark ? "bg-white/8 text-white/60" : "bg-gray-100 text-gray-500"}`}>
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 pb-8 space-y-4">
          {applied ? (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center py-10 gap-4 text-center">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center shadow-xl shadow-emerald-500/30">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className={`font-black text-base mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>تم التحديث بنجاح! 🎉</p>
                <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>تم تحديث {selectedIds.size} عروض بنجاح</p>
              </div>
              <button onClick={onClose} className="w-full py-3 rounded-2xl font-black text-sm bg-gradient-to-r from-emerald-500 to-cyan-500 text-white shadow-lg">إغلاق</button>
            </motion.div>
          ) : (
            <>
              {/* Select All */}
              <div className="flex items-center justify-between">
                <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>{selectedIds.size} مختار من {listings.length}</p>
                <div className="flex gap-2">
                  <button onClick={selectAll} className={`text-[10px] font-bold px-2.5 py-1 rounded-lg ${isDark ? "bg-white/10 text-white/70 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>اختيار الكل</button>
                  <button onClick={clearAll} className={`text-[10px] font-bold px-2.5 py-1 rounded-lg ${isDark ? "bg-white/5 text-white/40" : "bg-gray-50 text-gray-400"}`}>إلغاء</button>
                </div>
              </div>

              {/* Listings Checkboxes */}
              <div className="space-y-2">
                {listings.map((l, i) => (
                  <motion.button key={l.id} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                    onClick={() => toggleSelect(l.id)}
                    className={`w-full p-3 rounded-xl border flex items-center gap-3 text-right transition-all ${selectedIds.has(l.id) ? isDark ? "border-cyan-500/50 bg-cyan-500/10" : "border-cyan-400 bg-cyan-50" : isDark ? "border-white/8 bg-[#151a2d] hover:border-white/15" : "border-gray-100 bg-white shadow-sm"}`}>
                    <div className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center shrink-0 transition-all ${selectedIds.has(l.id) ? "bg-cyan-500 border-cyan-500" : isDark ? "border-white/20" : "border-gray-300"}`}>
                      {selectedIds.has(l.id) && <CheckCircle className="w-3 h-3 text-white" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-bold truncate ${isDark ? "text-white" : "text-gray-900"}`}>{l.title}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={`text-[9px] font-bold ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{l.price} ﷼</span>
                        <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${l.status === "active" ? isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700" : isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700"}`}>
                          {l.status === "active" ? "نشط" : "موقوف"}
                        </span>
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>

              {/* Update Type */}
              <div className="space-y-2">
                <p className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>نوع التحديث</p>
                <div className="grid grid-cols-3 gap-2">
                  {([
                    { key: "price" as const, label: "تعديل السعر", icon: DollarSign },
                    { key: "status" as const, label: "تغيير الحالة", icon: ToggleRight },
                    { key: "description" as const, label: "إضافة ملاحظة", icon: FileText },
                  ]).map(t => {
                    const Icon = t.icon;
                    const active = updateType === t.key;
                    return (
                      <button key={t.key} onClick={() => setUpdateType(t.key)}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${active ? isDark ? "border-cyan-500/50 bg-cyan-500/15" : "border-cyan-400 bg-cyan-50" : isDark ? "border-white/8 bg-white/3 hover:border-white/15" : "border-gray-100 bg-white"}`}>
                        <Icon className={`w-4 h-4 ${active ? isDark ? "text-cyan-400" : "text-cyan-600" : isDark ? "text-white/30" : "text-gray-400"}`} />
                        <span className={`text-[9px] font-bold text-center leading-tight ${active ? isDark ? "text-white" : "text-gray-900" : isDark ? "text-white/30" : "text-gray-400"}`}>{t.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Price Options */}
              {updateType === "price" && (
                <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-xl border space-y-2.5 ${isDark ? "bg-white/3 border-white/8" : "bg-gray-50 border-gray-100"}`}>
                  <div className="flex gap-2">
                    {(["decrease", "increase"] as const).map(a => (
                      <button key={a} onClick={() => setPriceAction(a)}
                        className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${priceAction === a ? a === "decrease" ? "bg-emerald-500 text-white" : "bg-red-500 text-white" : isDark ? "bg-white/5 text-white/40" : "bg-white text-gray-400 border border-gray-200"}`}>
                        {a === "decrease" ? "تخفيض" : "زيادة"}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="number" value={pricePercent} onChange={e => setPricePercent(e.target.value)} min="1" max="50"
                      className={`flex-1 text-sm px-3 py-2 rounded-xl border outline-none font-bold ${isDark ? "bg-white/5 border-white/10 text-white" : "bg-white border-gray-200 text-gray-900"}`} />
                    <span className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>%</span>
                  </div>
                </motion.div>
              )}

              {updateType === "status" && (
                <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-xl border space-y-2 ${isDark ? "bg-white/3 border-white/8" : "bg-gray-50 border-gray-100"}`}>
                  <div className="flex gap-2">
                    {(["active", "paused"] as const).map(s => (
                      <button key={s} onClick={() => setNewStatus(s)}
                        className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${newStatus === s ? s === "active" ? "bg-emerald-500 text-white" : "bg-amber-500 text-white" : isDark ? "bg-white/5 text-white/40" : "bg-white text-gray-400 border border-gray-200"}`}>
                        {s === "active" ? "تفعيل الكل" : "إيقاف الكل"}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {updateType === "description" && (
                <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-xl border space-y-2 ${isDark ? "bg-white/3 border-white/8" : "bg-gray-50 border-gray-100"}`}>
                  <textarea value={descNote} onChange={e => setDescNote(e.target.value)} rows={3}
                    placeholder="ملاحظة تُضاف لجميع العروض المختارة..."
                    className={`w-full text-xs px-3 py-2 rounded-xl border outline-none resize-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/25" : "bg-white border-gray-200 text-gray-900 placeholder-gray-300"}`} />
                </motion.div>
              )}

              {/* Apply Button */}
              <motion.button onClick={handleApply} disabled={selectedIds.size === 0 || !updateType || loading} whileTap={{ scale: 0.98 }}
                className={`w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all ${selectedIds.size > 0 && updateType ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg shadow-cyan-500/20" : isDark ? "bg-white/5 text-white/30" : "bg-gray-100 text-gray-400"}`}>
                {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> جاري التطبيق...</> : <><ArrowUpDown className="w-4 h-4" /> تطبيق التحديث على {selectedIds.size} عروض</>}
              </motion.button>
            </>
          )}
        </div>
      </motion.div>
    </>
  );
}

// ============================================================================
// BROKER BULK UPDATE VIEW — Bulk Update All Listings
// ============================================================================
export function BrokerBulkUpdateView({ isDark }: { isDark: boolean }) {
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [updateType, setUpdateType] = useState<"price" | "status" | "description" | null>(null);
  const [priceAction, setPriceAction] = useState<"increase" | "decrease">("decrease");
  const [pricePercent, setPricePercent] = useState("5");
  const [newStatus, setNewStatus] = useState<"active" | "paused">("active");
  const [descNote, setDescNote] = useState("");
  const [applied, setApplied] = useState(false);
  const [loading, setLoading] = useState(false);

  const listings = [
    { id: 1, title: "فيلا مودرن النرجس", price: "2,500,000", status: "active", type: "فيلا" },
    { id: 2, title: "شقة العليا 3 غرف", price: "850,000", status: "active", type: "شقة" },
    { id: 3, title: "أرض تجارية حطين", price: "4,200,000", status: "paused", type: "أرض" },
    { id: 4, title: "دوبلكس الملقا الراقي", price: "1,800,000", status: "active", type: "دوبلكس" },
  ];

  const toggleSelect = (id: number) => {
    setSelectedIds(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });
  };
  const selectAll = () => setSelectedIds(new Set(listings.map(l => l.id)));
  const clearAll = () => setSelectedIds(new Set());

  const handleApply = () => {
    if (selectedIds.size === 0 || !updateType) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); setApplied(true); }, 1500);
  };

  if (applied) {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center py-16 gap-5 text-center">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center shadow-2xl shadow-emerald-500/30">
          <CheckCircle className="w-10 h-10 text-white" />
        </div>
        <div>
          <p className={`font-black text-base mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>تم التحديث بنجاح! 🎉</p>
          <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>تم تحديث {selectedIds.size} عروض بنجاح</p>
        </div>
        <div className={`w-full p-4 rounded-2xl border ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-[11px] font-bold mb-2 ${isDark ? "text-white/60" : "text-gray-500"}`}>ملخص التحديث</p>
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className={isDark ? "text-white/50" : "text-gray-500"}>نوع التحديث</span>
              <span className={`font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{updateType === "price" ? "تعديل السعر" : updateType === "status" ? "تغيير الحالة" : "إضافة ملاحظة"}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className={isDark ? "text-white/50" : "text-gray-500"}>العروض المحدثة</span>
              <span className={`font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{selectedIds.size} عروض</span>
            </div>
          </div>
        </div>
        <button onClick={() => { setApplied(false); setSelectedIds(new Set()); setUpdateType(null); }}
          className="w-full py-3.5 rounded-2xl font-black text-sm bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-500/20">
          تحديث جماعي آخر
        </button>
      </motion.div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Info */}
      <div className={`p-3 rounded-2xl border flex items-start gap-3 ${isDark ? "bg-blue-500/10 border-blue-500/20" : "bg-blue-50 border-blue-200"}`}>
        <ArrowUpDown className={`w-4 h-4 mt-0.5 shrink-0 ${isDark ? "text-blue-400" : "text-blue-600"}`} />
        <p className={`text-xs leading-relaxed ${isDark ? "text-blue-300" : "text-blue-700"}`}>
          اختر العروض التي تريد تحديثها، ثم حدد نوع التحديث وطبّقه على الكل دفعة واحدة.
        </p>
      </div>

      {/* Select All / Clear */}
      <div className="flex items-center justify-between">
        <p className={`text-xs font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>{selectedIds.size} مختار من {listings.length}</p>
        <div className="flex gap-2">
          <button onClick={selectAll} className={`text-[10px] font-bold px-2.5 py-1 rounded-lg ${isDark ? "bg-white/10 text-white/70 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>اختيار الكل</button>
          <button onClick={clearAll} className={`text-[10px] font-bold px-2.5 py-1 rounded-lg ${isDark ? "bg-white/5 text-white/40" : "bg-gray-50 text-gray-400"}`}>إلغاء الكل</button>
        </div>
      </div>

      {/* Listings Checkboxes */}
      <div className="space-y-2">
        {listings.map((l, i) => (
          <motion.button key={l.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            onClick={() => toggleSelect(l.id)}
            className={`w-full p-3 rounded-2xl border flex items-center gap-3 text-right transition-all ${selectedIds.has(l.id) ? isDark ? "border-blue-500/50 bg-blue-500/10" : "border-blue-400 bg-blue-50" : isDark ? "border-white/8 bg-[#151a2d] hover:border-white/15" : "border-gray-100 bg-white shadow-sm hover:border-gray-300"}`}>
            <div className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center shrink-0 transition-all ${selectedIds.has(l.id) ? "bg-blue-500 border-blue-500" : isDark ? "border-white/20" : "border-gray-300"}`}>
              {selectedIds.has(l.id) && <CheckCircle className="w-3 h-3 text-white" />}
            </div>
            <div className="flex-1 min-w-0 text-right">
              <p className={`text-xs font-bold truncate ${isDark ? "text-white" : "text-gray-900"}`}>{l.title}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={`text-[9px] font-bold ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{l.price} ﷼</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${l.status === "active" ? isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700" : isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700"}`}>
                  {l.status === "active" ? "نشط" : "موقوف"}
                </span>
              </div>
            </div>
          </motion.button>
        ))}
      </div>

      {/* Update Type Selector */}
      <div className="space-y-2">
        <p className={`text-xs font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>نوع التحديث الجماعي</p>
        <div className="grid grid-cols-3 gap-2">
          {([
            { key: "price" as const, label: "تعديل السعر", icon: DollarSign, color: "cyan" },
            { key: "status" as const, label: "تغيير الحالة", icon: ToggleRight, color: "emerald" },
            { key: "description" as const, label: "إضافة ملاحظة", icon: FileText, color: "purple" },
          ]).map(t => {
            const Icon = t.icon;
            const active = updateType === t.key;
            return (
              <button key={t.key} onClick={() => setUpdateType(t.key)}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${active ? isDark ? "border-cyan-500/50 bg-cyan-500/15" : "border-cyan-400 bg-cyan-50" : isDark ? "border-white/8 bg-white/3 hover:border-white/15" : "border-gray-100 bg-white hover:border-gray-300"}`}>
                <Icon className={`w-4 h-4 ${active ? isDark ? "text-cyan-400" : "text-cyan-600" : isDark ? "text-white/40" : "text-gray-400"}`} />
                <span className={`text-[9px] font-bold text-center leading-tight ${active ? isDark ? "text-white" : "text-gray-900" : isDark ? "text-white/40" : "text-gray-400"}`}>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Update Options */}
      {updateType === "price" && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border space-y-3 ${isDark ? "bg-white/3 border-white/8" : "bg-gray-50 border-gray-100"}`}>
          <p className={`text-[11px] font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>اتجاه تعديل السعر</p>
          <div className="flex gap-2">
            {(["decrease", "increase"] as const).map(a => (
              <button key={a} onClick={() => setPriceAction(a)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${priceAction === a ? a === "decrease" ? "bg-emerald-500 text-white" : "bg-red-500 text-white" : isDark ? "bg-white/5 text-white/40" : "bg-white text-gray-400 border border-gray-200"}`}>
                {a === "decrease" ? "تخفيض" : "زيادة"}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <input type="number" value={pricePercent} onChange={e => setPricePercent(e.target.value)} min="1" max="50"
              className={`flex-1 text-sm px-3 py-2 rounded-xl border outline-none font-bold ${isDark ? "bg-white/5 border-white/10 text-white" : "bg-white border-gray-200 text-gray-900"}`} />
            <span className={`text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>%</span>
          </div>
        </motion.div>
      )}

      {updateType === "status" && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border space-y-3 ${isDark ? "bg-white/3 border-white/8" : "bg-gray-50 border-gray-100"}`}>
          <p className={`text-[11px] font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>الحالة الجديدة</p>
          <div className="flex gap-2">
            {(["active", "paused"] as const).map(s => (
              <button key={s} onClick={() => setNewStatus(s)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${newStatus === s ? s === "active" ? "bg-emerald-500 text-white" : "bg-amber-500 text-white" : isDark ? "bg-white/5 text-white/40" : "bg-white text-gray-400 border border-gray-200"}`}>
                {s === "active" ? "تفعيل الكل" : "إيقاف الكل"}
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {updateType === "description" && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border space-y-2 ${isDark ? "bg-white/3 border-white/8" : "bg-gray-50 border-gray-100"}`}>
          <p className={`text-[11px] font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>ملاحظة تُضاف لجميع المختارة</p>
          <textarea value={descNote} onChange={e => setDescNote(e.target.value)} rows={3}
            placeholder="مثال: السعر قابل للتفاوض للمشترين الجادين..."
            className={`w-full text-xs px-3 py-2 rounded-xl border outline-none resize-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/25" : "bg-white border-gray-200 text-gray-900 placeholder-gray-300"}`} />
        </motion.div>
      )}

      {/* Apply Button */}
      <motion.button onClick={handleApply} disabled={selectedIds.size === 0 || !updateType || loading} whileTap={{ scale: 0.98 }}
        className={`w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all ${selectedIds.size > 0 && updateType ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-500/20" : isDark ? "bg-white/5 text-white/30" : "bg-gray-100 text-gray-400"}`}>
        {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> جاري التطبيق...</> : <><ArrowUpDown className="w-4 h-4" /> تطبيق التحديث على {selectedIds.size} عروض</>}
      </motion.button>
    </div>
  );
}

// ============================================================================
// 2. OWNERS VIEW — Broker (Owner Management) — REDESIGNED
// ============================================================================
export function OwnersView({ isDark }: { isDark: boolean }) {
  const [activeTab, setActiveTab] = useState("all");
  const [selectedOwner, setSelectedOwner] = useState<any>(null);
  const [pageView, setPageView] = useState<"list" | "add">("list");

  const [owners, setOwners] = useState([
    {
      id: 1, name: "سعد القحطاني", phone: "0501234567",
      status: "جاهز للبيع", statusColor: "emerald", lastContact: "اليوم",
      description: "يمتلك عقارات جاهزة للبيع. يفضل المشترين النقديين.",
      properties: [
        { type: "فيلا", title: "فيلا 5 غرف - حي الملقا", price: "3,500,000", negotiable: true },
        { type: "أرض", title: "أرض سكنية 900م² - النرجس", price: "1,200,000", negotiable: false },
      ],
      notes: [
        { id: 1, text: "جبت له مشتري بنك ورفض، يريد كاش فقط", time: "منذ يومين", type: "reject" },
        { id: 2, text: "المالك يفضل الإخلاء الفوري بعد البيع", time: "أمس", type: "info" },
      ]
    },
    {
      id: 2, name: "نورة السالم", phone: "0509876543",
      status: "قيد التفاوض", statusColor: "amber", lastContact: "أمس",
      description: "مالكة شقة في دبي. تنتظر عرضاً مناسباً.",
      properties: [
        { type: "شقة", title: "بنتهاوس مطل - دبي مارينا", price: "4,200,000", negotiable: true },
      ],
      notes: [
        { id: 1, text: "قدم لها عرض 3.8M ورفضت، سعرها الأدنى 4M", time: "3 أيام", type: "reject" },
      ]
    },
    {
      id: 3, name: "محمد العتيبي", phone: "0555432100",
      status: "يفكر", statusColor: "blue", lastContact: "3 أيام",
      description: "يفكر في البيع لتمويل مشروع تجاري.",
      properties: [
        { type: "عمارة", title: "عمارة دورين - الخبر", price: "5,200,000", negotiable: false },
      ],
      notes: []
    },
  ]);

  const filtered = activeTab === "all" ? owners : owners.filter(o => {
    if (activeTab === "ready") return o.status === "جاهز للبيع";
    if (activeTab === "negotiating") return o.status === "قيد التفاوض";
    return true;
  });

  const statusColorMap: Record<string, string> = {
    emerald: isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700",
    amber: isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700",
    blue: isDark ? "bg-blue-500/20 text-blue-400" : "bg-blue-100 text-blue-700",
  };

  if (selectedOwner) {
    return <OwnerDetailView owner={selectedOwner} isDark={isDark} onBack={() => setSelectedOwner(null)}
      onUpdate={(updated: any) => { setOwners(prev => prev.map(o => o.id === updated.id ? updated : o)); setSelectedOwner(updated); }} />;
  }

  if (pageView === "add") {
    return <OwnerAddPage isDark={isDark} onBack={() => setPageView("list")}
      onAdd={(n: any) => { setOwners(prev => [...prev, { ...n, id: Date.now() }]); setPageView("list"); }} />;
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-xl border ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
          <Search className="w-4 h-4 opacity-40" />
          <input type="text" placeholder="ابحث عن مالك..." className="flex-1 bg-transparent text-xs outline-none" style={{ direction: 'rtl' }} />
        </div>
        <button onClick={() => setPageView("add")} className="px-3 py-2 rounded-xl bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 shadow-lg shadow-emerald-500/20">
          <Plus className="w-3.5 h-3.5" /> مالك
        </button>
      </div>

      <div className={`flex rounded-xl p-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
        {[{ id: "all", label: "الكل" }, { id: "ready", label: "جاهز للبيع" }, { id: "negotiating", label: "قيد التفاوض" }].map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold transition-all ${activeTab === t.id ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : "text-gray-400"}`}
          >{t.label}</button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "إجمالي الملاك", value: owners.length, color: isDark ? "text-white" : "text-gray-900" },
          { label: "جاهز للبيع", value: owners.filter(o => o.status === "جاهز للبيع").length, color: "text-emerald-400" },
          { label: "إجمالي العقارات", value: owners.reduce((s, o) => s + o.properties.length, 0), color: "text-cyan-400" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.map((o, i) => (
          <motion.button key={o.id} onClick={() => setSelectedOwner(o)}
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            className={`w-full p-4 rounded-2xl border text-right transition-all ${isDark ? "bg-[#151a2d] border-white/5 hover:bg-white/5" : "bg-white border-gray-100 shadow-sm hover:shadow-md"}`}
          >
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center font-black text-white text-lg shrink-0">{o.name[0]}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{o.name}</p>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${statusColorMap[o.statusColor]}`}>{o.status}</span>
                </div>
                <p className="text-[10px] text-gray-500 mb-2">{o.phone}</p>
                <div className="flex flex-wrap gap-1">
                  {o.properties.map((p: any, pi: number) => (
                    <span key={pi} className={`text-[9px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-0.5 ${isDark ? "bg-white/8 text-white/50" : "bg-gray-100 text-gray-600"}`}>
                      <Tag className="w-2 h-2" style={{ width: '8px', height: '8px' }} />{p.type}
                    </span>
                  ))}
                  {o.notes.length > 0 && (
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-0.5 ${isDark ? "bg-amber-500/10 text-amber-400" : "bg-amber-50 text-amber-600"}`}>
                      <StickyNote className="w-2 h-2" style={{ width: '8px', height: '8px' }} />{o.notes.length} ملاحظة
                    </span>
                  )}
                </div>
              </div>
              <ChevronRight className="w-4 h-4 opacity-25 mt-1 shrink-0" />
            </div>
          </motion.button>
        ))}
      </div>

    </div>
  );
}

function OwnerDetailView({ owner, isDark, onBack, onUpdate }: any) {
  const [noteText, setNoteText] = useState("");
  const [noteType, setNoteType] = useState<"reject" | "info" | "offer">("info");
  const [aiSummary, setAiSummary] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  const noteTypeCfg: Record<string, any> = {
    reject: { label: "رفض", Icon: XCircle, color: isDark ? "text-red-400 bg-red-500/10 border-red-500/20" : "text-red-700 bg-red-50 border-red-200" },
    info: { label: "ملاحظة", Icon: StickyNote, color: isDark ? "text-cyan-400 bg-cyan-500/10 border-cyan-500/20" : "text-cyan-700 bg-cyan-50 border-cyan-200" },
    offer: { label: "عرض", Icon: CheckCircle, color: isDark ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : "text-emerald-700 bg-emerald-50 border-emerald-200" },
  };

  const addNote = () => {
    if (!noteText.trim()) return;
    onUpdate({ ...owner, notes: [{ id: Date.now(), text: noteText, time: "الآن", type: noteType }, ...owner.notes] });
    setNoteText(""); setAiSummary("");
  };

  const handleAISummary = () => {
    setAiLoading(true);
    setTimeout(() => {
      const rejects = owner.notes.filter((n: any) => n.type === "reject").length;
      setAiSummary(`[AI] ملخص الذكاء الاصطناعي للمالك "${owner.name}":\n\n• لديه ${owner.properties.length} عقار معلن في المنصة\n• سجّلت ${owner.notes.length} ملاحظة حتى الآن${rejects > 0 ? `\n• رُصد ${rejects} رفض — تحقق من الشروط الخاصة` : ""}\n\n► التوصية: ${owner.notes.some((n: any) => n.text.includes("كاش")) ? "المالك يشترط الكاش فقط — تجنب عروض التمويل البنكي." : "راجع الملاحظات وتواص�� مع المالك لمعرفة أولوياته الحالية."}`);
      setAiLoading(false);
    }, 2000);
  };

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
      <button onClick={onBack} className={`flex items-center gap-2 text-sm font-bold mb-2 ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
        <ChevronRight className="w-4 h-4" /> العودة للملاك
      </button>

      <div className={`p-5 rounded-3xl border ${isDark ? "bg-gradient-to-br from-emerald-900/20 to-teal-900/20 border-emerald-500/20" : "bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200"}`}>
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-2xl font-black text-white shadow-lg shadow-emerald-500/30">{owner.name[0]}</div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className={`font-black text-lg ${isDark ? "text-white" : "text-gray-900"}`}>{owner.name}</h3>
              <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700"}`}>{owner.status}</span>
            </div>
            <p className={`text-sm flex items-center gap-1 ${isDark ? "text-white/60" : "text-gray-500"}`}><Phone className="w-3 h-3" /> {owner.phone}</p>
            <p className={`text-xs mt-2 leading-5 ${isDark ? "text-white/60" : "text-gray-600"}`}>{owner.description}</p>
          </div>
        </div>
      </div>

      <div>
        <h4 className={`text-xs font-black mb-2 flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
          <Building className="w-3.5 h-3.5 text-emerald-400" /> العقارات المعلنة
        </h4>
        <div className="space-y-2">
          {owner.properties.map((p: any, i: number) => (
            <div key={i} className={`p-3 rounded-2xl border flex items-center justify-between ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <div>
                <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{p.title}</p>
                <p className={`text-[10px] mt-0.5 ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{p.price} ريال</p>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[9px] font-bold px-2 py-1 rounded-lg ${isDark ? "bg-blue-500/10 text-blue-400" : "bg-blue-50 text-blue-600"}`}>{p.type}</span>
                <span className={`text-[9px] font-bold px-2 py-1 rounded-lg ${p.negotiable ? isDark ? "bg-emerald-500/10 text-emerald-400" : "bg-emerald-50 text-emerald-600" : isDark ? "bg-red-500/10 text-red-400" : "bg-red-50 text-red-600"}`}>
                  {p.negotiable ? "قابل للتفاوض" : "غير قابل"}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
            <StickyNote className="w-3.5 h-3.5 text-amber-400" /> سجل الملاحظات ({owner.notes.length})
          </h4>
          <button onClick={handleAISummary} disabled={aiLoading || owner.notes.length === 0}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-black transition-all ${owner.notes.length === 0 ? "opacity-30 cursor-not-allowed" : isDark ? "bg-purple-500/15 text-purple-400 border border-purple-500/20 hover:bg-purple-500/25" : "bg-purple-50 text-purple-600 border border-purple-200 hover:bg-purple-100"}`}>
            {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <BrainCircuit className="w-3 h-3" />}
            تلخيص بذكاء
          </button>
        </div>

        <AnimatePresence>
          {aiSummary && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className={`p-4 rounded-2xl border mb-3 ${isDark ? "bg-purple-900/20 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span className={`text-[10px] font-black ${isDark ? "text-purple-400" : "text-purple-600"}`}>ملخص الذكاء الاصطناعي</span>
                <button onClick={() => setAiSummary("")} className="mr-auto opacity-40 hover:opacity-80"><X className="w-3 h-3" /></button>
              </div>
              <p className={`text-[11px] leading-6 whitespace-pre-line ${isDark ? "text-white/80" : "text-gray-700"}`}>{aiSummary}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <div className={`p-3 rounded-2xl border mb-3 ${isDark ? "bg-[#151a2d] border-white/5" : "bg-gray-50 border-gray-200"}`}>
          <div className="flex gap-1.5 mb-2">
            {(["info", "offer", "reject"] as const).map(t => (
              <button key={t} onClick={() => setNoteType(t)}
                className={`flex-1 py-1.5 rounded-lg text-[9px] font-black border transition-all ${noteType === t
                  ? t === "reject" ? "bg-red-500 text-white border-red-500" : t === "offer" ? "bg-emerald-500 text-white border-emerald-500" : isDark ? "bg-cyan-500/30 text-cyan-400 border-cyan-500/30" : "bg-cyan-100 text-cyan-700 border-cyan-200"
                  : isDark ? "bg-white/5 text-white/30 border-white/5" : "bg-white text-gray-400 border-gray-200"}`}>
                {t === "reject" ? <><XCircle className="w-2.5 h-2.5" /> رفض</> : t === "offer" ? <><CheckCircle className="w-2.5 h-2.5" /> عرض</> : <><StickyNote className="w-2.5 h-2.5" /> ملاحظة</>}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <textarea value={noteText} onChange={e => setNoteText(e.target.value)} placeholder="اكتب ملاحظة... مثال: جبت له عرض ورفض لأن المشتري بنك" rows={2}
              className={`flex-1 bg-transparent text-xs outline-none resize-none leading-5 ${isDark ? "text-white placeholder-white/20" : "text-gray-900 placeholder-gray-400"}`} style={{ direction: 'rtl' }} />
            <button onClick={addNote} className={`px-3 py-1 rounded-xl self-end ${noteText.trim() ? "bg-amber-500 text-white hover:bg-amber-600" : "opacity-30 cursor-not-allowed " + (isDark ? "bg-white/5 text-white/30" : "bg-gray-200 text-gray-400")}`}>
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {owner.notes.length === 0 ? (
          <div className={`text-center py-8 rounded-2xl border border-dashed ${isDark ? "border-white/10" : "border-gray-200"}`}>
            <StickyNote className="w-8 h-8 opacity-20 mx-auto mb-2" />
            <p className="text-xs opacity-40">لا توجد ملاحظات بعد</p>
          </div>
        ) : (
          <div className="space-y-2">
            {owner.notes.map((n: any) => {
              const cfg = noteTypeCfg[n.type] || noteTypeCfg.info;
              return (
                <motion.div key={n.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                  <div className="flex items-start gap-2">
                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md shrink-0 border inline-flex items-center gap-1 ${cfg.color}`}><cfg.Icon className="w-3 h-3" /> {cfg.label}</span>
                    <p className={`text-[11px] flex-1 leading-5 ${isDark ? "text-white/80" : "text-gray-700"}`}>{n.text}</p>
                    <span className="text-[9px] opacity-30 shrink-0">{n.time}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex gap-2 pb-4">
        <button className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25">
          <Phone className="w-4 h-4" /> اتصال
        </button>
        <button className={`flex-1 py-3 rounded-2xl border font-bold text-sm flex items-center justify-center gap-2 ${isDark ? "border-white/10 text-white/70" : "border-gray-200 text-gray-700"}`}>
          <MessageSquare className="w-4 h-4" /> رسالة
        </button>
      </div>
    </motion.div>
  );
}

function OwnerAddPage({ isDark, onBack, onAdd }: any) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [desc, setDesc] = useState("");
  const [propType, setPropType] = useState("فيلا");
  const [propTitle, setPropTitle] = useState("");
  const [propPrice, setPropPrice] = useState("");
  const [propNegotiable, setPropNegotiable] = useState(true);
  const [status, setStatus] = useState("جاهز للبيع");

  // Mock property image gradients per type
  const propGradients: Record<string, string> = {
    "فيلا": "from-amber-600/30 to-orange-700/30",
    "شقة": "from-blue-600/30 to-cyan-700/30",
    "أرض": "from-green-600/30 to-teal-700/30",
    "عمارة": "from-purple-600/30 to-indigo-700/30",
    "دور": "from-pink-600/30 to-rose-700/30",
  };
  const propIconMap: Record<string, any> = { "فيلا": Home, "شقة": Building, "أرض": MapPin, "عمارة": Landmark, "دور": Home };

  const handleAdd = () => {
    if (!name.trim()) return;
    onAdd({
      name, phone, description: desc,
      status, statusColor: status === "جاهز للبيع" ? "emerald" : status === "قيد التفاوض" ? "amber" : "blue",
      lastContact: "الآن",
      properties: [{ type: propType, title: propTitle || `${propType} - جديد`, price: propPrice || "---", negotiable: propNegotiable, gradient: propGradients[propType] }],
      notes: []
    });
  };

  return (
    <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-5 pb-8">
      <button onClick={onBack} className={`flex items-center gap-2 text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
        <ChevronRight className="w-4 h-4" /> العودة للملاك
      </button>

      {/* Hero */}
      <div className={`p-5 rounded-3xl border ${isDark ? "bg-gradient-to-br from-emerald-900/25 to-teal-900/25 border-emerald-500/20" : "bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200"}`}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/30">
            <Key className="w-7 h-7 text-white" />
          </div>
          <div>
            <h3 className={`font-black text-xl ${isDark ? "text-white" : "text-gray-900"}`}>إضافة مالك جديد</h3>
            <p className={`text-xs mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>سيُربط العقار المُعلن بهذا الملف تلقائياً</p>
          </div>
        </div>
      </div>

      {/* Owner Info */}
      <div className="space-y-3">
        <p className={`text-[11px] font-black uppercase tracking-widest ${isDark ? "text-white/30" : "text-gray-400"}`}>بيانات المالك</p>
        {[{ label: "اسم المالك", val: name, set: setName, ph: "مثال: سعد الغامدي", icon: User },
          { label: "رقم الجوال", val: phone, set: setPhone, ph: "05xxxxxxxx", icon: Phone }].map((f, i) => (
          <div key={i}>
            <label className={`block text-xs font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>{f.label}</label>
            <div className={`flex items-center gap-3 px-4 py-3 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/8 focus-within:border-emerald-500/40" : "bg-white border-gray-200 shadow-sm focus-within:border-emerald-400"}`}>
              <f.icon className="w-4 h-4 opacity-30 shrink-0" />
              <input type="text" value={f.val} onChange={e => f.set(e.target.value)} placeholder={f.ph} className="flex-1 bg-transparent text-sm outline-none" style={{ direction: 'rtl' }} />
            </div>
          </div>
        ))}
        <div>
          <label className={`block text-xs font-bold mb-2 ${isDark ? "text-white/60" : "text-gray-600"}`}>حالة المالك</label>
          <div className="flex gap-2">
            {["جاهز للبيع", "قيد التفاوض", "يفكر"].map(s => (
              <button key={s} onClick={() => setStatus(s)} className={`flex-1 py-2 rounded-xl text-[10px] font-black border transition-all ${status === s ? s === "جاهز للبيع" ? "bg-emerald-500 text-white border-emerald-500" : s === "قيد التفاوض" ? "bg-amber-500 text-white border-amber-500" : isDark ? "bg-blue-500/30 text-blue-400 border-blue-500/30" : "bg-blue-100 text-blue-700 border-blue-200" : isDark ? "bg-white/5 text-white/30 border-white/5" : "bg-white text-gray-400 border-gray-200"}`}>{s}</button>
            ))}
          </div>
        </div>
        <div>
          <label className={`block text-xs font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>ملاحظات أولية عن ا��مالك</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="مثال: يشترط الكاش، يريد الإخلاء الفوري بعد البيع..." rows={2}
            className={`w-full px-4 py-3 rounded-2xl border text-xs resize-none outline-none leading-6 ${isDark ? "bg-[#151a2d] border-white/8 text-white placeholder-white/20" : "bg-white border-gray-200 text-gray-900 placeholder-gray-400"}`}
            style={{ direction: 'rtl' }} />
        </div>
      </div>

      {/* Property Section */}
      <div className="space-y-3">
        <p className={`text-[11px] font-black uppercase tracking-widest ${isDark ? "text-white/30" : "text-gray-400"}`}>العقار المعلن</p>

        {/* Property Type Picker */}
        <div>
          <label className={`block text-xs font-bold mb-2 ${isDark ? "text-white/60" : "text-gray-600"}`}>نوع العقار</label>
          <div className="flex flex-wrap gap-2">
            {["فيلا", "شقة", "أرض", "عمارة", "دور"].map(t => (
              <button key={t} onClick={() => setPropType(t)} className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${propType === t ? "bg-emerald-500 text-white border-emerald-500 shadow-md shadow-emerald-500/20" : isDark ? "bg-white/5 text-white/40 border-white/5 hover:bg-white/10" : "bg-white text-gray-500 border-gray-200 hover:bg-gray-50"}`}>{t}</button>
            ))}
          </div>
        </div>

        {/* Property Preview Card - visual with gradient */}
        <div className={`relative p-5 rounded-3xl border overflow-hidden ${isDark ? "bg-[#151a2d] border-white/8" : "bg-gray-50 border-gray-200"}`}>
          <div className={`absolute inset-0 bg-gradient-to-br ${propGradients[propType] || "from-gray-500/20 to-gray-600/20"}`} />
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-2">
                {(() => { const PropIcon = propIconMap[propType] || Home; return <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isDark ? "bg-white/10" : "bg-white/70"}`}><PropIcon className="w-5 h-5 opacity-60" /></div>; })()}
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-lg ${isDark ? "bg-white/10 text-white/60" : "bg-white/80 text-gray-600"}`}>{propType}</span>
              </div>
              {name && <div className={`text-right text-xs font-bold ${isDark ? "text-white/50" : "text-gray-500"}`}>مالك: {name}</div>}
            </div>
            <input value={propTitle} onChange={e => setPropTitle(e.target.value)} placeholder={`مثال: ${propType} في حي الملقا`}
              className={`w-full bg-transparent border-b outline-none text-sm font-black mb-3 pb-1 ${isDark ? "text-white placeholder-white/25 border-white/10" : "text-gray-900 placeholder-gray-400 border-gray-300"}`}
              style={{ direction: 'rtl' }} />
            <div className="flex gap-2">
              <div className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-xl border ${isDark ? "bg-white/5 border-white/8" : "bg-white/80 border-gray-200"}`}>
                <DollarSign className="w-3.5 h-3.5 opacity-30 shrink-0" />
                <input value={propPrice} onChange={e => setPropPrice(e.target.value)} placeholder="السعر (ريال)"
                  className="flex-1 bg-transparent text-xs outline-none" style={{ direction: 'rtl' }} />
              </div>
              <button onClick={() => setPropNegotiable(!propNegotiable)}
                className={`px-3 py-2 rounded-xl text-[10px] font-black border transition-all ${propNegotiable ? "bg-emerald-500 text-white border-emerald-500" : isDark ? "bg-red-500/20 text-red-400 border-red-500/20" : "bg-red-50 text-red-600 border-red-200"}`}>
                {propNegotiable ? <><CheckCircle className="w-3 h-3 inline ml-1" /> قابل</> : <><XCircle className="w-3 h-3 inline ml-1" /> نهائي</>}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Submit */}
      <button onClick={handleAdd}
        className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all ${name.trim() ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25 hover:shadow-xl" : "opacity-40 cursor-not-allowed " + (isDark ? "bg-white/5 text-white/20" : "bg-gray-200 text-gray-400")}`}>
        <CheckSquare className="w-5 h-5" /> إضافة المالك وعقاره
      </button>
    </motion.div>
  );
}

// ============================================================================
// NEW: CLIENTS VIEW — Broker + Developer (Smart CRM)
// ============================================================================
export function ClientsView({ isDark }: { isDark: boolean }) {
  const [selectedClient, setSelectedClient] = useState<any>(null);
  const [pageView, setPageView] = useState<"list" | "add">("list");
  const [clients, setClients] = useState([
    {
      id: 1, name: "فيصل الدوسري", phone: "0503210987", budget: "مليون ريال",
      description: "يبحث عن شقة 3 غرف في الرياض. ميزانيته محدودة جداً.",
      wantType: "شقة", wantRegion: "الرياض", wantNeighborhood: "الملقا",
      notes: [
        { id: 1, text: "عرضت عليه شقة في النرجس بـ1.1M فرفض، قال ميزانيته حدها مليون فقط", time: "أمس", type: "reject" },
        { id: 2, text: "جربت عرض في حي آخر وقال لا يريد إلا في الملقا أو النرجس", time: "3 أيام", type: "reject" },
      ]
    },
    {
      id: 2, name: "ريم الشهري", phone: "0559871234", budget: "2.5 مليون",
      description: "تريد فيلا مودرن في شمال الرياض مع مسبح.",
      wantType: "فيلا", wantRegion: "شمال الرياض", wantNeighborhood: "حطين",
      notes: [
        { id: 1, text: "تريد مسبح ومصعد مؤسس - شرط أساسي", time: "اليوم", type: "info" },
        { id: 2, text: "عرض فيلا في حطين أعجبها لكن تحتاج وقت للتفكير", time: "منذ يومين", type: "offer" },
      ]
    },
    {
      id: 3, name: "طلال المنصور", phone: "0566543210", budget: "4 مليون",
      description: "مستثمر يبحث عن عمارة ذات عائد إيجاري مرتفع.",
      wantType: "عمارة", wantRegion: "الرياض", wantNeighborhood: "العليا", notes: []
    },
  ]);

  if (selectedClient) {
    return <ClientDetailView client={selectedClient} isDark={isDark} onBack={() => setSelectedClient(null)}
      onUpdate={(u: any) => { setClients(prev => prev.map(c => c.id === u.id ? u : c)); setSelectedClient(u); }} />;
  }

  if (pageView === "add") {
    return <ClientAddPage isDark={isDark} onBack={() => setPageView("list")}
      onAdd={(c: any) => { setClients(prev => [...prev, { ...c, id: Date.now() }]); setPageView("list"); }} />;
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "إجمالي العملاء", value: clients.length, color: isDark ? "text-white" : "text-gray-900" },
          { label: "لديهم ملاحظات", value: clients.filter(c => c.notes.length > 0).length, color: "text-cyan-400" },
          { label: "بانتظار عرض", value: clients.filter(c => c.notes.length === 0).length, color: "text-amber-400" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <div className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-xl border ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
          <Search className="w-4 h-4 opacity-40" />
          <input type="text" placeholder="ابحث عن عميل..." className="flex-1 bg-transparent text-xs outline-none" style={{ direction: 'rtl' }} />
        </div>
        <button onClick={() => setPageView("add")} className="px-3 py-2 rounded-xl bg-blue-500 text-white text-xs font-bold flex items-center gap-1 shadow-lg shadow-blue-500/20">
          <Plus className="w-3.5 h-3.5" /> عميل
        </button>
      </div>

      <div className="space-y-3">
        {clients.map((c, i) => (
          <motion.button key={c.id} onClick={() => setSelectedClient(c)}
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            className={`w-full p-4 rounded-2xl border text-right transition-all ${isDark ? "bg-[#151a2d] border-white/5 hover:bg-white/5" : "bg-white border-gray-100 shadow-sm hover:shadow-md"}`}>
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-500 to-cyan-500 flex items-center justify-center font-black text-white text-lg shrink-0">{c.name[0]}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{c.name}</p>
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isDark ? "bg-emerald-500/10 text-emerald-400" : "bg-emerald-50 text-emerald-600"}`}>{c.budget}</span>
                </div>
                <p className={`text-[10px] mb-2 line-clamp-1 ${isDark ? "text-white/50" : "text-gray-500"}`}>{c.description}</p>
                <div className="flex flex-wrap gap-1.5">
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-0.5 ${isDark ? "bg-blue-500/10 text-blue-400" : "bg-blue-50 text-blue-600"}`}><Home className="w-2 h-2" style={{ width:'8px', height:'8px' }} /> {c.wantType}</span>
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-0.5 ${isDark ? "bg-white/8 text-white/40" : "bg-gray-100 text-gray-500"}`}><MapPin className="w-2 h-2" style={{ width:'8px', height:'8px' }} /> {c.wantRegion}</span>
                  {c.wantNeighborhood && <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-0.5 ${isDark ? "bg-emerald-500/10 text-emerald-400" : "bg-emerald-50 text-emerald-600"}`}><MapPin className="w-2 h-2" style={{ width:'8px', height:'8px' }} /> {c.wantNeighborhood}</span>}
                  {c.notes.length > 0 && <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-0.5 ${isDark ? "bg-amber-500/10 text-amber-400" : "bg-amber-50 text-amber-600"}`}><StickyNote className="w-2 h-2" style={{ width:'8px', height:'8px' }} /> {c.notes.length} ملاحظة</span>}
                </div>
              </div>
              <ChevronRight className="w-4 h-4 opacity-25 mt-1 shrink-0" />
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

function ClientDetailView({ client, isDark, onBack, onUpdate }: any) {
  const [noteText, setNoteText] = useState("");
  const [noteType, setNoteType] = useState<"reject" | "info" | "offer">("info");
  const [aiSummary, setAiSummary] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  const noteTypeCfg: Record<string, any> = {
    reject: { label: "رفض", Icon: XCircle, color: isDark ? "text-red-400 bg-red-500/10 border-red-500/20" : "text-red-700 bg-red-50 border-red-200" },
    info: { label: "ملاحظة", Icon: StickyNote, color: isDark ? "text-cyan-400 bg-cyan-500/10 border-cyan-500/20" : "text-cyan-700 bg-cyan-50 border-cyan-200" },
    offer: { label: "عرض قدّم", Icon: CheckCircle, color: isDark ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : "text-emerald-700 bg-emerald-50 border-emerald-200" },
  };

  const addNote = () => {
    if (!noteText.trim()) return;
    onUpdate({ ...client, notes: [{ id: Date.now(), text: noteText, time: "الآن", type: noteType }, ...client.notes] });
    setNoteText(""); setAiSummary("");
  };

  const handleAISummary = () => {
    setAiLoading(true);
    setTimeout(() => {
      const rejects = client.notes.filter((n: any) => n.type === "reject").length;
      let summary = `[AI] ملخص الذكاء الاصطناعي للعميل "${client.name}":\n\n`;
      summary += `• النوع: ${client.wantType} في ${client.wantRegion}\n`;
      summary += `• الميزانية القصوى: ${client.budget}\n\n`;
      if (rejects > 0) summary += `• رُصد رفض ${rejects} عروض — السبب الرئيسي: السعر أو الموقع لا يناسب\n`;
      summary += `\n► التوصية: ابحث في ${client.wantRegion} فقط بسعر لا يتجاوز ${client.budget}. لا تقترح بدائل خارج المنطقة.`;
      setAiSummary(summary);
      setAiLoading(false);
    }, 2200);
  };

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
      <button onClick={onBack} className={`flex items-center gap-2 text-sm font-bold mb-2 ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
        <ChevronRight className="w-4 h-4" /> العودة للعملاء
      </button>

      <div className={`p-5 rounded-3xl border ${isDark ? "bg-gradient-to-br from-blue-900/20 to-cyan-900/20 border-blue-500/20" : "bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200"}`}>
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center text-2xl font-black text-white shadow-lg shadow-blue-500/30">{client.name[0]}</div>
          <div className="flex-1">
            <h3 className={`font-black text-lg mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{client.name}</h3>
            <p className={`text-sm flex items-center gap-1 mb-2 ${isDark ? "text-white/60" : "text-gray-500"}`}><Phone className="w-3 h-3" /> {client.phone}</p>
            <p className={`text-xs leading-5 ${isDark ? "text-white/60" : "text-gray-600"}`}>{client.description}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-4">
          {[
            { label: "النوع المطلوب", value: client.wantType, Icon: Home },
            { label: "المنطقة", value: client.wantRegion, Icon: MapPin },
            { label: "الحي", value: client.wantNeighborhood || "—", Icon: MapPin },
            { label: "الميزانية", value: client.budget, Icon: DollarSign }
          ].map((r, i) => (
            <div key={i} className={`p-2.5 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-white/80"}`}>
              <r.Icon className="w-4 h-4 mx-auto mb-0.5 opacity-40" />
              <span className="block text-[9px] opacity-50">{r.label}</span>
              <span className={`block text-[10px] font-black mt-0.5 ${isDark ? "text-white" : "text-gray-900"}`}>{r.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className={`text-xs font-black flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
            <Bell className="w-3.5 h-3.5 text-amber-400" /> سجل التنبيهات ({client.notes.length})
          </h4>
          <button onClick={handleAISummary} disabled={aiLoading || client.notes.length === 0}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-black transition-all ${client.notes.length === 0 ? "opacity-30 cursor-not-allowed" : isDark ? "bg-blue-500/15 text-blue-400 border border-blue-500/20 hover:bg-blue-500/25" : "bg-blue-50 text-blue-600 border border-blue-200 hover:bg-blue-100"}`}>
            {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <BrainCircuit className="w-3 h-3" />}
            تلخيص بذكاء
          </button>
        </div>

        <AnimatePresence>
          {aiSummary && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className={`p-4 rounded-2xl border mb-3 ${isDark ? "bg-blue-900/20 border-blue-500/20" : "bg-blue-50 border-blue-200"}`}>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                <span className={`text-[10px] font-black ${isDark ? "text-blue-400" : "text-blue-600"}`}>ملخص الذكاء الاصطناعي</span>
                <button onClick={() => setAiSummary("")} className="mr-auto opacity-40 hover:opacity-80"><X className="w-3 h-3" /></button>
              </div>
              <p className={`text-[11px] leading-6 whitespace-pre-line ${isDark ? "text-white/80" : "text-gray-700"}`}>{aiSummary}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <div className={`p-3 rounded-2xl border mb-3 ${isDark ? "bg-[#151a2d] border-white/5" : "bg-gray-50 border-gray-200"}`}>
          <div className="flex gap-1.5 mb-2">
            {(["info", "offer", "reject"] as const).map(t => (
              <button key={t} onClick={() => setNoteType(t)}
                className={`flex-1 py-1.5 rounded-lg text-[9px] font-black border transition-all ${noteType === t
                  ? t === "reject" ? "bg-red-500 text-white border-red-500" : t === "offer" ? "bg-emerald-500 text-white border-emerald-500" : isDark ? "bg-cyan-500/30 text-cyan-400 border-cyan-500/30" : "bg-cyan-100 text-cyan-700 border-cyan-200"
                  : isDark ? "bg-white/5 text-white/30 border-white/5" : "bg-white text-gray-400 border-gray-200"}`}>
                {t === "reject" ? <><XCircle className="w-2.5 h-2.5" /> رفض</> : t === "offer" ? <><CheckCircle className="w-2.5 h-2.5" /> عرض</> : <><StickyNote className="w-2.5 h-2.5" /> ملاحظة</>}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <textarea value={noteText} onChange={e => setNoteText(e.target.value)}
              placeholder="سجّل ملاحظة، عرض قدّمته، أو سبب رفض العميل..." rows={2}
              className={`flex-1 bg-transparent text-xs outline-none resize-none leading-5 ${isDark ? "text-white placeholder-white/20" : "text-gray-900 placeholder-gray-400"}`} style={{ direction: 'rtl' }} />
            <button onClick={addNote} className={`px-3 py-1 rounded-xl self-end ${noteText.trim() ? "bg-blue-500 text-white hover:bg-blue-600" : "opacity-30 cursor-not-allowed " + (isDark ? "bg-white/5 text-white/30" : "bg-gray-200 text-gray-400")}`}>
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {client.notes.length === 0 ? (
          <div className={`text-center py-8 rounded-2xl border border-dashed ${isDark ? "border-white/10" : "border-gray-200"}`}>
            <Bell className="w-8 h-8 opacity-20 mx-auto mb-2" />
            <p className="text-xs opacity-40">لا توجد تنبيهات بعد — سجّل أول ملاحظة</p>
          </div>
        ) : (
          <div className="space-y-2">
            {client.notes.map((n: any) => {
              const cfg = noteTypeCfg[n.type] || noteTypeCfg.info;
              return (
                <motion.div key={n.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                  <div className="flex items-start gap-2">
                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md shrink-0 border inline-flex items-center gap-1 ${cfg.color}`}><cfg.Icon className="w-3 h-3" /> {cfg.label}</span>
                    <p className={`text-[11px] flex-1 leading-5 ${isDark ? "text-white/80" : "text-gray-700"}`}>{n.text}</p>
                    <span className="text-[9px] opacity-30 shrink-0">{n.time}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex gap-2 pb-4">
        <button className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-blue-500 to-cyan-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-500/25">
          <Phone className="w-4 h-4" /> اتصال
        </button>
        <button className={`flex-1 py-3 rounded-2xl border font-bold text-sm flex items-center justify-center gap-2 ${isDark ? "border-white/10 text-white/70" : "border-gray-200 text-gray-700"}`}>
          <MessageSquare className="w-4 h-4" /> رسالة
        </button>
      </div>
    </motion.div>
  );
}

function ClientAddPage({ isDark, onBack, onAdd }: any) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [desc, setDesc] = useState("");
  const [budget, setBudget] = useState("");
  const [wantType, setWantType] = useState("شقة");
  const [wantRegion, setWantRegion] = useState("الرياض");
  const [wantNeighborhood, setWantNeighborhood] = useState("النرجس");

  const neighborhoodsMap: Record<string, string[]> = {
    "الرياض": ["النرجس", "الملقا", "حطين", "الياسمين", "العليا", "العارض", "الورود"],
    "شمال الرياض": ["النرجس", "الملقا", "حطين", "الياسمين", "العارض"],
    "جدة": ["أبحر الشمالية", "الشاطئ", "الزهراء", "الروضة", "الربوة"],
    "الدمام": ["الشاطئ", "العزيزية", "الفيصلية"],
    "مكة المكرمة": ["العزيزية", "الشوقية", "أجياد"],
    "أبها": ["المنسك", "الورود", "المروج"],
    "تبوك": ["الروضة", "المصيف", "الوادي"],
  };
  const neighborhoods = neighborhoodsMap[wantRegion] || ["الحي الأول", "الحي الثاني"];

  const fields = [
    { label: "اسم العميل", val: name, set: setName, ph: "مثال: عبدالله المطيري", icon: User, type: "text" },
    { label: "رقم الجوال", val: phone, set: setPhone, ph: "05xxxxxxxx", icon: Phone, type: "tel" },
    { label: "الميزانية القصوى", val: budget, set: setBudget, ph: "مثال: مليون ريال أو 1,500,000", icon: DollarSign, type: "text" },
  ];

  return (
    <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-5 pb-8">
      {/* Back */}
      <button onClick={onBack} className={`flex items-center gap-2 text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
        <ChevronRight className="w-4 h-4" /> العودة للعملاء
      </button>

      {/* Hero Header */}
      <div className={`p-5 rounded-3xl border ${isDark ? "bg-gradient-to-br from-blue-900/25 to-cyan-900/25 border-blue-500/20" : "bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200"}`}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
            <User className="w-7 h-7 text-white" />
          </div>
          <div>
            <h3 className={`font-black text-xl ${isDark ? "text-white" : "text-gray-900"}`}>إضافة عميل جديد</h3>
            <p className={`text-xs mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>أدخل بيانات العميل واحتياجاته بدقة</p>
          </div>
        </div>
      </div>

      {/* Basic Info */}
      <div className="space-y-3">
        <p className={`text-[11px] font-black uppercase tracking-widest ${isDark ? "text-white/30" : "text-gray-400"}`}>المعلومات الأساسية</p>
        {fields.map((f, i) => (
          <div key={i}>
            <label className={`block text-xs font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>{f.label}</label>
            <div className={`flex items-center gap-3 px-4 py-3 rounded-2xl border transition-all ${isDark ? "bg-[#151a2d] border-white/8 focus-within:border-blue-500/40" : "bg-white border-gray-200 shadow-sm focus-within:border-blue-400"}`}>
              <f.icon className="w-4 h-4 opacity-30 shrink-0" />
              <input type={f.type} value={f.val} onChange={e => f.set(e.target.value)} placeholder={f.ph}
                className="flex-1 bg-transparent text-sm outline-none" style={{ direction: 'rtl' }} />
            </div>
          </div>
        ))}
      </div>

      {/* What They Want */}
      <div className="space-y-3">
        <p className={`text-[11px] font-black uppercase tracking-widest ${isDark ? "text-white/30" : "text-gray-400"}`}>ماذا يريد؟</p>
        
        {/* 3 Filters on ONE ROW */}
        <div className="grid grid-cols-3 gap-2">
          {/* Filter 1: نوع العقار */}
          <div>
            <label className={`block text-[10px] font-black mb-1.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>نوع العقار</label>
            <select
              value={wantType}
              onChange={e => setWantType(e.target.value)}
              className={`w-full px-2 py-2.5 rounded-xl border text-[11px] font-bold outline-none transition-all appearance-none cursor-pointer ${isDark ? "bg-[#151a2d] border-white/10 text-white focus:border-blue-500/40" : "bg-white border-gray-200 text-gray-900 focus:border-blue-300 shadow-sm"}`}
              style={{ direction: 'rtl' }}
            >
              {["فيلا", "شقة", "أرض", "عمارة", "دور", "تاون هاوس"].map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* Filter 2: المنطقة */}
          <div>
            <label className={`block text-[10px] font-black mb-1.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>المنطقة</label>
            <select
              value={wantRegion}
              onChange={e => { setWantRegion(e.target.value); setWantNeighborhood((neighborhoodsMap[e.target.value] || [""])[0]); }}
              className={`w-full px-2 py-2.5 rounded-xl border text-[11px] font-bold outline-none transition-all appearance-none cursor-pointer ${isDark ? "bg-[#151a2d] border-white/10 text-white focus:border-blue-500/40" : "bg-white border-gray-200 text-gray-900 focus:border-blue-300 shadow-sm"}`}
              style={{ direction: 'rtl' }}
            >
              {["الرياض", "شمال الرياض", "جدة", "الدمام", "مكة المكرمة", "أبها", "تبوك"].map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          {/* Filter 3: الحي */}
          <div>
            <label className={`block text-[10px] font-black mb-1.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>الحي</label>
            <select
              value={wantNeighborhood}
              onChange={e => setWantNeighborhood(e.target.value)}
              className={`w-full px-2 py-2.5 rounded-xl border text-[11px] font-bold outline-none transition-all appearance-none cursor-pointer ${isDark ? "bg-[#151a2d] border-white/10 text-white focus:border-blue-500/40" : "bg-white border-gray-200 text-gray-900 focus:border-blue-300 shadow-sm"}`}
              style={{ direction: 'rtl' }}
            >
              {neighborhoods.map(n => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className={`block text-xs font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>وصف دقيق لما يريده العميل</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)}
            placeholder="مثال: يريد شقة 3 غرف في الملقا فقط، ميزانيته حدها مليون ريال، يرفض أي حي ثانٍ..." rows={4}
            className={`w-full px-4 py-3 rounded-2xl border text-sm resize-none outline-none leading-7 transition-all ${isDark ? "bg-[#151a2d] border-white/8 text-white placeholder-white/20 focus:border-blue-500/40" : "bg-white border-gray-200 text-gray-900 placeholder-gray-400 focus:border-blue-300"}`}
            style={{ direction: 'rtl' }} />
        </div>
      </div>

      {/* Preview Card */}
      {name && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/8" : "bg-gray-50 border-gray-200"}`}>
          <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/30" : "text-gray-400"}`}>معاينة البطاقة</p>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-500 to-cyan-500 flex items-center justify-center font-black text-white">{name[0]}</div>
            <div>
              <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{name}</p>
              <p className="text-[10px] text-gray-500">{wantType} في {wantRegion} • حي {wantNeighborhood} • {budget || "لم تحدد الميزانية"}</p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Submit */}
      <button onClick={() => { if (name.trim()) onAdd({ name, phone, budget, description: desc, wantType, wantRegion, wantNeighborhood, notes: [] }); }}
        className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all ${name.trim() ? "bg-gradient-to-r from-blue-500 to-cyan-600 text-white shadow-lg shadow-blue-500/25 hover:shadow-xl" : "opacity-40 cursor-not-allowed " + (isDark ? "bg-white/5 text-white/20" : "bg-gray-200 text-gray-400")}`}>
        <CheckSquare className="w-5 h-5" /> إضافة العم��ل وحفظ
      </button>
    </motion.div>
  );
}

// ============================================================================
// NEW: TASKS VIEW — Broker + Developer (Priority Task Manager)
// ============================================================================
export function TasksView({ isDark }: { isDark: boolean }) {
  const [tasks, setTasks] = useState([
    { id: 1, text: "بكرة عندي زبون بيجي على الساعة 10 صباحاً ويبي يشوف عقار ابو خالد في النرجس", priority: "red" as const, done: false, time: "اليوم 10:00 ص", created: "منذ ساعة" },
    { id: 2, text: "مراجعة عقد البيع مع المحامي وإرسال النسخة النهائية للمالك", priority: "yellow" as const, done: false, time: "الأسبوع القادم", created: "أمس" },
    { id: 3, text: "نشر إعلان فيلا النرجس على منصات التواصل الاجتماعي", priority: "green" as const, done: true, time: "", created: "3 أيام" },
    { id: 4, text: "متابعة مع العميل فيصل بعد رفضه العرض الأخير", priority: "yellow" as const, done: false, time: "غداً", created: "منذ يومين" },
  ]);
  const [showAdd, setShowAdd] = useState(false);
  const [newTaskText, setNewTaskText] = useState("");
  const [newPriority, setNewPriority] = useState<"red" | "yellow" | "green">("yellow");
  const [newTime, setNewTime] = useState("");
  const [filter, setFilter] = useState<"all" | "pending" | "done">("all");
  const [aiSummaryLoading, setAiSummaryLoading] = useState(false);
  const [aiSummary, setAiSummary] = useState<string | null>(null);

  const priorityCfg = {
    red:    { label: "مهم جداً",  dot: "bg-red-500",     badge: isDark ? "bg-red-500/15 text-red-400 border-red-500/25" : "bg-red-50 text-red-600 border-red-200",     glow: "shadow-red-500/20" },
    yellow: { label: "شبه مهم",  dot: "bg-amber-400",   badge: isDark ? "bg-amber-500/15 text-amber-400 border-amber-500/25" : "bg-amber-50 text-amber-600 border-amber-200", glow: "shadow-amber-500/20" },
    green:  { label: "غير مهم",  dot: "bg-emerald-500", badge: isDark ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" : "bg-emerald-50 text-emerald-600 border-emerald-200", glow: "shadow-emerald-500/20" },
  };

  const handleAISummary = () => {
    setAiSummaryLoading(true);
    setAiSummary(null);
    setTimeout(() => {
      const pending = tasks.filter(t => !t.done);
      const urgent = pending.filter(t => t.priority === "red");
      const done = tasks.filter(t => t.done);
      setAiSummary(
        `لديك ${pending.length} مهام معلقة${urgent.length > 0 ? `، منها ${urgent.length} عاجلة تستوجب اهتمامك الفوري` : ""}.\n\n` +
        `${urgent.length > 0 ? `► أبرز مهمة عاجلة: "${urgent[0].text.slice(0, 60)}..."\n\n` : ""}` +
        `✅ أنجزت حتى الآن ${done.length} مهام.\n\n` +
        `💡 التوصية: ابدأ بالمهام العاجلة الحمراء، ثم انتقل للمتوسطة. تجنب تأجيل مهام التواصل مع العملاء.`
      );
      setAiSummaryLoading(false);
    }, 2000);
  };

  const filtered = tasks.filter(t => filter === "all" ? true : filter === "done" ? t.done : !t.done);
  const pendingCount = tasks.filter(t => !t.done).length;
  const redCount = tasks.filter(t => t.priority === "red" && !t.done).length;

  const toggleDone = (id: number) => setTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  const deleteTask = (id: number) => setTasks(prev => prev.filter(t => t.id !== id));
  const addTask = () => {
    if (!newTaskText.trim()) return;
    setTasks(prev => [{ id: Date.now(), text: newTaskText, priority: newPriority, done: false, time: newTime, created: "الآن" }, ...prev]);
    setNewTaskText(""); setNewTime(""); setShowAdd(false);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-2">
        <div className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <p className={`text-xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>{tasks.length}</p>
          <p className="text-[9px] opacity-50">إجمالي</p>
        </div>
        <div className={`p-3 rounded-2xl text-center border ${isDark ? "bg-red-500/5 border-red-500/15" : "bg-red-50 border-red-100"}`}>
          <p className="text-xl font-black text-red-500">{redCount}</p>
          <p className="text-[9px] opacity-50 flex items-center justify-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500 inline-block" /> عاجلة</p>
        </div>
        <div className={`p-3 rounded-2xl text-center border ${isDark ? "bg-emerald-500/5 border-emerald-500/15" : "bg-emerald-50 border-emerald-100"}`}>
          <p className="text-xl font-black text-emerald-500">{tasks.filter(t => t.done).length}</p>
          <p className="text-[9px] opacity-50 flex items-center justify-center gap-1"><CheckCircle className="w-2.5 h-2.5 text-emerald-500" /> مكتملة</p>
        </div>
      </div>

      <div className="flex gap-2">
        <div className={`flex flex-1 rounded-xl p-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
          {[{ id: "all" as const, label: "الكل" }, { id: "pending" as const, label: `معلقة (${pendingCount})` }, { id: "done" as const, label: "منجزة" }].map(f => (
            <button key={f.id} onClick={() => setFilter(f.id)}
              className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold transition-all ${filter === f.id ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : "text-gray-400"}`}>{f.label}</button>
          ))}
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="px-3 py-2 rounded-xl bg-pink-500 text-white text-xs font-bold flex items-center gap-1 shadow-lg shadow-pink-500/20">
          <Plus className="w-3.5 h-3.5" /> مهمة
        </button>
      </div>

      <AnimatePresence>
        {showAdd && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className={`p-4 rounded-2xl border overflow-hidden ${isDark ? "bg-[#151a2d] border-white/8" : "bg-gray-50 border-gray-200"}`}>
            <div className="flex items-center justify-between mb-3">
              <p className={`text-xs font-black ${isDark ? "text-white/80" : "text-gray-700"}`}>إضافة مهمة جديدة</p>
              <button onClick={() => setShowAdd(false)} className="opacity-40 hover:opacity-80"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-3 gap-2 mb-3">
              {(["red", "yellow", "green"] as const).map(p => (
                <button key={p} onClick={() => setNewPriority(p)}
                  className={`py-2 rounded-xl text-[10px] font-black border flex items-center justify-center gap-1.5 transition-all ${newPriority === p
                    ? p === "red" ? "bg-red-500 text-white border-red-500 shadow-lg shadow-red-500/30"
                      : p === "yellow" ? "bg-amber-500 text-white border-amber-500 shadow-lg shadow-amber-500/30"
                      : "bg-emerald-500 text-white border-emerald-500 shadow-lg shadow-emerald-500/30"
                    : isDark ? "bg-white/5 text-white/40 border-white/5" : "bg-white text-gray-500 border-gray-200"}`}>
                  <span className={`w-2 h-2 rounded-full ${p === "red" ? "bg-red-300" : p === "yellow" ? "bg-amber-300" : "bg-emerald-300"}`} />
                  {priorityCfg[p].label}
                </button>
              ))}
            </div>
            <textarea value={newTaskText} onChange={e => setNewTaskText(e.target.value)}
              placeholder="مثال: بكرة عندي زبون على الساعة 10 يبي يشوف عقار ابو خالد..." rows={3}
              className={`w-full bg-transparent text-sm outline-none resize-none leading-6 mb-3 ${isDark ? "text-white placeholder-white/25" : "text-gray-900 placeholder-gray-400"}`} style={{ direction: 'rtl' }} />
            <input type="text" value={newTime} onChange={e => setNewTime(e.target.value)} placeholder="الوقت (اختياري) — مثال: غداً 10:00 ص"
              className={`w-full bg-transparent text-xs outline-none mb-3 border-t pt-2 ${isDark ? "text-white/50 placeholder-white/20 border-white/5" : "text-gray-500 placeholder-gray-400 border-gray-200"}`} style={{ direction: 'rtl' }} />
            <button onClick={addTask} className={`w-full py-3 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${
              newTaskText.trim() ? "bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-lg shadow-pink-500/25" : "opacity-40 cursor-not-allowed " + (isDark ? "bg-white/5 text-white/20" : "bg-gray-200 text-gray-400")}`}>
              <CheckSquare className="w-4 h-4" /> إضافة المهمة
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-2.5">
        <AnimatePresence>
          {filtered.length === 0 && (
            <div className={`text-center py-12 rounded-2xl border border-dashed ${isDark ? "border-white/10" : "border-gray-200"}`}>
              <CheckSquare className="w-10 h-10 opacity-15 mx-auto mb-2" />
              <p className="text-sm opacity-30">{filter === "done" ? "لا توجد مهام منجزة" : "لا توجد مهام معلقة"}</p>
            </div>
          )}
          {filtered.map((task, i) => {
            const pc = priorityCfg[task.priority];
            return (
              <motion.div key={task.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ delay: i * 0.04 }}
                className={`p-4 rounded-2xl border transition-all ${task.done ? "opacity-50" : `shadow-md ${pc.glow}`} ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                <div className="flex items-start gap-3">
                  <button onClick={() => toggleDone(task.id)}
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 transition-all ${task.done ? "bg-emerald-500 border-emerald-500" : isDark ? "border-white/20 hover:border-white/50" : "border-gray-300 hover:border-gray-600"}`}>
                    {task.done && <CheckCircle className="w-4 h-4 text-white" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className={`flex items-center gap-1 px-2 py-0.5 rounded-lg border text-[9px] font-black ${pc.badge}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${pc.dot} ${!task.done ? "animate-pulse" : ""}`} />
                        {pc.label}
                      </div>
                      {task.time && (
                        <span className={`text-[9px] flex items-center gap-0.5 ${task.priority === "red" && !task.done ? "text-red-400 font-bold" : "opacity-40"}`}>
                          <AlarmClock className="w-2.5 h-2.5" /> {task.time}
                        </span>
                      )}
                    </div>
                    <p className={`text-xs leading-5 ${task.done ? "line-through opacity-50" : isDark ? "text-white/90" : "text-gray-800"}`}>{task.text}</p>
                    <p className="text-[9px] opacity-30 mt-1">{task.created}</p>
                  </div>
                  <button onClick={() => deleteTask(task.id)} className="w-6 h-6 rounded-lg flex items-center justify-center opacity-20 hover:opacity-60 hover:text-red-400 transition-all shrink-0">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* ── AI Summary Button ── */}
      <button
        onClick={handleAISummary}
        disabled={aiSummaryLoading || tasks.length === 0}
        className={`w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all ${tasks.length === 0 ? "opacity-30 cursor-not-allowed " + (isDark ? "bg-white/5 text-white/20" : "bg-gray-100 text-gray-300") : "bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white shadow-lg shadow-purple-500/20"}`}
      >
        {aiSummaryLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BrainCircuit className="w-4 h-4" />}
        {aiSummaryLoading ? "جاري التحليل..." : "تلخيص المهام بالذكاء الاصطناعي"}
      </button>

      {/* ── AI Summary Result ── */}
      <AnimatePresence>
        {aiSummary && !aiSummaryLoading && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-violet-900/20 to-purple-900/20 border-violet-500/20" : "bg-gradient-to-br from-violet-50 to-purple-50 border-violet-200"}`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-violet-400" />
                <span className={`text-xs font-black ${isDark ? "text-violet-400" : "text-violet-700"}`}>ملخص الذكاء الاصطناعي</span>
              </div>
              <button onClick={() => setAiSummary(null)} className="opacity-40 hover:opacity-80">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className={`text-[11px] leading-6 whitespace-pre-line ${isDark ? "text-white/75" : "text-gray-700"}`}>{aiSummary}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ============================================================================
// NEW: VALUATION AGENT VIEW — Landlord (AI Property Valuation)
// ============================================================================
export function ValuationAgentView({ isDark }: { isDark: boolean }) {
  return <PropertyValuationWidget isDark={isDark} />;
}

// ============================================================================
// 3. EDITOR AGENT VIEW — Landlord (Content Editor)
// ============================================================================
export function EditorAgentView({ isDark }: { isDark: boolean }) {
  const [rawText, setRawText] = useState("شقة في حي النرجس 3 غرف كبيرة بلكونة وموقف سيارة");
  const [generated, setGenerated] = useState(false);
  const [copied, setCopied] = useState(false);
  const [photoEnhanced, setPhotoEnhanced] = useState(false);

  const generatedText = "شقة راقية في قلب حي النرجس المميز — تتميز هذه الشقة بثلاث غرف فسيحة تمتلئ بالضوء الطبيعي، وبلكونة مطلة على حديقة الحي الخضراء، إضافةً إلى موقف سيارة خاص. تشطيب عصري فاخر يجمع بين الأناقة والعملية.";

  const handleGenerate = () => setGenerated(true);
  const handleCopy = () => { setCopied(true); setTimeout(() => setCopied(false), 2000); };

  return (
    <div className="space-y-4">
      {/* Raw Input */}
      <div>
        <label className={`block text-xs font-black mb-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
          أدخل وصفاً بسيطاً للعقار
        </label>
        <textarea
          value={rawText}
          onChange={e => { setRawText(e.target.value); setGenerated(false); }}
          rows={3}
          placeholder="اكتب ما تريد، حتى بالعامية..."
          className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none resize-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder:text-white/30" : "bg-gray-50 border-gray-200 text-gray-800 placeholder:text-gray-400"}`}
        />
      </div>

      {/* Generate Button */}
      <button
        onClick={handleGenerate}
        className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-500 to-rose-500 text-white font-black text-sm shadow-lg shadow-pink-500/20 hover:scale-[0.98] transition-all flex items-center justify-center gap-2"
      >
        <Sparkles className="w-4 h-4" /> توليد وصف احترافي
      </button>

      {/* Generated Result */}
      <AnimatePresence>
        {generated && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-pink-950/50 to-rose-950/50 border-pink-500/20" : "bg-pink-50 border-pink-200"}`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className={`text-[10px] font-black ${isDark ? "text-pink-400" : "text-pink-600"}`}>✨ الوصف الاحترافي</span>
              <button onClick={handleCopy} className={`text-[9px] font-bold flex items-center gap-1 px-2 py-1 rounded-lg ${isDark ? "bg-white/10 text-white/60 hover:bg-white/20" : "bg-pink-100 text-pink-600"}`}>
                {copied ? <CheckCircle className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copied ? "تم النسخ!" : "نسخ"}
              </button>
            </div>
            <p className={`text-[11px] leading-relaxed ${isDark ? "text-white/80" : "text-gray-700"}`}>{generatedText}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Photo Enhancement */}
      <div className={`p-4 rounded-2xl border ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isDark ? "bg-pink-500/20" : "bg-pink-100"}`}>
              <Image className="w-5 h-5 text-pink-500" />
            </div>
            <div>
              <p className={`text-xs font-black ${isDark ? "text-white/80" : "text-gray-800"}`}>تحسين الصور</p>
              <p className="text-[9px] opacity-50">تحسين آلي لجودة وإضاءة الصور</p>
            </div>
          </div>
          <button onClick={() => setPhotoEnhanced(!photoEnhanced)} className={`w-10 h-5 rounded-full relative transition-colors ${photoEnhanced ? "bg-pink-500" : "bg-gray-600"}`}>
            <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${photoEnhanced ? "left-6" : "left-1"}`} />
          </button>
        </div>
        {photoEnhanced && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mt-3 pt-3 border-t border-white/10">
            <p className="text-[10px] text-pink-400 font-bold">✓ سيتم تحسين الصور تلقائياً عند الرفع</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// 4. PERSONAL AGENT VIEW — Seeker (Mem0)
// ============================================================================
export function PersonalAgentView({ isDark }: { isDark: boolean }) {
  const preferences = [
    { label: "نوع العقار", value: "فيلا / تاون هاوس", icon: Home },
    { label: "المنطقة", value: "شمال الرياض", icon: MapPin },
    { label: "الميزانية", value: "١.٥ - ٢.٥ مليون", icon: DollarSign },
    { label: "عدد الغرف", value: "٤ غرف فأكثر", icon: Building },
  ];
  const recentSearches = [
    { query: "فيلا مودرن النرجس", time: "منذ ساعتين", results: 14 },
    { query: "شقة الملقا بالقرب من السوق", time: "أمس", results: 7 },
    { query: "تاون هاوس قمة الرياض", time: "3 أيام", results: 3 },
  ];
  const recommendations = [
    { title: "فيلا 5 غرف - النرجس", price: "2.1M", match: 96, tag: "لقطة 🔥" },
    { title: "تاون هاوس مودرن - حطين", price: "1.85M", match: 93, tag: "جديد ✨" },
  ];

  return (
    <div className="space-y-5">
      {/* Memory Badge */}
      <div className={`flex items-center gap-3 p-3 rounded-xl border ${isDark ? "bg-purple-500/10 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
        <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isDark ? "bg-purple-500/20" : "bg-purple-100"}`}>
          <Zap className="w-4 h-4 text-purple-500" />
        </div>
        <div>
          <p className="text-xs font-black text-purple-500">Mem0 — ذاكرة شخصية</p>
          <p className="text-[9px] opacity-60">يتذكر تفضيلاتك ويتعلم منها</p>
        </div>
        <span className="ml-auto text-[9px] font-black text-purple-400 bg-purple-500/20 px-2 py-0.5 rounded-full">24 ذاكرة</span>
      </div>

      {/* Saved Preferences */}
      <div>
        <h4 className={`text-xs font-black mb-3 ${isDark ? "text-white/70" : "text-gray-600"}`}>تفضيلاتي المحفوظة</h4>
        <div className="grid grid-cols-2 gap-2">
          {preferences.map((p, i) => {
            const Icon = p.icon;
            return (
              <div key={i} className={`p-3 rounded-xl border ${isDark ? "bg-white/5 border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                <div className="flex items-center gap-1.5 mb-1">
                  <Icon className="w-3 h-3 opacity-40" />
                  <p className="text-[9px] opacity-50">{p.label}</p>
                </div>
                <p className={`text-[11px] font-black ${isDark ? "text-white" : "text-gray-800"}`}>{p.value}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Searches */}
      <div>
        <h4 className={`text-xs font-black mb-3 ${isDark ? "text-white/70" : "text-gray-600"}`}>آخر عمليات البحث</h4>
        <div className="space-y-2">
          {recentSearches.map((s, i) => (
            <div key={i} className={`p-2.5 rounded-xl border flex items-center gap-3 ${isDark ? "bg-white/5 border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <Search className="w-3.5 h-3.5 opacity-30 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className={`text-[11px] font-bold truncate ${isDark ? "text-white/80" : "text-gray-700"}`}>{s.query}</p>
                <p className="text-[9px] opacity-40">{s.results} نتيجة • {s.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Recommendations */}
      <div>
        <h4 className={`text-xs font-black mb-3 flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
          <Sparkles className="w-3.5 h-3.5 text-purple-400" /> توصيات ذكية لك
        </h4>
        <div className="space-y-2">
          {recommendations.map((r, i) => (
            <div key={i} className={`p-3 rounded-xl border flex items-center gap-3 ${isDark ? "bg-[#151a2d] border-purple-500/20" : "bg-white border-purple-100 shadow-sm"}`}>
              <div className={`flex-1 min-w-0`}>
                <div className="flex items-center gap-2 mb-0.5">
                  <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-800"}`}>{r.title}</p>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 font-bold">{r.tag}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-emerald-400 font-bold">{r.price} ريال</span>
                  <span className="text-[9px] opacity-30">•</span>
                  <span className="text-[9px] text-blue-400 font-bold">{r.match}% تطابق</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 opacity-30 shrink-0" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 5. SEMANTIC SEARCH VIEW — Seeker (Natural Language Search)
// ============================================================================
export function SemanticSearchView({ isDark }: { isDark: boolean }) {
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<any[]>([]);

  const examples = [
    "فيلا مودرن شمال الرياض بسعر أقل من مليونين",
    "شقة قريبة من المدارس في الملقا",
    "تاون هاوس بحديقة وموقف مزدوج",
    "دور أرضي في حي هادي بعيد عن الضوضاء",
  ];

  const mockResults = [
    { title: "فيلا 5 غرف - النرجس", area: "شمال الرياض", price: "1,950,000", match: 97 },
    { title: "فيلا مودرن - حطين", area: "شمال الرياض", price: "2,100,000", match: 91 },
    { title: "فيلا دوبلكس - الياسمين", area: "شمال الرياض", price: "1,850,000", match: 88 },
  ];

  const handleSearch = () => {
    if (!query) return;
    setSearching(true);
    setResults([]);
    setTimeout(() => { setSearching(false); setResults(mockResults); }, 1500);
  };

  return (
    <div className="space-y-4">
      {/* Search Input */}
      <div className={`p-3 rounded-2xl border ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
        <div className="flex items-center gap-2 mb-2">
          <button className={`p-2 rounded-xl ${isDark ? "bg-blue-500/20 text-blue-400" : "bg-blue-100 text-blue-600"}`}>
            <Mic className="w-4 h-4" />
          </button>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSearch()}
            placeholder="ابحث بالكلام العامي..."
            className="flex-1 bg-transparent text-sm outline-none"
          />
          <button onClick={handleSearch} className="p-2 rounded-xl bg-purple-600 text-white">
            <Search className="w-4 h-4" />
          </button>
        </div>
        <p className="text-[9px] opacity-40">يفهم الطلب بالعامية ويحوّله لبحث دقيق</p>
      </div>

      {/* Example Queries */}
      {!results.length && !searching && (
        <div>
          <p className={`text-[10px] font-black opacity-50 mb-2`}>أمثلة على البحث الذكي:</p>
          <div className="flex flex-wrap gap-2">
            {examples.map((e, i) => (
              <button
                key={i}
                onClick={() => setQuery(e)}
                className={`px-2.5 py-1.5 rounded-xl text-[10px] font-bold border transition-colors ${isDark ? "border-purple-500/30 text-purple-400 bg-purple-500/5 hover:bg-purple-500/15" : "border-purple-200 text-purple-600 bg-purple-50 hover:bg-purple-100"}`}
              >
                {e}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Searching indicator */}
      {searching && (
        <div className="flex items-center gap-3 py-4">
          <div className="flex gap-1">
            {[0, 1, 2].map(i => (
              <motion.div key={i} animate={{ scale: [1, 1.4, 1] }} transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.15 }}
                className="w-2 h-2 rounded-full bg-purple-500" />
            ))}
          </div>
          <span className="text-xs opacity-60">يحلل الطلب ويبحث في آلاف العقارات...</span>
        </div>
      )}

      {/* Results */}
      {results.length > 0 && (
        <div>
          <p className={`text-[10px] font-black opacity-50 mb-3`}>{results.length} نتيجة مطابقة</p>
          <div className="space-y-3">
            {results.map((r, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                className={`p-3 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-to-tr from-purple-500/20 to-blue-500/20 shrink-0 flex items-center justify-center">
                  <Home className="w-6 h-6 opacity-30" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-800"}`}>{r.title}</p>
                  <p className="text-[9px] opacity-50 mt-0.5">{r.area}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] text-emerald-400 font-bold">{r.price} ريال</span>
                    <span className="text-[9px] text-blue-400 font-bold bg-blue-500/10 px-1.5 py-0.5 rounded-full">{r.match}% تطابق</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-30 shrink-0" />
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 6. WISHLIST VIEW — Seeker (Saved Properties)
// ============================================================================
export function WishlistView({ isDark }: { isDark: boolean }) {
  const [wishlist, setWishlist] = useState([
    { id: 1, title: "فيلا مودرن - النرجس", area: "شمال الرياض", price: 2100000, prevPrice: 2300000, type: "فيلا", rooms: 5, status: "متاح", priority: true },
    { id: 2, title: "شقة فاخرة - الملقا", area: "الرياض", price: 980000, prevPrice: 980000, type: "شقة", rooms: 3, status: "متاح", priority: false },
    { id: 3, title: "تاون هاوس - حطين", area: "شمال الرياض", price: 1750000, prevPrice: 1850000, type: "تاون هاوس", rooms: 4, status: "محجوز", priority: false },
  ]);

  const removeItem = (id: number) => setWishlist(prev => prev.filter(p => p.id !== id));
  const togglePriority = (id: number) => setWishlist(prev => prev.map(p => p.id === id ? { ...p, priority: !p.priority } : p));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className={`text-xs opacity-50`}>{wishlist.length} عقار محفوظ</p>
        <button className={`text-[10px] font-bold px-2 py-1 rounded-lg flex items-center gap-1 ${isDark ? "bg-white/5 text-white/50" : "bg-gray-100 text-gray-500"}`}>
          <Filter className="w-3 h-3" /> ترتيب
        </button>
      </div>

      <div className="space-y-3">
        {wishlist.map((p, i) => {
          const priceDropped = p.price < p.prevPrice;
          return (
            <motion.div
              key={p.id}
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ delay: i * 0.08 }}
              className={`p-3 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}
            >
              <div className="flex gap-3">
                {/* Thumbnail */}
                <div className={`w-16 h-16 rounded-xl shrink-0 flex items-center justify-center ${isDark ? "bg-white/5" : "bg-gray-100"} relative overflow-hidden`}>
                  <Home className="w-7 h-7 opacity-20" />
                  {p.status === "محجوز" && (
                    <div className="absolute inset-0 bg-red-500/30 flex items-center justify-center">
                      <span className="text-[8px] font-black text-red-400 bg-red-900/50 px-1 rounded">محجوز</span>
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-1">
                    <p className={`text-xs font-black leading-tight ${isDark ? "text-white" : "text-gray-800"}`}>{p.title}</p>
                    <div className="flex gap-1 shrink-0">
                      <button onClick={() => togglePriority(p.id)} className={`w-6 h-6 rounded-lg flex items-center justify-center ${p.priority ? "text-amber-400" : "opacity-20"}`}>
                        <Star className="w-3.5 h-3.5" fill={p.priority ? "currentColor" : "none"} />
                      </button>
                      <button onClick={() => removeItem(p.id)} className="w-6 h-6 rounded-lg flex items-center justify-center opacity-20 hover:opacity-60 hover:text-red-400 transition-all">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <p className="text-[9px] opacity-40 mt-0.5">{p.area} • {p.rooms} غرف</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-[11px] font-black ${isDark ? "text-white" : "text-gray-900"}`}>
                      {(p.price / 1000000).toFixed(2)}M ريال
                    </span>
                    {priceDropped && (
                      <span className="flex items-center gap-0.5 text-[9px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full">
                        <TrendingDown className="w-2.5 h-2.5" />
                        انخفض
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {wishlist.length === 0 && (
        <div className="text-center py-10">
          <Heart className="w-12 h-12 opacity-10 mx-auto mb-3" />
          <p className="text-sm opacity-40">قائمة المفضلة فارغة</p>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 7. EARLY ALERTS VIEW — Seeker VIP (24h Before Public Listing)
// ============================================================================
export function EarlyAlertsView({ isDark }: { isDark: boolean }) {
  const [enabled, setEnabled] = useState(true);
  const [alerts, setAlerts] = useState([
    { id: 1, title: "فيلا مودرن 5 غرف", area: "حي النرجس، الرياض", price: "2,350,000", type: "فيلا", match: 94, countdown: "قبل 18 ساعة من النشر", urgent: true, seen: false },
    { id: 2, title: "شقة دوبلكس فاخرة", area: "حي الملقا، الرياض", price: "1,100,000", type: "شقة", match: 87, countdown: "قبل 22 ساعة من النشر", urgent: true, seen: false },
    { id: 3, title: "تاون هاوس - حطين", area: "حي حطين، الرياض", price: "1,750,000", type: "تاون هاوس", match: 79, countdown: "نُشر قبل ساعتين", urgent: false, seen: true },
    { id: 4, title: "أرض سكنية 600م²", area: "حي الياسمين، الرياض", price: "980,000", type: "أرض", match: 71, countdown: "نُشر أمس", urgent: false, seen: true },
  ]);

  const markSeen = (id: number) => setAlerts(prev => prev.map(a => a.id === id ? { ...a, seen: true } : a));
  const unseen = alerts.filter(a => !a.seen).length;

  return (
    <div className="space-y-4">
      {/* Status Header */}
      <div className={`p-4 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-gradient-to-br from-amber-900/20 to-orange-900/20 border-amber-500/25" : "bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200"}`}>
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/30 shrink-0">
          <BellRing className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>تنبيهات VIP المبكرة</p>
          <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>تصلك العقارات قبل 24 ساعة من نشرها للعامة</p>
        </div>
        <button onClick={() => setEnabled(!enabled)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-black border transition-all ${enabled ? "bg-amber-500 text-white border-amber-500 shadow-md shadow-amber-500/30" : isDark ? "bg-white/5 text-white/40 border-white/10" : "bg-gray-100 text-gray-400 border-gray-200"}`}>
          {enabled ? <BellRing className="w-3 h-3" /> : <BellOff className="w-3 h-3" />}
          {enabled ? "مفعّل" : "موقوف"}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "هذا الأسبوع", value: "7", color: "text-amber-400" },
          { label: "غير مقروء", value: String(unseen), color: "text-red-400" },
          { label: "نسبة التطابق", value: "88%", color: "text-emerald-400" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Alert Preferences */}
      <div className={`p-3 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
        <p className={`text-[10px] font-black mb-2 ${isDark ? "text-white/40" : "text-gray-400"}`}>تفضيلاتي للتنبيهات</p>
        <div className="flex flex-wrap gap-2">
          {["فيلا", "شقة", "تاون هاوس", "شمال الرياض", "أقل من 2M"].map((tag, i) => (
            <span key={i} className={`px-2 py-1 rounded-lg text-[10px] font-bold ${isDark ? "bg-amber-500/15 text-amber-400 border border-amber-500/25" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
              {tag}
            </span>
          ))}
          <button className={`px-2 py-1 rounded-lg text-[10px] font-bold border-dashed border ${isDark ? "border-white/20 text-white/40 hover:bg-white/5" : "border-gray-300 text-gray-400 hover:bg-gray-50"}`}>
            <Plus className="w-3 h-3 inline ml-0.5" />تعديل
          </button>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-3">
        <p className={`text-xs font-black ${isDark ? "text-white/60" : "text-gray-500"}`}>آخر التنبيهات ({alerts.length})</p>
        {alerts.map((a, i) => (
          <motion.div key={a.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            onClick={() => markSeen(a.id)}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${a.seen ? "opacity-60" : ""} ${a.urgent && !a.seen ? isDark ? "bg-amber-900/10 border-amber-500/20" : "bg-amber-50 border-amber-200" : isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                <Home className="w-5 h-5 opacity-40" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{a.title}</p>
                  {!a.seen && <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0" />}
                </div>
                <p className={`text-[10px] mb-1.5 ${isDark ? "text-white/50" : "text-gray-500"}`}><MapPin className="w-2.5 h-2.5 inline ml-0.5" />{a.area}</p>
                <div className="flex items-center gap-3">
                  <span className={`text-[11px] font-black ${isDark ? "text-white" : "text-gray-900"}`}>{a.price} ريال</span>
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${isDark ? "bg-emerald-500/15 text-emerald-400" : "bg-emerald-100 text-emerald-700"}`}>{a.match}% تطابق</span>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 shrink-0">
                <span className={`text-[8px] font-bold px-2 py-0.5 rounded-full ${a.urgent && !a.seen ? "bg-amber-500 text-white" : isDark ? "bg-white/5 text-white/30" : "bg-gray-100 text-gray-400"}`}>{a.countdown}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 8. OFFERS VIEW — Landlord (Received Offers on My Properties)
// ============================================================================
export function OffersView({ isDark }: { isDark: boolean }) {
  const [offers, setOffers] = useState([
    { id: 1, buyerName: "فيصل الدوسري", property: "فيلا النرجس 5 غرف", amount: 3200000, askingPrice: 3500000, date: "اليوم 2:30 م", status: "pending" as const, via: "وسيط", message: "العرض جاد وجاهز للتوثيق الفوري" },
    { id: 2, buyerName: "ريم الشهري", property: "شقة الملقا 3 غرف", amount: 950000, askingPrice: 1050000, date: "أمس 11:00 ص", status: "pending" as const, via: "مباشر", message: "هل السعر قابل للنقاش؟" },
    { id: 3, buyerName: "طلال المنصور", property: "أرض الياسمين 600م²", amount: 1100000, askingPrice: 1200000, date: "3 أيام", status: "accepted" as const, via: "وسيط", message: "" },
    { id: 4, buyerName: "هنادي العمري", property: "فيلا النرجس 5 غرف", amount: 3000000, askingPrice: 3500000, date: "أسبوع", status: "rejected" as const, via: "مباشر", message: "هل يمكن تقسيط جزء؟" },
  ]);

  const updateStatus = (id: number, status: "accepted" | "rejected") => {
    setOffers(prev => prev.map(o => o.id === id ? { ...o, status } : o));
  };

  const pendingCount = offers.filter(o => o.status === "pending").length;
  const acceptedTotal = offers.filter(o => o.status === "accepted").reduce((s, o) => s + o.amount, 0);

  const statusConfig = {
    pending:  { label: "بانتظار ردك", class: isDark ? "bg-amber-500/15 text-amber-400 border-amber-500/25" : "bg-amber-50 text-amber-700 border-amber-200" },
    accepted: { label: "مقبول", class: isDark ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" : "bg-emerald-50 text-emerald-700 border-emerald-200" },
    rejected: { label: "مرفوض", class: isDark ? "bg-red-500/15 text-red-400 border-red-500/25" : "bg-red-50 text-red-700 border-red-200" },
  };

  return (
    <div className="space-y-4">
      {/* KPI Strip */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "عروض واردة", value: String(offers.length), color: isDark ? "text-white" : "text-gray-900" },
          { label: "تنتظر ردك", value: String(pendingCount), color: "text-amber-400" },
          { label: "قيمة مقبولة", value: acceptedTotal > 0 ? `${(acceptedTotal/1000000).toFixed(1)}M` : "—", color: "text-emerald-400" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Offers List */}
      <div className="space-y-3">
        {offers.map((offer, i) => {
          const diff = ((offer.askingPrice - offer.amount) / offer.askingPrice * 100).toFixed(0);
          return (
            <motion.div key={offer.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center text-white font-black text-sm">
                    {offer.buyerName[0]}
                  </div>
                  <div>
                    <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{offer.buyerName}</p>
                    <p className={`text-[9px] opacity-50`}>{offer.via} · {offer.date}</p>
                  </div>
                </div>
                <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${statusConfig[offer.status].class}`}>
                  {statusConfig[offer.status].label}
                </span>
              </div>

              <div className={`p-3 rounded-xl mb-3 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <p className={`text-[9px] opacity-50 mb-1`}>{offer.property}</p>
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{offer.amount.toLocaleString("ar-SA")} ريال</p>
                    <p className={`text-[9px] opacity-40 line-through`}>السعر المطلوب: {offer.askingPrice.toLocaleString("ar-SA")}</p>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${isDark ? "bg-red-500/15 text-red-400" : "bg-red-50 text-red-600"}`}>
                    -{diff}%
                  </span>
                </div>
              </div>

              {offer.message && (
                <p className={`text-[10px] mb-3 leading-5 ${isDark ? "text-white/60" : "text-gray-500"}`}>
                  <MessageSquare className="w-3 h-3 inline ml-1 opacity-50" />"{offer.message}"
                </p>
              )}

              {offer.status === "pending" && (
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => updateStatus(offer.id, "accepted")}
                    className="py-2 rounded-xl bg-emerald-500 text-white text-[10px] font-black flex items-center justify-center gap-1 shadow-lg shadow-emerald-500/20">
                    <ThumbsUp className="w-3 h-3" /> قبول العرض
                  </button>
                  <button onClick={() => updateStatus(offer.id, "rejected")}
                    className={`py-2 rounded-xl text-[10px] font-black flex items-center justify-center gap-1 border ${isDark ? "border-red-500/20 bg-red-500/10 text-red-400" : "border-red-200 bg-red-50 text-red-600"}`}>
                    <ThumbsDown className="w-3 h-3" /> رفض
                  </button>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================================
// 9. BROKER MATCH VIEW — Landlord Premium (Brokers Requesting Access)
// ============================================================================
export function BrokerMatchView({ isDark }: { isDark: boolean }) {
  const [brokers, setBrokers] = useState([
    { id: 1, name: "عبدالله العتيبي", rating: 4.9, deals: 87, fal: "FAL-2024-1289", specialty: "فلل ومجمعات", badge: "إيليت", approved: false, rejected: false, message: "عندي مشترين جاهزين يبحثون عن فيلا في النرجس بميزانية 3.5-4M" },
    { id: 2, name: "سارة القحطاني", rating: 4.7, deals: 54, fal: "FAL-2024-0987", specialty: "شقق وأبراج", badge: "متقدم", approved: false, rejected: false, message: "لديّ عميل يدفع كاش ويريد إغلاق الصفقة خلال أسبوع" },
    { id: 3, name: "شركة الأفق العقارية", rating: 4.8, deals: 214, fal: "FAL-2022-0345", specialty: "تجاري وسكني", badge: "منشأة", approved: true, rejected: false, message: "" },
  ]);

  const update = (id: number, key: "approved" | "rejected") => {
    setBrokers(prev => prev.map(b => b.id === id ? { ...b, approved: key === "approved", rejected: key === "rejected" } : b));
  };

  const badgeColor: Record<string, string> = {
    "إيليت": "bg-amber-500/20 text-amber-400 border-amber-500/30",
    "متقدم": "bg-purple-500/20 text-purple-400 border-purple-500/30",
    "منشأة": "bg-blue-500/20 text-blue-400 border-blue-500/30",
  };

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className={`p-4 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-purple-900/15 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
        <Handshake className={`w-6 h-6 shrink-0 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
        <div>
          <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{brokers.length} وسطاء يطلبون التسويق لعقاراتك</p>
          <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>تحقق من تقييماتهم وصفقاتهم قبل الموافقة</p>
        </div>
      </div>

      {/* Brokers */}
      {brokers.map((b, i) => (
        <motion.div key={b.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
          className={`p-4 rounded-2xl border transition-all ${b.approved ? isDark ? "border-emerald-500/25 bg-emerald-900/10" : "border-emerald-200 bg-emerald-50" : b.rejected ? "opacity-50" : isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
          <div className="flex items-start gap-3 mb-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center text-white font-black text-lg shrink-0">
              {b.name[0]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{b.name}</p>
                <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md border ${badgeColor[b.badge] || "bg-gray-500/20 text-gray-400"}`}>{b.badge}</span>
                {b.approved && <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30`}>موافق</span>}
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-0.5 text-[10px] text-amber-400 font-bold">
                  <Star className="w-3 h-3 fill-current" />{b.rating}
                </span>
                <span className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>{b.deals} صفقة</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-md ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-500"}`}>{b.fal}</span>
              </div>
            </div>
          </div>

          {b.message && (
            <p className={`text-[10px] leading-5 mb-3 p-2.5 rounded-xl ${isDark ? "bg-white/5 text-white/60" : "bg-gray-50 text-gray-600"}`}>
              <MessageCircle className="w-3 h-3 inline ml-1 opacity-50" />"{b.message}"
            </p>
          )}

          <div className="flex items-center gap-2 mb-3">
            <span className={`text-[9px] px-2 py-1 rounded-lg ${isDark ? "bg-white/5 text-white/50" : "bg-gray-100 text-gray-500"}`}>
              تخصص: {b.specialty}
            </span>
          </div>

          {!b.approved && !b.rejected && (
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => update(b.id, "approved")}
                className="py-2 rounded-xl bg-emerald-500 text-white text-[10px] font-black flex items-center justify-center gap-1 shadow-lg shadow-emerald-500/20">
                <CheckCircle className="w-3.5 h-3.5" /> قبول الوسيط
              </button>
              <button onClick={() => update(b.id, "rejected")}
                className={`py-2 rounded-xl text-[10px] font-black flex items-center justify-center gap-1 border ${isDark ? "border-white/10 text-white/50" : "border-gray-200 text-gray-500"}`}>
                <XCircle className="w-3.5 h-3.5" /> رفض
              </button>
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}

// ============================================================================
// 10. AI INQUIRY GUARD VIEW — Landlord Premium (Smart Chat Filter)
// ============================================================================
export function AIInquiryGuardView({ isDark }: { isDark: boolean }) {
  const [guardActive, setGuardActive] = useState(true);
  const [chats, setChats] = useState([
    { id: 1, name: "أحمد ناصر", time: "10 دق", msg: "كم سعر الفيلا؟ هل يقبل بدل؟", status: "allowed" as const, aiNote: "سؤال جاد - يبدو مهتماً حقيقياً", phone: "0501234567" },
    { id: 2, name: "مجهول 1", time: "25 دق", msg: "ابي رقمك الخاص", status: "blocked" as const, aiNote: "مشبوه - يطلب بيانات خاصة", phone: null },
    { id: 3, name: "سارة المحمد", time: "ساعة", msg: "هل يقبل التمويل البنكي؟ عندي موافقة مبدئية", status: "allowed" as const, aiNote: "جادة - لديها تمويل بنكي مؤكد", phone: "0559871234" },
    { id: 4, name: "مجهول 2", time: "3 ساعات", msg: "اعطني خصم 40%", status: "blocked" as const, aiNote: "محاولة مضايقة أو مزايدة غير واقعية", phone: null },
    { id: 5, name: "خالد الشهري", time: "أمس", msg: "متى يمكن معاينة العقار؟ أنا في الرياض حالياً", status: "allowed" as const, aiNote: "طلب زيارة حقيقي - أولوية", phone: "0566543210" },
  ]);

  const allowed = chats.filter(c => c.status === "allowed").length;
  const blocked = chats.filter(c => c.status === "blocked").length;

  return (
    <div className="space-y-4">
      {/* Guard Toggle */}
      <div className={`p-4 rounded-2xl border flex items-center justify-between ${guardActive ? isDark ? "bg-cyan-900/15 border-cyan-500/25" : "bg-cyan-50 border-cyan-200" : isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100"}`}>
        <div className="flex items-center gap-3">
          <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${guardActive ? "bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30" : isDark ? "bg-white/5" : "bg-gray-100"}`}>
            <Shield className={`w-6 h-6 ${guardActive ? "text-white" : "opacity-30"}`} />
          </div>
          <div>
            <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>حارس الاستفسارات AI</p>
            <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>{guardActive ? `فلتر ${blocked} محادثة مشبوهة هذا الشهر` : "الوضع اليدوي مفعّل"}</p>
          </div>
        </div>
        <button onClick={() => setGuardActive(!guardActive)}
          className={`w-12 h-6 rounded-full relative transition-colors ${guardActive ? "bg-cyan-500" : isDark ? "bg-gray-600" : "bg-gray-300"}`}>
          <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow-sm ${guardActive ? "right-1" : "left-1"}`} />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "إجمالي", value: String(chats.length), color: isDark ? "text-white" : "text-gray-900" },
          { label: "مسموح", value: String(allowed), color: "text-emerald-400" },
          { label: "محجوب", value: String(blocked), color: "text-red-400" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Chat List */}
      <div className="space-y-2.5">
        {chats.map((chat, i) => (
          <motion.div key={chat.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
            className={`p-3.5 rounded-2xl border ${chat.status === "blocked" ? isDark ? "bg-red-900/10 border-red-500/15 opacity-70" : "bg-red-50/80 border-red-100 opacity-70" : isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <div className="flex items-start gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-white font-black text-sm shrink-0 ${chat.status === "blocked" ? "bg-red-500/40" : "bg-gradient-to-br from-cyan-500 to-blue-600"}`}>
                {chat.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{chat.name}</p>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] opacity-40">{chat.time}</span>
                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full border ${chat.status === "blocked" ? isDark ? "bg-red-500/20 text-red-400 border-red-500/25" : "bg-red-50 text-red-600 border-red-200" : isDark ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/25" : "bg-emerald-50 text-emerald-700 border-emerald-200"}`}>
                      {chat.status === "blocked" ? "محجوب" : "مسموح"}
                    </span>
                  </div>
                </div>
                <p className={`text-[10px] leading-4 mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>"{chat.msg}"</p>
                <p className={`text-[9px] px-2 py-0.5 rounded-lg inline-block ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-500"}`}>
                  <Sparkles className="w-2.5 h-2.5 inline ml-0.5 text-cyan-400" />
                  {chat.aiNote}
                </p>
                {chat.phone && chat.status === "allowed" && (
                  <div className="mt-2">
                    <button className={`flex items-center gap-1.5 text-[10px] font-bold px-2 py-1 rounded-lg ${isDark ? "bg-emerald-500/15 text-emerald-400" : "bg-emerald-50 text-emerald-600"}`}>
                      <Phone className="w-3 h-3" /> {chat.phone}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 11. FAIR PRICE VIEW — Seeker VIP (Valuation-Style Market Price Analysis)
// ============================================================================
export function FairPriceView({ isDark }: { isDark: boolean }) {
  const [propType, setPropType] = useState("فيلا");
  const [region, setRegion] = useState("الرياض");
  const [neighborhood, setNeighborhood] = useState("النرجس");
  const [landArea, setLandArea] = useState("400");
  const [builtArea, setBuiltArea] = useState("300");
  const [propAge, setPropAge] = useState("3");
  const [streets, setStreets] = useState("2");
  const [listedPriceStr, setListedPriceStr] = useState("2,800,000");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const neighborhoods: Record<string, string[]> = {
    "الرياض": ["النرجس", "الملقا", "حطين", "الياسمين", "العليا"],
    "جدة": ["أبحر الشمالية", "الشاطئ", "الزهراء"],
    "الدمام": ["الشاطئ", "العزيزية"],
  };

  const handleAnalyze = () => {
    setLoading(true); setResult(null);
    setTimeout(() => {
      const listed = parseInt(listedPriceStr.replace(/,/g, "")) || 2800000;
      const ageFactor = Math.max(0.7, 1 - (parseInt(propAge) || 0) * 0.02);
      const streetFactor = parseInt(streets) >= 3 ? 1.08 : parseInt(streets) === 2 ? 1.04 : 1.0;
      const fair = Math.round(listed * 0.95 * ageFactor * streetFactor / 50000) * 50000;
      const diff = listed - fair;
      const diffPct = ((diff / listed) * 100).toFixed(1);
      const pricePerSqm = Math.round(fair / parseInt(landArea || "400"));
      setResult({ fair, diff, diffPct, pricePerSqm, listed, low: Math.round(fair * 0.93 / 50000) * 50000, high: Math.round(fair * 1.05 / 50000) * 50000 });
      setLoading(false);
    }, 2800);
  };

  const fmt = (n: number) => n.toLocaleString("ar-SA");
  const diffPct = "—";
  const listedPrice = 2800000;
  const fairPrice = 2520000;
  const diff = listedPrice - fairPrice;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className={`p-4 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-gradient-to-br from-emerald-900/20 to-teal-900/20 border-emerald-500/25" : "bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200"}`}>
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/30 shrink-0">
          <TrendingDown className="w-6 h-6 text-white" />
        </div>
        <div>
          <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>تحليل السعر العادل</p>
          <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>مقارنة مبنية على صفقات حقيقية مسجلة</p>
        </div>
      </div>

      {/* Inputs */}
      <div className="space-y-3">
        <div>
          <label className={`block text-xs font-bold mb-2 ${isDark ? "text-white/60" : "text-gray-600"}`}>نوع العقار</label>
          <div className="flex flex-wrap gap-2">
            {["فيلا", "شقة", "تاون هاوس", "أرض"].map(t => (
              <button key={t} onClick={() => { setPropType(t); setAnalyzed(false); }} className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${propType === t ? "bg-emerald-500 text-white border-emerald-500 shadow-md" : isDark ? "bg-white/5 text-white/40 border-white/5" : "bg-white text-gray-500 border-gray-200"}`}>{t}</button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={`block text-xs font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>الحي</label>
            <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border ${isDark ? "bg-[#151a2d] border-white/8" : "bg-white border-gray-200"}`}>
              <MapPin className="w-3.5 h-3.5 opacity-30" />
              <input value={area} onChange={e => { setArea(e.target.value); setAnalyzed(false); }} className="flex-1 bg-transparent text-xs outline-none" style={{ direction: "rtl" }} />
            </div>
          </div>
          <div>
            <label className={`block text-xs font-bold mb-1.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>المساحة (م²)</label>
            <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border ${isDark ? "bg-[#151a2d] border-white/8" : "bg-white border-gray-200"}`}>
              <Activity className="w-3.5 h-3.5 opacity-30" />
              <input value={sqm} onChange={e => { setSqm(e.target.value); setAnalyzed(false); }} className="flex-1 bg-transparent text-xs outline-none" style={{ direction: "rtl" }} />
            </div>
          </div>
        </div>
      </div>

      <button onClick={handleAnalyze} disabled={loading}
        className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 hover:scale-[0.98] transition-all disabled:opacity-50">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BarChart3 className="w-4 h-4" />}
        {loading ? "جاري التحليل..." : "تحليل السعر العادل"}
      </button>

      <AnimatePresence>
        {analyzed && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
            {/* Main Result */}
            <div className={`p-5 rounded-2xl border text-center ${isDark ? "bg-gradient-to-br from-emerald-900/25 to-teal-900/25 border-emerald-500/30" : "bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-300"}`}>
              <p className={`text-xs font-black mb-1 ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>السعر المعروض</p>
              <p className={`text-2xl font-black mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{listedPrice.toLocaleString("ar-SA")} ريال</p>
              <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full ${isDark ? "bg-emerald-500/20" : "bg-emerald-100"}`}>
                <TrendingDown className="w-4 h-4 text-emerald-500" />
                <span className="text-sm font-black text-emerald-500">أعلى من السعر العادل بـ {diffPct}%</span>
              </div>
            </div>

            {/* Comparison */}
            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <p className={`text-[10px] font-black mb-3 ${isDark ? "text-white/40" : "text-gray-400"}`}>مقارنة الأسعار</p>
              <div className="space-y-3">
                {[
                  { label: "السعر المعروض", value: listedPrice, color: "bg-red-500", pct: 100 },
                  { label: "السعر العادل (صفقات مسجلة)", value: fairPrice, color: "bg-emerald-500", pct: (fairPrice/listedPrice)*100 },
                  { label: "متوسط المنطقة", value: 2650000, color: "bg-blue-500", pct: (2650000/listedPrice)*100 },
                ].map((r, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-[10px] font-bold ${isDark ? "text-white/60" : "text-gray-600"}`}>{r.label}</span>
                      <span className={`text-[10px] font-black ${isDark ? "text-white" : "text-gray-900"}`}>{r.value.toLocaleString("ar-SA")}</span>
                    </div>
                    <div className={`h-2 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                      <motion.div initial={{ width: 0 }} animate={{ width: `${r.pct}%` }} transition={{ duration: 0.8, delay: i * 0.15 }}
                        className={`h-full rounded-full ${r.color}`} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Advice */}
            <div className={`p-4 rounded-2xl border ${isDark ? "bg-purple-900/15 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className={`text-xs font-black ${isDark ? "text-purple-400" : "text-purple-600"}`}>توصية ڤال</span>
              </div>
              <p className={`text-xs leading-6 ${isDark ? "text-white/70" : "text-gray-700"}`}>
                السعر المعروض أعلى من السعر العادل للمنطقة بـ <strong className="text-red-400">{diff.toLocaleString("ar-SA")} ريال</strong>. ننصح بالتفاوض للوصول إلى <strong className="text-emerald-400">{fairPrice.toLocaleString("ar-SA")} ريال</strong> أو أقل. بناءً على 12 صفقة مسجلة في {area} خلال آ��ر 6 أشهر.
              </p>
            </div>

            {/* Nearby Transactions */}
            <div>
              <p className={`text-xs font-black mb-2 ${isDark ? "text-white/60" : "text-gray-500"}`}>صفقات قريبة مسجلة</p>
              <div className="space-y-2">
                {[
                  { title: `${propType} - ${area}`, price: 2500000, date: "قبل أسبوعين", sqm: 380 },
                  { title: `${propType} مجاورة`, price: 2600000, date: "قبل شهر", sqm: 420 },
                  { title: `${propType} - ${area}`, price: 2480000, date: "قبل شهرين", sqm: 360 },
                ].map((t, i) => (
                  <div key={i} className={`flex items-center justify-between p-2.5 rounded-xl border ${isDark ? "bg-white/5 border-white/5" : "bg-gray-50 border-gray-100"}`}>
                    <div>
                      <p className={`text-[10px] font-bold ${isDark ? "text-white/80" : "text-gray-700"}`}>{t.title}</p>
                      <p className="text-[9px] opacity-40">{t.sqm}م² · {t.date}</p>
                    </div>
                    <span className={`text-[11px] font-black ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{t.price.toLocaleString("ar-SA")}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ============================================================================
// 12. MARKETING AGENT VIEW — Developer (In-App AI Marketing Studio)
// ============================================================================

const INAPP_TEMPLATES: Record<string, Record<string, string>> = {
  "النخيل ريزيدنس": {
    title: "النخيل ريزيدنس | 240 وحدة فاخرة — الملقا، شمال الرياض",
    desc: "مشروع سكني راقٍ يجمع بين الهدوء والتصميم العصري في قلب حي الملقا. وحدات تبدأ من 120م² حتى 280م² بتشطيبات أوروبية فاخرة، مسبح، نادٍ صحي متكامل، وبوابة ذكية. التمويل العقاري متاح ويقبل برامج سكني. التسليم فوري.",
    points: "• تشطيبات بريميوم بأعلى المواد الأوروبية\n• مسبح خارجي + نادٍ صحي + ملعب أطفال\n• بوابة ذكية مع نظام أمن 24/7\n• يقبل التمويل العقاري وبرنامج سكني\n• إطلالة على حدائق داخلية مشجّرة\n• تسليم فوري — متاح للمعاينة الآن",
    reply: "شكراً لاهتمامك بمشروع النخيل ريزيدنس 🌟\n\nفريقنا استلم استفساركم وسيتواصل معكم خلال ساعة. يمكنكم حجز موعد معاينة مباشرةً من التطبيق أو تحديد الوحدة المناسبة.\n\nنسعد بخدمتكم — فريق النخيل ريزيدنس",
  },
  "واحة الأعمال": {
    title: "واحة الأعمال | مكاتب تجارية فاخرة — حي العليا، الرياض",
    desc: "مجمع تجاري من الدرجة الأولى في قلب حي العليا. يضم 18 طابقاً بمساحات مكتبية مرنة من 80م² حتى 1,200م². بنية تحتية ذكية بالكامل، خدمات كونسيرج، مواقف 3 طوابق، وغرف اجتماعات مشتركة بتجهيزات عالمية.",
    points: "• موقع استراتيجي في العليا — قلب أعمال الرياض\n• مساحات مرنة: من مكتب فردي لطابق كامل\n• نظام ذكي: إضاءة + تكييف + أمن تلقائي\n• خدمات كونسيرج + استقبال احترافي\n• مواقف 3 طوابق + شاحن مركبات كهربائية\n• عوائد إيجارية مضمونة 8% سنوياً",
    reply: "شكراً لاهتمامكم بواحة الأعمال 🏢\n\nتم استلام طلبكم. سيتواصل معكم مسؤول العلاقات التجارية لدينا خلال أقل من 30 دقيقة لمناقشة متطلباتكم بالتفصيل وترتيب جولة تعريفية للمبنى.\n\nنتطلع للشراكة — فريق واحة الأعمال",
  },
};

const MATCHED_USERS_INIT = [
  { id: 1, name: "م. خالد العتيبي", type: "باحث", budget: "1.2 — 1.5M ﷼", area: "الملقا / النرجس", match: 97, active: "نشط الآن", avatar: "خ", color: "from-cyan-500 to-blue-600", sent: false, sending: false },
  { id: 2, name: "أ. سارة الحربي", type: "وسيط", budget: "1 — 2M ﷼", area: "شمال الرياض", match: 94, active: "منذ ساعة", avatar: "س", color: "from-purple-500 to-pink-500", sent: false, sending: false },
  { id: 3, name: "م. فهد الدوسري", type: "باحث", budget: "1.1 — 1.4M ﷼", area: "الملقا", match: 91, active: "اليوم", avatar: "ف", color: "from-emerald-500 to-teal-500", sent: false, sending: false },
  { id: 4, name: "أ. محمد الشمري", type: "وسيط", budget: "800K — 2M ﷼", area: "الرياض الشمالية", match: 88, active: "أمس", avatar: "م", color: "from-orange-500 to-red-500", sent: false, sending: false },
  { id: 5, name: "م. نورة القحطاني", type: "باحث", budget: "1.2 — 1.6M ﷼", area: "النرجس / الملقا", match: 85, active: "يومان", avatar: "ن", color: "from-rose-500 to-pink-600", sent: false, sending: false },
];

const DAILY_VIEWS = [42, 67, 55, 89, 71, 110, 98, 134, 122, 148, 139, 162, 178, 155];

const CONTENT_INSIGHTS = [
  { text: "وصف العقار يؤثر 68% على قرار المشتري — كلما كان أوضح زاد الاستفسار", color: "text-cyan-400" },
  { text: "الإعلانات بنقاط بيع محددة تحصل على 2.4× استفسارات أكثر", color: "text-emerald-400" },
  { text: "الرد التلقائي الفوري يرفع نسبة إتمام الصفقة 43%", color: "text-orange-400" },
];

// ── Campaigns Tab Component (used inside MarketingAgentView) ──────────────────
function CampaignsTab({ isDark }: { isDark: boolean }) {
  const [campaigns, setCampaigns] = useState([
    { id: 1, name: "النخيل ريزيدنس — ربيع 2026", status: "نشطة" as const, budget: 15000, spent: 9200, leads: 124, reach: "45.2K", roas: 340, endDate: "31 مارس" },
    { id: 2, name: "واحة الأعمال — Q2", status: "مجدولة" as const, budget: 20000, spent: 0, leads: 0, reach: "—", roas: 0, endDate: "30 أبريل" },
    { id: 3, name: "مشروع الواجهة — Q4 2025", status: "منتهية" as const, budget: 12000, spent: 12000, leads: 89, reach: "38.7K", roas: 280, endDate: "31 ديسمبر" },
  ]);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newBudget, setNewBudget] = useState("");
  const [newEnd, setNewEnd] = useState("");
  const [aiLoading, setAiLoading] = useState<number | null>(null);
  const [aiReport, setAiReport] = useState<Record<number, string>>({});

  const statusCfg = {
    "نشطة": { bg: isDark ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" : "bg-emerald-50 text-emerald-700 border-emerald-200", dot: "bg-emerald-400 animate-pulse" },
    "مجدولة": { bg: isDark ? "bg-amber-500/20 text-amber-400 border-amber-500/30" : "bg-amber-50 text-amber-700 border-amber-200", dot: "bg-amber-400" },
    "منتهية": { bg: isDark ? "bg-gray-500/20 text-gray-400 border-gray-500/30" : "bg-gray-100 text-gray-500 border-gray-200", dot: "bg-gray-400" },
  };

  const toggleStatus = (id: number) => {
    setCampaigns(prev => prev.map(c => c.id === id
      ? { ...c, status: c.status === "نشطة" ? "مجدولة" : c.status === "مجدولة" ? "نشطة" : c.status }
      : c));
  };

  const generateReport = (id: number) => {
    setAiLoading(id);
    setTimeout(() => {
      const c = campaigns.find(x => x.id === id)!;
      setAiReport(prev => ({
        ...prev,
        [id]: c.status === "منتهية"
          ? `[AI] حملة "${c.name}" أنجزت ${c.leads} عميل محتمل بتكلفة ${Math.round(c.spent / Math.max(1, c.leads))} ريال/عميل. العائد ${c.roas}%. ننصح بإعادة تفعيلها في مارس لأن الطلب الموسمي مرتفع.`
          : `[AI] الحملة تسير بشكل جيد. المصروف ${Math.round((c.spent / c.budget) * 100)}% من الميزانية وحقق ${c.leads} عميل. زيادة الميزانية 20% ستُضاعف العملاء بمعدل ROI محافظ 2.8x.`,
      }));
      setAiLoading(null);
    }, 1800);
  };

  const addCampaign = () => {
    if (!newName.trim()) return;
    setCampaigns(prev => [...prev, {
      id: Date.now(), name: newName, status: "مجدولة",
      budget: parseInt(newBudget) || 10000, spent: 0, leads: 0, reach: "—", roas: 0, endDate: newEnd || "—"
    }]);
    setNewName(""); setNewBudget(""); setNewEnd(""); setShowCreate(false);
  };

  const totalLeads = campaigns.reduce((s, c) => s + c.leads, 0);
  const totalSpent = campaigns.reduce((s, c) => s + c.spent, 0);
  const activeCampaigns = campaigns.filter(c => c.status === "نشطة").length;

  const bg = isDark ? "bg-[#151a2d]" : "bg-white";
  const border = isDark ? "border-white/5" : "border-gray-100";

  return (
    <div className="space-y-4">
      {/* KPIs */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "حملات نشطة", value: String(activeCampaigns), color: "text-emerald-400" },
          { label: "إجمالي العملاء", value: String(totalLeads), color: "text-violet-400" },
          { label: "المصروف", value: `${(totalSpent / 1000).toFixed(1)}K`, color: isDark ? "text-white" : "text-gray-900" },
        ].map((s, i) => (
          <div key={i} className={`p-3 rounded-2xl text-center border ${bg} ${border}`}>
            <p className={`text-lg font-black ${s.color}`}>{s.value}</p>
            <p className="text-[9px] opacity-50 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Create Campaign */}
      <button onClick={() => setShowCreate(!showCreate)}
        className={`w-full py-3 rounded-2xl border border-dashed text-xs font-bold flex items-center justify-center gap-2 transition-colors ${isDark ? "border-violet-500/30 text-violet-400 hover:bg-violet-500/10" : "border-violet-300 text-violet-600 hover:bg-violet-50"}`}>
        <Plus className="w-4 h-4" /> إنشاء حملة جديدة
      </button>

      <AnimatePresence>
        {showCreate && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className={`p-4 rounded-2xl border ${isDark ? "bg-[#1a1030] border-violet-500/20" : "bg-violet-50 border-violet-200"}`}>
            <p className={`text-xs font-black mb-3 ${isDark ? "text-violet-300" : "text-violet-700"}`}>بيانات الحملة الجديدة</p>
            <div className="space-y-2">
              <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="اسم الحملة (مثال: مشروع الياسمين — ربيع)"
                className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/30" : "bg-white border-gray-200"}`} />
              <div className="grid grid-cols-2 gap-2">
                <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200"}`}>
                  <DollarSign className="w-3.5 h-3.5 opacity-30 shrink-0" />
                  <input value={newBudget} onChange={e => setNewBudget(e.target.value)} placeholder="الميزانية (ريال)"
                    className={`flex-1 bg-transparent text-xs outline-none ${isDark ? "text-white placeholder-white/20" : ""}`} style={{ direction: "rtl" }} />
                </div>
                <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200"}`}>
                  <Clock className="w-3.5 h-3.5 opacity-30 shrink-0" />
                  <input value={newEnd} onChange={e => setNewEnd(e.target.value)} placeholder="تاريخ الانتهاء"
                    className={`flex-1 bg-transparent text-xs outline-none ${isDark ? "text-white placeholder-white/20" : ""}`} style={{ direction: "rtl" }} />
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-3">
              <button onClick={addCampaign} className={`flex-1 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-violet-600 to-purple-600 text-white shadow-md ${newName.trim() ? "" : "opacity-40 cursor-not-allowed"}`}>إنشاء الحملة</button>
              <button onClick={() => setShowCreate(false)} className={`px-4 py-2 rounded-xl text-xs font-bold ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-400"}`}>إلغاء</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Campaigns List */}
      <div className="space-y-3">
        {campaigns.map((c, i) => {
          const cfg = statusCfg[c.status];
          const spentPct = c.budget > 0 ? Math.min(100, Math.round((c.spent / c.budget) * 100)) : 0;
          return (
            <motion.div key={c.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className={`p-4 rounded-2xl border ${bg} ${border}`}>
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-black truncate ${isDark ? "text-white" : "text-gray-900"}`}>{c.name}</p>
                  <p className={`text-[9px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}>ينتهي: {c.endDate}</p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border flex items-center gap-1 ${cfg.bg}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />{c.status}
                  </span>
                  {c.status !== "منتهية" && (
                    <button onClick={() => toggleStatus(c.id)}
                      className={`text-[8px] px-2 py-1 rounded-lg font-bold border transition-all ${isDark ? "border-white/10 text-white/40 hover:bg-white/5" : "border-gray-200 text-gray-400 hover:bg-gray-50"}`}>
                      {c.status === "نشطة" ? "إيقاف" : "تشغيل"}
                    </button>
                  )}
                </div>
              </div>

              {/* Metrics grid */}
              <div className="grid grid-cols-4 gap-1.5 mb-3">
                {[
                  { label: "وصول", value: c.reach, color: "text-cyan-400" },
                  { label: "عملاء", value: String(c.leads), color: "text-violet-400" },
                  { label: "مصروف", value: `${(c.spent / 1000).toFixed(1)}K`, color: isDark ? "text-white/70" : "text-gray-700" },
                  { label: "ROAS", value: c.roas > 0 ? `${c.roas}%` : "—", color: c.roas > 300 ? "text-emerald-400" : c.roas > 0 ? "text-amber-400" : "text-gray-400" },
                ].map((m, mi) => (
                  <div key={mi} className={`p-2 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                    <p className={`text-[10px] font-black ${m.color}`}>{m.value}</p>
                    <p className="text-[8px] opacity-40 mt-0.5">{m.label}</p>
                  </div>
                ))}
              </div>

              {/* Budget Bar */}
              {c.budget > 0 && (
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-[9px] ${isDark ? "text-white/40" : "text-gray-400"}`}>الميزانية المستخدمة</span>
                    <span className={`text-[9px] font-black ${spentPct >= 90 ? "text-red-400" : "text-violet-400"}`}>{spentPct}%</span>
                  </div>
                  <div className={`h-1.5 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                    <motion.div initial={{ width: 0 }} animate={{ width: `${spentPct}%` }} transition={{ duration: 0.7, delay: i * 0.1 }}
                      className={`h-full rounded-full ${spentPct >= 90 ? "bg-red-500" : "bg-gradient-to-r from-violet-500 to-purple-400"}`} />
                  </div>
                </div>
              )}

              {/* AI Report */}
              <AnimatePresence>
                {aiReport[c.id] && (
                  <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                    className={`p-3 rounded-xl border mb-2 ${isDark ? "bg-violet-900/20 border-violet-500/20" : "bg-violet-50 border-violet-200"}`}>
                    <div className="flex items-start gap-2">
                      <Sparkles className="w-3 h-3 text-violet-400 mt-0.5 shrink-0" />
                      <p className={`text-[10px] leading-5 ${isDark ? "text-white/75" : "text-gray-700"}`}>{aiReport[c.id]}</p>
                      <button onClick={() => setAiReport(prev => { const n = {...prev}; delete n[c.id]; return n; })}
                        className="opacity-30 hover:opacity-60 shrink-0"><X className="w-3 h-3" /></button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <button onClick={() => generateReport(c.id)} disabled={aiLoading === c.id}
                className={`w-full py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1.5 transition-all ${isDark ? "bg-white/5 text-white/50 hover:bg-violet-500/15 hover:text-violet-300 border border-white/8" : "bg-gray-50 text-gray-500 hover:bg-violet-50 hover:text-violet-600 border border-gray-200"}`}>
                {aiLoading === c.id ? <><Loader2 className="w-3 h-3 animate-spin" /> يحلل...</> : <><BrainCircuit className="w-3 h-3" /> تقرير AI</>}
              </button>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

const MARKETING_PROJECTS = [
  {
    key: "النخيل ريزيدنس" as const,
    type: "سكني",
    location: "الملقا، شمال الرياض",
    units: "240 وحدة",
    totalValue: "360M ﷼",
    status: "نشط",
    views: "2,840",
    leads: 67,
    gradient: "from-violet-600 to-purple-700",
    badge: "الأعلى أداءً",
  },
  {
    key: "واحة الأعمال" as const,
    type: "تجاري",
    location: "حي العليا، الرياض",
    units: "18 طابقاً",
    totalValue: "220M ﷼",
    status: "نشط",
    views: "1,240",
    leads: 34,
    gradient: "from-blue-600 to-cyan-600",
    badge: "تجاري",
  },
];

const MARKETING_RECS: Record<string, Array<{ title: string; reason: string; impact: string; action: string; urgency: string; color: string }>> = {
  "النخيل ريزيدنس": [
    { title: "حدّث صور المشروع الرئيسية", reason: "إعلانات بصور عالية الجودة تحصل على 2.8× مشاهدات أكثر في أيون", impact: "+60% مشاهدات", action: "رفع صور جديدة", urgency: "عاجل", color: "red" },
    { title: "أضف جولة افتراضية 360°", reason: "68% من الباحثين يفضلون الجولة الافتراضية قبل الزيارة", impact: "+43% استفسارات", action: "رفع فيديو", urgency: "مهم", color: "violet" },
    { title: "فعّل التنبيه لقائمة الانتظار", reason: "127 مستخدم في أيون بحثوا عن وحدات مشابهة هذا الأسبوع", impact: "+127 مهتم", action: "تفعيل التنبيه", urgency: "قريب", color: "amber" },
    { title: "انشر في أوقات الذروة (8-10م)", reason: "AI رصد أن 74% من استفساراتك تأتي في هذا التوقيت", impact: "+35% تفاعل", action: "جدولة النشر", urgency: "اختياري", color: "blue" },
  ],
  "واحة الأعمال": [
    { title: "استهدف الشركات الناشئة في العليا", reason: "ارتفعت الشركات الناشئة 40% في الحي — طلب مرتفع على مكاتب مرنة", impact: "+18 عميل محتمل", action: "حملة مستهدفة", urgency: "عاجل", color: "red" },
    { title: "أبرز خيار الطابق الكامل", reason: "3 شركات كبرى بحثت عن طابق كامل الشهر الماضي ولم تجد", impact: "+3 صفقات محتملة", action: "تحديث الإعلان", urgency: "مهم", color: "violet" },
    { title: "أضف عروض الإيجار التشغيلي", reason: "الشركات الصغيرة تفضل الإيجار المرن على الشراء بنسبة 81%", impact: "+55% استفسارات", action: "إضافة خيار الإيجار", urgency: "قريب", color: "amber" },
    { title: "راجع تسعير مواقف السيارات", reason: "المنافسون يقدمون 3 مواقف مجانية — ميزتك التنافسية مهددة", impact: "تحسين التنافسية", action: "مراجعة التسعير", urgency: "اختياري", color: "blue" },
  ],
};

const URGENCY_STYLES: Record<string, { badge: string; dot: string }> = {
  "عاجل":     { badge: "bg-red-500/20 text-red-400 border-red-500/30",     dot: "bg-red-400" },
  "مهم":      { badge: "bg-violet-500/20 text-violet-400 border-violet-500/30", dot: "bg-violet-400" },
  "قريب":     { badge: "bg-amber-500/20 text-amber-400 border-amber-500/30",   dot: "bg-amber-400" },
  "اختياري":  { badge: "bg-blue-500/20 text-blue-400 border-blue-500/20",       dot: "bg-blue-400" },
};

export function MarketingAgentView({ isDark }: { isDark: boolean }) {
  const [selectedProjectKey, setSelectedProjectKey] = useState<string | null>(null);
  const [tab, setTab] = useState<"text" | "recs">("text");
  const selectedProject = MARKETING_PROJECTS.find(p => p.key === selectedProjectKey) ?? null;

  // === TEXT MARKETING STATE ===
  const [contentType, setContentType] = useState<"title" | "desc" | "points" | "reply">("desc");
  const [generating, setGenerating] = useState(false);
  const [displayedText, setDisplayedText] = useState("");
  const [fullText, setFullText] = useState("");
  const [applied, setApplied] = useState(false);
  const [copied, setCopied] = useState(false);
  const typeRef = useRef<any>(null);

  const bg = isDark ? "bg-[#151a2d]" : "bg-white";
  const brd = isDark ? "border-white/5" : "border-gray-100";

  const CTYPES = [
    { key: "desc" as const, label: "وصف المشروع", sub: "النص الرئيسي للإعلان" },
    { key: "title" as const, label: "عنوان الإعلان", sub: "جملة افتتاحية جذابة" },
    { key: "points" as const, label: "نقاط البيع", sub: "مزايا قابلة للنسخ" },
    { key: "reply" as const, label: "رد الاستفسار", sub: "رد تلقائي ذكي" },
  ];

  const generate = () => {
    if (generating || !selectedProjectKey) return;
    setGenerating(true); setDisplayedText(""); setApplied(false); setCopied(false);
    const text = INAPP_TEMPLATES[selectedProjectKey as keyof typeof INAPP_TEMPLATES]?.[contentType] || "";
    setFullText(text);
    clearInterval(typeRef.current);
    setTimeout(() => {
      setGenerating(false);
      let i = 0;
      typeRef.current = setInterval(() => {
        i++;
        setDisplayedText(text.slice(0, i));
        if (i >= text.length) clearInterval(typeRef.current);
      }, 14);
    }, 1000);
  };

  const copy = () => { navigator.clipboard.writeText(fullText).catch(() => {}); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const applyContent = () => setApplied(true);

  return (
    <div className="space-y-4">
      {/* ─── HEADER ─── */}
      <div className={`relative overflow-hidden rounded-2xl border p-4 ${isDark ? "bg-gradient-to-bl from-[#1a1030] via-[#12102a] to-[#0a1628] border-violet-500/20" : "bg-gradient-to-bl from-violet-50 via-white to-blue-50 border-violet-200"}`}>
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-violet-500/10 translate-x-10 -translate-y-10 blur-2xl" />
          <div className="absolute bottom-0 left-0 w-28 h-28 rounded-full bg-cyan-500/10 -translate-x-6 translate-y-6 blur-2xl" />
        </div>
        <div className="relative flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 via-purple-600 to-indigo-700 flex items-center justify-center shadow-lg shadow-violet-500/30 shrink-0">
            <Megaphone className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>مساعد التسويق AI</p>
            <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>اختر مشروعاً · ولّد نصاً تسويقياً · استلم توصيات الذكاء</p>
          </div>
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-violet-500/20 border border-violet-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-pulse" />
            <span className="text-[9px] font-black text-violet-400">AI ON</span>
          </div>
        </div>
      </div>

      {/* ─── STEP 1: PROJECT SELECTION ─── */}
      {!selectedProjectKey && (
        <div className="space-y-3">
          <p className={`text-xs font-black flex items-center gap-2 ${isDark ? "text-white/70" : "text-gray-600"}`}>
            <Building className="w-3.5 h-3.5 text-violet-400" />
            اختر المشروع المراد تسويقه
          </p>
          {MARKETING_PROJECTS.map((proj, i) => (
            <motion.button
              key={proj.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => { setSelectedProjectKey(proj.key); setTab("text"); setDisplayedText(""); setFullText(""); setApplied(false); setCopied(false); }}
              className={`w-full rounded-2xl border overflow-hidden text-right transition-all hover:border-violet-500/40 ${isDark ? `${bg} border-white/8 hover:bg-white/5` : "bg-white border-gray-100 shadow-sm hover:shadow-md"}`}
            >
              {/* Project color strip */}
              <div className={`h-1.5 w-full bg-gradient-to-r ${proj.gradient}`} />
              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{proj.key}</p>
                      <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-50 text-emerald-700"}`}>{proj.status}</span>
                      <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full ${isDark ? "bg-violet-500/20 text-violet-400" : "bg-violet-50 text-violet-700"}`}>{proj.badge}</span>
                    </div>
                    <div className="flex items-center gap-1 mb-2">
                      <MapPin className={`w-2.5 h-2.5 shrink-0 ${isDark ? "text-white/30" : "text-gray-400"}`} />
                      <p className={`text-[10px] ${isDark ? "text-white/45" : "text-gray-500"}`}>{proj.location}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-[9px] ${isDark ? "text-white/35" : "text-gray-400"}`}><Layers className="w-2.5 h-2.5 inline ml-0.5" />{proj.units}</span>
                      <span className={`text-[9px] ${isDark ? "text-white/35" : "text-gray-400"}`}><Eye className="w-2.5 h-2.5 inline ml-0.5" />{proj.views}</span>
                      <span className={`text-[9px] ${isDark ? "text-cyan-400/70" : "text-cyan-600"}`}><MessageCircle className="w-2.5 h-2.5 inline ml-0.5" />{proj.leads} استفسار</span>
                    </div>
                  </div>
                  <div className="shrink-0 flex flex-col items-end gap-1">
                    <p className={`text-xs font-black ${isDark ? "text-violet-300" : "text-violet-700"}`}>{proj.totalValue}</p>
                    <p className={`text-[9px] ${isDark ? "text-white/30" : "text-gray-400"}`}>{proj.type}</p>
                    <div className={`mt-2 w-7 h-7 rounded-xl bg-gradient-to-br ${proj.gradient} flex items-center justify-center shadow-md`}>
                      <ChevronRight className="w-3.5 h-3.5 text-white" />
                    </div>
                  </div>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      )}

      {/* ─── STEP 2: PROJECT SELECTED ─── */}
      {selectedProjectKey && selectedProject && (
        <div className="space-y-4">
          {/* Project Summary Banner */}
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
            className={`relative overflow-hidden rounded-2xl border p-4 bg-gradient-to-r ${selectedProject.gradient}`}>
            <div className="absolute inset-0 bg-black/30" />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                  <Building className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm font-black text-white">{selectedProject.key}</p>
                  <p className="text-[10px] text-white/70 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-2.5 h-2.5" />{selectedProject.location}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-right">
                  <p className="text-[9px] text-white/60">{selectedProject.units}</p>
                  <p className="text-xs font-black text-white">{selectedProject.totalValue}</p>
                </div>
                <button
                  onClick={() => { setSelectedProjectKey(null); setDisplayedText(""); setFullText(""); }}
                  className="w-7 h-7 rounded-lg bg-white/20 hover:bg-white/30 flex items-center justify-center">
                  <X className="w-3.5 h-3.5 text-white" />
                </button>
              </div>
            </div>
            {/* Quick stats */}
            <div className="relative flex gap-4 mt-3 pt-3 border-t border-white/20">
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3 text-white/60" />
                <span className="text-[10px] text-white font-bold">{selectedProject.views}</span>
                <span className="text-[9px] text-white/50">مشاهدة</span>
              </div>
              <div className="flex items-center gap-1">
                <MessageCircle className="w-3 h-3 text-white/60" />
                <span className="text-[10px] text-white font-bold">{selectedProject.leads}</span>
                <span className="text-[9px] text-white/50">استفسار</span>
              </div>
              <div className="flex items-center gap-1">
                <span className={`w-2 h-2 rounded-full ${selectedProject.status === "نشط" ? "bg-emerald-400" : "bg-amber-400"} animate-pulse`} />
                <span className="text-[9px] text-white/70 font-bold">{selectedProject.status}</span>
              </div>
            </div>
          </motion.div>

          {/* Tabs: تسويق نص | توصيات الذكاء */}
          <div className={`flex rounded-2xl p-1 gap-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
            {([
              { key: "text" as const, label: "تسويق نص", icon: Sparkles },
              { key: "recs" as const, label: "توصيات الذكاء", icon: BrainCircuit },
            ]).map(t => {
              const Icon = t.icon;
              const active = tab === t.key;
              return (
                <button key={t.key} onClick={() => setTab(t.key)}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${active ? isDark ? "bg-gradient-to-r from-violet-600/80 to-purple-600/80 text-white shadow-md" : "bg-white text-gray-900 shadow-sm" : isDark ? "text-white/40 hover:text-white/60" : "text-gray-400 hover:text-gray-600"}`}>
                  <Icon className="w-3.5 h-3.5" /> {t.label}
                </button>
              );
            })}
          </div>

          {/* ── TAB 1: تسويق نص ── */}
          {tab === "text" && (
            <div className="space-y-3">
              {/* Content Type Picker */}
              <p className={`text-[10px] font-bold ${isDark ? "text-white/50" : "text-gray-400"}`}>اختر نوع النص التسويقي</p>
              <div className="grid grid-cols-2 gap-2">
                {CTYPES.map(ct => {
                  const active = contentType === ct.key;
                  return (
                    <button key={ct.key} onClick={() => { setContentType(ct.key); setDisplayedText(""); setFullText(""); setApplied(false); }}
                      className={`p-3 rounded-2xl border text-right transition-all ${active ? isDark ? "bg-violet-500/20 border-violet-500/40" : "bg-violet-50 border-violet-300" : isDark ? `${bg} border-white/8 hover:border-violet-500/20` : "bg-white border-gray-100 shadow-sm hover:border-violet-200"}`}>
                      <p className={`text-xs font-black ${active ? isDark ? "text-violet-300" : "text-violet-700" : isDark ? "text-white/70" : "text-gray-700"}`}>{ct.label}</p>
                      <p className={`text-[9px] mt-0.5 ${active ? isDark ? "text-violet-400/70" : "text-violet-500" : isDark ? "text-white/30" : "text-gray-400"}`}>{ct.sub}</p>
                    </button>
                  );
                })}
              </div>

              {/* Generate Button */}
              <button onClick={generate} disabled={generating}
                className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2.5 transition-all ${generating ? "opacity-70 cursor-wait" : "hover:scale-[1.01] active:scale-[0.99]"} bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white shadow-xl shadow-violet-500/25`}>
                {generating ? <><Cpu className="w-4 h-4 animate-spin" /> AI يكتب المحتوى...</> : <><Sparkles className="w-5 h-5" /> توليد النص بـ AI</>}
              </button>

              {/* Generated Output */}
              <AnimatePresence>
                {(displayedText || generating) && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                    className={`rounded-2xl border overflow-hidden ${isDark ? "bg-[#0d1020] border-violet-500/20" : "bg-gray-50 border-violet-200"}`}>
                    <div className={`flex items-center justify-between px-4 py-2.5 border-b ${isDark ? "border-violet-500/10 bg-violet-500/5" : "border-violet-100 bg-violet-50/60"}`}>
                      <div className="flex items-center gap-2">
                        <div className={`w-1.5 h-1.5 rounded-full ${generating ? "bg-violet-400 animate-pulse" : "bg-emerald-400"}`} />
                        <span className={`text-[10px] font-black ${isDark ? "text-violet-300" : "text-violet-700"}`}>
                          {generating ? "AI يكتب..." : "جاهز للنشر ✨"}
                        </span>
                      </div>
                      {!generating && displayedText && (
                        <div className="flex items-center gap-1.5">
                          <button onClick={copy}
                            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[9px] font-bold transition-all ${copied ? "bg-emerald-500 text-white" : isDark ? "bg-white/8 text-white/50 hover:bg-white/15" : "bg-white text-gray-500 border border-gray-200 hover:border-violet-300"}`}>
                            {copied ? <><CheckCircle className="w-3 h-3" /> نُسخ</> : <><Copy className="w-3 h-3" /> نسخ</>}
                          </button>
                          <button onClick={applyContent}
                            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[9px] font-bold transition-all ${applied ? "bg-emerald-500 text-white" : "bg-violet-500 text-white hover:bg-violet-600"}`}>
                            {applied ? <><CheckCircle className="w-3 h-3" /> طُبّق</> : <><Zap className="w-3 h-3" /> تطبيق</>}
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="p-4 min-h-[70px]">
                      {generating && !displayedText ? (
                        <div className="space-y-2 animate-pulse">
                          {[85, 60, 95, 45, 70, 55].map((w, i) => (
                            <div key={i} className={`h-2 rounded-full ${isDark ? "bg-violet-500/15" : "bg-violet-100"}`} style={{ width: `${w}%` }} />
                          ))}
                        </div>
                      ) : (
                        <p className={`text-xs leading-7 whitespace-pre-line ${isDark ? "text-white/85" : "text-gray-800"}`}>
                          {displayedText}
                          {displayedText.length < fullText.length && displayedText.length > 0 && (
                            <span className="inline-block w-0.5 h-3.5 bg-violet-400 ml-0.5 animate-pulse align-middle" />
                          )}
                        </p>
                      )}
                    </div>
                    {!generating && displayedText.length >= fullText.length && fullText.length > 0 && (
                      <>
                        <div className={`border-t overflow-hidden ${isDark ? "border-violet-500/10" : "border-violet-100"}`}>
                          <div className={`p-3 ${isDark ? "bg-violet-500/5" : "bg-violet-50/50"}`}>
                            <p className={`text-[9px] font-bold mb-2 flex items-center gap-1 ${isDark ? "text-violet-400" : "text-violet-600"}`}>
                              <Eye className="w-3 h-3" /> معاينة الإعلان كما يظهر في منصة أيون
                            </p>
                            <div className={`rounded-xl border p-3 ${isDark ? "bg-[#0d1020] border-white/8" : "bg-white border-gray-200 shadow-sm"}`}>
                              <div className="flex items-center gap-2 mb-2">
                                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${selectedProject?.gradient} shrink-0 flex items-center justify-center`}>
                                  <Building className="w-5 h-5 text-white" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className={`text-[10px] font-black leading-tight truncate ${isDark ? "text-white" : "text-gray-900"}`}>{selectedProjectKey}</p>
                                  <p className={`text-[8px] mt-0.5 flex items-center gap-0.5 ${isDark ? "text-white/40" : "text-gray-400"}`}><MapPin className="w-2 h-2" />{selectedProject?.location}</p>
                                </div>
                                <div className={`px-1.5 py-0.5 rounded-full text-[8px] font-bold shrink-0 ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-50 text-emerald-700"}`}>إعلان ممول</div>
                              </div>
                              <p className={`text-[9px] leading-4 line-clamp-3 ${isDark ? "text-white/70" : "text-gray-600"}`}>{displayedText}</p>
                              <div className="flex items-center gap-3 mt-2">
                                <span className={`text-[8px] flex items-center gap-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}><Eye className="w-2.5 h-2.5" />2,840</span>
                                <span className={`text-[8px] flex items-center gap-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}><MessageCircle className="w-2.5 h-2.5" />67</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="px-4 pb-3 pt-1">
                          <button onClick={generate}
                            className={`w-full py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1.5 transition-colors ${isDark ? "bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/60" : "bg-gray-100 text-gray-400 hover:bg-violet-50 hover:text-violet-600"}`}>
                            <RefreshCcw className="w-3 h-3" /> إعادة التوليد
                          </button>
                        </div>
                      </>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* AI Insight hint */}
              <div className={`flex items-start gap-2 p-3 rounded-xl ${isDark ? "bg-white/4 border border-white/5" : "bg-violet-50/60 border border-violet-100"}`}>
                <BrainCircuit className="w-3.5 h-3.5 text-violet-400 mt-0.5 shrink-0" />
                <p className={`text-[9px] leading-4 ${isDark ? "text-white/50" : "text-gray-500"}`}>
                  <span className="font-black text-violet-400">AI يسحب بيانات المشروع: </span>
                  الموقع، الوحدات، السعر، المرافق — ليولّد نصاً دقيقاً خاصاً بـ {selectedProjectKey}
                </p>
              </div>
            </div>
          )}

          {/* ── TAB 2: توصيات الذكاء ── */}
          {tab === "recs" && (
            <div className="space-y-3">
              <div className={`flex items-center gap-2 p-3 rounded-xl ${isDark ? "bg-violet-500/10 border border-violet-500/20" : "bg-violet-50 border border-violet-200"}`}>
                <BrainCircuit className="w-4 h-4 text-violet-400 shrink-0" />
                <p className={`text-[10px] ${isDark ? "text-violet-300" : "text-violet-700"}`}>
                  <span className="font-black">ذكاء أيون</span> حلّل أداء إعلانك وسوق المنطقة وأعدّ {(MARKETING_RECS[selectedProjectKey] ?? []).length} توصيات مخصصة
                </p>
              </div>
              {(MARKETING_RECS[selectedProjectKey] ?? []).map((rec, i) => {
                const urgencyStyle = URGENCY_STYLES[rec.urgency] ?? URGENCY_STYLES["اختياري"];
                return (
                  <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
                    className={`p-4 rounded-2xl border ${isDark ? `${bg} border-white/8` : "bg-white border-gray-100 shadow-sm"}`}>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{rec.title}</p>
                      <span className={`shrink-0 text-[8px] font-bold px-1.5 py-0.5 rounded-full border ${urgencyStyle.badge}`}>{rec.urgency}</span>
                    </div>
                    <p className={`text-[10px] leading-4 mb-3 ${isDark ? "text-white/50" : "text-gray-500"}`}>{rec.reason}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className={`w-2 h-2 rounded-full ${urgencyStyle.dot}`} />
                        <span className={`text-[9px] font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{rec.impact}</span>
                      </div>
                      <button className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-[9px] font-black transition-all bg-gradient-to-r from-violet-600 to-purple-600 text-white shadow-sm hover:shadow-md`}>
                        <Zap className="w-2.5 h-2.5" /> {rec.action}
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 13. ANALYTICS VIEW — Broker / Developer (Performance Dashboard)
// ============================================================================
export function AnalyticsView({ isDark }: { isDark: boolean }) {
  const [period, setPeriod] = useState<"week" | "month" | "quarter">("month");

  const kpis = [
    { label: "مشاهدات الإعلانات", value: "12,480", change: "+18%", up: true },
    { label: "استفسارات واردة", value: "234", change: "+9%", up: true },
    { label: "معدل التحويل", value: "3.2%", change: "-0.4%", up: false },
    { label: "صفقات مغلقة", value: "8", change: "+3", up: true },
  ];

  const topListings = [
    { title: "فيلا النرجس 5 غرف", views: 1820, leads: 34, status: "نشط" },
    { title: "شقة الملقا 3 غرف", views: 1240, leads: 21, status: "نشط" },
    { title: "أرض الياسمين 600م²", views: 890, leads: 15, status: "مؤجر" },
    { title: "تاون هاوس حطين", views: 670, leads: 9, status: "نشط" },
  ];

  const months = ["أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر", "يناير"];
  const bars   = [40, 65, 55, 80, 70, 95];

  return (
    <div className="space-y-5">
      {/* Period Toggle */}
      <div className={`flex rounded-2xl p-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
        {([["week", "أسبوع"], ["month", "شهر"], ["quarter", "ربع سنة"]] as const).map(([id, label]) => (
          <button key={id} onClick={() => setPeriod(id)}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${period === id ? isDark ? "bg-white/10 text-white" : "bg-white text-gray-900 shadow-sm" : "text-gray-400"}`}>
            {label}
          </button>
        ))}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3">
        {kpis.map((k, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
            className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
            <p className={`text-[9px] font-bold mb-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>{k.label}</p>
            <p className={`text-xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>{k.value}</p>
            <span className={`text-[9px] font-bold flex items-center gap-0.5 mt-1 ${k.up ? "text-emerald-400" : "text-red-400"}`}>
              {k.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              {k.change}
            </span>
          </motion.div>
        ))}
      </div>

      {/* Bar Chart */}
      <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
        <p className={`text-xs font-black mb-4 ${isDark ? "text-white/60" : "text-gray-600"}`}>المشاهدات الشهرية</p>
        <div className="flex items-end gap-2 h-20">
          {bars.map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <motion.div initial={{ height: 0 }} animate={{ height: `${h}%` }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className={`w-full rounded-t-lg ${i === bars.length - 1 ? "bg-cyan-500" : isDark ? "bg-white/15" : "bg-gray-200"}`}
                style={{ height: `${h}%` }} />
              <span className={`text-[8px] opacity-40`}>{months[i].slice(0, 3)}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Top Listings */}
      <div>
        <p className={`text-xs font-black mb-3 ${isDark ? "text-white/60" : "text-gray-600"}`}>أداء الإعلانات</p>
        <div className="space-y-2.5">
          {topListings.map((l, i) => (
            <div key={i} className={`p-3 rounded-2xl border flex items-center gap-3 ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black text-white shrink-0 ${i === 0 ? "bg-amber-500" : i === 1 ? "bg-blue-500" : "bg-gray-500"}`}>
                {i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"} truncate`}>{l.title}</p>
                <div className="flex items-center gap-3 mt-0.5">
                  <span className={`text-[9px] ${isDark ? "text-white/40" : "text-gray-400"}`}><Eye className="w-2.5 h-2.5 inline ml-0.5" />{l.views.toLocaleString("ar-SA")}</span>
                  <span className={`text-[9px] ${isDark ? "text-cyan-400" : "text-cyan-600"}`}><MessageSquare className="w-2.5 h-2.5 inline ml-0.5" />{l.leads}</span>
                </div>
              </div>
              <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${isDark ? "bg-emerald-500/15 text-emerald-400" : "bg-emerald-50 text-emerald-600"}`}>{l.status}</span>
            </div>
          ))}
        </div>
      </div>

      {/* AI Insight */}
      <div className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-blue-900/20 to-cyan-900/20 border-blue-500/20" : "bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200"}`}>
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-blue-400" />
          <span className={`text-xs font-black ${isDark ? "text-blue-400" : "text-blue-600"}`}>تحليل ڤال</span>
        </div>
        <p className={`text-xs leading-6 ${isDark ? "text-white/70" : "text-gray-700"}`}>
          إعلاناتك حققت نمواً بنسبة <strong className="text-emerald-400">18%</strong> في المشاهدات هذا الشهر. أفضل وقت للنشر هو <strong>الثلاثاء والأربعاء مساءً</strong>. عقار "فيلا النرجس" الأعلى أداءً — يُنصح بتجديد صوره.
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// 14. GROWTH AGENT VIEW — Developer (Sales Pipeline + Growth KPIs)
// ============================================================================
const PIPELINE_STAGES = [
  { key: "lead", label: "عميل محتمل", color: "bg-blue-500", count: 42, value: "18.4M" },
  { key: "qualify", label: "مؤهّل", color: "bg-cyan-500", count: 28, value: "12.2M" },
  { key: "visit", label: "زيارة مجدولة", color: "bg-violet-500", count: 17, value: "7.5M" },
  { key: "offer", label: "عرض مقدّم", color: "bg-amber-500", count: 11, value: "4.8M" },
  { key: "closed", label: "صفقة مغلقة", color: "bg-emerald-500", count: 6, value: "2.6M" },
];

const GROWTH_MONTHS = ["أكت", "نوف", "ديس", "ين", "فب", "مار"];
const GROWTH_BARS   = [38, 52, 47, 68, 75, 91];
const DEALS_BARS    = [3, 4, 4, 5, 6, 8];

export function GrowthAgentView({ isDark }: { isDark: boolean }) {
  const [tab, setTab] = useState<"pipeline" | "kpis" | "recs">("pipeline");
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [recLoading, setRecLoading] = useState(false);
  const [recDone, setRecDone] = useState(false);

  const maxBar = Math.max(...GROWTH_BARS);

  const bg = isDark ? "bg-[#151a2d]" : "bg-white";
  const border = isDark ? "border-white/5" : "border-gray-100";

  const aiRecs = [
    { title: "رفع سعر وحدات الطابق الرابع", reason: "الطلب على المناسيب العليا ارتفع 28% هذا الشهر في منطقتك", action: "رفع السعر 3%", impact: "+185K ريال", urgency: "عاجل", color: "emerald" },
    { title: "تفعيل العروض على الوحدات الركنية", reason: "8 وحدات ركنية متأخرة في البيع — متوسط تأخير 47 يوماً", action: "خصم 2% لمدة أسبوعين", impact: "+4 صفقات سريعة", urgency: "قريب", color: "amber" },
    { title: "إعادة استهداف الزوار الذين لم يُغلقوا", reason: "13 زيارة لم تُحوّل لعرض في آخر 30 يوماً", action: "إرسال عرض مخصص عبر أيون", impact: "+5 عملاء محتملين", urgency: "اختياري", color: "blue" },
    { title: "تحديث سعر المتر لـ 'النخيل' في التطبيق", reason: "المنافسون رفعوا أسعارهم 5% — عقارك تحت السوق الآن", action: "تحديث قائمة الأسعار", impact: "تحسين الهامش", urgency: "مهم", color: "violet" },
  ];

  const urgencyConfig: Record<string, string> = {
    "عاجل": "bg-red-500/20 text-red-400 border-red-500/30",
    "قريب": "bg-amber-500/20 text-amber-400 border-amber-500/30",
    "مهم": "bg-violet-500/20 text-violet-400 border-violet-500/30",
    "اختياري": isDark ? "bg-white/8 text-white/40 border-white/10" : "bg-gray-100 text-gray-400 border-gray-200",
  };

  const colorBtn: Record<string, string> = {
    emerald: "bg-emerald-500 text-white hover:bg-emerald-600",
    amber: "bg-amber-500 text-white hover:bg-amber-600",
    blue: "bg-blue-500 text-white hover:bg-blue-600",
    violet: "bg-violet-500 text-white hover:bg-violet-600",
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className={`relative overflow-hidden rounded-2xl border p-4 ${isDark ? "bg-gradient-to-bl from-[#0d1a10] via-[#0d1810] to-[#0a1220] border-emerald-500/20" : "bg-gradient-to-bl from-emerald-50 to-teal-50 border-emerald-200"}`}>
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-emerald-500/10 translate-x-8 -translate-y-8 blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 rounded-full bg-teal-500/10 -translate-x-4 translate-y-4 blur-2xl" />
        </div>
        <div className="relative flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/30 shrink-0">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>مساعد النمو AI</p>
            <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>يرصد المبيعات · يحلّل المسار · يوصي بالفرص</p>
          </div>
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[9px] font-black text-emerald-400">AI ON</span>
          </div>
        </div>
        {/* Quick KPIs */}
        <div className="relative grid grid-cols-3 gap-2 mt-3">
          {[
            { label: "إجمالي المبيعات", value: "2.6M", change: "+27%", color: "text-emerald-400" },
            { label: "عملاء في المسار", value: "104", change: "+12%", color: "text-cyan-400" },
            { label: "معدل الإغلاق", value: "14.3%", change: "+3%", color: "text-amber-400" },
          ].map((k, i) => (
            <div key={i} className={`p-2.5 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-white/70"}`}>
              <p className={`text-base font-black ${k.color}`}>{k.value}</p>
              <p className={`text-[8px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-500"}`}>{k.label}</p>
              <p className="text-[8px] text-emerald-400 font-bold">{k.change} ↑</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className={`flex rounded-2xl p-1 gap-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
        {([
          { key: "pipeline" as const, label: "مسار المبيعات", icon: Activity },
          { key: "kpis" as const, label: "لوحة النمو", icon: BarChart3 },
          { key: "recs" as const, label: "توصيات AI", icon: Lightbulb },
        ]).map(t => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex-1 py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition-all ${active ? isDark ? "bg-gradient-to-r from-emerald-600/80 to-teal-600/80 text-white shadow-md" : "bg-white text-gray-900 shadow-sm" : isDark ? "text-white/40 hover:text-white/60" : "text-gray-400"}`}>
              <Icon className="w-3 h-3" /> {t.label}
            </button>
          );
        })}
      </div>

      {/* ── TAB 1: SALES PIPELINE ── */}
      {tab === "pipeline" && (
        <div className="space-y-4">
          <p className={`text-[10px] font-black ${isDark ? "text-white/40" : "text-gray-400"}`}>اضغط على أي مرحلة لعرض تفاصيلها</p>
          {/* Funnel visual */}
          <div className="space-y-2">
            {PIPELINE_STAGES.map((stage, i) => {
              const widthPct = 100 - i * 13;
              const isSelected = selectedStage === stage.key;
              return (
                <motion.button key={stage.key} onClick={() => setSelectedStage(isSelected ? null : stage.key)}
                  whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                  className={`w-full rounded-2xl border transition-all overflow-hidden ${isSelected ? isDark ? "border-emerald-500/40" : "border-emerald-300" : isDark ? "border-white/5" : "border-gray-100"} ${isDark ? "bg-[#151a2d]" : "bg-white shadow-sm"}`}>
                  <div className="p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-2.5 h-2.5 rounded-full ${stage.color}`} />
                        <span className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{stage.label}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-[10px] font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>{stage.value} ﷼</span>
                        <span className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{stage.count}</span>
                      </div>
                    </div>
                    <div className={`h-2 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                      <motion.div initial={{ width: 0 }} animate={{ width: `${widthPct}%` }} transition={{ duration: 0.7, delay: i * 0.08 }}
                        className={`h-full rounded-full ${stage.color}`} />
                    </div>
                  </div>
                  <AnimatePresence>
                    {isSelected && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                        className={`border-t overflow-hidden ${isDark ? "border-white/5 bg-emerald-900/10" : "border-gray-100 bg-emerald-50/50"}`}>
                        <div className="p-3 space-y-2">
                          {[
                            { name: "م. خالد العتيبي", budget: "1.4M", days: 5 },
                            { name: "ريم الحربي", budget: "1.2M", days: 8 },
                            { name: "طلال المنصور", budget: "2.1M", days: 2 },
                          ].slice(0, Math.min(stage.count, 3)).map((c, ci) => (
                            <div key={ci} className={`flex items-center justify-between p-2 rounded-xl ${isDark ? "bg-white/5" : "bg-white"}`}>
                              <div className="flex items-center gap-2">
                                <div className={`w-7 h-7 rounded-xl ${stage.color} flex items-center justify-center`}>
                                  <span className="text-[9px] font-black text-white">{c.name[0]}</span>
                                </div>
                                <div>
                                  <p className={`text-[10px] font-black ${isDark ? "text-white" : "text-gray-900"}`}>{c.name}</p>
                                  <p className="text-[8px] opacity-40">في المرحلة منذ {c.days} أيام</p>
                                </div>
                              </div>
                              <span className={`text-[10px] font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{c.budget}</span>
                            </div>
                          ))}
                          {stage.count > 3 && (
                            <p className={`text-[9px] text-center ${isDark ? "text-white/30" : "text-gray-400"}`}>+{stage.count - 3} آخرون في هذه المرحلة</p>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.button>
              );
            })}
          </div>

          {/* Conversion Rates */}
          <div className={`p-4 rounded-2xl border ${bg} ${border}`}>
            <p className={`text-xs font-black mb-3 ${isDark ? "text-white/60" : "text-gray-600"}`}>معدلات التحويل بين المراحل</p>
            <div className="space-y-2">
              {[
                { from: "عميل محتمل → مؤهّل", rate: 67, color: "bg-cyan-500" },
                { from: "مؤهّل → زيارة", rate: 61, color: "bg-violet-500" },
                { from: "زيارة → عرض", rate: 65, color: "bg-amber-500" },
                { from: "عرض → إغلاق", rate: 55, color: "bg-emerald-500" },
              ].map((r, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-[9px] ${isDark ? "text-white/50" : "text-gray-500"}`}>{r.from}</span>
                    <span className={`text-[9px] font-black ${isDark ? "text-white" : "text-gray-900"}`}>{r.rate}%</span>
                  </div>
                  <div className={`h-1.5 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                    <motion.div initial={{ width: 0 }} animate={{ width: `${r.rate}%` }} transition={{ duration: 0.6, delay: i * 0.1 }}
                      className={`h-full rounded-full ${r.color}`} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 2: GROWTH KPIs ── */}
      {tab === "kpis" && (
        <div className="space-y-4">
          {/* Revenue Chart */}
          <div className={`p-4 rounded-2xl border ${bg} ${border}`}>
            <div className="flex items-center justify-between mb-4">
              <p className={`text-xs font-black ${isDark ? "text-white/70" : "text-gray-700"}`}>الإيرادات الشهرية (مليون ريال)</p>
              <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-50 text-emerald-600"}`}>آخر 6 شهور</span>
            </div>
            <div className="flex items-end gap-2 h-24">
              {GROWTH_BARS.map((v, i) => {
                const pct = (v / maxBar) * 100;
                const isLast = i === GROWTH_BARS.length - 1;
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <motion.div initial={{ height: 0 }} animate={{ height: `${pct}%` }} transition={{ duration: 0.6, delay: i * 0.06 }}
                      className={`w-full rounded-t-lg ${isLast ? "bg-gradient-to-b from-emerald-400 to-teal-600" : isDark ? "bg-white/10" : "bg-emerald-200/70"}`} />
                    <span className={`text-[8px] ${isDark ? "text-white/30" : "text-gray-400"}`}>{GROWTH_MONTHS[i]}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Deals Chart */}
          <div className={`p-4 rounded-2xl border ${bg} ${border}`}>
            <p className={`text-xs font-black mb-4 ${isDark ? "text-white/70" : "text-gray-700"}`}>الصفقات المغلقة شهرياً</p>
            <div className="flex items-end gap-2 h-16">
              {DEALS_BARS.map((v, i) => {
                const maxD = Math.max(...DEALS_BARS);
                const pct = (v / maxD) * 100;
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <span className={`text-[8px] font-black ${isDark ? "text-white/50" : "text-gray-500"}`}>{v}</span>
                    <motion.div initial={{ height: 0 }} animate={{ height: `${pct}%` }} transition={{ duration: 0.5, delay: i * 0.06 }}
                      className={`w-full rounded-t-md ${i === DEALS_BARS.length - 1 ? "bg-amber-500" : isDark ? "bg-white/10" : "bg-amber-200/70"}`} />
                    <span className={`text-[8px] ${isDark ? "text-white/25" : "text-gray-300"}`}>{GROWTH_MONTHS[i]}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Metric Breakdown */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "متوسط قيمة الصفقة", value: "433K ﷼", icon: DollarSign, color: "text-emerald-400", bg: isDark ? "bg-emerald-500/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200" },
              { label: "دورة المبيعات (أيام)", value: "38 يوم", icon: Calendar, color: "text-cyan-400", bg: isDark ? "bg-cyan-500/10 border-cyan-500/20" : "bg-cyan-50 border-cyan-200" },
              { label: "نسبة العملاء المُعادين", value: "22%", icon: RefreshCcw, color: "text-violet-400", bg: isDark ? "bg-violet-500/10 border-violet-500/20" : "bg-violet-50 border-violet-200" },
              { label: "وحدات متبقية للبيع", value: "87", icon: Building, color: "text-amber-400", bg: isDark ? "bg-amber-500/10 border-amber-500/20" : "bg-amber-50 border-amber-200" },
            ].map((m, i) => {
              const Icon = m.icon;
              return (
                <div key={i} className={`p-3.5 rounded-2xl border ${m.bg}`}>
                  <Icon className={`w-4 h-4 mb-1.5 ${m.color}`} />
                  <p className={`text-lg font-black ${m.color}`}>{m.value}</p>
                  <p className={`text-[9px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-500"}`}>{m.label}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── TAB 3: AI RECOMMENDATIONS ── */}
      {tab === "recs" && (
        <div className="space-y-3">
          <div className={`flex items-center justify-between p-3 rounded-2xl border ${isDark ? "bg-emerald-900/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"}`}>
            <div className="flex items-center gap-2">
              <BrainCircuit className="w-4 h-4 text-emerald-400" />
              <span className={`text-xs font-black ${isDark ? "text-emerald-400" : "text-emerald-700"}`}>AI حلّل مشاريعك وجاهز بـ {aiRecs.length} توصية</span>
            </div>
            <button onClick={() => { setRecLoading(true); setTimeout(() => { setRecLoading(false); setRecDone(true); }, 2000); }}
              disabled={recLoading}
              className={`text-[9px] font-bold px-2.5 py-1.5 rounded-xl border transition-all ${recLoading ? "opacity-50 cursor-wait" : ""} ${isDark ? "bg-white/8 border-white/10 text-white/60 hover:bg-emerald-500/15 hover:text-emerald-300" : "bg-white border-gray-200 text-gray-500 hover:border-emerald-300"}`}>
              {recLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCcw className="w-3 h-3" />}
            </button>
          </div>

          {recLoading && (
            <div className={`h-1 rounded-full overflow-hidden ${isDark ? "bg-white/5" : "bg-emerald-100"}`}>
              <motion.div initial={{ x: "-100%" }} animate={{ x: "100%" }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                className="h-full w-1/3 rounded-full bg-gradient-to-r from-emerald-500 to-teal-400" />
            </div>
          )}

          {aiRecs.map((rec, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
              className={`p-4 rounded-2xl border ${bg} ${border}`}>
              <div className="flex items-start gap-2 mb-3">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${isDark ? `bg-${rec.color}-500/20` : `bg-${rec.color}-100`}`}>
                  <Lightbulb className={`w-4 h-4 text-${rec.color}-500`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                    <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{rec.title}</p>
                    <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full border ${urgencyConfig[rec.urgency]}`}>{rec.urgency}</span>
                  </div>
                  <p className={`text-[10px] leading-4 ${isDark ? "text-white/55" : "text-gray-500"}`}>{rec.reason}</p>
                </div>
              </div>
              <div className={`flex items-center justify-between p-2.5 rounded-xl mb-3 ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                <div>
                  <p className={`text-[9px] ${isDark ? "text-white/40" : "text-gray-400"}`}>الإجراء المقترح</p>
                  <p className={`text-[10px] font-bold ${isDark ? "text-white/80" : "text-gray-700"}`}>{rec.action}</p>
                </div>
                <div className="text-left">
                  <p className={`text-[9px] ${isDark ? "text-white/40" : "text-gray-400"}`}>التأثير المتوقع</p>
                  <p className={`text-[10px] font-black text-emerald-400`}>{rec.impact}</p>
                </div>
              </div>
              <button className={`w-full py-2 rounded-xl text-[10px] font-black flex items-center justify-center gap-1.5 transition-all shadow-sm ${colorBtn[rec.color]}`}>
                <Zap className="w-3 h-3" /> تطبيق التوصية
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 15. DEVELOPER SALES TEAM VIEW — Developer (Full Team Management)
// ============================================================================
const TEAM_INIT = [
  { id: 1, name: "سارة الزهراني", role: "مدير مبيعات", deals: 12, target: 15, revenue: 5200000, commission: 156000, rating: 4.9, avatar: "س", joined: "يناير 2025", phone: "0501111111", activeLeads: 8, color: "from-violet-500 to-purple-600" },
  { id: 2, name: "محمد العلي", role: "مستشار مبيعات", deals: 8, target: 10, revenue: 3450000, commission: 103500, rating: 4.6, avatar: "م", joined: "مارس 2025", phone: "0502222222", activeLeads: 5, color: "from-blue-500 to-cyan-600" },
  { id: 3, name: "نورة الحارثي", role: "مستشارة مبيعات", deals: 6, target: 8, revenue: 2600000, commission: 78000, rating: 4.7, avatar: "ن", joined: "فبراير 2025", phone: "0503333333", activeLeads: 6, color: "from-emerald-500 to-teal-600" },
  { id: 4, name: "فهد الدوسري", role: "متدرب مبيعات", deals: 3, target: 5, revenue: 1300000, commission: 39000, rating: 4.2, avatar: "ف", joined: "أبريل 2025", phone: "0504444444", activeLeads: 3, color: "from-amber-500 to-orange-600" },
];

export function DeveloperTeamView({ isDark }: { isDark: boolean }) {
  const [members, setMembers] = useState(TEAM_INIT);
  const [tab, setTab] = useState<"team" | "performance" | "tasks">("team");
  const [selectedMember, setSelectedMember] = useState<any | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState("مستشار مبيعات");
  const [newTarget, setNewTarget] = useState("8");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState("");
  const [tasks, setTasks] = useState([
    { id: 1, text: "متابعة عملاء مشروع النخيل المعلقين", assignee: "سارة الزهراني", priority: "red" as const, done: false },
    { id: 2, text: "تجديد عروض الطابق الرابع وإرسالها للمشترين المؤهلين", assignee: "محمد العلي", priority: "yellow" as const, done: false },
    { id: 3, text: "حضور ورشة عمل التسويق الرقمي", assignee: "الفريق كله", priority: "green" as const, done: true },
    { id: 4, text: "إعداد تقرير أداء الربع الأول", assignee: "نورة الحارثي", priority: "red" as const, done: false },
  ]);
  const [newTask, setNewTask] = useState("");
  const [newTaskAssignee, setNewTaskAssignee] = useState("");
  const [newTaskPriority, setNewTaskPriority] = useState<"red" | "yellow" | "green">("yellow");
  const [showTaskForm, setShowTaskForm] = useState(false);

  const totalRevenue = members.reduce((s, m) => s + m.revenue, 0);
  const totalDeals = members.reduce((s, m) => s + m.deals, 0);
  const totalCommission = members.reduce((s, m) => s + m.commission, 0);
  const topPerformer = [...members].sort((a, b) => b.deals - a.deals)[0];

  const bg = isDark ? "bg-[#151a2d]" : "bg-white";
  const border = isDark ? "border-white/5" : "border-gray-100";

  const priorityCfg = {
    red:    { label: "عاجل", dot: "bg-red-500", badge: isDark ? "bg-red-500/15 text-red-400 border-red-500/25" : "bg-red-50 text-red-600 border-red-200" },
    yellow: { label: "مهم", dot: "bg-amber-400", badge: isDark ? "bg-amber-500/15 text-amber-400 border-amber-500/25" : "bg-amber-50 text-amber-600 border-amber-200" },
    green:  { label: "عادي", dot: "bg-emerald-500", badge: isDark ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" : "bg-emerald-50 text-emerald-600 border-emerald-200" },
  };

  const addMember = () => {
    if (!newName.trim()) return;
    const colors = ["from-violet-500 to-purple-600", "from-blue-500 to-cyan-600", "from-rose-500 to-pink-600", "from-indigo-500 to-blue-600"];
    setMembers(prev => [...prev, {
      id: Date.now(), name: newName, role: newRole,
      deals: 0, target: parseInt(newTarget) || 8, revenue: 0, commission: 0,
      rating: 0, avatar: newName[0], joined: "الآن", phone: "—",
      activeLeads: 0, color: colors[Math.floor(Math.random() * colors.length)],
    }]);
    setNewName(""); setNewRole("مستشار مبيعات"); setNewTarget("8"); setShowAddForm(false);
  };

  const addTask = () => {
    if (!newTask.trim()) return;
    setTasks(prev => [{ id: Date.now(), text: newTask, assignee: newTaskAssignee || "غير محدد", priority: newTaskPriority, done: false }, ...prev]);
    setNewTask(""); setNewTaskAssignee(""); setShowTaskForm(false);
  };

  const generateAI = () => {
    setAiLoading(true); setAiAnalysis("");
    setTimeout(() => {
      const top = topPerformer;
      setAiAnalysis(
        `[AI] تحليل أداء فريق مبيعات المشاريع:\n\n` +
        `• أفضل موظف: ${top.name} — أغلق ${top.deals} صفقة وحقق ${(top.revenue / 1000000).toFixed(1)}M ريال\n` +
        `• معدل إكمال الهدف: ${((totalDeals / members.reduce((s,m) => s + m.target, 0)) * 100).toFixed(0)}%\n` +
        `• إجمالي العمولات: ${(totalCommission / 1000).toFixed(0)}K ريال\n\n` +
        `► التوصيات:\n` +
        `1. فهد الدوسري يحتاج توجيهاً مكثفاً — أداؤه 60% من الهدف\n` +
        `2. ارفع هدف سارة الزهراني لـ 18 صفقة — تتجاوز هدفها باستمرار\n` +
        `3. أضف عضوين جديدين للفريق — الطلب الحالي أعلى من طاقة الفريق`
      );
      setAiLoading(false);
    }, 2200);
  };

  if (selectedMember) {
    const m = selectedMember;
    const targetPct = Math.min(100, Math.round((m.deals / m.target) * 100));
    return (
      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
        <button onClick={() => setSelectedMember(null)} className={`flex items-center gap-2 text-sm font-bold ${isDark ? "text-white/60 hover:text-white" : "text-gray-500 hover:text-gray-800"}`}>
          <ChevronRight className="w-4 h-4" /> العودة للفريق
        </button>

        {/* Member Header */}
        <div className={`p-5 rounded-3xl border ${isDark ? "bg-gradient-to-br from-blue-900/20 to-violet-900/20 border-blue-500/20" : "bg-gradient-to-br from-blue-50 to-violet-50 border-blue-200"}`}>
          <div className="flex items-center gap-4">
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${m.color} flex items-center justify-center text-2xl font-black text-white shadow-lg`}>{m.avatar}</div>
            <div className="flex-1">
              <h3 className={`font-black text-lg ${isDark ? "text-white" : "text-gray-900"}`}>{m.name}</h3>
              <p className={`text-sm ${isDark ? "text-white/60" : "text-gray-500"}`}>{m.role}</p>
              <div className="flex items-center gap-3 mt-1">
                <span className="flex items-center gap-0.5 text-[10px] text-amber-400 font-bold"><Star className="w-3 h-3 fill-current" />{m.rating || "جديد"}</span>
                <span className={`text-[9px] ${isDark ? "text-white/40" : "text-gray-400"}`}>انضم {m.joined}</span>
              </div>
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "الصفقات المغلقة", value: m.deals, sub: `من ${m.target} هدف`, color: "text-violet-400" },
            { label: "الإيرادات", value: `${(m.revenue / 1000000).toFixed(1)}M`, sub: "ريال سعودي", color: "text-emerald-400" },
            { label: "العمولة المستحقة", value: `${(m.commission / 1000).toFixed(0)}K`, sub: "ريال سعودي", color: "text-amber-400" },
            { label: "عملاء نشطون", value: m.activeLeads, sub: "في المسار", color: "text-cyan-400" },
          ].map((k, i) => (
            <div key={i} className={`p-3.5 rounded-2xl border ${bg} ${border}`}>
              <p className={`text-xl font-black ${k.color}`}>{k.value}</p>
              <p className={`text-[10px] font-bold mt-0.5 ${isDark ? "text-white/60" : "text-gray-600"}`}>{k.label}</p>
              <p className={`text-[9px] mt-0.5 ${isDark ? "text-white/30" : "text-gray-400"}`}>{k.sub}</p>
            </div>
          ))}
        </div>

        {/* Target Progress */}
        <div className={`p-4 rounded-2xl border ${bg} ${border}`}>
          <div className="flex items-center justify-between mb-2">
            <span className={`text-xs font-black ${isDark ? "text-white/70" : "text-gray-700"}`}>تقدم الهدف الشهري</span>
            <span className={`text-xs font-black ${targetPct >= 100 ? "text-emerald-400" : targetPct >= 70 ? "text-amber-400" : "text-red-400"}`}>{targetPct}%</span>
          </div>
          <div className={`h-3 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
            <motion.div initial={{ width: 0 }} animate={{ width: `${targetPct}%` }} transition={{ duration: 0.8 }}
              className={`h-full rounded-full ${targetPct >= 100 ? "bg-gradient-to-r from-emerald-500 to-teal-400" : targetPct >= 70 ? "bg-gradient-to-r from-amber-500 to-orange-400" : "bg-gradient-to-r from-red-500 to-rose-400"}`} />
          </div>
          <p className={`text-[10px] mt-2 ${isDark ? "text-white/40" : "text-gray-400"}`}>{m.deals} صفقة من {m.target} مطلوبة</p>
        </div>

        <div className="flex gap-2 pb-4">
          <button className={`flex-1 py-3 rounded-2xl bg-gradient-to-r from-blue-500 to-violet-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg`}>
            <Phone className="w-4 h-4" /> اتصال
          </button>
          <button className={`flex-1 py-3 rounded-2xl border font-bold text-sm flex items-center justify-center gap-2 ${isDark ? "border-white/10 text-white/70" : "border-gray-200 text-gray-700"}`}>
            <MessageSquare className="w-4 h-4" /> رسالة
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className={`relative overflow-hidden rounded-2xl border p-4 ${isDark ? "bg-gradient-to-bl from-[#1a1030] via-[#120d28] to-[#0a1220] border-indigo-500/20" : "bg-gradient-to-bl from-indigo-50 to-violet-50 border-indigo-200"}`}>
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-indigo-500/10 translate-x-8 -translate-y-8 blur-2xl" />
        </div>
        <div className="relative flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30 shrink-0">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>فريق المبيعات</p>
            <p className={`text-[10px] mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>إدارة وتتبع أداء فريقك الميداني</p>
          </div>
          <span className={`text-[9px] px-2 py-1 rounded-lg font-bold ${isDark ? "bg-indigo-500/20 text-indigo-400" : "bg-indigo-100 text-indigo-700"}`}>{members.length} أعضاء</span>
        </div>
        {/* Summary stats */}
        <div className="relative grid grid-cols-3 gap-2">
          {[
            { label: "إجمالي الصفقات", value: totalDeals, color: "text-violet-400" },
            { label: "الإيرادات", value: `${(totalRevenue / 1000000).toFixed(1)}M`, color: "text-emerald-400" },
            { label: "العمولات", value: `${(totalCommission / 1000).toFixed(0)}K`, color: "text-amber-400" },
          ].map((s, i) => (
            <div key={i} className={`p-2.5 rounded-xl text-center ${isDark ? "bg-white/5" : "bg-white/70"}`}>
              <p className={`text-base font-black ${s.color}`}>{s.value}</p>
              <p className={`text-[8px] mt-0.5 ${isDark ? "text-white/40" : "text-gray-500"}`}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className={`flex rounded-2xl p-1 gap-1 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
        {([
          { key: "team" as const, label: "الفريق", icon: Users },
          { key: "performance" as const, label: "الأداء", icon: BarChart3 },
          { key: "tasks" as const, label: "المهام", icon: CheckSquare },
        ]).map(t => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex-1 py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 transition-all ${active ? isDark ? "bg-gradient-to-r from-indigo-600/80 to-violet-600/80 text-white shadow-md" : "bg-white text-gray-900 shadow-sm" : isDark ? "text-white/40 hover:text-white/60" : "text-gray-400"}`}>
              <Icon className="w-3 h-3" /> {t.label}
            </button>
          );
        })}
      </div>

      {/* ── TAB 1: TEAM ── */}
      {tab === "team" && (
        <div className="space-y-3">
          <button onClick={() => setShowAddForm(!showAddForm)}
            className={`w-full py-3 rounded-2xl border border-dashed text-xs font-bold flex items-center justify-center gap-2 transition-colors ${isDark ? "border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10" : "border-indigo-300 text-indigo-600 hover:bg-indigo-50"}`}>
            <UserPlus className="w-4 h-4" /> إضافة عضو جديد
          </button>

          <AnimatePresence>
            {showAddForm && (
              <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/8" : "bg-white border-gray-100 shadow-sm"}`}>
                <p className={`text-xs font-black mb-3 ${isDark ? "text-white/70" : "text-gray-700"}`}>بيانات العضو الجديد</p>
                <div className="space-y-2">
                  <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="الاسم الكامل"
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/30" : "bg-gray-50 border-gray-200"}`} />
                  <select value={newRole} onChange={e => setNewRole(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none ${isDark ? "bg-[#1a2035] border-white/10 text-white" : "bg-gray-50 border-gray-200"}`}>
                    <option>مدير مبيعات</option>
                    <option>مستشار مبيعات</option>
                    <option>مستشارة مبيعات</option>
                    <option>متدرب مبيعات</option>
                    <option>منسق مبيعات</option>
                  </select>
                  <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
                    <Target className="w-3.5 h-3.5 opacity-30 shrink-0" />
                    <input value={newTarget} onChange={e => setNewTarget(e.target.value)} placeholder="الهدف الشهري (صفقات)"
                      className={`flex-1 bg-transparent text-xs outline-none ${isDark ? "text-white placeholder-white/20" : ""}`} style={{ direction: "rtl" }} />
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button onClick={addMember} className="flex-1 py-2 rounded-xl text-xs font-bold bg-indigo-500 text-white hover:bg-indigo-600 transition-colors">إضافة</button>
                  <button onClick={() => setShowAddForm(false)} className={`px-4 py-2 rounded-xl text-xs font-bold ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-400"}`}>إلغاء</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {members.map((m, i) => {
            const targetPct = Math.min(100, Math.round((m.deals / m.target) * 100));
            return (
              <motion.button key={m.id} onClick={() => setSelectedMember(m)}
                initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
                className={`w-full p-4 rounded-2xl border text-right transition-all ${isDark ? "bg-[#151a2d] border-white/5 hover:bg-white/5" : "bg-white border-gray-100 shadow-sm hover:shadow-md"}`}>
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${m.color} flex items-center justify-center text-white font-black text-lg shrink-0`}>{m.avatar}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <p className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{m.name}</p>
                      <span className={`text-[10px] font-black ${targetPct >= 100 ? "text-emerald-400" : targetPct >= 70 ? "text-amber-400" : "text-red-400"}`}>{targetPct}%</span>
                    </div>
                    <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>{m.role}</p>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className={`text-[10px] font-black ${isDark ? "text-white/70" : "text-gray-700"}`}>{m.deals} صفقة</span>
                      <span className="text-[9px] opacity-30">•</span>
                      <span className="text-[10px] text-emerald-400 font-bold">{(m.revenue / 1000000).toFixed(1)}M ﷼</span>
                      <span className="text-[9px] opacity-30">•</span>
                      <span className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>{m.activeLeads} نشط</span>
                    </div>
                    <div className={`h-1 rounded-full mt-2 ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                      <motion.div initial={{ width: 0 }} animate={{ width: `${targetPct}%` }} transition={{ duration: 0.7, delay: i * 0.1 }}
                        className={`h-full rounded-full ${targetPct >= 100 ? "bg-emerald-500" : targetPct >= 70 ? "bg-amber-500" : "bg-red-500"}`} />
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 opacity-25 shrink-0" />
                </div>
              </motion.button>
            );
          })}
        </div>
      )}

      {/* ── TAB 2: PERFORMANCE ── */}
      {tab === "performance" && (
        <div className="space-y-4">
          {/* Rankings */}
          <div>
            <p className={`text-xs font-black mb-3 ${isDark ? "text-white/60" : "text-gray-600"}`}>ترتيب أداء الفريق 🏆</p>
            <div className="space-y-2">
              {[...members].sort((a, b) => b.deals - a.deals).map((m, i) => {
                const maxDeals = Math.max(...members.map(x => x.deals)) || 1;
                const barPct = Math.round((m.deals / maxDeals) * 100);
                const medals = ["🥇", "🥈", "🥉", ""];
                return (
                  <div key={m.id} className={`p-3 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-lg w-6 shrink-0">{medals[i] || "🔹"}</span>
                      <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${m.color} flex items-center justify-center text-white text-xs font-black shrink-0`}>{m.avatar}</div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-xs font-black ${isDark ? "text-white" : "text-gray-900"}`}>{m.name}</p>
                        <p className={`text-[9px] ${isDark ? "text-white/40" : "text-gray-400"}`}>{m.deals} صفقة • {(m.revenue / 1000000).toFixed(1)}M ﷼</p>
                      </div>
                      <div className="text-left">
                        <p className="text-xs font-black text-amber-400">{(m.commission / 1000).toFixed(0)}K</p>
                        <p className={`text-[8px] ${isDark ? "text-white/30" : "text-gray-400"}`}>عمولة</p>
                      </div>
                    </div>
                    <div className={`h-2 rounded-full ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                      <motion.div initial={{ width: 0 }} animate={{ width: `${barPct}%` }} transition={{ duration: 0.7, delay: i * 0.1 }}
                        className={`h-full rounded-full bg-gradient-to-r ${m.color}`} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* AI Team Analysis */}
          <button onClick={generateAI} disabled={aiLoading}
            className="w-full py-3.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg transition-all disabled:opacity-70">
            {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BrainCircuit className="w-4 h-4" />}
            {aiLoading ? "يحلل أداء الفريق..." : "تحليل AI للفريق كامل"}
          </button>

          <AnimatePresence>
            {aiAnalysis && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className={`p-4 rounded-2xl border ${isDark ? "bg-gradient-to-br from-indigo-900/20 to-violet-900/20 border-indigo-500/20" : "bg-gradient-to-br from-indigo-50 to-violet-50 border-indigo-200"}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    <span className={`text-xs font-black ${isDark ? "text-indigo-400" : "text-indigo-700"}`}>تحليل AI لفريق المبيعات</span>
                  </div>
                  <button onClick={() => setAiAnalysis("")} className="opacity-30 hover:opacity-60"><X className="w-3 h-3" /></button>
                </div>
                <p className={`text-[11px] leading-6 whitespace-pre-line ${isDark ? "text-white/80" : "text-gray-700"}`}>{aiAnalysis}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {/* ── TAB 3: TASKS ── */}
      {tab === "tasks" && (
        <div className="space-y-3">
          <button onClick={() => setShowTaskForm(!showTaskForm)}
            className={`w-full py-3 rounded-2xl border border-dashed text-xs font-bold flex items-center justify-center gap-2 transition-colors ${isDark ? "border-violet-500/30 text-violet-400 hover:bg-violet-500/10" : "border-violet-300 text-violet-600 hover:bg-violet-50"}`}>
            <Plus className="w-4 h-4" /> إضافة مهمة للفريق
          </button>

          <AnimatePresence>
            {showTaskForm && (
              <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className={`p-4 rounded-2xl border ${isDark ? "bg-[#151a2d] border-white/8" : "bg-white border-gray-100 shadow-sm"}`}>
                <div className="flex gap-1.5 mb-3">
                  {(["red", "yellow", "green"] as const).map(p => (
                    <button key={p} onClick={() => setNewTaskPriority(p)}
                      className={`flex-1 py-1.5 rounded-lg text-[9px] font-black border transition-all ${newTaskPriority === p ? p === "red" ? "bg-red-500 text-white border-red-500" : p === "yellow" ? "bg-amber-500 text-white border-amber-500" : "bg-emerald-500 text-white border-emerald-500" : isDark ? "bg-white/5 text-white/30 border-white/5" : "bg-white text-gray-400 border-gray-200"}`}>
                      {priorityCfg[p].label}
                    </button>
                  ))}
                </div>
                <textarea value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="وصف المهمة..." rows={2}
                  className={`w-full px-3 py-2 rounded-xl border text-xs resize-none outline-none mb-2 ${isDark ? "bg-white/5 border-white/10 text-white placeholder-white/20" : "bg-gray-50 border-gray-200"}`} />
                <select value={newTaskAssignee} onChange={e => setNewTaskAssignee(e.target.value)}
                  className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none mb-3 ${isDark ? "bg-[#1a2035] border-white/10 text-white" : "bg-gray-50 border-gray-200"}`}>
                  <option value="">كلّف لـ (اختياري)</option>
                  {members.map(m => <option key={m.id}>{m.name}</option>)}
                  <option value="الفريق كله">الفريق كله</option>
                </select>
                <div className="flex gap-2">
                  <button onClick={addTask} className={`flex-1 py-2 rounded-xl text-xs font-bold bg-violet-500 text-white ${newTask.trim() ? "" : "opacity-40 cursor-not-allowed"}`}>إضافة</button>
                  <button onClick={() => setShowTaskForm(false)} className={`px-4 py-2 rounded-xl text-xs font-bold ${isDark ? "bg-white/5 text-white/40" : "bg-gray-100 text-gray-400"}`}>إلغاء</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-2">
            {tasks.map((task, i) => {
              const pc = priorityCfg[task.priority];
              return (
                <motion.div key={task.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                  className={`p-3.5 rounded-2xl border transition-opacity ${task.done ? "opacity-50" : ""} ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                  <div className="flex items-start gap-2.5">
                    <button onClick={() => setTasks(prev => prev.map(t => t.id === task.id ? { ...t, done: !t.done } : t))}
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 transition-all ${task.done ? "bg-emerald-500 border-emerald-500" : isDark ? "border-white/20" : "border-gray-300"}`}>
                      {task.done && <CheckCircle className="w-3.5 h-3.5 text-white" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs leading-5 ${task.done ? "line-through opacity-40" : isDark ? "text-white/85" : "text-gray-800"}`}>{task.text}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full border flex items-center gap-0.5 ${pc.badge}`}>
                          <span className={`w-1 h-1 rounded-full ${pc.dot}`} />{pc.label}
                        </span>
                        {task.assignee && (
                          <span className={`text-[8px] px-1.5 py-0.5 rounded-full ${isDark ? "bg-white/5 text-white/35" : "bg-gray-100 text-gray-400"}`}><User style={{ width: "8px", height: "8px", display: "inline" }} /> {task.assignee}</span>
                        )}
                      </div>
                    </div>
                    <button onClick={() => setTasks(prev => prev.filter(t => t.id !== task.id))}
                      className="w-6 h-6 rounded-lg flex items-center justify-center opacity-20 hover:opacity-60 hover:text-red-400 transition-all shrink-0">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
            {tasks.length === 0 && (
              <div className={`text-center py-10 rounded-2xl border border-dashed ${isDark ? "border-white/10" : "border-gray-200"}`}>
                <CheckSquare className="w-8 h-8 opacity-15 mx-auto mb-2" />
                <p className={`text-xs ${isDark ? "text-white/30" : "text-gray-400"}`}>لا توجد مهام — أضف أولى مهام الفريق</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
