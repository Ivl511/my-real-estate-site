import { Search, Bell, User, Globe, Menu, Home, Heart, MessageSquare, Plus } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

interface WebNavbarProps {
  currentScreen: string;
  onNavigate: (screen: any) => void;
  onOpenAddMenu: () => void;
}

export function WebNavbar({ currentScreen, onNavigate, onOpenAddMenu }: WebNavbarProps) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const navLinks = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'search', label: 'استكشف', icon: Globe },
    { id: 'favorites', label: 'المفضلة', icon: Heart },
    { id: 'inbox', label: 'الرسائل', icon: MessageSquare },
  ];

  return (
    <nav className={`hidden md:flex fixed top-0 left-0 right-0 z-50 h-20 items-center justify-between px-8 border-b backdrop-blur-xl transition-all duration-300 ${
      isDark 
        ? 'bg-[#050505]/80 border-white/10' 
        : 'bg-white/80 border-gray-200'
    }`}>
      {/* LOGO AREA */}
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <span className="font-black text-white text-xl">A</span>
          </div>
          <span className={`text-2xl font-black tracking-tighter ${isDark ? 'text-white' : 'text-gray-900'}`}>
            ڤال
          </span>
        </div>

        {/* DESKTOP SEARCH */}
        <div className={`relative hidden lg:block w-96 transition-all focus-within:w-[500px]`}>
          <Search className={`absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-white/30' : 'text-gray-400'}`} />
          <input 
            type="text" 
            placeholder="ابحث عن عقار، حي، أو مشروع..." 
            className={`w-full h-12 rounded-2xl pr-12 pl-4 outline-none border transition-all ${
              isDark 
                ? 'bg-white/5 border-white/10 focus:border-cyan-500/50 text-white placeholder:text-white/30' 
                : 'bg-gray-100 border-transparent focus:bg-white focus:border-blue-500 text-gray-900'
            }`}
          />
        </div>
      </div>

      {/* CENTER LINKS */}
      <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/5">
        {navLinks.map((link) => (
          <button
            key={link.id}
            onClick={() => onNavigate(link.id)}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-bold transition-all ${
              currentScreen === link.id 
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg' 
                : isDark ? 'text-white/60 hover:text-white hover:bg-white/5' : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <link.icon className="w-4 h-4" />
            {link.label}
          </button>
        ))}
      </div>

      {/* RIGHT ACTIONS */}
      <div className="flex items-center gap-4">
        <button 
            onClick={onOpenAddMenu}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-bold hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all transform hover:-translate-y-0.5"
        >
            <Plus className="w-5 h-5" />
            <span>إضافة عقار</span>
        </button>

        <div className="w-px h-8 bg-white/10 mx-2" />

        <button className={`relative p-2.5 rounded-xl transition-colors ${isDark ? 'hover:bg-white/10 text-white/70' : 'hover:bg-gray-100 text-gray-600'}`}>
            <Bell className="w-6 h-6" />
            <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#050505]" />
        </button>

        <button 
            onClick={() => onNavigate('profile')}
            className="flex items-center gap-3 pl-1 pr-4 py-1 rounded-full border border-white/10 bg-white/5 hover:border-cyan-500/30 transition-all group"
        >
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-xs shadow-inner">
                AS
            </div>
            <div className="hidden xl:block text-right">
                <p className={`text-xs font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>أحمد سالم</p>
                <p className={`text-[10px] ${isDark ? 'text-white/40' : 'text-gray-500'}`}>وسيط عقاري</p>
            </div>
            <Menu className={`w-4 h-4 ${isDark ? 'text-white/40 group-hover:text-white' : 'text-gray-400'} transition-colors`} />
        </button>
      </div>
    </nav>
  );
}