import { motion } from "motion/react";
import { ArrowRight, Search, TrendingUp, MapPin, DollarSign, Users, Zap, Briefcase, Home as HomeIcon, Building2, X, Sparkles, ShoppingCart, Key, ArrowLeftRight } from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../context/ThemeContext";

interface RequestsScreenProps {
  onBack: () => void;
  onSelectRequest?: (id: string) => void;
}

// User Requests Data (People looking to BUY/RENT)
const userRequestsData = {
  broker: [
    {
      id: "1",
      type: "فيلا فاخرة",
      title: "وسيط يبحث عن فيلا فاخرة لعميل VIP",
      budget: "8,000,000 - 12,000,000 ر.س",
      location: "شمال الرياض",
      postedBy: "وسيط عقاري",
      urgent: true,
      matches: 4,
    },
  ],
  seeker: [
    {
      id: "2",
      type: "منزل عائلي",
      title: "عائلة تبحث عن منزل مريح",
      budget: "2,000,000 - 3,000,000 ر.س",
      location: "حي النرجس",
      postedBy: "باحث",
      urgent: false,
      matches: 8,
    },
  ],
  developer: [
    {
      id: "3",
      type: "شراء أرض",
      title: "مطور يبحث عن أرض في الملقا",
      budget: "5,000,000 ر.س",
      location: "حي الملقا",
      postedBy: "مطور عقاري",
      urgent: true,
      matches: 2,
    },
  ],
};

// Marketing Requests Data (Owners/Developers looking for MARKETERS)
const marketingRequestsData = {
  owner: [
    {
      id: "4",
      title: "مطلوب مسوق عقاري",
      property: "برج تجاري في جدة",
      offer: "عقد حصري + عمولة 2.5%",
      location: "جدة",
      commission: "2.5%",
      contract: "حصري",
      urgent: false,
    },
    {
      id: "5",
      title: "مطلوب وسيط لبيع فيلا",
      property: "فيلا فاخرة - حي الملقا",
      offer: "عمولة 3% + دعم تسويقي",
      location: "الرياض - الملقا",
      commission: "3%",
      contract: "عادي",
      urgent: true,
    },
  ],
  developer: [
    {
      id: "6",
      title: "إطلاق مشروع حصري",
      property: "مجمع 50 فيلا",
      offer: "عمولة 5% + مكافأة",
      location: "شرق الرياض",
      commission: "5%",
      contract: "حصري",
      urgent: true,
    },
  ],
};

export function RequestsScreen({ onBack, onSelectRequest }: RequestsScreenProps) {
  const [mainTab, setMainTab] = useState<"user" | "marketing">("user");
  const [userSubFilter, setUserSubFilter] = useState("broker");
  const [marketingSubFilter, setMarketingSubFilter] = useState("owner");
  const [typeFilter, setTypeFilter] = useState<"all" | "buy" | "rent" | "exchange">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const { theme } = useTheme();

  const isDark = theme === "dark";

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gradient-to-br from-gray-50 to-gray-100'} overflow-y-auto`}>
      {/* Header */}
      <div className="px-5 pt-12 pb-4 relative z-10">
        <div className="flex items-center gap-3 mb-6">
          <button 
            onClick={onBack} 
            className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
              isDark ? 'glass-premium' : 'bg-white shadow-lg'
            }`}
          >
            <ArrowRight className={`w-5 h-5 ${isDark ? 'text-white' : 'text-gray-900'}`} />
          </button>
          <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>مركز الطلبات</h2>
        </div>

        {/* RULE 1: Segmented Control (Toggle Switch) - Mutually Exclusive */}
        <div className={`rounded-2xl p-1.5 grid grid-cols-2 gap-1.5 mb-4 ${
          isDark ? 'glass-premium border border-white/10' : 'bg-white shadow-lg'
        }`}>
          <button
            onClick={() => setMainTab("user")}
            className={`py-3.5 rounded-xl text-sm font-black transition-all ${
              mainTab === "user"
                ? isDark 
                  ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-xl"
                  : "bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-lg"
                : isDark 
                  ? "text-white/40 hover:text-white/70"
                  : "text-gray-400 hover:text-gray-700"
            }`}
          >
            طلبات البحث
          </button>
          <button
            onClick={() => setMainTab("marketing")}
            className={`py-3.5 rounded-xl text-sm font-black transition-all ${
              mainTab === "marketing"
                ? isDark 
                  ? "bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-xl"
                  : "bg-gradient-to-r from-purple-600 to-pink-700 text-white shadow-lg"
                : isDark 
                  ? "text-white/40 hover:text-white/70"
                  : "text-gray-400 hover:text-gray-700"
            }`}
          >
            طلبات التسويق
          </button>
        </div>

        {/* RULE 2: AION AI Search Bar Integration */}
        <div className={`w-full rounded-2xl px-4 py-3.5 flex items-center gap-3 mb-4 relative ${
          isDark ? 'glass-strong border border-cyan-500/20' : 'bg-white shadow-xl border border-blue-100'
        }`}>
          {/* Glow Effect (Dark Mode Only) */}
          {isDark && (
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/10 to-purple-500/10 blur-xl" />
          )}
          
          <Sparkles className={`w-5 h-5 relative z-10 ${isDark ? 'text-cyan-400 animate-pulse' : 'text-blue-600'}`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="اسأل EON Brain عن الطلبات..."
            className={`flex-1 bg-transparent outline-none text-sm font-medium text-right relative z-10 ${
              isDark ? 'text-white placeholder:text-white/50' : 'text-gray-900 placeholder:text-gray-400'
            }`}
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery("")}
              className={`w-6 h-6 rounded-full flex items-center justify-center relative z-10 ${
                isDark ? 'bg-white/10' : 'bg-gray-100'
              }`}
            >
              <X className={`w-4 h-4 ${isDark ? 'text-white/60' : 'text-gray-600'}`} />
            </button>
          )}
        </div>

        {/* RULE 3: Specific List Filters (Budget, Location) */}
      </div>

      {/* Sub-Filters (Chips) */}
      <div className="px-5 mb-4 relative z-10">
        {mainTab === "user" ? (
          <div className="flex gap-2">
            {[
              { id: "broker", label: "طلبات الوسطاء", icon: "🤝" },
              { id: "seeker", label: "طلبات الباحثين", icon: "🏠" },
              { id: "developer", label: "طلبات المطورين", icon: "🏗️" },
            ].map((filter) => (
              <button
                key={filter.id}
                onClick={() => setUserSubFilter(filter.id)}
                className={`flex-1 py-3 rounded-2xl text-xs font-bold transition-all ${
                  userSubFilter === filter.id
                    ? isDark
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg"
                      : "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg"
                    : isDark
                      ? "glass-premium text-white/40"
                      : "bg-white text-gray-400 shadow"
                }`}
              >
                <div className="flex items-center justify-center gap-1.5">
                  <span>{filter.icon}</span>
                  <span>{filter.label}</span>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="flex gap-2">
            {[
              { id: "owner", label: "طلبات الملاك", icon: "👤" },
              { id: "developer", label: "طلبات المطورين", icon: "🏗️" },
            ].map((filter) => (
              <button
                key={filter.id}
                onClick={() => setMarketingSubFilter(filter.id)}
                className={`flex-1 py-3 rounded-2xl text-xs font-bold transition-all ${
                  marketingSubFilter === filter.id
                    ? isDark
                      ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg"
                      : "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg"
                    : isDark
                      ? "glass-premium text-white/40"
                      : "bg-white text-gray-400 shadow"
                }`}
              >
                <div className="flex items-center justify-center gap-1.5">
                  <span>{filter.icon}</span>
                  <span>{filter.label}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Type Filter (شراء / إيجار / بدل) — Only for User Requests */}
      {mainTab === "user" && (
        <div className="px-5 mb-4 relative z-10">
          <div className={`rounded-2xl p-1 flex gap-1 ${
            isDark ? 'bg-white/5 border border-white/10' : 'bg-gray-100 border border-gray-200'
          }`}>
            {[
              { id: "all" as const, label: "الكل", icon: null },
              { id: "buy" as const, label: "شراء", icon: ShoppingCart },
              { id: "rent" as const, label: "إيجار", icon: Key },
              { id: "exchange" as const, label: "بدل", icon: ArrowLeftRight },
            ].map((filter) => {
              const Icon = filter.icon;
              return (
                <button
                  key={filter.id}
                  onClick={() => setTypeFilter(filter.id)}
                  className={`flex-1 py-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1 ${
                    typeFilter === filter.id
                      ? isDark
                        ? "bg-gradient-to-r from-cyan-500/80 to-blue-500/80 text-white shadow-lg"
                        : "bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md"
                      : isDark
                        ? "text-white/40 hover:text-white/60"
                        : "text-gray-400 hover:text-gray-600"
                  }`}
                >
                  {Icon && <Icon className="w-3 h-3" />}
                  <span>{filter.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Requests List */}
      <div className="flex-1 px-5 pb-32 relative z-10">
        {mainTab === "user" ? (
          // User Requests List
          <div className="space-y-3">
            {userRequestsData[userSubFilter as keyof typeof userRequestsData].map((request, index) => (
              <motion.div
                key={request.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => onSelectRequest?.(request.id)}
                className={`rounded-3xl p-5 cursor-pointer transition-all ${
                  isDark ? 'glass-strong hover:glass-premium' : 'bg-white shadow-xl hover:shadow-2xl'
                }`}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {request.urgent && (
                      <div className={`rounded-lg px-2 py-1 flex items-center gap-1 ${
                        isDark 
                          ? 'bg-orange-500/20 border border-orange-500/30'
                          : 'bg-orange-100 border border-orange-300'
                      }`}>
                        <Zap className={`w-3 h-3 ${isDark ? 'text-orange-400' : 'text-orange-600'}`} />
                        <span className={`text-xs font-black ${isDark ? 'text-orange-400' : 'text-orange-600'}`}>
                          عاجل
                        </span>
                      </div>
                    )}
                    <div className={`rounded-lg px-3 py-1 ${
                      isDark 
                        ? 'bg-purple-500/20 border border-purple-500/30'
                        : 'bg-purple-100 border border-purple-300'
                    }`}>
                      <span className={`text-xs font-bold ${isDark ? 'text-purple-400' : 'text-purple-700'}`}>
                        {request.type}
                      </span>
                    </div>
                  </div>
                  
                  <div className={`rounded-xl px-3 py-1.5 ${
                    isDark ? 'glass-premium' : 'bg-gray-100'
                  }`}>
                    <div className="flex items-center gap-1.5">
                      <Users className={`w-3.5 h-3.5 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
                      <span className={`text-sm font-black ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>
                        {request.matches}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Title */}
                <h3 className={`font-black text-lg mb-3 text-right ${
                  isDark ? 'text-white' : 'text-gray-900'
                }`}>
                  {request.title}
                </h3>

                {/* Details */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <DollarSign className={`w-4 h-4 ${isDark ? 'text-white/40' : 'text-gray-400'}`} />
                      <span className={`text-sm font-bold ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                        {request.budget}
                      </span>
                    </div>
                    <span className={`text-xs font-bold ${isDark ? 'text-white/40' : 'text-gray-400'}`}>
                      الميزانية
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <MapPin className={`w-4 h-4 ${isDark ? 'text-cyan-400' : 'text-blue-600'}`} />
                      <span className={`text-sm font-bold ${isDark ? 'text-cyan-400' : 'text-blue-600'}`}>
                        {request.location}
                      </span>
                    </div>
                    <span className={`text-xs font-bold ${isDark ? 'text-white/40' : 'text-gray-400'}`}>
                      الموقع
                    </span>
                  </div>
                </div>

                {/* Action Buttons - TWO DISTINCT BUTTONS */}
                <div className="flex gap-2">
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    className={`flex-1 rounded-2xl py-3.5 font-bold flex items-center justify-center gap-2 ${
                      isDark
                        ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white'
                        : 'bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-lg'
                    }`}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>تقديم عرض</span>
                  </motion.button>
                  
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    className={`rounded-2xl px-5 py-3.5 font-bold ${
                      isDark
                        ? 'bg-white/10 text-white/60 hover:bg-white/15 border border-white/20'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-gray-300'
                    } transition-colors`}
                  >
                    <span>تجاهل</span>
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          // Marketing Requests List
          <div className="space-y-3">
            {marketingRequestsData[marketingSubFilter as keyof typeof marketingRequestsData].map((request, index) => (
              <motion.div
                key={request.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => onSelectRequest?.(request.id)}
                className={`rounded-3xl p-5 border-2 cursor-pointer transition-all ${
                  isDark 
                    ? 'glass-strong border-emerald-500/30 hover:glass-premium'
                    : 'bg-white shadow-xl border-emerald-300 hover:shadow-2xl'
                }`}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {request.urgent && (
                      <div className={`rounded-lg px-2 py-1 flex items-center gap-1 ${
                        isDark 
                          ? 'bg-orange-500/20 border border-orange-500/30'
                          : 'bg-orange-100 border border-orange-300'
                      }`}>
                        <Zap className={`w-3 h-3 ${isDark ? 'text-orange-400' : 'text-orange-600'}`} />
                        <span className={`text-xs font-black ${isDark ? 'text-orange-400' : 'text-orange-600'}`}>
                          عاجل
                        </span>
                      </div>
                    )}
                    <div className={`rounded-lg px-3 py-1 ${
                      isDark 
                        ? 'bg-emerald-500/20 border border-emerald-500/30'
                        : 'bg-emerald-100 border border-emerald-300'
                    }`}>
                      <span className={`text-xs font-bold ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>
                        {request.contract}
                      </span>
                    </div>
                  </div>
                  
                  <div className={`rounded-xl px-3 py-1.5 ${
                    isDark 
                      ? 'bg-gradient-to-r from-emerald-500/20 to-cyan-500/20'
                      : 'bg-emerald-100'
                  }`}>
                    <span className={`text-base font-black ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>
                      {request.commission}
                    </span>
                  </div>
                </div>

                {/* Title */}
                <h3 className={`font-black text-lg mb-2 text-right ${
                  isDark ? 'text-white' : 'text-gray-900'
                }`}>
                  {request.title}
                </h3>

                {/* Property */}
                <div className={`mb-3 p-3 rounded-xl ${
                  isDark ? 'bg-white/5' : 'bg-gray-50'
                }`}>
                  <div className="flex items-center gap-2 justify-end">
                    <span className={`text-sm font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      {request.property}
                    </span>
                    <Building2 className={`w-4 h-4 ${isDark ? 'text-cyan-400' : 'text-blue-600'}`} />
                  </div>
                </div>

                {/* Offer */}
                <div className="mb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Briefcase className={`w-4 h-4 ${isDark ? 'text-white/40' : 'text-gray-400'}`} />
                      <span className={`text-sm font-bold ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                        {request.offer}
                      </span>
                    </div>
                    <span className={`text-xs font-bold ${isDark ? 'text-white/40' : 'text-gray-400'}`}>
                      العرض
                    </span>
                  </div>
                </div>

                {/* Action Button */}
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  className={`w-full rounded-2xl py-3.5 font-bold flex items-center justify-center gap-2 ${
                    isDark
                      ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-white'
                      : 'bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-lg'
                  }`}
                >
                  <Briefcase className="w-4 h-4" />
                  <span>قبول عرض التسويق</span>
                </motion.button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}