import { DetailViewContainer } from "./ProfileDetailViews";
import { FloatingAION } from "./FloatingAION";
import { NegotiationAgentView, OwnersView, EditorAgentView, PersonalAgentView, SemanticSearchView, WishlistView, ClientsView, TasksView, ValuationAgentView, EarlyAlertsView, OffersView, BrokerMatchView, AIInquiryGuardView, FairPriceView, AnalyticsView, MarketingAgentView, GrowthAgentView, DeveloperTeamView, TeamManagementView, MyRequestsView, BrokerListingsView, BrokerBulkUpdateView } from "./ProfileSubScreens";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Settings, Share2, QrCode, Users, Building, FileText, Lock, MapPin, Lightbulb, BarChart3, Bell, Heart, Sparkles, TrendingDown, Briefcase, Target, ChevronRight, ListTodo, ShieldCheck, TrendingUp, Eye, EyeOff, X, User, Phone, Edit3, Search, Filter, Cpu, CheckCircle, PieChart, Activity, DollarSign, Calendar, MessageSquare, AlertTriangle, Zap, LogOut, Globe, Moon, Sun, LockKeyhole, HelpCircle, FileQuestion, HardHat, Hammer, Clock, Star, ArrowUpRight, Handshake, PenTool, Database, UserPlus, Package, Megaphone, CheckSquare, UserCheck, Home, ChevronDown, MessageCircle, Award, Send, Trash2, Plus, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { useTheme } from "../../context/ThemeContext";
import type { Screen } from "../../App";

interface ProfileScreenProps {
  onBack: () => void;
  onNavigate?: (screen: Screen) => void;
}

type Persona = "broker" | "developer" | "landlord" | "seeker";

// TIERS
type BrokerTier = "basic" | "advanced" | "elite";
type DeveloperTier = "basic" | "advanced" | "growth";
type LandlordTier = "basic" | "professional";
type SeekerTier = "basic" | "smart";

type View = 
  | "dashboard" | "settings"
  // Common
  | "properties" | "tasks" | "my_requests" | "team_management"
  // Broker Specific
  | "clients" | "owners" | "matching_agent" | "negotiation_agent" | "analyst_agent" | "inventory_agent"
  | "broker_listings" | "broker_bulk_update"
  // Developer Specific
  | "growth_agent" | "projects" | "sales_team"
  // Landlord Specific
  | "editor_agent" | "valuation_agent" | "assets" | "offers" | "ai_inquiry_guard" | "broker_match"
  // Marketing
  | "marketing_agent"
  // Seeker Specific
  | "personal_agent" | "semantic_search" | "wishlist" | "early_alerts" | "fair_price"; 

export function ProfileScreen({ onBack, onNavigate }: ProfileScreenProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  // Simulation State
  const [devPersona, setDevPersona] = useState<Persona>("broker");
  const [brokerTier, setBrokerTier] = useState<BrokerTier>("elite");
  const [brokerType, setBrokerType] = useState<"individual" | "corporate">("individual");
  const [developerTier, setDeveloperTier] = useState<DeveloperTier>("growth");
  const [landlordTier, setLandlordTier] = useState<LandlordTier>("professional");
  const [seekerTier, setSeekerTier] = useState<SeekerTier>("smart");
  const [viewMode, setViewMode] = useState<"owner" | "visitor">("owner");

  const [currentView, setCurrentView] = useState<View>("dashboard");
  const [socialModal, setSocialModal] = useState<"followers" | "following" | "likes" | null>(null);
  const [followersPrivate, setFollowersPrivate] = useState(false);

  const handlePersonaChange = (p: Persona) => {
      setDevPersona(p);
      setCurrentView("dashboard");
      setViewMode("owner");
  }

  // --- LOGIC ---
  const getTierInfo = () => {
    switch (devPersona) {
      case "seeker":
        return seekerTier === "smart" 
          ? { label: "VIP Hunter", points: 200, color: "#D946EF", gradient: "from-purple-900 via-fuchsia-900 to-pink-900" }
          : { label: "زائر", points: 50, color: "#94A3B8", gradient: "from-slate-700 to-slate-800" };
      case "landlord":
        return landlordTier === "professional"
          ? { label: "مالك ذهبي", points: 400, color: "#F59E0B", gradient: "from-amber-900 via-yellow-900 to-orange-950" }
          : { label: "مالك", points: 100, color: "#A8A29E", gradient: "from-stone-700 to-stone-800" };
      case "broker":
        if (brokerTier === "elite") return { label: "وسيط إيليت", points: 2000, color: "#D4AF37", gradient: "from-slate-900 via-slate-800 to-black" };
        if (brokerTier === "advanced") return { label: "وسيط متقدم", points: 800, color: "#A855F7", gradient: "from-indigo-900 via-purple-900 to-slate-900" };
        return { label: "وسيط مبتدئ", points: 200, color: "#10B981", gradient: "from-emerald-800 to-teal-900" };
      case "developer":
        if (developerTier === "growth") return { label: "مطور نخبة", points: 5000, color: "#E2E8F0", gradient: "from-slate-950 via-black to-slate-900" };
        if (developerTier === "advanced") return { label: "مطور متقدم", points: 2000, color: "#60A5FA", gradient: "from-blue-900 to-indigo-900" };
        return { label: "مطور مبتدئ", points: 500, color: "#94A3B8", gradient: "from-slate-700 to-slate-800" };
    }
  };

  const tierInfo = getTierInfo();

  // Stats Logic - Inside Card
  const getCardStats = () => {
     if (devPersona === "seeker") return [{ label: "المحفظة", value: "2.5M" }, { label: "الطلبات", value: "3" }];
     if (devPersona === "landlord") return [{ label: "العقارات", value: landlordTier === "professional" ? "5" : "1" }, { label: "المشاهدات", value: "1.2k" }];
     if (devPersona === "broker") {
         const limit = brokerTier === "elite" ? "30" : brokerTier === "advanced" ? "10" : "3";
         return [{ label: "حد العقارات", value: limit }, { label: "الصفقات", value: "154" }];
     }
     if (devPersona === "developer") {
         const limit = developerTier === "growth" ? "10" : developerTier === "advanced" ? "3" : "1";
         return [{ label: "المشاريع", value: limit }, { label: "الوحدات", value: "450" }];
     }
     return [];
  };

  return (
    <div className={`h-full flex flex-col overflow-hidden relative ${isDark ? 'noise-bg' : 'bg-gradient-to-br from-gray-50 to-gray-100'}`}>
      
      {/* 1. SIMULATION CONTROL BAR */}
      <div className="fixed top-0 left-0 right-0 z-[100] bg-[#0f172a] border-b border-white/10 shadow-2xl">
        <div className="px-3 py-2 flex flex-col gap-2">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <button onClick={onBack} className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center">
                        <ArrowRight className="w-4 h-4 text-white" />
                    </button>
                    <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse shadow-[0_0_10px_#06b6d4]" />
                        <span className="text-[10px] font-black text-white/90 tracking-wider">ڤال TIERS</span>
                    </div>
                </div>
                 <button onClick={toggleTheme} className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center">
                    {isDark ? <Moon className="w-3.5 h-3.5 text-white/70" /> : <Sun className="w-3.5 h-3.5 text-white/70" />}
                </button>
            </div>
            
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar items-center">
                {/* Visitor/Owner toggle */}
                <div className="flex bg-black/40 rounded-lg p-1 border border-white/10 shrink-0">
                    <button onClick={() => setViewMode("owner")} className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 ${viewMode === "owner" ? "bg-cyan-600 text-white" : "text-white/40"}`}>
                      <User className="w-2.5 h-2.5" /> مالك
                    </button>
                    <button onClick={() => setViewMode("visitor")} className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 ${viewMode === "visitor" ? "bg-violet-600 text-white" : "text-white/40"}`}>
                      <Eye className="w-2.5 h-2.5" /> زائر
                    </button>
                </div>
                <div className="flex bg-black/40 rounded-lg p-1 border border-white/10 shrink-0">
                    <button onClick={() => handlePersonaChange("broker")} className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 ${devPersona === "broker" ? "bg-emerald-600 text-white" : "text-white/40"}`}><Briefcase className="w-2.5 h-2.5" /> وسيط</button>
                    <button onClick={() => handlePersonaChange("developer")} className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 ${devPersona === "developer" ? "bg-blue-600 text-white" : "text-white/40"}`}><Building className="w-2.5 h-2.5" /> مطور</button>
                    <button onClick={() => handlePersonaChange("landlord")} className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 ${devPersona === "landlord" ? "bg-amber-600 text-white" : "text-white/40"}`}><Home className="w-2.5 h-2.5" /> مالك</button>
                    <button onClick={() => handlePersonaChange("seeker")} className={`px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 ${devPersona === "seeker" ? "bg-purple-600 text-white" : "text-white/40"}`}><Search className="w-2.5 h-2.5" /> باحث</button>
                </div>

                <div className="flex bg-black/40 rounded-lg p-1 border border-white/10 shrink-0">
                    {devPersona === "broker" && (
                        <>
                             <button onClick={() => setBrokerType("individual")} className={`px-2 py-1 rounded text-[10px] font-bold ${brokerType === "individual" ? "bg-white/20 text-white" : "text-white/40"}`}>فرد</button>
                             <button onClick={() => setBrokerType("corporate")} className={`px-2 py-1 rounded text-[10px] font-bold ${brokerType === "corporate" ? "bg-white/20 text-white" : "text-white/40"}`}>منشأة</button>
                             <div className="w-px bg-white/10 h-3 mx-1 self-center" />
                             <button onClick={() => setBrokerTier("basic")} className={`px-2 py-1 rounded text-[10px] font-bold ${brokerTier === "basic" ? "bg-slate-600 text-white" : "text-white/40"}`}>مبتدئ</button>
                             <button onClick={() => setBrokerTier("advanced")} className={`px-2 py-1 rounded text-[10px] font-bold ${brokerTier === "advanced" ? "bg-purple-600 text-white" : "text-white/40"}`}>متقدم</button>
                             <button onClick={() => setBrokerTier("elite")} className={`px-2 py-1 rounded text-[10px] font-bold ${brokerTier === "elite" ? "bg-amber-500 text-black" : "text-white/40"}`}>إيليت</button>
                        </>
                    )}
                     {devPersona === "developer" && (
                        <>
                             <button onClick={() => setDeveloperTier("basic")} className={`px-2 py-1 rounded text-[10px] font-bold ${developerTier === "basic" ? "bg-slate-600 text-white" : "text-white/40"}`}>مبتدئ</button>
                             <button onClick={() => setDeveloperTier("advanced")} className={`px-2 py-1 rounded text-[10px] font-bold ${developerTier === "advanced" ? "bg-purple-600 text-white" : "text-white/40"}`}>متقدم</button>
                             <button onClick={() => setDeveloperTier("growth")} className={`px-2 py-1 rounded text-[10px] font-bold ${developerTier === "growth" ? "bg-blue-500 text-white" : "text-white/40"}`}>نمو</button>
                        </>
                    )}
                     {devPersona === "landlord" && (
                        <>
                             <button onClick={() => setLandlordTier("basic")} className={`px-2 py-1 rounded text-[10px] font-bold ${landlordTier === "basic" ? "bg-slate-600 text-white" : "text-white/40"}`}>مجاني</button>
                             <button onClick={() => setLandlordTier("professional")} className={`px-2 py-1 rounded text-[10px] font-bold ${landlordTier === "professional" ? "bg-amber-500 text-black" : "text-white/40"}`}>احترافي</button>
                        </>
                    )}
                    {devPersona === "seeker" && (
                        <>
                             <button onClick={() => setSeekerTier("basic")} className={`px-2 py-1 rounded text-[10px] font-bold ${seekerTier === "basic" ? "bg-slate-600 text-white" : "text-white/40"}`}>مجاني</button>
                             <button onClick={() => setSeekerTier("smart")} className={`px-2 py-1 rounded text-[10px] font-bold ${seekerTier === "smart" ? "bg-fuchsia-500 text-white" : "text-white/40"}`}>VIP</button>
                        </>
                    )}
                </div>
            </div>
        </div>
      </div>

      {/* SOCIAL MODAL */}
      <AnimatePresence>
        {socialModal && (
          <SocialModal
            type={socialModal}
            isDark={isDark}
            followersPrivate={followersPrivate}
            onTogglePrivate={() => setFollowersPrivate(v => !v)}
            onClose={() => setSocialModal(null)}
          />
        )}
      </AnimatePresence>

      {/* VISITOR VIEW */}
      <AnimatePresence mode="wait">
        {viewMode === "visitor" && (
          <VisitorProfileView
            key="visitor"
            persona={devPersona}
            tierInfo={tierInfo}
            isDark={isDark}
          />
        )}
      </AnimatePresence>

      {/* 2. DASHBOARD (owner mode only) */}
      <AnimatePresence mode="wait">
        {viewMode === "owner" && currentView === "dashboard" ? (
            <motion.div 
                key="dashboard"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="flex-1 overflow-y-auto pb-32 pt-[140px]"
            >
                {/* ID CARD */}
                <div className="px-5 mb-6">
                    <motion.div
                        initial={{ rotateX: -10, y: 20, opacity: 0 }}
                        animate={{ rotateX: 0, y: 0, opacity: 1 }}
                        className="relative"
                        style={{ perspective: "1000px" }}
                    >
                        <div className={`relative rounded-[2.5rem] p-8 min-h-[240px] overflow-hidden border border-white/10 shadow-2xl bg-gradient-to-br ${tierInfo.gradient}`}>
                            {/* ── CIRCUIT TRACES – top right ── */}
                            <svg className="absolute top-0 right-0 w-[65%] h-[80%] pointer-events-none" viewBox="0 0 220 160" fill="none" style={{ opacity: 0.13 }}>
                              <g stroke="white" strokeWidth="0.9">
                                <line x1="45" y1="18" x2="220" y2="18" /><line x1="22" y1="42" x2="220" y2="42" />
                                <line x1="68" y1="64" x2="220" y2="64" /><line x1="48" y1="90" x2="220" y2="90" />
                                <line x1="92" y1="114" x2="220" y2="114" /><line x1="32" y1="140" x2="190" y2="140" />
                                <line x1="45" y1="0" x2="45" y2="42" /><line x1="68" y1="0" x2="68" y2="64" />
                                <line x1="92" y1="18" x2="92" y2="114" /><line x1="118" y1="0" x2="118" y2="90" />
                                <line x1="142" y1="18" x2="142" y2="114" /><line x1="165" y1="0" x2="165" y2="90" />
                                <line x1="190" y1="18" x2="190" y2="160" /><line x1="48" y1="90" x2="48" y2="160" />
                                <line x1="32" y1="114" x2="32" y2="160" />
                              </g>
                              <g fill="white">
                                {[[43,16],[43,40],[66,40],[66,62],[90,16],[90,40],[90,88],[90,112],
                                  [116,16],[116,40],[116,88],[140,16],[140,40],[140,62],[140,88],[140,112],
                                  [163,16],[163,40],[163,88],[188,16],[188,40],[188,62],[46,88],[46,112],
                                  [46,138],[30,112],[30,138]
                                ].map(([x,y],i) => <rect key={i} x={x} y={y} width="4" height="4" />)}
                              </g>
                            </svg>
                            {/* ── CIRCUIT TRACES – bottom left ── */}
                            <svg className="absolute bottom-0 left-0 w-[38%] h-[45%] pointer-events-none" viewBox="0 0 130 90" fill="none" style={{ opacity: 0.10 }}>
                              <g stroke="white" strokeWidth="0.9">
                                <line x1="0" y1="32" x2="85" y2="32" /><line x1="0" y1="58" x2="65" y2="58" />
                                <line x1="0" y1="78" x2="105" y2="78" />
                                <line x1="28" y1="0" x2="28" y2="58" /><line x1="55" y1="0" x2="55" y2="78" />
                                <line x1="80" y1="32" x2="80" y2="90" /><line x1="105" y1="58" x2="105" y2="90" />
                              </g>
                              <g fill="white">
                                {[[26,30],[26,56],[53,30],[53,56],[53,76],[78,30],[78,56],[103,56],[103,76]].map(([x,y],i) => <rect key={i} x={x} y={y} width="4" height="4" />)}
                              </g>
                            </svg>
                            {/* Shimmer + top edge glow */}
                            <div className="absolute inset-0 bg-gradient-to-br from-white/0 via-white/3 to-white/8 pointer-events-none" />
                            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none" />

                            {/* ── CARD CONTENT ── */}
                            <div className="relative z-10 flex justify-between h-full min-h-[176px]">
                              {/* LEFT: Brand + Tier name + FAL + Points */}
                              <div className="flex flex-col justify-between">
                                <div>
                                  <p className="text-[9px] font-black tracking-[0.3em] text-white/40 mb-2">ڤال</p>
                                  <p className="text-2xl font-black text-white leading-none tracking-tight" style={{ textShadow: `0 0 24px ${tierInfo.color}70` }}>
                                    {tierInfo.label.toUpperCase()}
                                  </p>
                                  <p className="text-[9px] font-black tracking-[0.22em] text-white/40 mt-1">TIER</p>
                                </div>
                                <div>
                                  <div className="flex items-center gap-1.5 mb-2">
                                    <div className="px-1.5 py-0.5 border border-white/25 rounded-md text-[8px] font-black text-white/80 tracking-wider">فال</div>
                                    <span className="text-[8px] text-white/30 font-bold tracking-widest">FAL</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Zap className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                                    <span className="text-lg font-black text-white">{tierInfo.points}</span>
                                    <span className="text-[9px] text-white/40">نقطة</span>
                                  </div>
                                </div>
                              </div>

                              {/* RIGHT: Status dot + Name + Role + Stats */}
                              <div className="flex flex-col justify-between text-right">
                                <div>
                                  <div className="flex items-center justify-end gap-1.5 mb-2">
                                    <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: tierInfo.color, boxShadow: `0 0 6px ${tierInfo.color}` }} />
                                    <span className="text-[9px] font-black tracking-wider uppercase text-white/50">{tierInfo.label}</span>
                                  </div>
                                  <h3 className="text-2xl font-black text-white leading-tight" style={{ fontFamily: 'Cairo', textShadow: `0 0 20px ${tierInfo.color}50` }}>
                                    {devPersona === "broker" ? (brokerType === "corporate" ? "شركة الأفق" : "عبدالله العتيبي") :
                                     devPersona === "developer" ? "شركة العمران" :
                                     devPersona === "landlord" ? "سعد القحطاني" : "نورة السالم"}
                                  </h3>
                                  <p className="text-[11px] text-white/55 font-bold mt-1">
                                    {devPersona === "broker" ? (brokerType === "corporate" ? "وسيط منشأة" : "وسيط عقاري فردي") :
                                     devPersona === "developer" ? "مطور عقاري" :
                                     devPersona === "landlord" ? "مالك عقار" : "باحث عقاري"}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  {getCardStats().map((stat: any, i: number) => (
                                    <p key={i} className="text-[10px] text-white/45">
                                      {stat.label}: <span className="text-white font-black" style={{ textShadow: `0 0 10px ${tierInfo.color}60` }}>{stat.value}</span>
                                    </p>
                                  ))}
                                </div>
                              </div>
                            </div>
                        </div>
                    </motion.div>
                </div>

                {/* SOCIAL STATS BAR */}
                <div className="px-5 mb-6">
                    <div className={`rounded-2xl overflow-hidden border ${isDark ? 'bg-white/5 border-white/10' : 'bg-white shadow-sm border-gray-100'}`}>
                        <div className="flex">
                            <button onClick={() => setSocialModal("following")} className={`flex-1 py-3.5 text-center border-l transition-colors ${isDark ? "border-white/10 hover:bg-white/5" : "border-gray-100 hover:bg-gray-50"}`}>
                                <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 mb-1"><UserPlus className="w-3 h-3" /> متابَع</div>
                                <p className={`font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>245</p>
                            </button>
                            <button onClick={() => setSocialModal("followers")} className={`flex-1 py-3.5 text-center border-l transition-colors relative ${isDark ? "border-white/10 hover:bg-white/5" : "border-gray-100 hover:bg-gray-50"}`}>
                                <div className="flex items-center justify-center gap-1.5 text-[10px] text-gray-400 mb-1">
                                    <Users className="w-3 h-3" /> متابعين
                                    {followersPrivate && <EyeOff className="w-2.5 h-2.5 text-amber-500" />}
                                </div>
                                <p className={`font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{followersPrivate ? "••••" : "12.5k"}</p>
                            </button>
                            <button onClick={() => setSocialModal("likes")} className={`flex-1 py-3.5 text-center transition-colors ${isDark ? "hover:bg-white/5" : "hover:bg-gray-50"}`}>
                                <div className="flex items-center justify-center gap-1 text-[10px] text-gray-400 mb-1"><Eye className="w-3 h-3 text-cyan-500" /> لايكات</div>
                                <p className={`font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>4.8k</p>
                            </button>
                        </div>
                    </div>
                </div>

                {/* WIDGETS (AGENTS & TOOLS) */}
                <div className="px-5">
                    <h3 className={`text-sm font-bold mb-4 flex items-center gap-2 ${isDark ? 'text-white/80' : 'text-gray-600'}`}>
                        <Cpu className="w-4 h-4 text-cyan-500 animate-pulse" />
                        الخدمات والمساعدون
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                        {/* --- BROKER --- */}
                        {devPersona === "broker" && (
                            <>
                                {/* Inventory (Elite Only) */}
                                {brokerTier === "elite" && (
                                     <AppWidget icon={Database} label="المخزون" color="red" onClick={() => setCurrentView("inventory_agent")} isDark={isDark} desc="عقارات غير منشورة" />
                                )}

                                {/* Core Agents */}
                                <AppWidget icon={Handshake} label="مساعد التفاوض" color="purple" onClick={() => setCurrentView("negotiation_agent")} isDark={isDark} locked={brokerTier === "basic"} />
                                <AppWidget icon={DollarSign} label="مساعد التقييم" color="emerald" onClick={() => setCurrentView("valuation_agent")} isDark={isDark} locked={brokerTier === "basic"} desc="تقييم AI للسعر" />
                                
                                {/* Management */}
                                <AppWidget icon={Users} label="إدارة العملاء" color="blue" onClick={() => setCurrentView("clients")} isDark={isDark} />
                                <AppWidget icon={Lock} label="إدارة الملاك" color="emerald" onClick={() => setCurrentView("owners")} isDark={isDark} />
                                
                                {/* Operations */}
                                <AppWidget icon={FileText} label="طلباتي" color="indigo" onClick={() => setCurrentView("my_requests")} isDark={isDark} />
                                <AppWidget icon={ListTodo} label="مهامي" color="pink" onClick={() => setCurrentView("tasks")} isDark={isDark} notify={3} />
                                
                                {/* Semantic Search */}
                                 <AppWidget icon={Search} label="البحث الدلالي" color="blue" onClick={() => setCurrentView("semantic_search")} isDark={isDark} desc="بحث ذكي AI" />

                            </>
                        )}

                        {/* --- DEVELOPER --- */}
                        {devPersona === "developer" && (
                            <>
                                {/* Inventory (Growth Only) */}
                                {developerTier === "growth" && (
                                     <AppWidget icon={Database} label="المخزون" color="red" onClick={() => setCurrentView("inventory_agent")} isDark={isDark} desc="عقارات غير منشورة" />
                                )}
                                
                                <AppWidget icon={Target} label="مساعد المطابقة" color="cyan" onClick={() => setCurrentView("matching_agent")} isDark={isDark} desc="مشترين مطابقين" notify={23} />
                                <AppWidget icon={DollarSign} label="مساعد التقييم" color="emerald" onClick={() => setCurrentView("valuation_agent")} isDark={isDark} desc="تقييم AI للسعر" />
                                <AppWidget icon={Handshake} label="مساعد المفاوض" color="purple" onClick={() => setCurrentView("negotiation_agent")} isDark={isDark} locked={developerTier === "basic"} desc="تفاوض ذكي AI" />
                                <AppWidget icon={Megaphone} label="مساعد التسويق" color="orange" onClick={() => setCurrentView("growth_agent")} isDark={isDark} locked={developerTier === "basic"} desc={developerTier !== "basic" ? "حملات ذكية" : undefined} />
                                <AppWidget icon={Building} label="المشاريع" color="blue" onClick={() => setCurrentView("projects")} isDark={isDark} />
                                <AppWidget icon={TrendingUp} label="مساعد النمو" color="emerald" onClick={() => setCurrentView("analyst_agent")} isDark={isDark} locked={developerTier !== "growth"} desc="تحليلات AI" />
                                <AppWidget icon={Users} label="إدارة العملاء" color="blue" onClick={() => setCurrentView("clients")} isDark={isDark} />
                                <AppWidget icon={FileText} label="طلباتي" color="indigo" onClick={() => setCurrentView("my_requests")} isDark={isDark} />
                                <AppWidget icon={ListTodo} label="مهامي" color="pink" onClick={() => setCurrentView("tasks")} isDark={isDark} />
                                <AppWidget icon={Search} label="البحث الدلالي" color="blue" onClick={() => setCurrentView("semantic_search")} isDark={isDark} desc="بحث ذكي AI" />
                            </>
                        )}

                        {/* --- LANDLORD --- */}
                        {devPersona === "landlord" && (
                            <>
                                <AppWidget icon={Building} label="عقاراتي" color="indigo" onClick={() => setCurrentView("properties")} isDark={isDark} />
                                <AppWidget icon={Handshake} label="مطابقة الوسطاء" color="purple" onClick={() => setCurrentView("broker_match")} isDark={isDark} locked={landlordTier === "basic"} notify={landlordTier === "professional" ? 3 : undefined} />
                                <AppWidget icon={DollarSign} label="مساعد التقييم" color="emerald" onClick={() => setCurrentView("valuation_agent")} isDark={isDark} locked={landlordTier === "basic"} />
                                <AppWidget icon={Search} label="البحث الدلالي" color="blue" onClick={() => setCurrentView("semantic_search")} isDark={isDark} desc="بحث ذكي AI" />
                                <AppWidget icon={FileText} label="طلباتي" color="blue" onClick={() => setCurrentView("my_requests")} isDark={isDark} />
                                <AppWidget icon={ListTodo} label="مهامي" color="pink" onClick={() => setCurrentView("tasks")} isDark={isDark} notify={2} />
                            </>
                        )}

                         {/* --- SEEKER --- */}
                         {devPersona === "seeker" && (
                            <>
                                <AppWidget icon={Target} label="مساعد المطابقة" color="cyan" onClick={() => setCurrentView("matching_agent")} isDark={isDark} locked={seekerTier === "basic"} desc={seekerTier === "smart" ? "95% تطابق" : "عقارات مطابقة"} />
                                <AppWidget icon={DollarSign} label="مساعد التقييم" color="emerald" onClick={() => setCurrentView("fair_price")} isDark={isDark} locked={seekerTier === "basic"} desc={seekerTier === "smart" ? "أقل من السوق 10%" : undefined} />
                                <AppWidget icon={Search} label="البحث الدلالي" color="blue" onClick={() => setCurrentView("semantic_search")} isDark={isDark} locked={seekerTier === "basic"} />
                                <AppWidget icon={FileText} label="طلباتي" color="indigo" onClick={() => setCurrentView("my_requests")} isDark={isDark} />
                                <AppWidget icon={Heart} label="المفضلة" color="pink" onClick={() => setCurrentView("wishlist")} isDark={isDark} />
                                <AppWidget icon={ListTodo} label="مهامي" color="pink" onClick={() => setCurrentView("tasks")} isDark={isDark} />
                            </>
                        )}
                    </div>
                </div>

                {/* BROKER LISTINGS SECTION — below services grid */}
                {devPersona === "broker" && (
                  <div className="px-5 mt-6">
                    <h3 className={`text-sm font-bold mb-4 flex items-center gap-2 ${isDark ? 'text-white/80' : 'text-gray-600'}`}>
                      <Building className="w-4 h-4 text-blue-500" />
                      عروضي العقارية
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <AppWidget
                        icon={Building}
                        label="العروض المعلنة"
                        color="blue"
                        onClick={() => setCurrentView("broker_listings")}
                        isDark={isDark}
                        desc="4 عروض نشطة"
                        notify={4}
                      />
                    </div>


                  </div>
                )}

                {/* SETTINGS LINK */}
                <div className="px-5 mt-6">
                    <button onClick={() => setCurrentView("settings")} className={`w-full p-4 rounded-2xl flex items-center justify-between ${isDark ? 'bg-[#1E2330]' : 'bg-white border border-gray-100'}`}>
                        <div className="flex items-center gap-3">
                            <Settings className="w-5 h-5 text-gray-500" />
                            <span className={`font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>الإعدادات</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-500" />
                    </button>
                </div>
            </motion.div>
        ) : viewMode === "owner" && currentView === "settings" ? (
             <SettingsView onBack={() => setCurrentView("dashboard")} isDark={isDark} />
        ) : viewMode === "owner" ? (
            <SubScreenWrapper onBack={() => setCurrentView("dashboard")} isDark={isDark} title={getViewTitle(currentView)} icon={getViewIcon(currentView)}>
                {renderSubScreen(currentView, isDark, devPersona)}
            </SubScreenWrapper>
        ) : null}
      </AnimatePresence>

      {/* FLOATNIG AION AGENT */}
      <FloatingAION currentPersona={devPersona} tier={tierInfo.label} brokerType={brokerType} />
    </div>
  );
}

// ============================================================================
// WIDGET & SHARED
// ============================================================================
function AppWidget({ icon: Icon, label, color, onClick, isDark, desc, locked, notify }: any) {
    const colorClasses: any = {
        cyan: isDark ? "bg-cyan-500/20 text-cyan-400" : "bg-cyan-100 text-cyan-600",
        purple: isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-600",
        emerald: isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-600",
        blue: isDark ? "bg-blue-500/20 text-blue-400" : "bg-blue-100 text-blue-600",
        orange: isDark ? "bg-orange-500/20 text-orange-400" : "bg-orange-100 text-orange-600",
        pink: isDark ? "bg-pink-500/20 text-pink-400" : "bg-pink-100 text-pink-600",
        indigo: isDark ? "bg-indigo-500/20 text-indigo-400" : "bg-indigo-100 text-indigo-600",
        amber: isDark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-600",
        red: isDark ? "bg-red-500/20 text-red-400" : "bg-red-100 text-red-600",
    };

    return (
        <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onClick}
            className={`relative p-4 rounded-3xl border flex flex-col items-center justify-center gap-2 transition-all min-h-[120px] text-center ${
                locked ? 'grayscale opacity-70 cursor-not-allowed' : ''
            } ${
                isDark ? 'bg-[#151a2d] border-white/5 hover:bg-white/5' : 'bg-white shadow-sm hover:shadow-md border-gray-100'
            }`}
        >
             {notify && (
                <div className="absolute top-2 right-2 w-5 h-5 bg-red-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center shadow-lg animate-bounce">
                    {notify}
                </div>
            )}
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${colorClasses[color]}`}>
                {locked ? <Lock className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
            </div>
            <div>
                <span className={`block text-xs font-bold ${isDark ? 'text-white/90' : 'text-gray-800'}`}>{label}</span>
                {desc && <span className="text-[9px] text-gray-500 mt-0.5 block">{desc}</span>}
            </div>
            {locked && (
                <div className="absolute inset-0 bg-white/5 backdrop-blur-[1px] rounded-3xl" />
            )}
        </motion.button>
    )
}

function SubScreenWrapper({ children, onBack, isDark, title, icon: Icon }: any) {
    return (
        <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 overflow-y-auto pb-20 pt-[110px] flex flex-col"
        >
            <div className="px-5 py-2 flex items-center gap-3 mb-4">
                 <button onClick={onBack} className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                     isDark ? 'bg-white/5 hover:bg-white/10 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
                 }`}>
                     <ArrowRight className="w-5 h-5" />
                 </button>
                 <div className="flex items-center gap-2">
                    {Icon && <Icon className={`w-6 h-6 ${isDark ? 'text-cyan-400' : 'text-cyan-600'}`} />}
                    <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{title}</h2>
                 </div>
            </div>
            <div className="px-5 flex-1">
                {children}
            </div>
        </motion.div>
    )
}

function SettingsView({ onBack, isDark }: any) {
    const { toggleTheme } = useTheme();
    const [notificationsEnabled, setNotificationsEnabled] = useState(true);
    const [locationEnabled, setLocationEnabled] = useState(true);
    const [ticketSubmitted, setTicketSubmitted] = useState(false);

    const settingsSections = [
        {
            title: "عام",
            items: [
                {
                    icon: isDark ? Moon : Sun,
                    iconColor: isDark ? "text-purple-400" : "text-orange-400",
                    label: "��لمظهر",
                    value: isDark ? "داكن" : "فاتح",
                    action: toggleTheme,
                },
                {
                    icon: Globe,
                    iconColor: "text-blue-400",
                    label: "اللغة",
                    value: "العربية",
                    action: () => {},
                },
                {
                    icon: Bell,
                    iconColor: "text-amber-400",
                    label: "الإشعارات",
                    toggle: true,
                    toggleValue: notificationsEnabled,
                    action: () => setNotificationsEnabled(!notificationsEnabled),
                },
                {
                    icon: MapPin,
                    iconColor: "text-emerald-400",
                    label: "خدمات الموقع",
                    toggle: true,
                    toggleValue: locationEnabled,
                    action: () => setLocationEnabled(!locationEnabled),
                },
            ],
        },
        {
            title: "الحساب",
            items: [
                {
                    icon: User,
                    iconColor: "text-cyan-400",
                    label: "تعديل الملف الشخصي",
                    action: () => {},
                },
                {
                    icon: LockKeyhole,
                    iconColor: "text-red-400",
                    label: "تغيير كلمة المرور",
                    action: () => {},
                },
                {
                    icon: ShieldCheck,
                    iconColor: "text-emerald-400",
                    label: "التحقق بخطوتين",
                    value: "مفعّل",
                    action: () => {},
                },
            ],
        },
        {
            title: "الدعم والمساعدة",
            items: [
                {
                    icon: HelpCircle,
                    iconColor: "text-blue-400",
                    label: "مركز المساعدة",
                    action: () => {},
                },
                {
                    icon: MessageSquare,
                    iconColor: "text-purple-400",
                    label: "رفع تذكرة دعم",
                    action: () => setTicketSubmitted(true),
                    highlight: true,
                },
                {
                    icon: FileQuestion,
                    iconColor: "text-indigo-400",
                    label: "الأسئلة الشائعة",
                    action: () => {},
                },
                {
                    icon: Phone,
                    iconColor: "text-emerald-400",
                    label: "تواصل معنا",
                    value: "920000000",
                    action: () => {},
                },
            ],
        },
        {
            title: "قانوني",
            items: [
                {
                    icon: FileText,
                    iconColor: "text-gray-400",
                    label: "سياسة الخصوصية",
                    action: () => {},
                },
                {
                    icon: FileText,
                    iconColor: "text-gray-400",
                    label: "الشروط والأحكام",
                    action: () => {},
                },
                {
                    icon: Share2,
                    iconColor: "text-cyan-400",
                    label: "مشاركة التطبيق",
                    action: () => {},
                },
            ],
        },
    ];

    return (
        <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 overflow-y-auto pb-32 pt-[110px]"
        >
             <div className="px-5 py-2 flex items-center gap-3 mb-6">
                 <button onClick={onBack} className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${isDark ? 'bg-white/5 text-white' : 'bg-gray-100 text-gray-900'}`}>
                     <ArrowRight className="w-5 h-5" />
                 </button>
                 <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>الإعدادات</h2>
            </div>

            <div className="px-5 space-y-6">
                {/* Ticket Submitted Popup */}
                <AnimatePresence>
                    {ticketSubmitted && (
                        <motion.div
                            initial={{ opacity: 0, y: -10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            className={`p-4 rounded-2xl border flex items-center gap-3 ${
                                isDark ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-emerald-50 border-emerald-200'
                            }`}
                        >
                            <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
                            <div className="flex-1">
                                <p className={`text-xs font-black ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>تم رفع التذكرة بنجاح</p>
                                <p className="text-[10px] opacity-60">سيتم الرد خلال 24 ساعة عمل</p>
                            </div>
                            <button onClick={() => setTicketSubmitted(false)} className="w-6 h-6 rounded-lg flex items-center justify-center bg-white/10 hover:bg-white/20">
                                <X className="w-3 h-3 opacity-50" />
                            </button>
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Settings Sections */}
                {settingsSections.map((section, sIdx) => (
                    <div key={sIdx}>
                        <h3 className={`text-[11px] font-black mb-3 px-1 ${isDark ? 'text-white/40' : 'text-gray-400'}`}>
                            {section.title}
                        </h3>
                        <div className={`rounded-2xl overflow-hidden border ${isDark ? 'bg-[#1E2330] border-white/5' : 'bg-white border-gray-100'}`}>
                            {section.items.map((item, iIdx) => {
                                const Icon = item.icon;
                                return (
                                    <button
                                        key={iIdx}
                                        onClick={item.action}
                                        className={`w-full p-4 flex items-center justify-between transition-colors ${
                                            iIdx < section.items.length - 1
                                                ? isDark ? 'border-b border-white/5' : 'border-b border-gray-100'
                                                : ''
                                        } ${
                                            isDark ? 'hover:bg-white/5' : 'hover:bg-gray-50'
                                        } ${
                                            (item as any).highlight ? isDark ? 'bg-purple-500/5' : 'bg-purple-50/50' : ''
                                        }`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <Icon className={`w-5 h-5 ${item.iconColor}`} />
                                            <span className={`font-bold text-sm ${isDark ? 'text-white' : 'text-gray-900'}`}>{item.label}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            {(item as any).value && (
                                                <span className="text-xs text-gray-500">{(item as any).value}</span>
                                            )}
                                            {(item as any).toggle ? (
                                                <div className={`w-10 h-5 rounded-full relative transition-colors ${(item as any).toggleValue ? 'bg-emerald-500' : isDark ? 'bg-gray-600' : 'bg-gray-300'}`}>
                                                    <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${(item as any).toggleValue ? 'left-6' : 'left-1'}`} />
                                                </div>
                                            ) : (
                                                <ChevronRight className={`w-4 h-4 ${isDark ? 'text-white/20' : 'text-gray-300'}`} />
                                            )}
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                ))}

                {/* Logout Button */}
                <button className={`w-full p-4 rounded-2xl flex items-center justify-center gap-3 border transition-colors ${
                    isDark ? 'border-red-500/20 bg-red-500/5 hover:bg-red-500/10' : 'border-red-200 bg-red-50 hover:bg-red-100'
                }`}>
                    <LogOut className="w-5 h-5 text-red-500" />
                    <span className="font-bold text-red-500">تسجيل الخروج</span>
                </button>

                {/* Version Info */}
                <div className={`p-4 rounded-2xl text-center ${isDark ? 'bg-[#1E2330]' : 'bg-white border border-gray-100'}`}>
                    <p className="text-xs text-gray-500">ڤال Real Estate V2.0</p>
                    <p className="text-[9px] text-gray-400 mt-1">جميع الحقوق محفوظة 2026</p>
                </div>
            </div>
        </motion.div>
    )
}

// ============================================================================
// RENDERERS
// ============================================================================

function getViewTitle(view: View) {
    switch(view) {
        case "matching_agent": return "مساعد المطابقة AI";
        case "negotiation_agent": return "مساعد التفاوض AI";
        case "analyst_agent": return "مساعد تحليل السوق";
        case "growth_agent": return "مساعد التسويق AI";
        case "marketing_agent": return "مساعد التسويق AI";
        case "editor_agent": return "مساعد تحرير المحتوى";
        case "valuation_agent": return "مساعد التقييم العقاري";
        case "personal_agent": return "المساعد الشخصي (Mem0)";
        case "semantic_search": return "محرك البحث الدلالي";
        case "clients": return "إدارة العملاء";
        case "owners": return "إدارة الملاك";
        case "team_management": return "إدارة الفريق";
        case "my_requests": return "طلباتي";
        case "tasks": return "مهامي";
        case "offers": return "العروض الواردة";
        case "assets": return "عقاراتي";
        case "properties": return "عقاراتي";
        case "wishlist": return "قائمة المفضلة";
        case "early_alerts": return "التنبيهات المبكرة VIP";
        case "ai_inquiry_guard": return "حارس الاستفسارات AI";
        case "broker_match": return "مطابقة الوسطاء";
        case "fair_price": return "مساعد التقييم";
        case "projects": return "مشاريعي";
        case "sales_team": return "فريق المبيعات";
        case "broker_listings": return "العروض المعلنة";
        case "broker_bulk_update": return "التحديث الجماعي للعروض";
        case "inventory_agent": return "المخزون الخاص";
        default: return "التفاصيل";
    }
}

function getViewIcon(view: View) {
    switch(view) {
        case "matching_agent": return Target;
        case "negotiation_agent": return Handshake;
        case "analyst_agent": return BarChart3;
        case "growth_agent": return Megaphone;
        case "marketing_agent": return Megaphone;
        case "editor_agent": return PenTool;
        case "valuation_agent": return DollarSign;
        case "personal_agent": return Cpu;
        case "semantic_search": return Search;
        case "clients": return Users;
        case "owners": return Lock;
        case "team_management": return UserPlus;
        case "my_requests": return FileText;
        case "tasks": return ListTodo;
        case "inventory_agent": return Database;
        case "projects": return Building;
        case "sales_team": return Users;
        case "assets": return Building;
        case "offers": return FileText;
        case "wishlist": return Heart;
        case "early_alerts": return Bell;
        case "ai_inquiry_guard": return ShieldCheck;
        case "broker_match": return Handshake;
        case "fair_price": return DollarSign;
        case "properties": return Building;
        case "broker_listings": return Building;
        case "broker_bulk_update": return ArrowUpRight;
        default: return Sparkles;
    }
}

function renderSubScreen(view: View, isDark: boolean, devPersona?: string) {
     // Dedicated interactive view for Developer's Matching Agent
     if (view === 'matching_agent') {
         if (devPersona === 'seeker') {
             return <SeekerMatchingAgentView isDark={isDark} />;
         }
         return <DeveloperMatchingAgentView isDark={isDark} />;
     }

     // Interactive sub-screens for views that previously showed GenericTechView
     if (view === 'negotiation_agent') return <NegotiationAgentView isDark={isDark} />;
     if (view === 'owners') return <OwnersView isDark={isDark} />;
     if (view === 'clients') return <ClientsView isDark={isDark} />;
     if (view === 'tasks') return <TasksView isDark={isDark} />;
     if (view === 'editor_agent') return <EditorAgentView isDark={isDark} />;
     if (view === 'personal_agent') return <PersonalAgentView isDark={isDark} />;
     if (view === 'semantic_search') return <SemanticSearchView isDark={isDark} />;
     if (view === 'wishlist') return <WishlistView isDark={isDark} />;
     if (view === 'valuation_agent') return <ValuationAgentView isDark={isDark} />;
     if (view === 'early_alerts') return <EarlyAlertsView isDark={isDark} />;
     if (view === 'offers') return <OffersView isDark={isDark} />;
     if (view === 'broker_match') return <BrokerMatchView isDark={isDark} />;
     if (view === 'ai_inquiry_guard') return <AIInquiryGuardView isDark={isDark} />;
     if (view === 'fair_price') return <FairPriceView isDark={isDark} />;
     if (view === 'analyst_agent') return <AnalyticsView isDark={isDark} />;
     if (view === 'marketing_agent') return <MarketingAgentView isDark={isDark} />;
     if (view === 'growth_agent') return <MarketingAgentView isDark={isDark} />;

     if (view === 'team_management') return <DeveloperTeamView isDark={isDark} />;
     if (view === 'broker_listings') return <BrokerListingsView isDark={isDark} />;
     if (view === 'broker_bulk_update') return <BrokerBulkUpdateView isDark={isDark} />;
     if (view === 'my_requests') return <MyRequestsView isDark={isDark} isBroker={devPersona === 'broker'} onNavigateToClients={() => setCurrentView('clients')} />;

     // Map internal Views to DetailViewContainer IDs
     let detailId = '';

     // Mapping logic
     if (view === 'inventory_agent') detailId = 'inventory_view';
     if (view === 'projects' || view === 'properties' || view === 'assets') detailId = 'my_listings';
     if (view === 'sales_team') detailId = 'sales_team';
     
     if (detailId) {
         return <DetailViewContainer viewId={detailId} onBack={() => {}} />;
     }

     return <GenericTechView title={getViewTitle(view)} isDark={isDark} />;
}

// ============================================================================
// SOCIAL MODAL
// ============================================================================
function SocialModal({ type, isDark, followersPrivate, onTogglePrivate, onClose }: any) {
    const followingList = [
        { name: "شركة رتال للتطوير", role: "مطور عقاري", avatar: "https://i.pravatar.cc/150?img=10" },
        { name: "أحمد العتيبي", role: "وسيط عقاري", avatar: "https://i.pravatar.cc/150?img=11" },
        { name: "سارة الزهراني", role: "مالكة عقار", avatar: "https://i.pravatar.cc/150?img=15" },
        { name: "مجموعة ڤال", role: "منصة عقارية", avatar: "https://i.pravatar.cc/150?img=20" },
    ];
    const followersList = [
        { name: "فهد الدوسري", role: "باحث عقاري", avatar: "https://i.pravatar.cc/150?img=5" },
        { name: "نورة السالم", role: "مالكة عقار", avatar: "https://i.pravatar.cc/150?img=6" },
        { name: "عبدالله الغامدي", role: "وسيط عقاري", avatar: "https://i.pravatar.cc/150?img=7" },
        { name: "شركة العمران", role: "مطور عقاري", avatar: "https://i.pravatar.cc/150?img=9" },
        { name: "خالد المطيري", role: "باحث عقاري", avatar: "https://i.pravatar.cc/150?img=13" },
    ];
    const likesList = [
        { name: "محمد الشمري", role: "أعجبه: فيلا النرجس", avatar: "https://i.pravatar.cc/150?img=30" },
        { name: "سلطان القحطاني", role: "أعجبه: شقة العليا", avatar: "https://i.pravatar.cc/150?img=31" },
        { name: "هنادي العمري", role: "أعجبها: أرض الياسمين", avatar: "https://i.pravatar.cc/150?img=35" },
    ];
    const list = type === "following" ? followingList : type === "followers" ? followersList : likesList;
    const titles: Record<string, string> = { following: "المتابَعون (245)", followers: "المتابعون (12.5k)", views: "الإعجابات (4.8k)" };

    return (
        <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[60]" onClick={onClose} />
            <motion.div initial={{ opacity: 0, y: 40, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 40, scale: 0.95 }}
                className={`fixed inset-x-4 bottom-8 top-[15%] z-[61] rounded-3xl flex flex-col max-w-lg mx-auto overflow-hidden border shadow-2xl ${isDark ? "bg-[#0d1424] border-white/10" : "bg-white border-gray-200"}`}>
                {/* Header */}
                <div className={`flex items-center justify-between px-5 py-4 border-b ${isDark ? "border-white/8" : "border-gray-100"}`}>
                    <h3 className={`font-black text-base ${isDark ? "text-white" : "text-gray-900"}`}>{titles[type]}</h3>
                    <div className="flex items-center gap-2">
                        {type === "followers" && (
                            <button onClick={onTogglePrivate}
                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${
                                    followersPrivate
                                        ? isDark ? "bg-amber-500/20 border-amber-500/40 text-amber-400" : "bg-amber-50 border-amber-300 text-amber-700"
                                        : isDark ? "bg-white/5 border-white/10 text-white/60" : "bg-gray-50 border-gray-200 text-gray-600"
                                }`}>
                                {followersPrivate ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                                {followersPrivate ? "خاص" : "عام"}
                            </button>
                        )}
                        <button onClick={onClose} className={`w-8 h-8 rounded-xl flex items-center justify-center ${isDark ? "bg-white/8 text-white/60" : "bg-gray-100 text-gray-600"}`}>
                            <X className="w-4 h-4" />
                        </button>
                    </div>
                </div>
                {type === "followers" && followersPrivate ? (
                    <div className="flex-1 flex flex-col items-center justify-center gap-3">
                        <div className={`w-16 h-16 rounded-3xl flex items-center justify-center ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
                            <EyeOff className="w-8 h-8 text-amber-500" />
                        </div>
                        <p className={`font-black text-sm ${isDark ? "text-white" : "text-gray-900"}`}>القائمة خا��ة</p>
                        <p className={`text-xs text-center max-w-[200px] ${isDark ? "text-white/40" : "text-gray-400"}`}>قائمة المتابعين مخفية عن الآخرين</p>
                    </div>
                ) : (
                    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
                        {list.map((item, i) => (
                            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                                className={`flex items-center gap-3 p-3 rounded-2xl transition-colors ${isDark ? "hover:bg-white/5" : "hover:bg-gray-50"}`}>
                                <div className="w-11 h-11 rounded-2xl overflow-hidden shrink-0">
                                    <img src={item.avatar} alt={item.name} className="w-full h-full object-cover" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className={`font-black text-sm truncate ${isDark ? "text-white" : "text-gray-900"}`}>{item.name}</p>
                                    <p className={`text-[11px] truncate ${isDark ? "text-white/40" : "text-gray-400"}`}>{item.role}</p>
                                </div>
                                <button className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${isDark ? "border-white/10 text-white/60 hover:bg-white/5" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
                                    {type === "following" ? "إلغاء المتابعة" : "متابعة"}
                                </button>
                            </motion.div>
                        ))}
                    </div>
                )}
            </motion.div>
        </>
    );
}

// ============================================================================
// VISITOR PROFILE VIEW
// ============================================================================
function VisitorProfileView({ persona, tierInfo, isDark }: any) {
    const [activeTab, setActiveTab] = useState<"offers" | "requests">(persona === "seeker" ? "requests" : "offers");
    
    // Reset tab when persona changes
    useEffect(() => {
        setActiveTab(persona === "seeker" ? "requests" : "offers");
    }, [persona]);

    const names: Record<string, string> = { broker: "عبدالله العتيبي", developer: "شركة العمران للتطوير", landlord: "سعد القحطاني", seeker: "نورة السالم" };
    const roles: Record<string, string> = { broker: "وسيط عقاري معتمد", developer: "مطور عقاري", landlord: "مالك عقار", seeker: "باحث عقاري" };
    
    // Mock Data
    const brokerListings = [
        { title: "فيلا مودرن النرجس", price: "2.5M", tag: "للبيع", img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&q=80" },
        { title: "شقة العليا 3 غرف", price: "850k", tag: "للبيع", img: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400&q=80" },
        { title: "أرض تجارية حطين", price: "4.2M", tag: "للبيع", img: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&q=80" },
    ];
    const devProjects = [
        { title: "مشروع النخيل", units: 24, completion: 75, img: "https://images.unsplash.com/photo-1656158113009-c8f5b3268aca?w=400&q=80" },
        { title: "برج المدار", units: 16, completion: 45, img: "https://images.unsplash.com/photo-1764080400538-4487aa44172f?w=400&q=80" },
    ];
    const requests = [
        { title: "مطلوب فيلا 5 غرف شمال الرياض", budget: "3M", type: "بحث" },
        { title: "طلب تسويق شقة النرجس", budget: "900k", type: "تسويق" },
        { title: "مطلوب أرض تجارية الملقا", budget: "4.5M", type: "بحث" },
    ];

    // Stats based on persona
    const stats = {
        broker: { followers: "12.5k", following: "245", views: "48.2k" },
        developer: { followers: "45.2k", following: "1.2k", views: "1.2M" },
        landlord: { followers: "850", following: "45", views: "9.8k" },
        seeker: { followers: "120", following: "320", views: "340" },
    }[persona as string] || { followers: "0", following: "0", views: "0" };

    return (
        <motion.div key="visitor" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
            className={`absolute inset-0 overflow-y-auto pb-32 pt-[140px] z-10 ${isDark ? "bg-[#0f172a]" : "bg-gray-50"}`}>
            
            {/* 1. HEADER CARD */}
            <div className="px-5 mb-6">
                <div className={`rounded-[32px] p-6 border relative overflow-hidden ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-xl shadow-slate-200/50"}`}>
                    {/* Background Pattern */}
                    <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-blue-500/10 to-transparent pointer-events-none" />
                    
                    <div className="relative z-10 flex flex-col items-center text-center">
                        {/* Avatar & Stats Row */}
                        <div className="flex items-center justify-between w-full mb-4">
                             {/* Stats Right */}
                             <div className="text-center w-20">
                                <p className={`text-lg font-black ${isDark ? "text-white" : "text-gray-900"}`}>{stats.views}</p>
                                <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>لايكات</p>
                            </div>

                            {/* Avatar Center */}
                            <div className="relative -mt-4">
                                <div className={`w-24 h-24 rounded-3xl flex items-center justify-center text-4xl font-black text-white shadow-2xl bg-gradient-to-br ${tierInfo.gradient} border-4 ${isDark ? "border-[#151a2d]" : "border-white"}`}>
                                    {names[persona][0]}
                                </div>
                                <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-blue-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full border-2 border-white shadow-sm whitespace-nowrap">
                                    {tierInfo.label}
                                </div>
                            </div>

                             {/* Stats Left */}
                            <div className="text-center w-20">
                                <p className={`text-lg font-black ${isDark ? "text-white" : "text-gray-900"}`}>{stats.followers}</p>
                                <p className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>متابعين</p>
                            </div>
                        </div>

                        {/* Name & Role */}
                        <div className="mb-4">
                            <h2 className={`text-xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>{names[persona]}</h2>
                            <p className={`text-xs mt-1 ${isDark ? "text-white/50" : "text-gray-500"}`}>{roles[persona]}</p>
                        </div>

                        {/* Rating & Actions Row */}
                        <div className="flex items-center gap-3 w-full justify-center">
                             <button className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${isDark ? "bg-white/5 text-white hover:bg-white/10" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>
                                <Phone className="w-4 h-4" />
                            </button>

                            <div className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 ${isDark ? "bg-amber-500/10 border border-amber-500/20" : "bg-amber-50 border border-amber-100"}`}>
                                <span className={`text-xs font-black ${isDark ? "text-amber-400" : "text-amber-600"}`}>4.8</span>
                                <div className="flex gap-0.5">
                                    {[1,2,3,4,5].map(s => <Star key={s} className={`w-3 h-3 ${s <= 4 ? "text-amber-400 fill-amber-400" : isDark ? "text-white/10" : "text-gray-300"}`} />)}
                                </div>
                            </div>

                             <button className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${isDark ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" : "bg-blue-600 text-white shadow-lg shadow-blue-500/30"}`}>
                                <MessageCircle className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* 2. TABS (Offers & Requests) */}
            <div className="px-5 mb-5 sticky top-[135px] z-20">
                <div className={`p-1 rounded-2xl flex ${isDark ? "bg-[#151a2d] border border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                    {persona !== "seeker" && (
                        <button 
                            onClick={() => setActiveTab("offers")}
                            className={`flex-1 py-3 rounded-xl text-xs font-black transition-all ${
                                activeTab === "offers" 
                                ? isDark ? "bg-white/10 text-white shadow-sm" : "bg-gray-100 text-gray-900 shadow-sm" 
                                : isDark ? "text-white/40" : "text-gray-400"
                            }`}
                        >
                            العروض المعلنة
                        </button>
                    )}
                    <button 
                        onClick={() => setActiveTab("requests")}
                        className={`flex-1 py-3 rounded-xl text-xs font-black transition-all ${
                            activeTab === "requests" 
                            ? isDark ? "bg-white/10 text-white shadow-sm" : "bg-gray-100 text-gray-900 shadow-sm" 
                            : isDark ? "text-white/40" : "text-gray-400"
                        }`}
                    >
                        الطلبات المعلنة
                    </button>
                </div>
            </div>

            {/* 3. CONTENT LIST */}
            <div className="px-5 space-y-3 pb-10">
                {activeTab === "offers" && persona !== "seeker" ? (
                    <>
                        {persona === "developer" ? (
                             // Developer Projects
                             devProjects.map((p, i) => (
                                <div key={i} className={`p-4 rounded-3xl border overflow-hidden ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                                    <div className="relative h-32 rounded-2xl overflow-hidden mb-3">
                                        <img src={p.img} alt={p.title} className="w-full h-full object-cover" />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                                        <div className="absolute bottom-3 right-3 text-white">
                                            <p className="font-black text-sm">{p.title}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>{p.units} وحدة سكنية</span>
                                        <span className="text-xs font-black text-emerald-500">{p.completion}% مكتمل</span>
                                    </div>
                                    <div className={`mt-2 h-1.5 rounded-full ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
                                        <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500" style={{ width: `${p.completion}%` }} />
                                    </div>
                                </div>
                            ))
                        ) : (
                            // Broker/Landlord Listings
                            brokerListings.map((l, i) => (
                                <div key={i} className={`flex gap-3 p-3 rounded-3xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                                    <div className="w-24 h-20 rounded-2xl overflow-hidden shrink-0 relative">
                                        <img src={l.img} alt={l.title} className="w-full h-full object-cover" />
                                        <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-black/50 backdrop-blur-md border border-white/20">
                                            <p className="text-[8px] font-black text-white">{l.tag}</p>
                                        </div>
                                    </div>
                                    <div className="flex-1 py-1 min-w-0 flex flex-col justify-between">
                                        <div>
                                            <p className={`font-black text-sm truncate mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{l.title}</p>
                                            <p className={`text-[10px] flex items-center gap-1 ${isDark ? "text-white/40" : "text-gray-500"}`}>
                                                <MapPin className="w-3 h-3" /> حي النرجس، الرياض
                                            </p>
                                        </div>
                                        <div className="flex items-center justify-between mt-2">
                                            <p className={`font-black text-sm ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{l.price}</p>
                                            <button className={`w-7 h-7 rounded-lg flex items-center justify-center ${isDark ? "bg-white/5 text-white/40 hover:bg-white/10" : "bg-gray-100 text-gray-400 hover:bg-gray-200"}`}>
                                                <ArrowRight className="w-3.5 h-3.5" />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))
                        )}
                        {/* Empty state filler */}
                        {(persona === "developer" ? devProjects.length : brokerListings.length) === 0 && (
                            <div className="text-center py-10 opacity-40">
                                <p className="text-xs">لا توجد عروض معلنة حالياً</p>
                            </div>
                        )}
                    </>
                ) : (
                    <>
                        {requests.map((r, i) => (
                            <div key={i} className={`p-4 rounded-3xl border ${isDark ? "bg-[#151a2d] border-white/5" : "bg-white border-gray-100 shadow-sm"}`}>
                                <div className="flex items-start gap-3">
                                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${r.type === "بحث" ? isDark ? "bg-blue-500/10 text-blue-400" : "bg-blue-50 text-blue-600" : isDark ? "bg-pink-500/10 text-pink-400" : "bg-pink-50 text-pink-600"}`}>
                                        {r.type === "بحث" ? <Search className="w-5 h-5" /> : <Megaphone className="w-5 h-5" />}
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start mb-1">
                                            <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${r.type === "بحث" ? isDark ? "bg-blue-500/10 text-blue-400" : "bg-blue-100 text-blue-700" : isDark ? "bg-pink-500/10 text-pink-400" : "bg-pink-100 text-pink-700"}`}>{r.type}</span>
                                            <span className={`text-[10px] ${isDark ? "text-white/40" : "text-gray-400"}`}>منذ يومين</span>
                                        </div>
                                        <p className={`font-black text-sm mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>{r.title}</p>
                                        <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>الميزانية: <span className={isDark ? "text-white" : "text-gray-900"}>{r.budget}</span></p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </>
                )}
            </div>
        </motion.div>
    );
}

function SectionHeader({ title, count, isDark }: any) {
    return (
        <div className="flex items-center justify-between">
            <span className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{title}</span>
            <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${isDark ? "bg-white/10 text-white/50" : "bg-gray-100 text-gray-500"}`}>{count}</span>
        </div>
    );
}

function GenericTechView({ title, isDark }: any) {
    return (
        <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mb-6 ${isDark ? 'bg-white/5' : 'bg-gray-100'}`}>
                <Cpu className="w-10 h-10 text-cyan-500 animate-pulse" />
            </div>
            <h3 className={`text-2xl font-black mb-3 ${isDark ? 'text-white' : 'text-gray-900'}`}>{title}</h3>
            <p className="text-sm text-gray-500 max-w-[250px] leading-relaxed">
                يتم تحميل البيانات وعرض التحليلات في الوقت الفعلي...
            </p>
        </div>
    )
}

// ============================================================================
// DEVELOPER MATCHING AGENT — FEATURED CARD & INTERACTIVE VIEW
// ============================================================================

function DeveloperMatchingAgentFeatured({ isDark, onClick }: { isDark: boolean; onClick: () => void }) {
    return (
        <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={onClick}
            className={`mt-4 w-full rounded-3xl border overflow-hidden relative ${
                isDark
                    ? 'bg-gradient-to-br from-blue-950 via-indigo-950 to-slate-900 border-blue-500/30'
                    : 'bg-gradient-to-br from-blue-50 to-indigo-100 border-blue-200'
            }`}
        >
            {/* LIVE badge */}
            <div className="absolute top-3 left-3 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[9px] font-black text-emerald-400">LIVE</span>
            </div>

            <div className="p-5 pt-10">
                <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-2xl bg-blue-500/20 flex items-center justify-center">
                        <Target className="w-5 h-5 text-blue-400" />
                    </div>
                    <div className="text-right flex-1">
                        <p className="text-sm font-black text-white">وكيل المطابقة AI</p>
                        <p className="text-[10px] opacity-60">يجلب المشترين الجاهزين إلى مشروعك مباشرةً</p>
                    </div>
                </div>

                {/* Stats Row */}
                <div className="grid grid-cols-3 gap-2 mb-3">
                    <div className={`p-2 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
                        <p className="text-xl font-black text-blue-400">23</p>
                        <p className="text-[9px] opacity-60">مشتري جاهز</p>
                    </div>
                    <div className={`p-2 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
                        <p className="text-xl font-black text-emerald-400">8</p>
                        <p className="text-[9px] opacity-60">طلب زيارة</p>
                    </div>
                    <div className={`p-2 rounded-xl text-center ${isDark ? 'bg-white/5' : 'bg-white/60'}`}>
                        <p className="text-xl font-black text-amber-400">5</p>
                        <p className="text-[9px] opacity-60">في التفاوض</p>
                    </div>
                </div>

                {/* Buyer Avatars Preview */}
                <div className="flex items-center gap-2">
                    <div className="flex -space-x-2 space-x-reverse">
                        {["أ","م","س","ن"].map((l, i) => (
                            <div key={i} className="w-7 h-7 rounded-full bg-gradient-to-tr from-blue-500 to-cyan-500 border-2 border-slate-900 flex items-center justify-center">
                                <span className="text-[9px] font-black text-white">{l}</span>
                            </div>
                        ))}
                        <div className="w-7 h-7 rounded-full bg-white/10 border-2 border-slate-900 flex items-center justify-center">
                            <span className="text-[9px] font-black text-white/70">+19</span>
                        </div>
                    </div>
                    <span className="text-[10px] opacity-60 flex-1">مشترين مطابقين لمشروعك</span>
                    <ChevronRight className="w-4 h-4 opacity-40" />
                </div>
            </div>
        </motion.button>
    );
}

// ── Two-mode wrapper: mode selection → marketing OR search ──────────
function DeveloperMatchingAgentView({ isDark }: { isDark: boolean }) {
    const [mode, setMode] = useState<'marketing' | 'search' | null>(null);

    if (mode === 'marketing') {
        return (
            <div className="space-y-4">
                <button
                    onClick={() => setMode(null)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${isDark ? 'bg-white/8 text-gray-300 hover:bg-white/15' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                    <ChevronRight className="w-3.5 h-3.5 rotate-180" />
                    رجوع للخيارات
                </button>
                <DeveloperMarketingContent isDark={isDark} />
            </div>
        );
    }

    if (mode === 'search') {
        return (
            <div className="space-y-4">
                <button
                    onClick={() => setMode(null)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${isDark ? 'bg-white/8 text-gray-300 hover:bg-white/15' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                    <ChevronRight className="w-3.5 h-3.5 rotate-180" />
                    رجوع للخيارات
                </button>
                <SeekerMatchingAgentView isDark={isDark} />
            </div>
        );
    }

    // ── Mode selection screen ──────────────────────────────────────
    return (
        <div className="space-y-4">

            {/* ── Hero Header ─────────────────────────────────── */}
            <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-[#0d1630] via-[#0a1525] to-[#080f1e] border border-cyan-500/20"
            >
                <div className="absolute -top-6 -right-6 w-28 h-28 rounded-full bg-cyan-500/15 blur-2xl pointer-events-none" />
                <div className="absolute -bottom-4 -left-4 w-20 h-20 rounded-full bg-blue-600/10 blur-xl pointer-events-none" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 rounded-full bg-indigo-500/5 blur-3xl pointer-events-none" />

                <div className="relative flex items-center gap-4">
                    <div className="relative shrink-0">
                        <div className="absolute inset-0 rounded-2xl bg-cyan-500/30 blur-md scale-125" />
                        <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-xl shadow-cyan-500/40">
                            <Target className="w-7 h-7 text-white" />
                        </div>
                    </div>
                    <div className="flex-1 text-right">
                        <div className="flex items-center justify-end gap-2 mb-1">
                            <p className="text-sm font-black text-white">مساعد المطابقة AI</p>
                            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                <span className="text-[9px] font-black text-emerald-400">LIVE</span>
                            </div>
                        </div>
                        <p className="text-[11px] text-white/45">مدعوم بالذكاء الاصطناعي — اختر وضع الاستخدام</p>
                    </div>
                </div>

                <div className="relative grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-white/8">
                    {[
                        { num: '23', label: 'باحث متاح', color: 'text-cyan-400' },
                        { num: '8', label: 'عرض جاهز', color: 'text-emerald-400' },
                        { num: '94%', label: 'دقة التطابق', color: 'text-amber-400' },
                    ].map((s, i) => (
                        <div key={i} className="text-center">
                            <p className={`text-lg font-black ${s.color}`}>{s.num}</p>
                            <p className="text-[9px] text-white/35">{s.label}</p>
                        </div>
                    ))}
                </div>
            </motion.div>

            {/* ── Section divider ─────────────────────────────── */}
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.15 }}
                className="flex items-center gap-3"
            >
                <div className={`flex-1 h-px ${isDark ? 'bg-white/8' : 'bg-gray-200'}`} />
                <span className={`text-[10px] font-black tracking-widest ${isDark ? 'text-white/25' : 'text-gray-400'}`}>اختر الخدمة</span>
                <div className={`flex-1 h-px ${isDark ? 'bg-white/8' : 'bg-gray-200'}`} />
            </motion.div>

            {/* ── Card 1: Marketing ───────────────────────────── */}
            <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, type: 'spring', stiffness: 220, damping: 24 }}
                whileHover={{ scale: 1.015, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setMode('marketing')}
                className={`w-full rounded-3xl border text-right transition-all relative overflow-hidden group ${
                    isDark
                        ? 'bg-gradient-to-br from-blue-950/90 via-[#080f25] to-cyan-950/70 border-blue-500/30 hover:border-cyan-400/60'
                        : 'bg-gradient-to-br from-blue-50 via-sky-50 to-cyan-50 border-blue-200 hover:border-blue-400 shadow-sm hover:shadow-md'
                }`}
            >
                {/* Glow top line */}
                <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent" />
                {/* BG orb */}
                <div className="absolute -bottom-10 -left-10 w-36 h-36 rounded-full bg-blue-500/8 blur-2xl pointer-events-none group-hover:bg-blue-400/15 transition-colors duration-700" />

                <div className="relative p-5">
                    {/* Live badge */}
                    <div className="absolute top-4 left-4 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span className={`text-[9px] font-black ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>23 باحث جاهز</span>
                    </div>

                    {/* Icon + heading */}
                    <div className="flex items-center gap-3 mb-4 mt-1">
                        <div className="relative shrink-0">
                            <div className="absolute inset-0 rounded-2xl bg-blue-500/20 blur-md scale-110" />
                            <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/40">
                                <Target className="w-6 h-6 text-white" />
                            </div>
                        </div>
                        <div className="flex-1 text-right">
                            <p className={`font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>إيجاد مطابقين لمشروعك</p>
                            <p className={`text-[10px] mt-0.5 ${isDark ? 'text-cyan-400/70' : 'text-blue-600'}`}>تسويق ذكي · مباشر · فوري</p>
                        </div>
                    </div>

                    {/* Description */}
                    <p className={`text-[11px] leading-6 mb-4 text-right ${isDark ? 'text-white/55' : 'text-gray-600'}`}>
                        اختر مشروعك وسيقوم الذكاء الاصطناعي تلقائياً بتحليل قاعدة الباحثين وإيجاد الأكثر تطابقاً وإرسال عروضك لهم مباشرةً
                    </p>

                    {/* Stats row */}
                    <div className={`grid grid-cols-3 gap-2 mb-4 p-3 rounded-2xl ${isDark ? 'bg-white/5 border border-white/5' : 'bg-white/80 border border-blue-100'}`}>
                        {[
                            { v: '23', l: 'مشتري جاهز', c: isDark ? 'text-blue-400' : 'text-blue-600' },
                            { v: '8', l: 'طلب زيارة', c: isDark ? 'text-emerald-400' : 'text-emerald-600' },
                            { v: '5', l: 'في التفاوض', c: isDark ? 'text-amber-400' : 'text-amber-600' },
                        ].map((s, i) => (
                            <div key={i} className="text-center">
                                <p className={`text-base font-black ${s.c}`}>{s.v}</p>
                                <p className={`text-[8px] ${isDark ? 'text-white/30' : 'text-gray-400'}`}>{s.l}</p>
                            </div>
                        ))}
                    </div>

                    {/* Footer: tags + arrow */}
                    <div className="flex items-center justify-between">
                        <div className={`flex items-center justify-center w-9 h-9 rounded-xl transition-all duration-300 ${isDark ? 'bg-cyan-500/15 text-cyan-400 group-hover:bg-cyan-500/30' : 'bg-blue-100 text-blue-600 group-hover:bg-blue-200'}`}>
                            <ChevronRight className="w-4 h-4 rotate-180" />
                        </div>
                        <div className="flex items-center gap-1.5 flex-wrap justify-end">
                            {['مشاريعك', 'باحثون مطابقون', 'إرسال عروض'].map((tag, i) => (
                                <span key={i} className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isDark ? 'bg-blue-500/15 text-blue-300 border border-blue-500/20' : 'bg-blue-100 text-blue-700'}`}>{tag}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </motion.button>

            {/* ── Card 2: Search ──────────────────────────────── */}
            <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.32, type: 'spring', stiffness: 220, damping: 24 }}
                whileHover={{ scale: 1.015, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setMode('search')}
                className={`w-full rounded-3xl border text-right transition-all relative overflow-hidden group ${
                    isDark
                        ? 'bg-gradient-to-br from-purple-950/90 via-[#10082a] to-pink-950/70 border-purple-500/30 hover:border-purple-400/60'
                        : 'bg-gradient-to-br from-violet-50 via-purple-50 to-pink-50 border-purple-200 hover:border-purple-400 shadow-sm hover:shadow-md'
                }`}
            >
                {/* Glow top line */}
                <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-400/60 to-transparent" />
                {/* BG orb */}
                <div className="absolute -bottom-10 -left-10 w-36 h-36 rounded-full bg-purple-500/8 blur-2xl pointer-events-none group-hover:bg-purple-400/15 transition-colors duration-700" />

                <div className="relative p-5">
                    {/* Icon + heading */}
                    <div className="flex items-center gap-3 mb-4">
                        <div className="relative shrink-0">
                            <div className="absolute inset-0 rounded-2xl bg-purple-500/20 blur-md scale-110" />
                            <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/40">
                                <Sparkles className="w-6 h-6 text-white" />
                            </div>
                        </div>
                        <div className="flex-1 text-right">
                            <p className={`font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>البحث عن عقار لنفسك</p>
                            <p className={`text-[10px] mt-0.5 ${isDark ? 'text-purple-400/70' : 'text-purple-600'}`}>بحث ذكي · بالكلام الطبيعي</p>
                        </div>
                    </div>

                    {/* Description */}
                    <p className={`text-[11px] leading-6 mb-4 text-right ${isDark ? 'text-white/55' : 'text-gray-600'}`}>
                        أضف رغبتك بالكلام الطبيعي كأنك تتكلم مع وسيطك، وسيجد الذكاء الاصطناعي أفضل العقارات المطابقة لاحتياجاتك الشخصية
                    </p>

                    {/* Animated typing hint */}
                    <div className={`flex items-center gap-3 mb-4 px-3.5 py-3 rounded-2xl border ${isDark ? 'bg-white/4 border-white/8' : 'bg-white border-gray-200'}`}>
                        <div className="flex gap-0.5 items-end shrink-0 pb-0.5">
                            {[3, 5, 3].map((h, i) => (
                                <motion.div
                                    key={i}
                                    animate={{ scaleY: [1, 1.9, 1] }}
                                    transition={{ duration: 0.85, repeat: Infinity, delay: i * 0.2, ease: 'easeInOut' }}
                                    className={`w-1 rounded-full ${isDark ? 'bg-purple-400' : 'bg-purple-500'}`}
                                    style={{ height: `${h}px`, transformOrigin: 'bottom' }}
                                />
                            ))}
                        </div>
                        <p className={`text-[10px] italic flex-1 text-right ${isDark ? 'text-white/22' : 'text-gray-400'}`}>
                            "ابي شقة 3 غرف في حي النرجس، الدور الثاني، تقبل البنك ..."
                        </p>
                    </div>

                    {/* Footer: tags + arrow */}
                    <div className="flex items-center justify-between">
                        <div className={`flex items-center justify-center w-9 h-9 rounded-xl transition-all duration-300 ${isDark ? 'bg-purple-500/15 text-purple-400 group-hover:bg-purple-500/30' : 'bg-purple-100 text-purple-600 group-hover:bg-purple-200'}`}>
                            <ChevronRight className="w-4 h-4 rotate-180" />
                        </div>
                        <div className="flex items-center gap-1.5 flex-wrap justify-end">
                            {['رغبتك بالكلام', 'بحث ذكي', 'عروض مطابقة'].map((tag, i) => (
                                <span key={i} className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isDark ? 'bg-purple-500/15 text-purple-300 border border-purple-500/20' : 'bg-purple-100 text-purple-700'}`}>{tag}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </motion.button>
        </div>
    );
}

// ── Marketing content (original DeveloperMatchingAgentView logic) ────
function DeveloperMarketingContent({ isDark }: { isDark: boolean }) {
    const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [showResults, setShowResults] = useState(false);

    const projects = [
        { id: 'villa', label: 'مشروع النخيل', type: 'فيلا سكنية', price: '2.5M', units: 12, accentDark: 'from-amber-900/30 to-orange-900/20 border-amber-500/30', accentLight: 'from-amber-50 to-orange-50 border-amber-200', iconColor: 'text-amber-400', dotColor: 'bg-amber-500', buyers: 23 },
        { id: 'apt', label: 'أبراج العليا', type: 'شقة فاخرة', price: '1.8M', units: 48, accentDark: 'from-blue-900/30 to-indigo-900/20 border-blue-500/30', accentLight: 'from-blue-50 to-indigo-50 border-blue-200', iconColor: 'text-blue-400', dotColor: 'bg-blue-500', buyers: 15 },
        { id: 'town', label: 'الفرسان بارك', type: 'تاون هاوس', price: '3.1M', units: 8, accentDark: 'from-emerald-900/30 to-teal-900/20 border-emerald-500/30', accentLight: 'from-emerald-50 to-teal-50 border-emerald-200', iconColor: 'text-emerald-400', dotColor: 'bg-emerald-500', buyers: 9 },
    ];

    const handleSelect = (id: string) => {
        if (selectedProjectId === id && showResults) return;
        setSelectedProjectId(id);
        setShowResults(false);
        setIsLoading(true);
        setTimeout(() => { setIsLoading(false); setShowResults(true); }, 2300);
    };

    const selected = projects.find(p => p.id === selectedProjectId);

    const buyerSets: Record<string, any[]> = {
        villa: [
            { name: "أحمد المنصور", match: 97, budget: "2.5M", need: "فيلا", status: "جاهز للدفع", statusColor: "emerald", avatar: "أ" },
            { name: "محمد السبيعي", match: 94, budget: "2.2M", need: "فيلا دوبلكس", status: "يطلب زيارة", statusColor: "blue", avatar: "م" },
            { name: "سارة العتيبي", match: 91, budget: "3.2M", need: "فيلا كبيرة", status: "في التفاوض", statusColor: "amber", avatar: "س" },
            { name: "نواف الشمري", match: 88, budget: "2.0M", need: "فيلا مودرن", status: "تمت المطابقة", statusColor: "purple", avatar: "ن" },
            { name: "لمياء القحطاني", match: 85, budget: "2.1M", need: "فيلا مع مسبح", status: "يراجع العروض", statusColor: "cyan", avatar: "ل" },
        ],
        apt: [
            { name: "فهد الدوسري", match: 96, budget: "1.8M", need: "شقة 3 غرف", status: "جاهز للدفع", statusColor: "emerald", avatar: "ف" },
            { name: "نورة السالم", match: 90, budget: "1.5M", need: "شقة فاخرة", status: "يطلب زيارة", statusColor: "blue", avatar: "ن" },
            { name: "عبدالله الغامدي", match: 87, budget: "2.0M", need: "بنتهاوس", status: "في التفاوض", statusColor: "amber", avatar: "ع" },
        ],
        town: [
            { name: "خالد المطيري", match: 95, budget: "3.5M", need: "تاون هاوس", status: "جاهز للدفع", statusColor: "emerald", avatar: "خ" },
            { name: "ريم الشهري", match: 88, budget: "3.0M", need: "تاون هاوس راقي", status: "يطلب زيارة", statusColor: "blue", avatar: "ر" },
        ],
    };

    const buyers = selectedProjectId ? (buyerSets[selectedProjectId] || []) : [];

    const statusColorMap: any = {
        emerald: isDark ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" : "bg-emerald-100 text-emerald-700 border-emerald-200",
        blue: isDark ? "bg-blue-500/20 text-blue-400 border-blue-500/30" : "bg-blue-100 text-blue-700 border-blue-200",
        amber: isDark ? "bg-amber-500/20 text-amber-400 border-amber-500/30" : "bg-amber-100 text-amber-700 border-amber-200",
        purple: isDark ? "bg-purple-500/20 text-purple-400 border-purple-500/30" : "bg-purple-100 text-purple-700 border-purple-200",
        cyan: isDark ? "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" : "bg-cyan-100 text-cyan-700 border-cyan-200",
    };

    const avgMatch = buyers.length > 0 ? Math.round(buyers.reduce((s, b) => s + b.match, 0) / buyers.length) : 0;

    return (
        <div className="space-y-5">
            {/* ── Step 1: Select Project ── */}
            <div>
                <div className="flex items-center gap-2 mb-3">
                    <div className="w-5 h-5 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white text-[9px] font-black shrink-0">١</div>
                    <h4 className={`text-xs font-black ${isDark ? 'text-white/70' : 'text-gray-600'}`}>اختر المشروع الذي تريد مطابقته</h4>
                </div>
                <div className="space-y-2.5">
                    {projects.map((p) => {
                        const isActive = selectedProjectId === p.id;
                        return (
                            <motion.button
                                key={p.id}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => handleSelect(p.id)}
                                className={`w-full p-4 rounded-2xl border flex items-center gap-3 text-right transition-all ${
                                    isActive
                                        ? `bg-gradient-to-br ${isDark ? p.accentDark : p.accentLight}`
                                        : isDark ? 'bg-[#151a2d] border-white/5 hover:bg-white/5' : 'bg-white border-gray-100 shadow-sm hover:shadow-md'
                                }`}
                            >
                                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${isActive ? isDark ? 'bg-white/10' : 'bg-white/70 shadow-sm' : isDark ? 'bg-white/5' : 'bg-gray-50'}`}>
                                    <Building className={`w-6 h-6 ${isActive ? p.iconColor : isDark ? 'text-white/30' : 'text-gray-300'}`} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-1">
                                        <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{p.label}</p>
                                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${isActive ? isDark ? 'bg-white/15 text-white/60' : 'bg-white/60 text-gray-600' : isDark ? 'bg-white/8 text-white/30' : 'bg-gray-100 text-gray-400'}`}>{p.type}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[10px] font-black text-cyan-400">{p.price} ريال</span>
                                        <span className={`text-[9px] ${isDark ? 'text-white/15' : 'text-gray-200'}`}>•</span>
                                        <span className={`text-[10px] ${isDark ? 'text-white/35' : 'text-gray-400'}`}>{p.units} وحدة</span>
                                        {isActive && showResults && (
                                            <>
                                                <span className={`text-[9px] ${isDark ? 'text-white/15' : 'text-gray-200'}`}>•</span>
                                                <span className="text-[10px] font-black text-emerald-400">{p.buyers} مطابق</span>
                                            </>
                                        )}
                                    </div>
                                </div>
                                {isActive && showResults && (
                                    <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                                )}
                                {isActive && isLoading && (
                                    <div className={`w-3 h-3 rounded-full ${p.dotColor} animate-pulse shrink-0`} />
                                )}
                            </motion.button>
                        );
                    })}
                </div>
            </div>

            {/* ── Loading State ── */}
            <AnimatePresence>
                {isLoading && (
                    <motion.div
                        key="loading"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className={`p-6 rounded-2xl border text-center space-y-3 ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}
                    >
                        <div className="relative mx-auto w-14 h-14 flex items-center justify-center">
                            <div className="absolute inset-0 rounded-full border-2 border-cyan-500/20" />
                            <div className="absolute inset-0 rounded-full border-2 border-t-cyan-500 border-r-transparent border-b-transparent border-l-transparent animate-spin" />
                            <Target className="w-5 h-5 text-cyan-400" />
                        </div>
                        <div>
                            <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>جاري البحث عن الباحثين المطابقين...</p>
                            <p className={`text-[10px] mt-1 ${isDark ? 'text-white/35' : 'text-gray-400'}`}>يتم تحليل طلبات الباحثين ومطابقتها مع مشروع {selected?.label}</p>
                        </div>
                        <div className={`h-1.5 rounded-full overflow-hidden ${isDark ? 'bg-white/5' : 'bg-gray-100'}`}>
                            <motion.div
                                initial={{ width: '0%' }}
                                animate={{ width: '100%' }}
                                transition={{ duration: 2.1, ease: 'linear' }}
                                className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                            />
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* ── Results ── */}
            <AnimatePresence>
                {showResults && selected && (
                    <motion.div key="results" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                        {/* Step 2 Label */}
                        <div className="flex items-center gap-2">
                            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-white text-[9px] font-black shrink-0">٢</div>
                            <h4 className={`text-xs font-black ${isDark ? 'text-white/70' : 'text-gray-600'}`}>الباحثون المطابقون — {selected.label}</h4>
                        </div>

                        {/* Live Stats Card */}
                        <div className={`p-4 rounded-2xl border relative overflow-hidden bg-gradient-to-br ${isDark ? selected.accentDark : selected.accentLight}`}>
                            <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                <span className="text-[9px] font-black text-emerald-400">LIVE</span>
                            </div>
                            <div className="grid grid-cols-3 gap-3 mt-4">
                                <div className="text-center">
                                    <p className={`text-2xl font-black ${selected.iconColor}`}>{buyers.length}</p>
                                    <p className="text-[9px] opacity-50">باحث جاهز</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-2xl font-black text-cyan-400">{Math.floor(buyers.length * 0.4)}</p>
                                    <p className="text-[9px] opacity-50">طلب زيارة</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-2xl font-black text-amber-400">{Math.max(1, Math.floor(buyers.length * 0.2))}</p>
                                    <p className="text-[9px] opacity-50">في التفاوض</p>
                                </div>
                            </div>
                            <div className="mt-3">
                                <div className={`flex justify-between text-[9px] mb-1 ${isDark ? 'text-white/40' : 'text-gray-400'}`}>
                                    <span>متوسط نسبة التطابق</span>
                                    <span>{avgMatch}%</span>
                                </div>
                                <div className={`h-1.5 rounded-full ${isDark ? 'bg-white/10' : 'bg-white/50'}`}>
                                    <motion.div
                                        initial={{ width: '0%' }}
                                        animate={{ width: `${avgMatch}%` }}
                                        transition={{ duration: 1.5, ease: 'easeOut' }}
                                        className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Buyers List */}
                        <div className="space-y-2.5">
                            {buyers.map((buyer, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, x: 20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: i * 0.09 }}
                                    className={`p-3.5 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-black text-white shrink-0">
                                            {buyer.avatar}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center justify-between mb-1">
                                                <p className={`text-xs font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>{buyer.name}</p>
                                                <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${statusColorMap[buyer.statusColor]}`}>{buyer.status}</span>
                                            </div>
                                            <div className="flex items-center gap-2 mb-1.5">
                                                <span className={`text-[9px] ${isDark ? 'text-white/40' : 'text-gray-400'}`}>{buyer.need}</span>
                                                <span className={`text-[9px] ${isDark ? 'text-white/15' : 'text-gray-200'}`}>•</span>
                                                <span className="text-[9px] font-black text-emerald-400">{buyer.budget}</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <div className={`flex-1 h-1 rounded-full ${isDark ? 'bg-white/10' : 'bg-gray-100'}`}>
                                                    <div className="h-full bg-gradient-to-r from-cyan-500 to-blue-400 rounded-full" style={{ width: `${buyer.match}%` }} />
                                                </div>
                                                <span className="text-[9px] font-black text-cyan-400">{buyer.match}%</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex gap-2 mt-3">
                                        <button className={`flex-1 py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 ${isDark ? 'bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30' : 'bg-cyan-50 text-cyan-600 hover:bg-cyan-100'}`}>
                                            <Send className="w-3 h-3" /> إرسال العرض
                                        </button>
                                        <button className={`flex-1 py-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1 ${isDark ? 'bg-white/5 text-white/50 hover:bg-white/10' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}>
                                            <Phone className="w-3 h-3" /> تواصل
                                        </button>
                                    </div>
                                </motion.div>
                            ))}
                        </div>

                        {/* Bulk Send */}
                        <button className="w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25 hover:from-cyan-600 hover:to-blue-700 transition-all">
                            <Send className="w-4 h-4" />
                            إرسال العرض لكل المطابقين ({buyers.length})
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

function SeekerMatchingAgentView({ isDark }: { isDark: boolean }) {
    // ── Wish state ─────────────────────────────────────────────
    const [wishText, setWishText] = useState('');
    const [savedWish, setSavedWish] = useState<string | null>(
        'ابي عمارة دورين تقبل البنك في مدينة الطائف الي الحوية تحديداً في حي رحاب، يكون موقعها مميز وسعرها تحت المليون'
    );
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState('');
    const [isSearching, setIsSearching] = useState(false);
    const [offersVisible, setOffersVisible] = useState(true);
    const [offersTab, setOffersTab] = useState<'matching' | 'other'>('matching');

    // ── Offer match state ───────────────────────────────────────
    const [matchedIds, setMatchedIds] = useState<Set<number>>(new Set());
    const [dismissedIds, setDismissedIds] = useState<Set<number>>(new Set());
    const [reasonInputFor, setReasonInputFor] = useState<number | null>(null);
    const [reasonText, setReasonText] = useState('');
    const [dismissedOther, setDismissedOther] = useState<Set<number>>(new Set());
    const [reasonOtherFor, setReasonOtherFor] = useState<number | null>(null);
    const [reasonOtherText, setReasonOtherText] = useState('');

    const offers = [
        { id: 0, title: 'عمارة دورين - حي الرحاب', location: 'الطائف - حي الرحاب', price: '950,000', match: 97, type: 'عمارة', floors: 2, bank: true, img: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=400&q=80' },
        { id: 1, title: 'عمارة سكنية - الحوية', location: 'الطائف - الحوية', price: '890,000', match: 91, type: 'عمارة', floors: 2, bank: true, img: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=400&q=80' },
        { id: 2, title: 'عمارة تجارية سكنية', location: 'الطائف - الرحاب', price: '980,000', match: 84, type: 'عمارة', floors: 3, bank: false, img: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400&q=80' },
        { id: 3, title: 'دوبلكس مستقل - حي الرحاب', location: 'الطائف - حي الرحاب', price: '750,000', match: 78, type: 'دوبلكس', floors: 2, bank: true, img: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=400&q=80' },
    ];

    const otherOffers = [
        { id: 10, title: 'فيلا دورين - النخيل', location: 'الطائف - النخيل', price: '1,100,000', match: 65, type: 'فيلا', floors: 2, bank: true, aiNote: 'قريب من المنطقة المطلوبة وبنفس المواصفات', img: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&q=80' },
        { id: 11, title: 'عمارة 4 شقق - الشهداء', location: 'الطائف - الشهداء', price: '850,000', match: 60, type: 'عمارة', floors: 2, bank: false, aiNote: 'سعر أقل من الميزانية وموقع مميز', img: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400&q=80' },
        { id: 12, title: 'عمارة سكنية - البساتين', location: 'الطائف - البساتين', price: '1,050,000', match: 55, type: 'عمارة', floors: 3, bank: true, aiNote: 'فوق الميزانية قليلاً لكن موقع استراتيجي', img: 'https://images.unsplash.com/photo-1523217582562-09d0def993a6?w=400&q=80' },
    ];

    const visibleOffers = offers.filter(o => !dismissedIds.has(o.id));
    const visibleOtherOffers = otherOffers.filter(o => !dismissedOther.has(o.id));

    const handleSaveWish = () => {
        if (!wishText.trim()) return;
        setSavedWish(wishText.trim());
        setWishText('');
        setIsSearching(true);
        setMatchedIds(new Set());
        setDismissedIds(new Set());
        setDismissedOther(new Set());
        setReasonInputFor(null);
        setTimeout(() => { setIsSearching(false); setOffersVisible(true); }, 2200);
    };

    const handleEditStart = () => { setEditText(savedWish || ''); setIsEditing(true); };

    const handleEditSave = () => {
        if (!editText.trim()) return;
        setSavedWish(editText.trim());
        setIsEditing(false);
        setIsSearching(true);
        setOffersVisible(false);
        setMatchedIds(new Set());
        setDismissedIds(new Set());
        setDismissedOther(new Set());
        setReasonInputFor(null);
        setTimeout(() => { setIsSearching(false); setOffersVisible(true); }, 2000);
    };

    const handleDelete = () => {
        setSavedWish(null);
        setOffersVisible(false);
        setMatchedIds(new Set());
        setDismissedIds(new Set());
        setDismissedOther(new Set());
        setReasonInputFor(null);
    };

    const handleToggleMatched = (id: number) => {
        setMatchedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    };

    const handleNotMatchingClick = (id: number) => {
        setReasonInputFor(prev => (prev === id ? null : id));
        setReasonText('');
    };

    const handleSubmitReason = (id: number) => {
        setDismissedIds(prev => new Set([...prev, id]));
        setReasonInputFor(null);
        setReasonText('');
    };

    const handleOtherNotMatchingClick = (id: number) => {
        setReasonOtherFor(prev => (prev === id ? null : id));
        setReasonOtherText('');
    };

    const handleSubmitOtherReason = (id: number) => {
        setDismissedOther(prev => new Set([...prev, id]));
        setReasonOtherFor(null);
        setReasonOtherText('');
    };

    const matchedCount = matchedIds.size;
    const dismissedCount = dismissedIds.size;

    return (
        <div className="space-y-5">
            {/* ── Header ─────────────────────────────────────── */}
            <div className={`p-4 rounded-2xl border flex items-center gap-3 ${isDark ? 'bg-gradient-to-br from-emerald-900/20 to-teal-900/20 border-emerald-500/25' : 'bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200'}`}>
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/30 shrink-0">
                    <Target className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                    <p className={`text-sm font-black ${isDark ? 'text-white' : 'text-gray-900'}`}>مساعد المطابقة</p>
                    <p className={`text-[10px] mt-0.5 ${isDark ? 'text-white/50' : 'text-gray-500'}`}>أضف رغبتك بالكلام الطبيعي ونجيبلك أفضل العروض</p>
                </div>
                {offersVisible && !isSearching && (
                    <div className={`text-[9px] font-black px-2 py-1 rounded-lg ${isDark ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-700'}`}>
                        {offers.length} عروض
                    </div>
                )}
            </div>

            {/* ── Wish Input (if no saved wish) ──────────────── */}
            {!savedWish && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                    className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-white/8' : 'bg-white border-gray-100 shadow-sm'}`}>
                    <p className={`text-xs font-black mb-3 flex items-center gap-2 ${isDark ? 'text-white/70' : 'text-gray-700'}`}>
                        <Edit3 className="w-3.5 h-3.5 text-emerald-400" /> أضف رغبتك
                    </p>
                    <textarea
                        value={wishText}
                        onChange={e => setWishText(e.target.value)}
                        rows={4}
                        placeholder={"مثال: ابي عمارة دورين تقبل البنك في مدينة الطائف الي الحوية تحديداً في حي رحاب، يكون موقعها مميز وسعرها تحت المليون..."}
                        className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none resize-none leading-6 ${isDark ? 'bg-white/5 border-white/10 text-white placeholder-white/25' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'}`}
                        style={{ direction: 'rtl' }}
                    />
                    <button
                        onClick={handleSaveWish}
                        disabled={!wishText.trim()}
                        className={`mt-3 w-full py-3 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${wishText.trim() ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/20 hover:scale-[0.98]' : 'opacity-40 cursor-not-allowed ' + (isDark ? 'bg-white/5 text-white/20' : 'bg-gray-200 text-gray-400')}`}>
                        <CheckCircle className="w-4 h-4" /> حفظ الرغبة وبدء البحث
                    </button>
                </motion.div>
            )}

            {/* ── Saved Wish Card ─────────────────────────────── */}
            {savedWish && !isEditing && (
                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                    className={`p-4 rounded-2xl border ${isDark ? 'bg-gradient-to-br from-emerald-900/15 to-teal-900/15 border-emerald-500/20' : 'bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200'}`}>
                    <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-2">
                            <div className={`w-7 h-7 rounded-xl flex items-center justify-center ${isDark ? 'bg-emerald-500/20' : 'bg-emerald-100'}`}>
                                <Heart className="w-3.5 h-3.5 text-emerald-500" fill="currentColor" />
                            </div>
                            <span className={`text-xs font-black ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>رغبتي المحفوظة</span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                            <button onClick={handleEditStart}
                                className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${isDark ? 'bg-white/8 hover:bg-white/15 text-white/50 hover:text-white' : 'bg-white hover:bg-gray-100 text-gray-400 hover:text-gray-700 shadow-sm'}`}>
                                <Edit3 className="w-3 h-3" />
                            </button>
                            <button onClick={handleDelete}
                                className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${isDark ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400' : 'bg-red-50 hover:bg-red-100 text-red-500'}`}>
                                <Trash2 className="w-3 h-3" />
                            </button>
                        </div>
                    </div>
                    <p className={`text-[11px] leading-6 ${isDark ? 'text-white/80' : 'text-gray-700'}`} style={{ direction: 'rtl' }}>
                        {savedWish}
                    </p>
                    <div className="flex flex-wrap gap-1.5 mt-3">
                        {['عمارة', 'دورين', 'الطائف', 'الحوية', 'حي الرحاب', 'تقبل البنك', 'تحت المليون'].map((tag, i) => (
                            <span key={i} className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isDark ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' : 'bg-emerald-100 text-emerald-700'}`}>
                                {tag}
                            </span>
                        ))}
                    </div>
                </motion.div>
            )}

            {/* ── Edit Mode ────────────────────────────────────── */}
            {isEditing && (
                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                    className={`p-4 rounded-2xl border ${isDark ? 'bg-[#151a2d] border-emerald-500/30' : 'bg-white border-emerald-200 shadow-sm'}`}>
                    <p className={`text-xs font-black mb-3 flex items-center gap-2 ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>
                        <Edit3 className="w-3.5 h-3.5" /> تعديل الرغبة
                    </p>
                    <textarea
                        value={editText}
                        onChange={e => setEditText(e.target.value)}
                        rows={4}
                        autoFocus
                        className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none resize-none leading-6 ${isDark ? 'bg-white/5 border-emerald-500/25 text-white' : 'bg-gray-50 border-emerald-300 text-gray-900'}`}
                        style={{ direction: 'rtl' }}
                    />
                    <div className="flex gap-2 mt-3">
                        <button onClick={handleEditSave}
                            className="flex-1 py-2.5 rounded-xl font-black text-xs bg-emerald-500 text-white hover:bg-emerald-600 transition-colors flex items-center justify-center gap-1.5">
                            <CheckCircle className="w-3.5 h-3.5" /> حفظ التعديل
                        </button>
                        <button onClick={() => setIsEditing(false)}
                            className={`px-4 py-2.5 rounded-xl font-black text-xs ${isDark ? 'bg-white/8 text-white/50 hover:bg-white/15' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
                            إلغاء
                        </button>
                    </div>
                </motion.div>
            )}

            {/* ── Searching Indicator ──────────────────────────── */}
            {isSearching && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    className={`p-5 rounded-2xl border text-center ${isDark ? 'bg-[#151a2d] border-white/5' : 'bg-white border-gray-100 shadow-sm'}`}>
                    <div className="flex items-center justify-center gap-2 mb-3">
                        {[0, 1, 2].map(i => (
                            <motion.div key={i} animate={{ scale: [1, 1.4, 1] }} transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.2 }}
                                className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                        ))}
                    </div>
                    <p className={`text-xs font-black ${isDark ? 'text-white/70' : 'text-gray-700'}`}>المساعد يحلل رغبتك...</p>
                    <p className={`text-[9px] mt-1 ${isDark ? 'text-white/30' : 'text-gray-400'}`}>يبحث في آلاف العقارات ويرتبها حسب درجة التطابق</p>
                </motion.div>
            )}

            {/* ── Offers Section ───────────────────────────────── */}
            {offersVisible && !isSearching && savedWish && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">

                    {/* ── Tab Switcher ── */}
                    <div className={`flex gap-1 p-1 rounded-2xl ${isDark ? 'bg-white/5' : 'bg-gray-100'}`}>
                        <button
                            onClick={() => setOffersTab('matching')}
                            className={`flex-1 py-2.5 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                                offersTab === 'matching'
                                    ? isDark ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 shadow-md' : 'bg-white text-emerald-700 shadow-sm border border-emerald-200'
                                    : isDark ? 'text-white/40 hover:text-white/60' : 'text-gray-400 hover:text-gray-600'
                            }`}
                        >
                            <Sparkles className="w-3.5 h-3.5" />
                            العروض المطابقة ({visibleOffers.length})
                        </button>
                        <button
                            onClick={() => setOffersTab('other')}
                            className={`flex-1 py-2.5 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                                offersTab === 'other'
                                    ? isDark ? 'bg-purple-500/30 text-purple-300 border border-purple-500/40 shadow-md' : 'bg-white text-purple-700 shadow-sm border border-purple-200'
                                    : isDark ? 'text-white/40 hover:text-white/60' : 'text-gray-400 hover:text-gray-600'
                            }`}
                        >
                            <Zap className="w-3.5 h-3.5" />
                            عروض أخرى ({visibleOtherOffers.length})
                        </button>
                    </div>

                    {/* ── MATCHING OFFERS TAB ── */}
                    {offersTab === 'matching' && (
                        <div className="space-y-3">
                            {/* Section Header */}
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <Target className="w-4 h-4 text-emerald-400" />
                                    <span className={`text-xs font-black ${isDark ? 'text-white/70' : 'text-gray-700'}`}>
                                        العروض المطابقة لرغبتك
                                    </span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                    {matchedCount > 0 && (
                                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isDark ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-700'}`}>
                                            ✓ {matchedCount} مطابق
                                        </span>
                                    )}
                                    {dismissedCount > 0 && (
                                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${isDark ? 'bg-red-500/15 text-red-400' : 'bg-red-50 text-red-600'}`}>
                                            ✕ {dismissedCount} تم إخفاؤه
                                        </span>
                                    )}
                                </div>
                            </div>

                            <AnimatePresence>
                                {visibleOffers.map((offer, i) => {
                                    const isMatched = matchedIds.has(offer.id);
                                    const showingReason = reasonInputFor === offer.id;
                                    return (
                                        <motion.div key={offer.id}
                                            layout
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, scale: 0.95, height: 0 }}
                                            transition={{ delay: i * 0.06, layout: { duration: 0.3 } }}
                                            className={`rounded-2xl border overflow-hidden transition-all ${
                                                isMatched
                                                    ? isDark ? 'border-emerald-500/40 bg-emerald-900/10' : 'border-emerald-300 bg-emerald-50/60'
                                                    : isDark ? 'border-white/5 bg-[#151a2d]' : 'border-gray-100 bg-white shadow-sm'
                                            }`}>
                                            {/* Image Strip */}
                                            <div className="relative h-24 overflow-hidden">
                                                <img src={offer.img} alt={offer.title} className="w-full h-full object-cover" />
                                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                                                <div className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-[9px] font-black ${offer.match >= 90 ? 'bg-emerald-500 text-white' : offer.match >= 80 ? 'bg-amber-500 text-white' : 'bg-gray-500/80 text-white'}`}>
                                                    {offer.match}% تطابق
                                                </div>
                                                <div className={`absolute top-2 left-2 px-2 py-0.5 rounded-full text-[9px] font-bold ${isDark ? 'bg-black/50 text-white/80' : 'bg-white/90 text-gray-700'}`}>
                                                    {offer.type}
                                                </div>
                                                <div className="absolute bottom-2 right-2">
                                                    <p className="text-white font-black text-xs drop-shadow">{offer.title}</p>
                                                    <p className="text-white/70 text-[10px] flex items-center gap-0.5">
                                                        <MapPin className="w-2.5 h-2.5" /> {offer.location}
                                                    </p>
                                                </div>
                                                {isMatched && (
                                                    <div className="absolute inset-0 bg-emerald-500/10 flex items-center justify-center">
                                                        <div className="bg-emerald-500 text-white text-[10px] font-black px-3 py-1.5 rounded-full flex items-center gap-1 shadow-lg">
                                                            <CheckCircle className="w-3.5 h-3.5" /> مطابق
                                                        </div>
                                                    </div>
                                                )}
                                            </div>

                                            {/* Content */}
                                            <div className="p-3">
                                                <div className="flex items-center justify-between mb-2">
                                                    <span className={`font-black text-sm ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>{offer.price} ﷼</span>
                                                    <div className="flex items-center gap-1.5">
                                                        {offer.bank && (
                                                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${isDark ? 'bg-blue-500/15 text-blue-400 border border-blue-500/20' : 'bg-blue-50 text-blue-600 border border-blue-200'}`}>
                                                                ✓ يقبل البنك
                                                            </span>
                                                        )}
                                                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${isDark ? 'bg-white/8 text-white/50' : 'bg-gray-100 text-gray-500'}`}>
                                                            {offer.floors} أدوار
                                                        </span>
                                                    </div>
                                                </div>

                                                {/* Match / Not Match Buttons */}
                                                <div className="grid grid-cols-2 gap-2">
                                                    <button
                                                        onClick={() => handleToggleMatched(offer.id)}
                                                        className={`py-2 rounded-xl text-[10px] font-black flex items-center justify-center gap-1.5 transition-all ${
                                                            isMatched
                                                                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/25'
                                                                : isDark
                                                                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/25'
                                                                    : 'bg-emerald-50 text-emerald-600 border border-emerald-200 hover:bg-emerald-100'
                                                        }`}>
                                                        <CheckCircle className="w-3.5 h-3.5" />
                                                        مطابق
                                                    </button>
                                                    <button
                                                        onClick={() => handleNotMatchingClick(offer.id)}
                                                        className={`py-2 rounded-xl text-[10px] font-black flex items-center justify-center gap-1.5 transition-all ${
                                                            showingReason
                                                                ? isDark ? 'bg-red-500/30 text-red-400 border border-red-500/30' : 'bg-red-100 text-red-600 border border-red-300'
                                                                : isDark
                                                                    ? 'bg-white/5 text-white/40 border border-white/10 hover:bg-white/10'
                                                                    : 'bg-gray-50 text-gray-400 border border-gray-200 hover:bg-gray-100'
                                                        }`}>
                                                        <X className="w-3.5 h-3.5" />
                                                        غير مطابق
                                                    </button>
                                                </div>

                                                {/* Reason Input */}
                                                <AnimatePresence>
                                                    {showingReason && (
                                                        <motion.div
                                                            initial={{ opacity: 0, height: 0 }}
                                                            animate={{ opacity: 1, height: 'auto' }}
                                                            exit={{ opacity: 0, height: 0 }}
                                                            className="overflow-hidden"
                                                        >
                                                            <div className={`mt-2 p-3 rounded-xl border ${isDark ? 'bg-red-900/10 border-red-500/20' : 'bg-red-50 border-red-200'}`}>
                                                                <p className={`text-[9px] font-black mb-2 flex items-center gap-1 ${isDark ? 'text-red-400' : 'text-red-600'}`}>
                                                                    <AlertTriangle className="w-3 h-3" /> ما سبب عدم المطابقة؟
                                                                </p>
                                                                <input
                                                                    type="text"
                                                                    value={reasonText}
                                                                    onChange={e => setReasonText(e.target.value)}
                                                                    onKeyDown={e => e.key === 'Enter' && reasonText.trim() && handleSubmitReason(offer.id)}
                                                                    placeholder="مثال: الموقع بعيد، السعر مرتفع..."
                                                                    autoFocus
                                                                    className={`w-full px-3 py-2 rounded-xl text-xs border outline-none mb-2 ${isDark ? 'bg-white/5 border-red-500/20 text-white placeholder-white/30' : 'bg-white border-red-200 text-gray-900 placeholder-gray-400'}`}
                                                                    style={{ direction: 'rtl' }}
                                                                />
                                                                <div className="flex gap-2">
                                                                    <button
                                                                        onClick={() => handleSubmitReason(offer.id)}
                                                                        disabled={!reasonText.trim()}
                                                                        className={`flex-1 py-1.5 rounded-xl text-[10px] font-black transition-all ${reasonText.trim() ? 'bg-red-500 text-white hover:bg-red-600' : 'opacity-40 cursor-not-allowed ' + (isDark ? 'bg-white/5 text-white/20' : 'bg-gray-200 text-gray-400')}`}>
                                                                        تأكيد وإخفاء العرض
                                                                    </button>
                                                                    <button
                                                                        onClick={() => setReasonInputFor(null)}
                                                                        className={`px-3 py-1.5 rounded-xl text-[10px] font-bold ${isDark ? 'bg-white/5 text-white/40 hover:bg-white/10' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}>
                                                                        إلغاء
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </motion.div>
                                                    )}
                                                </AnimatePresence>
                                            </div>
                                        </motion.div>
                                    );
                                })}
                            </AnimatePresence>

                            {visibleOffers.length === 0 && (
                                <div className={`p-8 rounded-2xl text-center border border-dashed ${isDark ? 'border-white/10' : 'border-gray-200'}`}>
                                    <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-400" />
                                    <p className={`text-xs font-bold ${isDark ? 'text-white/40' : 'text-gray-400'}`}>لا توجد عروض مطابقة متبقية</p>
                                    <p className={`text-[10px] mt-1 ${isDark ? 'text-white/25' : 'text-gray-300'}`}>جرب تعديل رغبتك أو استعرض "عروض أخرى"</p>
                                </div>
                            )}

                            {/* AI Learning Note */}
                            {(matchedCount + dismissedCount) >= 2 && (
                                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                                    className={`p-3 rounded-xl border flex items-start gap-2.5 ${isDark ? 'bg-purple-900/15 border-purple-500/20' : 'bg-purple-50 border-purple-200'}`}>
                                    <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
                                    <p className={`text-[10px] leading-5 ${isDark ? 'text-purple-300/80' : 'text-purple-700'}`}>
                                        المساعد يتعلم من ردودك — سيحسّن نتائجه في المرة القادمة بناءً على اختياراتك
                                    </p>
                                </motion.div>
                            )}
                        </div>
                    )}

                    {/* ── OTHER OFFERS TAB (AI Recommendations) ── */}
                    {offersTab === 'other' && (
                        <div className="space-y-3">
                            {/* Header */}
                            <div className={`flex items-center gap-2 p-3 rounded-xl border ${isDark ? 'bg-purple-500/10 border-purple-500/20' : 'bg-purple-50 border-purple-200'}`}>
                                <Zap className="w-4 h-4 text-purple-400 shrink-0 animate-pulse" />
                                <p className={`text-[10px] ${isDark ? 'text-purple-300' : 'text-purple-700'}`}>
                                    <span className="font-black">توصيات الذكاء الاصطناعي</span> — عروض قريبة من رغبتك وليست مطابقة تماماً
                                </p>
                            </div>

                            <AnimatePresence>
                                {visibleOtherOffers.map((offer, i) => {
                                    const showingReason = reasonOtherFor === offer.id;
                                    return (
                                        <motion.div key={offer.id}
                                            layout
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, scale: 0.95, height: 0 }}
                                            transition={{ delay: i * 0.07, layout: { duration: 0.3 } }}
                                            className={`rounded-2xl border overflow-hidden ${isDark ? 'border-purple-500/15 bg-[#151a2d]' : 'border-purple-100 bg-white shadow-sm'}`}
                                        >
                                            {/* Image Strip */}
                                            <div className="relative h-24 overflow-hidden">
                                                <img src={offer.img} alt={offer.title} className="w-full h-full object-cover" />
                                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                                                <div className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-[9px] font-black bg-purple-500/80 text-white`}>
                                                    {offer.match}% قريب
                                                </div>
                                                <div className={`absolute top-2 left-2 px-2 py-0.5 rounded-full text-[9px] font-bold bg-black/50 text-white/80`}>
                                                    🤖 AI
                                                </div>
                                                <div className="absolute bottom-2 right-2">
                                                    <p className="text-white font-black text-xs drop-shadow">{offer.title}</p>
                                                    <p className="text-white/70 text-[10px] flex items-center gap-0.5">
                                                        <MapPin className="w-2.5 h-2.5" /> {offer.location}
                                                    </p>
                                                </div>
                                            </div>

                                            {/* Content */}
                                            <div className="p-3">
                                                {/* AI Note */}
                                                <div className={`flex items-start gap-1.5 mb-2 p-2 rounded-lg ${isDark ? 'bg-purple-500/10' : 'bg-purple-50'}`}>
                                                    <Sparkles className="w-3 h-3 text-purple-400 shrink-0 mt-0.5" />
                                                    <p className={`text-[9px] leading-4 ${isDark ? 'text-purple-300' : 'text-purple-700'}`}>{offer.aiNote}</p>
                                                </div>

                                                <div className="flex items-center justify-between mb-2">
                                                    <span className={`font-black text-sm ${isDark ? 'text-purple-400' : 'text-purple-600'}`}>{offer.price} ﷼</span>
                                                    <div className="flex items-center gap-1.5">
                                                        {offer.bank && (
                                                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${isDark ? 'bg-blue-500/15 text-blue-400 border border-blue-500/20' : 'bg-blue-50 text-blue-600 border border-blue-200'}`}>
                                                                ✓ يقبل البنك
                                                            </span>
                                                        )}
                                                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${isDark ? 'bg-white/8 text-white/50' : 'bg-gray-100 text-gray-500'}`}>
                                                            {offer.floors} أدوار
                                                        </span>
                                                    </div>
                                                </div>

                                                {/* Action Buttons */}
                                                <div className="grid grid-cols-2 gap-2">
                                                    <button className={`py-2 rounded-xl text-[10px] font-black flex items-center justify-center gap-1.5 transition-all ${isDark ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30 hover:bg-purple-500/30' : 'bg-purple-50 text-purple-700 border border-purple-200 hover:bg-purple-100'}`}>
                                                        <Eye className="w-3.5 h-3.5" />
                                                        عرض التفاصيل
                                                    </button>
                                                    <button
                                                        onClick={() => handleOtherNotMatchingClick(offer.id)}
                                                        className={`py-2 rounded-xl text-[10px] font-black flex items-center justify-center gap-1.5 transition-all ${
                                                            showingReason
                                                                ? isDark ? 'bg-red-500/30 text-red-400 border border-red-500/30' : 'bg-red-100 text-red-600 border border-red-300'
                                                                : isDark ? 'bg-white/5 text-white/40 border border-white/10 hover:bg-white/10' : 'bg-gray-50 text-gray-400 border border-gray-200 hover:bg-gray-100'
                                                        }`}>
                                                        <X className="w-3.5 h-3.5" />
                                                        غير مناسب
                                                    </button>
                                                </div>

                                                {/* Reason Input for Other Offers */}
                                                <AnimatePresence>
                                                    {showingReason && (
                                                        <motion.div
                                                            initial={{ opacity: 0, height: 0 }}
                                                            animate={{ opacity: 1, height: 'auto' }}
                                                            exit={{ opacity: 0, height: 0 }}
                                                            className="overflow-hidden"
                                                        >
                                                            <div className={`mt-2 p-3 rounded-xl border ${isDark ? 'bg-red-900/10 border-red-500/20' : 'bg-red-50 border-red-200'}`}>
                                                                <p className={`text-[9px] font-black mb-2 flex items-center gap-1 ${isDark ? 'text-red-400' : 'text-red-600'}`}>
                                                                    <AlertTriangle className="w-3 h-3" /> لماذا هذا العرض غير مناسب؟
                                                                </p>
                                                                <input
                                                                    type="text"
                                                                    value={reasonOtherText}
                                                                    onChange={e => setReasonOtherText(e.target.value)}
                                                                    onKeyDown={e => e.key === 'Enter' && reasonOtherText.trim() && handleSubmitOtherReason(offer.id)}
                                                                    placeholder="مثال: الموقع بعيد جداً، النوع مختلف..."
                                                                    autoFocus
                                                                    className={`w-full px-3 py-2 rounded-xl text-xs border outline-none mb-2 ${isDark ? 'bg-white/5 border-red-500/20 text-white placeholder-white/30' : 'bg-white border-red-200 text-gray-900 placeholder-gray-400'}`}
                                                                    style={{ direction: 'rtl' }}
                                                                />
                                                                <div className="flex gap-2">
                                                                    <button
                                                                        onClick={() => handleSubmitOtherReason(offer.id)}
                                                                        disabled={!reasonOtherText.trim()}
                                                                        className={`flex-1 py-1.5 rounded-xl text-[10px] font-black transition-all ${reasonOtherText.trim() ? 'bg-red-500 text-white hover:bg-red-600' : 'opacity-40 cursor-not-allowed ' + (isDark ? 'bg-white/5 text-white/20' : 'bg-gray-200 text-gray-400')}`}>
                                                                        تأكيد وإخفاء
                                                                    </button>
                                                                    <button
                                                                        onClick={() => setReasonOtherFor(null)}
                                                                        className={`px-3 py-1.5 rounded-xl text-[10px] font-bold ${isDark ? 'bg-white/5 text-white/40 hover:bg-white/10' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}>
                                                                        إلغاء
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </motion.div>
                                                    )}
                                                </AnimatePresence>
                                            </div>
                                        </motion.div>
                                    );
                                })}
                            </AnimatePresence>

                            {visibleOtherOffers.length === 0 && (
                                <div className={`p-8 rounded-2xl text-center border border-dashed ${isDark ? 'border-white/10' : 'border-gray-200'}`}>
                                    <Zap className="w-8 h-8 mx-auto mb-2 text-purple-400 opacity-50" />
                                    <p className={`text-xs font-bold ${isDark ? 'text-white/40' : 'text-gray-400'}`}>لا توجد عروض أخرى متبقية</p>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Change Wish Button */}
                    <button
                        onClick={handleDelete}
                        className={`w-full py-3 rounded-2xl border border-dashed text-xs font-bold flex items-center justify-center gap-2 transition-colors ${isDark ? 'border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10' : 'border-emerald-300 text-emerald-600 hover:bg-emerald-50'}`}>
                        <Plus className="w-3.5 h-3.5" /> تغيير الرغبة أو إضافة رغبة جديدة
                    </button>
                </motion.div>
            )}
        </div>
    );
}