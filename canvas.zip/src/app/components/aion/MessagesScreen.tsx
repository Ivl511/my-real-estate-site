import { motion } from "motion/react";
import { ArrowRight, Search, Filter, MessageCircle, Clock, CheckCheck, Sparkles, TrendingUp, AlertCircle, Zap, Send, Phone, Video, MoreVertical, Mic, Image as ImgIcon, ClipboardList, Briefcase, HardHat, Key, UserSearch, Home, FileText, Building } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useTheme } from "../../context/ThemeContext";

interface MessagesScreenProps {
  onBack: () => void;
}

// Conversation threads data
const conversations = [
  {
    id: "eon-brain",
    isEON: true,
    avatar: "🤖",
    name: "EON Assistant",
    nameAr: "المساعد الذكي",
    badge: "المساعد العقاري الذكي",
    status: "متصل",
    lastMessage: "وجدت لك 3 عقارات في حي الملقا تطابق ميزانيتك 2,500,000 ر.س",
    timestamp: "الآن",
    unread: 2,
    isPinned: true,
    userType: "system",
  },
  {
    id: "1",
    isEON: false,
    avatar: "https://i.pravatar.cc/150?img=1",
    name: "عبدالله المحمدي",
    role: "مكتب إعمار للعقارات",
    property: "بخصوص: فيلا حي العارض",
    lastMessage: "تم تحديث السعر بناءً على طلبك - السعر الجديد 3,200,000 ر.س",
    timestamp: "منذ 5د",
    unread: 1,
    status: "عرض سعر",
    statusColor: "orange",
    userType: "broker",
  },
  {
    id: "2",
    isEON: false,
    avatar: "https://i.pravatar.cc/150?img=5",
    name: "سارة الغامدي",
    role: "مالكة عقار",
    property: "بخصوص: شقة النرجس 350 م²",
    lastMessage: "هل يمكن ترتيب معاينة غداً الساعة 10 صباحاً؟",
    timestamp: "منذ 15د",
    unread: 0,
    status: null,
    statusColor: null,
    userType: "landlord",
  },
  {
    id: "3",
    isEON: false,
    avatar: "https://i.pravatar.cc/150?img=3",
    name: "أحمد الراشد",
    role: "وسيط عقاري",
    property: "بخصوص: عقد إيجار موحد",
    lastMessage: "تم إرسال العقد للمراجعة القانونية",
    timestamp: "منذ ساعة",
    unread: 0,
    status: null,
    statusColor: null,
    userType: "broker",
  },
  {
    id: "4",
    isEON: false,
    avatar: "https://i.pravatar.cc/150?img=8",
    name: "فهد الدوسري",
    role: "باحث عن عقار",
    property: "بخصوص: شقة في الرياض",
    lastMessage: "شكراً جزيلاً على المساعدة",
    timestamp: "منذ 3 ساعات",
    unread: 0,
    status: null,
    statusColor: null,
    userType: "seeker",
  },
  {
    id: "5",
    isEON: false,
    avatar: "https://i.pravatar.cc/150?img=12",
    name: "شركة العمران للتطوير",
    role: "مطور عقاري",
    property: "بخصوص: مشروع الياسمين",
    lastMessage: "لدينا 50 وحدة جاهزة للتسويق بعمولة 5%",
    timestamp: "منذ يوم",
    unread: 0,
    status: null,
    statusColor: null,
    userType: "developer",
  },
];

export function MessagesScreen({ onBack }: MessagesScreenProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("الكل");
  const [userTypeFilter, setUserTypeFilter] = useState("all");
  const [selectedConv, setSelectedConv] = useState<typeof conversations[0] | null>(null);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  if (selectedConv) {
    return <ConversationView conv={selectedConv} onBack={() => setSelectedConv(null)} isDark={isDark} />;
  }

  const filters = [
    { id: "all", label: "الكل", count: conversations.length },
    { id: "quotes", label: "عروض أسعار", count: 2 },
    { id: "systemAlerts", label: "تنبيهات النظام", count: 1 },
    { id: "archived", label: "الأرشيف", count: 0 },
  ];

  const userTypeFilters = [
    { id: "all", label: "الكل", Icon: ClipboardList },
    { id: "broker", label: "الوسطاء", Icon: Briefcase },
    { id: "developer", label: "المطورين", Icon: Building },
    { id: "landlord", label: "الملاك", Icon: Key },
    { id: "seeker", label: "الباحثين", Icon: UserSearch },
  ];

  const filteredConversations = conversations.filter(conv => {
    // First apply the main filter
    let passesMainFilter = true;
    if (activeFilter === "all" || activeFilter === "الكل") passesMainFilter = true;
    else if (activeFilter === "quotes" || activeFilter === "عروض أسعار") passesMainFilter = conv.status === "عرض سعر";
    else if (activeFilter === "systemAlerts" || activeFilter === "تنبيهات النظام") passesMainFilter = conv.isEON;
    else if (activeFilter === "archived" || activeFilter === "الأرشيف") passesMainFilter = false;
    
    // Then apply user type filter
    let passesUserTypeFilter = true;
    if (userTypeFilter !== "all") {
      passesUserTypeFilter = conv.userType === userTypeFilter;
    }
    
    return passesMainFilter && passesUserTypeFilter;
  });

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gradient-to-br from-gray-50 to-gray-100'} overflow-hidden`}>
      {/* HEADER */}
      <div className="px-5 pt-12 pb-4">
        {/* Top: Title */}
        <div className="flex items-center gap-3 mb-4">
          <button 
            onClick={onBack} 
            className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
              isDark ? 'glass-premium' : 'bg-white shadow-lg'
            }`}
          >
            <ArrowRight className={`w-5 h-5 ${isDark ? 'text-white' : 'text-gray-900'}`} />
          </button>
          <h2 className={`text-xl font-black ${isDark ? 'text-white' : 'text-gray-900'} flex-1 text-right`} style={{ fontFamily: 'Cairo' }}>
            الرسائل الواردة
          </h2>
          <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
            isDark ? 'glass-premium' : 'bg-white shadow-lg'
          }`}>
            <div className="relative">
              <MessageCircle className={`w-5 h-5 ${isDark ? 'text-cyan-400' : 'text-blue-600'}`} />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-[#0A0E1A]" />
            </div>
          </div>
        </div>

        {/* Search Input */}
        <div className={`w-full rounded-2xl px-4 py-3.5 flex items-center gap-3 mb-4 relative ${
          isDark ? 'glass-strong border border-white/10' : 'bg-white shadow-xl'
        }`}>
          <Search className={`w-5 h-5 ${isDark ? 'text-white/40' : 'text-gray-400'}`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في المحادثات..."
            className={`flex-1 bg-transparent outline-none text-sm font-medium text-right ${
              isDark ? 'text-white placeholder:text-white/50' : 'text-gray-900 placeholder:text-gray-400'
            }`}
          />
          <button className={`w-9 h-9 rounded-xl flex items-center justify-center ${
            isDark ? 'glass-premium' : 'bg-gray-100'
          }`}>
            <Filter className={`w-4 h-4 ${isDark ? 'text-cyan-400' : 'text-blue-600'}`} />
          </button>
        </div>

        {/* Smart Chips Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide mb-3">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.label)}
              className={`flex-shrink-0 px-4 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 ${
                activeFilter === filter.label
                  ? isDark
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg"
                    : "bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-lg"
                  : isDark
                    ? "glass-premium text-white/60 hover:text-white"
                    : "bg-white text-gray-600 hover:text-gray-900 shadow"
              }`}
            >
              {filter.label === "عروض أسعار" && <AlertCircle className="w-3.5 h-3.5 text-amber-400" />}
              <span>{filter.label}</span>
              {filter.count > 0 && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                  activeFilter === filter.label
                    ? "bg-white/20"
                    : isDark
                      ? "bg-white/10"
                      : "bg-gray-100"
                }`}>
                  {filter.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* User Type Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {userTypeFilters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setUserTypeFilter(filter.id)}
              className={`flex-shrink-0 px-4 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center gap-2 ${
                userTypeFilter === filter.id
                  ? isDark
                    ? "bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-lg"
                    : "bg-gradient-to-r from-purple-600 to-pink-700 text-white shadow-lg"
                  : isDark
                    ? "glass-premium text-white/60 hover:text-white"
                    : "bg-white text-gray-600 hover:text-gray-900 shadow"
              }`}
            >
              <filter.Icon className="w-3.5 h-3.5" />
              <span>{filter.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* CONVERSATION LIST */}
      <div className="flex-1 overflow-y-auto px-5 pb-32 space-y-3">
        {filteredConversations.map((conv, index) => (
          <motion.button
            key={conv.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedConv(conv)}
            className={`w-full rounded-3xl p-4 cursor-pointer transition-all text-left ${
              conv.isEON
                ? isDark
                  ? "bg-gradient-to-br from-cyan-500/20 via-blue-500/10 to-purple-500/10 border-2 border-cyan-400/40 shadow-lg shadow-cyan-500/20 animate-pulse-glow"
                  : "bg-gradient-to-br from-cyan-50 via-blue-50 to-purple-50 border-2 border-cyan-400 shadow-lg"
                : isDark
                  ? "glass-strong hover:glass-premium"
                  : "bg-white hover:shadow-xl shadow-lg"
            }`}
          >
            <div className="flex items-start gap-3">
              {/* Avatar + Role Icon */}
              <div className="relative flex-shrink-0">
                {conv.isEON ? (
                  // EON Brain Special Avatar
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center relative ${
                    isDark
                      ? "bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600"
                      : "bg-gradient-to-br from-cyan-300 via-blue-400 to-purple-500"
                  }`}>
                    <Sparkles className="w-7 h-7 text-white animate-pulse" />
                    {/* Glow Effect */}
                    {isDark && (
                      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-400/50 to-purple-500/50 blur-md -z-10" />
                    )}
                  </div>
                ) : (
                  // Human Avatar
                  <div className="w-12 h-12 rounded-2xl overflow-hidden bg-gradient-to-br from-purple-500 to-pink-500">
                    <img src={conv.avatar} alt={conv.name} className="w-full h-full object-cover" />
                  </div>
                )}

                {/* Status Indicator for EON */}
                {conv.isEON && (
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-r from-emerald-400 to-green-500 border-2 border-white flex items-center justify-center">
                    <Zap className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                {/* Name + Badge */}
                <div className="flex items-start justify-between mb-1">
                  <div className="flex-1 text-right">
                    <h3 className={`font-black text-sm mb-0.5 ${
                      isDark ? 'text-white' : 'text-gray-900'
                    }`} style={{ fontFamily: 'Cairo' }}>
                      {conv.name}
                    </h3>
                    {conv.isEON ? (
                      // EON Badge
                      <div className="inline-block px-2 py-0.5 rounded-md bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-400/30">
                        <p className={`text-[10px] font-black ${
                          isDark ? 'text-cyan-400' : 'text-cyan-700'
                        }`}>
                          {conv.badge}
                        </p>
                      </div>
                    ) : (
                      // Human Property Context
                      <p className={`text-xs font-semibold flex items-center gap-1 ${
                        isDark ? 'text-white/50' : 'text-gray-500'
                      }`}>
                        {conv.userType === "broker" ? <Briefcase className="w-3 h-3 shrink-0" /> : conv.userType === "developer" ? <Building className="w-3 h-3 shrink-0" /> : conv.userType === "landlord" ? <Key className="w-3 h-3 shrink-0" /> : conv.userType === "seeker" ? <UserSearch className="w-3 h-3 shrink-0" /> : <FileText className="w-3 h-3 shrink-0" />}
                        {conv.property}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-1.5 flex-shrink-0 ml-2">
                    <Clock className={`w-3 h-3 ${isDark ? 'text-white/30' : 'text-gray-400'}`} />
                    <span className={`text-xs font-bold ${
                      isDark ? 'text-white/50' : 'text-gray-500'
                    }`}>
                      {conv.timestamp}
                    </span>
                  </div>
                </div>

                {/* Last Message Preview */}
                <p className={`text-sm font-medium mb-2 text-right line-clamp-1 ${
                  conv.unread > 0
                    ? isDark ? 'text-white' : 'text-gray-900'
                    : isDark ? 'text-white/60' : 'text-gray-600'
                }`}>
                  {conv.lastMessage}
                </p>

                {/* Status Badge / Unread Count */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {conv.status && (
                      <div className={`px-3 py-1 rounded-lg flex items-center gap-1.5 ${
                        conv.statusColor === "orange"
                          ? isDark
                            ? "bg-amber-500/20 border border-amber-500/30"
                            : "bg-amber-100 border border-amber-300"
                          : conv.statusColor === "emerald"
                            ? isDark
                              ? "bg-emerald-500/20 border border-emerald-500/30"
                              : "bg-emerald-100 border border-emerald-300"
                            : isDark
                              ? "bg-purple-500/20 border border-purple-500/30"
                              : "bg-purple-100 border border-purple-300"
                      }`}>
                        {conv.statusColor === "orange" ? (
                          <AlertCircle className={`w-3 h-3 ${
                            isDark ? 'text-amber-400' : 'text-amber-600'
                          }`} />
                        ) : conv.statusColor === "emerald" ? (
                          <TrendingUp className={`w-3 h-3 ${
                            isDark ? 'text-emerald-400' : 'text-emerald-600'
                          }`} />
                        ) : (
                          <MessageCircle className={`w-3 h-3 ${
                            isDark ? 'text-purple-400' : 'text-purple-600'
                          }`} />
                        )}
                        <span className={`text-xs font-black ${
                          conv.statusColor === "orange"
                            ? isDark ? 'text-amber-400' : 'text-amber-600'
                            : conv.statusColor === "emerald"
                              ? isDark ? 'text-emerald-400' : 'text-emerald-600'
                              : isDark ? 'text-purple-400' : 'text-purple-600'
                        }`}>
                          {conv.status}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Unread Badge */}
                  {conv.unread > 0 && (
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      isDark
                        ? "bg-gradient-to-r from-cyan-500 to-blue-600"
                        : "bg-gradient-to-r from-blue-600 to-indigo-700"
                    }`}>
                      <span className="text-white text-xs font-black">{conv.unread}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// CONVERSATION MESSAGES DATA
// ==========================================
const convMessages: Record<string, { id: string; text: string; isUser: boolean; time: string; read?: boolean }[]> = {
  "eon-brain": [
    { id: "1", text: "مرحباً! كيف أستطيع مساعدتك اليوم؟", isUser: false, time: "10:00" },
    { id: "2", text: "أبحث عن فيلا في شمال الرياض", isUser: true, time: "10:01" },
    { id: "3", text: "وجدت لك 3 عقارات في حي الملقا تطابق ميزانيتك 2,500,000 ر.س 🏡\n• فيلا النرجس - 2.4M - 5 غرف\n• فيلا الملقا - 2.5M - 4 غرف\n• فيلا حطين - 2.3M - 5 غرف", isUser: false, time: "10:01" },
    { id: "4", text: "ما رأيك في فيلا النرجس؟ ابدو مناسبة", isUser: true, time: "10:03" },
    { id: "5", text: "ممتاز! سعر المتر في فيلا النرجس أقل من متوسط الحي بـ 5% 📊\nنصيحة: الأسعار في ارتفاع، الأفضل التصرف خلال أسبوعين.", isUser: false, time: "10:04" },
  ],
  "1": [
    { id: "1", text: "مرحباً، بخصوص فيلا حي العارض", isUser: false, time: "09:00" },
    { id: "2", text: "هل السعر قابل للتفاوض؟", isUser: true, time: "09:15" },
    { id: "3", text: "نعم، يمكن التفاوض في حدود 100,000 ر.س", isUser: false, time: "09:20" },
    { id: "4", text: "تم تحديث السعر بناءً على طلبك - السعر الجديد 3,200,000 ر.س", isUser: false, time: "09:45", read: true },
  ],
  "2": [
    { id: "1", text: "أهلاً، شقة النرجس متاحة للمعاينة", isUser: false, time: "08:00" },
    { id: "2", text: "متى يمكن المعاينة؟", isUser: true, time: "08:30" },
    { id: "3", text: "هل يمكن ترتيب معاينة غداً الساعة 10 صباحاً؟", isUser: false, time: "08:45" },
  ],
  "3": [
    { id: "1", text: "عقد الإيجار الموحد جاهز للمراجعة", isUser: false, time: "07:00" },
    { id: "2", text: "تم إرسال العقد للمراجعة القانونية", isUser: false, time: "07:30" },
  ],
  "4": [
    { id: "1", text: "شكراً على مساعدتك في البحث", isUser: true, time: "15:00" },
    { id: "2", text: "شكراً جزيلاً على المساعدة", isUser: false, time: "15:05" },
  ],
  "5": [
    { id: "1", text: "مشروع الياسمين: 50 وحدة جاهزة للتسويق", isUser: false, time: "14:00" },
    { id: "2", text: "ما هي نسبة العمولة؟", isUser: true, time: "14:15" },
    { id: "3", text: "لدينا 50 وحدة جاهزة للتسويق بعمولة 5%", isUser: false, time: "14:30" },
  ],
};

// ==========================================
// CONVERSATION VIEW COMPONENT
// ==========================================
function ConversationView({ conv, onBack, isDark }: { conv: any; onBack: () => void; isDark: boolean }) {
  const [inputText, setInputText] = useState("");
  const [messages, setMessages] = useState(convMessages[conv.id] || []);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!inputText.trim()) return;
    const newMsg = { id: Date.now().toString(), text: inputText, isUser: true, time: new Date().toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" }) };
    setMessages(prev => [...prev, newMsg]);
    setInputText("");
    // Simulate reply after 1.5s
    setTimeout(() => {
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), text: "شكراً على رسالتك، سأرد عليك في أقرب وقت ممكن.", isUser: false, time: new Date().toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" }) }]);
    }, 1500);
  };

  return (
    <motion.div
      initial={{ x: "100%", opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: "100%", opacity: 0 }}
      transition={{ type: "spring", damping: 28, stiffness: 300 }}
      className={`h-full flex flex-col ${isDark ? "bg-[#0a0f1e]" : "bg-gray-50"}`}
    >
      {/* HEADER */}
      <div className={`px-4 pt-12 pb-4 flex items-center gap-3 border-b ${isDark ? "bg-[#0f172a]/95 backdrop-blur border-white/8" : "bg-white border-gray-200 shadow-sm"}`}>
        <button onClick={onBack} className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${isDark ? "bg-white/8 text-white" : "bg-gray-100 text-gray-700"}`}>
          <ArrowRight className="w-5 h-5" />
        </button>
        {/* Avatar */}
        <div className="w-10 h-10 rounded-2xl overflow-hidden shrink-0 bg-gradient-to-br from-cyan-500 to-blue-600">
          {conv.isEON
            ? <div className="w-full h-full flex items-center justify-center"><Sparkles className="w-5 h-5 text-white" /></div>
            : <img src={conv.avatar} alt={conv.name} className="w-full h-full object-cover" />
          }
        </div>
        <div className="flex-1 min-w-0">
          <h3 className={`font-black text-sm truncate ${isDark ? "text-white" : "text-gray-900"}`}>{conv.name}</h3>
          <p className={`text-[10px] truncate ${isDark ? "text-white/40" : "text-gray-400"}`}>{conv.role || conv.badge || "متصل الآن"}</p>
        </div>
        <div className="flex gap-2">
          <button className={`w-9 h-9 rounded-xl flex items-center justify-center ${isDark ? "bg-white/8 text-white/60" : "bg-gray-100 text-gray-600"}`}><Phone className="w-4 h-4" /></button>
          <button className={`w-9 h-9 rounded-xl flex items-center justify-center ${isDark ? "bg-white/8 text-white/60" : "bg-gray-100 text-gray-600"}`}><Video className="w-4 h-4" /></button>
          <button className={`w-9 h-9 rounded-xl flex items-center justify-center ${isDark ? "bg-white/8 text-white/60" : "bg-gray-100 text-gray-600"}`}><MoreVertical className="w-4 h-4" /></button>
        </div>
      </div>

      {/* MESSAGES */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.map((msg) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${msg.isUser ? "justify-end" : "justify-start"}`}
          >
            {!msg.isUser && (
              <div className="w-8 h-8 rounded-xl overflow-hidden shrink-0 ml-2 mt-auto bg-gradient-to-br from-cyan-500 to-blue-600">
                {conv.isEON
                  ? <div className="w-full h-full flex items-center justify-center"><Sparkles className="w-4 h-4 text-white" /></div>
                  : <img src={conv.avatar} alt="" className="w-full h-full object-cover" />
                }
              </div>
            )}
            <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
              msg.isUser
                ? "bg-gradient-to-br from-cyan-500 to-blue-600 text-white rounded-tl-sm"
                : isDark ? "bg-white/10 text-white rounded-tr-sm" : "bg-white text-gray-800 shadow-sm rounded-tr-sm"
            }`} style={{ direction: "rtl", whiteSpace: "pre-wrap" }}>
              {msg.text}
              <div className={`flex items-center justify-end gap-1 mt-1 ${msg.isUser ? "text-white/60" : isDark ? "text-white/30" : "text-gray-400"}`}>
                <span style={{ fontSize: "9px" }}>{msg.time}</span>
                {msg.isUser && <CheckCheck style={{ width: "10px", height: "10px" }} />}
              </div>
            </div>
          </motion.div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* INPUT */}
      <div className={`px-4 pb-6 pt-3 border-t ${isDark ? "bg-[#0f172a]/95 border-white/8" : "bg-white border-gray-200"}`}>
        <div className={`flex items-center gap-2 rounded-2xl border-2 px-3 py-2 ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
          <button className={isDark ? "text-white/40" : "text-gray-400"}><ImgIcon className="w-5 h-5" /></button>
          <input
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            onKeyDown={e => e.key === "Enter" && sendMessage()}
            placeholder="اكتب رسالة..."
            className={`flex-1 bg-transparent outline-none text-sm ${isDark ? "text-white placeholder-white/30" : "text-gray-900 placeholder-gray-400"}`}
            style={{ direction: "rtl" }}
          />
          <button className={isDark ? "text-white/40" : "text-gray-400"}><Mic className="w-5 h-5" /></button>
          <button
            onClick={sendMessage}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${inputText.trim() ? "bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-md" : isDark ? "bg-white/5 text-white/20" : "bg-gray-200 text-gray-400"}`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}