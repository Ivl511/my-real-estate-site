import { Menu, MoreVertical } from "lucide-react";

export function ChatHeader() {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-b bg-white">
      <div className="flex items-center gap-3">
        <button className="p-2 -ml-2 hover:bg-gray-100 rounded-lg">
          <Menu className="w-5 h-5 text-gray-700" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
            <span className="text-white text-sm font-medium">AI</span>
          </div>
          <div>
            <h1 className="font-semibold text-gray-900">AI Assistant</h1>
            <p className="text-xs text-green-600">Online</p>
          </div>
        </div>
      </div>
      <button className="p-2 hover:bg-gray-100 rounded-lg">
        <MoreVertical className="w-5 h-5 text-gray-700" />
      </button>
    </div>
  );
}
