import { motion } from "motion/react";
import { ArrowRight, Globe, Bell, Lock, FileText, Shield } from "lucide-react";
import { useState } from "react";
import { useTheme } from "../../context/ThemeContext";

interface SettingsScreenProps {
  onBack: () => void;
}

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";
  const [language, setLanguage] = useState<"ar" | "en">("ar");
  const [notifications, setNotifications] = useState(true);

  return (
    <div className={`h-full flex flex-col ${isDark ? 'noise-bg' : 'bg-gradient-to-br from-gray-50 to-gray-100'} overflow-y-auto pb-32`}>
      {/* Header */}
      <div className="px-5 pt-12 pb-6 sticky top-0 z-10 backdrop-blur-xl">
        <div className="flex items-center gap-3 mb-4">
          <button 
            onClick={onBack} 
            className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
              isDark ? 'glass-premium' : 'bg-white shadow-lg'
            }`}
          >
            <ArrowRight className={`w-5 h-5 ${isDark ? 'text-white' : 'text-gray-900'}`} />
          </button>
          <h2 className={`text-2xl font-black ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
            الإعدادات
          </h2>
        </div>
      </div>

      {/* Settings List */}
      <div className="px-5 space-y-4">
        {/* Language Setting */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-3xl p-5 ${isDark ? 'glass-strong' : 'bg-white shadow-lg'}`}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                isDark ? 'bg-cyan-500/20' : 'bg-cyan-100'
              }`}>
                <Globe className={`w-6 h-6 ${isDark ? 'text-cyan-400' : 'text-cyan-600'}`} />
              </div>
              <div className="text-right">
                <h3 className={`font-black text-base ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
                  اللغة
                </h3>
                <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                  Language
                </p>
              </div>
            </div>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setLanguage("ar")}
              className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                language === "ar"
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                  : isDark ? 'bg-white/10 text-white/60' : 'bg-gray-100 text-gray-600'
              }`}
            >
              العربية
            </button>
            <button
              onClick={() => setLanguage("en")}
              className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                language === "en"
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                  : isDark ? 'bg-white/10 text-white/60' : 'bg-gray-100 text-gray-600'
              }`}
            >
              English
            </button>
          </div>
        </motion.div>

        {/* Notifications Setting */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className={`rounded-3xl p-5 ${isDark ? 'glass-strong' : 'bg-white shadow-lg'}`}
        >
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-3 flex-1 cursor-pointer">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                isDark ? 'bg-purple-500/20' : 'bg-purple-100'
              }`}>
                <Bell className={`w-6 h-6 ${isDark ? 'text-purple-400' : 'text-purple-600'}`} />
              </div>
              <div className="text-right flex-1">
                <h3 className={`font-black text-base ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
                  الإشعارات
                </h3>
                <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                  تفعيل أو إيقاف التنبيهات
                </p>
              </div>
            </label>
            <div className="relative">
              <input 
                type="checkbox" 
                checked={notifications}
                onChange={() => setNotifications(!notifications)}
                className="sr-only peer"
              />
              <div onClick={() => setNotifications(!notifications)} className={`w-14 h-8 rounded-full cursor-pointer transition-all ${
                notifications 
                  ? 'bg-gradient-to-r from-emerald-500 to-green-600'
                  : isDark ? 'bg-white/20' : 'bg-gray-300'
              }`}>
                <div className={`w-6 h-6 bg-white rounded-full shadow-lg transition-transform duration-300 mt-1 ${
                  notifications ? 'mr-1' : 'mr-7'
                }`} />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Theme Setting */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className={`rounded-3xl p-5 ${isDark ? 'glass-strong' : 'bg-white shadow-lg'}`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                isDark ? 'bg-amber-500/20' : 'bg-amber-100'
              }`}>
                <span className="text-2xl">{isDark ? '🌙' : '☀️'}</span>
              </div>
              <div className="text-right">
                <h3 className={`font-black text-base ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
                  المظهر
                </h3>
                <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                  {isDark ? 'الوضع الليلي' : 'الوضع النهاري'}
                </p>
              </div>
            </div>
            <button
              onClick={toggleTheme}
              className={`px-4 py-2 rounded-xl font-bold transition-all ${
                isDark 
                  ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white'
                  : 'bg-gradient-to-r from-blue-500 to-cyan-600 text-white'
              }`}
            >
              تبديل
            </button>
          </div>
        </motion.div>

        {/* Change Password */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`w-full rounded-3xl p-5 transition-all ${
            isDark ? 'glass-strong hover:glass-premium' : 'bg-white hover:shadow-xl shadow-lg'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
              isDark ? 'bg-orange-500/20' : 'bg-orange-100'
            }`}>
              <Lock className={`w-6 h-6 ${isDark ? 'text-orange-400' : 'text-orange-600'}`} />
            </div>
            <div className="flex-1 text-right">
              <h3 className={`font-black text-base ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
                تغيير كلمة المرور
              </h3>
              <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                تحديث بيانات الدخول
              </p>
            </div>
          </div>
        </motion.button>

        {/* Privacy Policy */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className={`w-full rounded-3xl p-5 transition-all ${
            isDark ? 'glass-strong hover:glass-premium' : 'bg-white hover:shadow-xl shadow-lg'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
              isDark ? 'bg-blue-500/20' : 'bg-blue-100'
            }`}>
              <FileText className={`w-6 h-6 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
            </div>
            <div className="flex-1 text-right">
              <h3 className={`font-black text-base ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
                سياسة الخصوصية
              </h3>
              <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                اطلع على شروط الاستخدام
              </p>
            </div>
          </div>
        </motion.button>

        {/* Security */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className={`w-full rounded-3xl p-5 transition-all ${
            isDark ? 'glass-strong hover:glass-premium' : 'bg-white hover:shadow-xl shadow-lg'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
              isDark ? 'bg-emerald-500/20' : 'bg-emerald-100'
            }`}>
              <Shield className={`w-6 h-6 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
            </div>
            <div className="flex-1 text-right">
              <h3 className={`font-black text-base ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
                الأمان
              </h3>
              <p className={`text-sm ${isDark ? 'text-white/60' : 'text-gray-600'}`}>
                المصادقة الثنائية والأمان
              </p>
            </div>
          </div>
        </motion.button>
      </div>
    </div>
  );
}
