import { motion } from "motion/react";
import { Home, ClipboardList, MessageCircle, User, Sparkles, Plus, Search, Bell } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";
import type { Screen } from "../../App";

interface DesktopNavbarProps {
  currentScreen: Screen;
  onNavigate: (screen: Screen) => void;
  onOpenAddMenu: () => void;
}

export function DesktopNavbar({ currentScreen, onNavigate, onOpenAddMenu }: DesktopNavbarProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  const isActive = (screen: Screen) => currentScreen === screen;

  const navItems = [
    { id: "home", label: "الرئيسية", icon: Home },
    { id: "requests", label: "الطلبات", icon: ClipboardList },
    { id: "inbox", label: "المحادثات", icon: MessageCircle },
    { id: "profile", label: "حسابي", icon: User },
  ];

  return (
    <nav className={`hidden md:flex fixed top-0 left-0 right-0 h-20 z-[100] transition-all duration-300 ${
      isDark ? 'bg-[#050505]/80 backdrop-blur-md border-b border-white/5' : 'bg-white/90 backdrop-blur-md border-b border-gray-100 shadow-sm'
    }`}>
      <div className="container mx-auto px-6 h-full flex items-center justify-between">
        
        {/* RIGHT: Logo & Search */}
        <div className="flex items-center gap-8">
            {/* Logo */}
            <div 
                className="flex items-center gap-2 cursor-pointer group" 
                onClick={() => onNavigate("home")}
            >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-500 ${
                    isDark ? 'bg-gradient-to-br from-cyan-500 to-blue-600' : 'bg-gradient-to-br from-blue-600 to-indigo-700'
                }`}>
                    <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                    <h1 className={`text-2xl font-black tracking-tight ${isDark ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Cairo' }}>
                        أيون
                    </h1>
                </div>
            </div>

            {/* Desktop Search Bar */}
            <div className={`hidden lg:flex items-center gap-3 px-4 py-2.5 rounded-full w-96 border transition-all ${
                isDark 
                    ? 'bg-white/5 border-white/10 focus-within:border-cyan-500/50 focus-within:bg-white/10' 
                    : 'bg-gray-100 border-transparent focus-within:bg-white focus-within:border-blue-200 focus-within:shadow-md'
            }`}>
                <Search className={`w-5 h-5 ${isDark ? 'text-white/40' : 'text-gray-400'}`} />
                <input 
                    type="text" 
                    placeholder="ابحث عن عقار، حي، أو مشروع..." 
                    className={`bg-transparent border-none outline-none w-full text-sm font-medium ${
                        isDark ? 'text-white placeholder:text-white/30' : 'text-gray-900 placeholder:text-gray-500'
                    }`}
                />
            </div>
        </div>

        {/* CENTER: Navigation Links */}
        <div className="flex items-center gap-1">
            {navItems.map((item) => {
                const active = isActive(item.id as Screen);
                const Icon = item.icon;
                return (
                    <button
                        key={item.id}
                        onClick={() => onNavigate(item.id as Screen)}
                        className={`relative px-6 py-2.5 rounded-xl flex items-center gap-2 transition-all duration-300 ${
                            active 
                                ? isDark ? 'text-white' : 'text-blue-600'
                                : isDark ? 'text-white/50 hover:bg-white/5 hover:text-white' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
                        }`}
                    >
                        {active && (
                            <motion.div
                                layoutId="desktopNav"
                                className={`absolute inset-0 rounded-xl ${
                                    isDark ? 'bg-white/10' : 'bg-blue-50'
                                }`}
                            />
                        )}
                        <Icon className={`w-5 h-5 relative z-10 ${active ? 'fill-current' : ''}`} />
                        <span className="font-bold text-sm relative z-10">{item.label}</span>
                    </button>
                )
            })}
        </div>

        {/* LEFT: Actions */}
        <div className="flex items-center gap-4">
            {/* Add Button */}
            <button 
                onClick={onOpenAddMenu}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-bold text-sm transition-transform active:scale-95 shadow-lg shadow-cyan-500/20 ${
                    isDark 
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:brightness-110' 
                        : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:brightness-110'
                }`}
            >
                <Plus className="w-5 h-5" />
                <span>إعلان جديد</span>
            </button>

            <div className="w-px h-8 bg-gray-200 dark:bg-white/10" />

            {/* Notifications */}
            <button className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                isDark ? 'hover:bg-white/10 text-white/60 hover:text-white' : 'hover:bg-gray-100 text-gray-500 hover:text-gray-900'
            }`}>
                <div className="relative">
                    <Bell className="w-5 h-5" />
                    <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#050505]" />
                </div>
            </button>

             {/* Theme Toggle */}
             <button 
                onClick={toggleTheme}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                    isDark ? 'hover:bg-white/10 text-yellow-400' : 'hover:bg-gray-100 text-slate-600'
                }`}
            >
                {isDark ? '☀️' : '🌙'}
            </button>
        </div>
      </div>
    </nav>
  );
}
