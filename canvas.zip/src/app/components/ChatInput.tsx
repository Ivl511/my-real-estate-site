import { useState } from "react";
import { Send, Mic, Paperclip } from "lucide-react";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
}

export function ChatInput({ onSendMessage }: ChatInputProps) {
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message);
      setMessage("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="border-t bg-white px-4 py-3">
      <div className="flex items-end gap-2">
        <button
          type="button"
          className="p-2 hover:bg-gray-100 rounded-lg flex-shrink-0"
        >
          <Paperclip className="w-5 h-5 text-gray-600" />
        </button>
        <div className="flex-1 bg-gray-100 rounded-2xl px-4 py-2.5 flex items-center gap-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-transparent outline-none text-sm text-gray-900 placeholder:text-gray-500"
          />
          {!message.trim() && (
            <button
              type="button"
              className="p-1 hover:bg-gray-200 rounded-lg"
            >
              <Mic className="w-5 h-5 text-gray-600" />
            </button>
          )}
        </div>
        <button
          type="submit"
          disabled={!message.trim()}
          className={`p-2.5 rounded-full flex-shrink-0 transition-colors ${
            message.trim()
              ? 'bg-blue-500 hover:bg-blue-600'
              : 'bg-gray-300'
          }`}
        >
          <Send className="w-5 h-5 text-white" />
        </button>
      </div>
    </form>
  );
}
