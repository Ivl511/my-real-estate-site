import { MessageCircle, Home, TrendingUp, DollarSign, Users, Sparkles, ArrowLeft } from "lucide-react";
import type { Screen } from "../../App";

interface HomeScreenProps {
  onNavigate: (screen: Screen, property?: any, context?: string) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const quickActions = [
    { icon: Home, label: "سكن", color: "from-blue-500 to-blue-600", context: "أبحث عن سكن" },
    { icon: TrendingUp, label: "استثمار", color: "from-emerald-500 to-emerald-600", context: "أبحث عن فرصة استثمارية" },
    { icon: DollarSign, label: "سعر المتر", color: "from-purple-500 to-purple-600", context: "أريد معرفة سعر المتر" },
    { icon: Users, label: "وسيط", color: "from-orange-500 to-orange-600", context: "أبحث عن وسيط عقاري" },
  ];

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-emerald-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex-1 flex flex-col">
        {/* Header */}
        <div className="pt-12 pb-8 px-6 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-3xl mb-4 shadow-2xl">
            <Sparkles className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">أيون</h1>
          <p className="text-emerald-300 text-lg">منصتك العقارية الذكية</p>
        </div>

        {/* Main AI Chat Input */}
        <div className="flex-1 flex flex-col justify-center px-6 pb-8">
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-2xl mb-8">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold mb-1">مساعدك العقاري الذكي</h3>
                <p className="text-blue-200 text-sm">تحدث معي بأي طريقة... سأفهمك وأساعدك</p>
              </div>
            </div>
            
            <button
              onClick={() => onNavigate("chat")}
              className="w-full bg-white/90 hover:bg-white rounded-2xl px-6 py-4 text-right text-slate-600 transition-all duration-300 shadow-xl hover:shadow-2xl hover:scale-[1.02]"
            >
              <span className="text-sm">مثال: أبحث عن شقة شرحة في شمال الرياض...</span>
            </button>
          </div>

          {/* Quick Actions */}
          <div className="space-y-3">
            <p className="text-white/70 text-sm text-center mb-4">أو اختر ما تحتاجه مباشرة</p>
            <div className="grid grid-cols-2 gap-3">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={() => onNavigate("chat", undefined, action.context)}
                  className="bg-white/10 backdrop-blur-xl hover:bg-white/20 rounded-2xl p-5 border border-white/20 transition-all duration-300 hover:scale-105 group"
                >
                  <div className={`w-12 h-12 bg-gradient-to-br ${action.color} rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform shadow-lg`}>
                    <action.icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-white font-medium">{action.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Features */}
        <div className="px-6 pb-8">
          <div className="bg-gradient-to-r from-emerald-500/20 to-blue-500/20 backdrop-blur-xl rounded-2xl p-4 border border-white/20">
            <div className="flex items-center justify-center gap-6 text-white/80 text-xs">
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                <span>متصل بنفاذ</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
                <span>أسعار لحظية</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
                <span>رأي AI فوري</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
