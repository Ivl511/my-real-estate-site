import { MessageCircle, Home, TrendingUp, DollarSign, Users, Sparkles } from "lucide-react";

interface HomeScreenProps {
  onNavigateToChat: () => void;
  onNavigateToProperty: (id: string) => void;
}

const quickActions = [
  { id: "1", label: "سكن", icon: Home, color: "from-blue-500 to-blue-600" },
  { id: "2", label: "استثمار", icon: TrendingUp, color: "from-green-500 to-green-600" },
  { id: "3", label: "سعر المتر", icon: DollarSign, color: "from-blue-600 to-blue-700" },
  { id: "4", label: "وسيط", icon: Users, color: "from-green-600 to-green-700" },
];

const featuredProperties = [
  {
    id: "1",
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800",
    title: "فيلا فاخرة - حي الملقا",
    price: "2,500,000",
    location: "الرياض، حي الملقا",
    area: "450",
    aiInsight: "سعر مناسب - منطقة استثمارية ممتازة",
    aiScore: 92,
  },
  {
    id: "2",
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800",
    title: "شقة عصرية - طريق الملك فهد",
    price: "850,000",
    location: "الرياض، طريق الملك فهد",
    area: "180",
    aiInsight: "فرصة استثمارية - ارتفاع متوقع 15%",
    aiScore: 88,
  },
];

export function HomeScreen({ onNavigateToChat, onNavigateToProperty }: HomeScreenProps) {
  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-800 pt-12 pb-8 px-6 rounded-b-3xl shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1">أيون العقاري</h1>
            <p className="text-blue-200 text-sm">مساعدك الذكي في عالم العقار</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* AI Chat Input */}
        <button
          onClick={onNavigateToChat}
          className="w-full bg-white rounded-2xl px-5 py-4 flex items-center gap-3 shadow-lg hover:shadow-xl transition-shadow"
        >
          <MessageCircle className="w-5 h-5 text-blue-900" />
          <span className="text-gray-400 text-right flex-1">تحدث مع مساعد أيون الذكي...</span>
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        </button>
      </div>

      {/* Quick Actions */}
      <div className="px-6 py-6">
        <h2 className="text-lg font-bold text-gray-900 mb-4">إجراءات سريعة</h2>
        <div className="grid grid-cols-2 gap-3">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                onClick={onNavigateToChat}
                className={`bg-gradient-to-br ${action.color} rounded-2xl p-4 flex flex-col items-center gap-2 shadow-md hover:shadow-lg transition-all active:scale-95`}
              >
                <Icon className="w-7 h-7 text-white" />
                <span className="text-white font-semibold text-sm">{action.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Featured Properties */}
      <div className="flex-1 overflow-y-auto px-6 pb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-gray-900">عقارات مميزة</h2>
          <span className="text-sm text-blue-600 font-semibold">عرض الكل</span>
        </div>

        <div className="space-y-4">
          {featuredProperties.map((property) => (
            <button
              key={property.id}
              onClick={() => onNavigateToProperty(property.id)}
              className="w-full bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow"
            >
              {/* Property Image */}
              <div className="relative h-48">
                <img
                  src={property.image}
                  alt={property.title}
                  className="w-full h-full object-cover"
                />
                {/* AI Badge */}
                <div className="absolute top-3 right-3 bg-gradient-to-r from-green-500 to-green-600 rounded-full px-3 py-1.5 flex items-center gap-1.5 shadow-lg">
                  <Sparkles className="w-3.5 h-3.5 text-white" />
                  <span className="text-white text-xs font-bold">AI {property.aiScore}%</span>
                </div>
              </div>

              {/* Property Info */}
              <div className="p-4 text-right">
                <h3 className="font-bold text-gray-900 mb-2">{property.title}</h3>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-gray-500">{property.area} م²</span>
                  <span className="text-xl font-bold text-blue-900">{property.price} ريال</span>
                </div>
                <p className="text-sm text-gray-600 mb-3">{property.location}</p>
                
                {/* AI Insight */}
                <div className="bg-green-50 border border-green-200 rounded-xl p-3 flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-green-800 font-medium">{property.aiInsight}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
