import { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles, Send, X, Building2, MapPin, DollarSign, BedDouble,
  Heart, XCircle, CheckCircle, ChevronRight, Users, Zap, Star,
  ArrowLeft, Target, Layers, MessageSquare, Check, Radio,
  Filter, Crown, Bell, Rocket, Eye, TrendingUp, Search,
  ChevronDown, BarChart3, UserCheck, AlertCircle, Flame,
  Home, Building, Trees, Award, Shield, Clock, SlidersHorizontal
} from "lucide-react";

// ─────────────────────────────────────────────────────────────
//  SHARED TYPES
// ─────────────────────────────────────────────────────────────

interface SavedPreferences {
  type: string;
  location: string;
  budget: string;
  rooms: string;
  likes: string[];
  dislikes: string[];
}

interface MatchedProperty {
  id: number;
  name: string;
  location: string;
  price: string;
  rooms: number;
  match: number;
  tag: string;
  color: string;
}

const MATCHED_PROPERTIES: MatchedProperty[] = [
  { id: 1, name: "فيلا الملقا الفاخرة", location: "الملقا، الرياض", price: "1.85M ر.س", rooms: 4, match: 97, tag: "أعلى تطابق", color: "emerald" },
  { id: 2, name: "فيلا النرجس الراقية", location: "النرجس، الرياض", price: "2.1M ر.س", rooms: 5, match: 89, tag: "قريب من المدارس", color: "blue" },
  { id: 3, name: "فيلا حطين الكلاسيكية", location: "حطين، الرياض", price: "1.7M ر.س", rooms: 4, match: 82, tag: "سعر مميز", color: "purple" },
];

// ─────────────────────────────────────────────────────────────
//  SEEKER MATCHING ASSISTANT
// ─────────────────────────────────────────────────────────────

type ChatStep = "welcome" | "type" | "location" | "budget" | "rooms" | "likes" | "dislikes" | "done";

interface ChatMessage {
  from: "ai" | "user";
  text: string;
  ts?: string;
}

const STEPS_LIST: ChatStep[] = ["welcome", "type", "location", "budget", "rooms", "likes", "dislikes", "done"];
const STEPS_LABELS: Partial<Record<ChatStep, string>> = {
  type: "نوع العقار",
  location: "الموقع",
  budget: "الميزانية",
  rooms: "الغرف",
  likes: "المميزات",
  dislikes: "الشروط",
};

const STEP_QUESTIONS: Record<string, string> = {
  welcome: "مرحباً! 👋 أنا مساعد AION الذكي.\nسأساعدك في إيجاد العقار المثالي عبر 6 خطوات سريعة.\n\nما نوع العقار الذي تبحث عنه؟",
  type: "اختيار ممتاز! 🏡\n\nما المنطقة المفضلة لديك في الرياض؟",
  location: "رائع، معلومة مهمة! 📍\n\nما هو نطاق ميزانيتك؟",
  budget: "واضح، سيساعدني ذلك كثيراً. 💰\n\nكم عدد الغرف الذي تحتاجه؟",
  rooms: "ممتاز! 🛏️\n\nما الميزات التي تهمك أكثر؟ يمكنك اختيار أكثر من واحدة.",
  likes: "تمام! 💫\n\nوما الأشياء التي تفضل تجنبها تماماً؟",
  dislikes: "🎉 أنهيت التحليل!\nحفظت رغبتك العقارية بنجاح. أبحث الآن في 12,400 عقار...",
};

const QUICK_REPLIES: Record<string, Array<{ label: string; icon: string }>> = {
  type: [
    { label: "فيلا", icon: "🏡" },
    { label: "شقة", icon: "🏢" },
    { label: "دوبلكس", icon: "🏘️" },
    { label: "تاون هاوس", icon: "🏠" },
  ],
  location: [
    { label: "الملقا", icon: "📍" },
    { label: "العليا", icon: "🏙️" },
    { label: "النرجس", icon: "🌺" },
    { label: "حطين", icon: "🌳" },
    { label: "أي منطقة", icon: "🗺️" },
  ],
  budget: [
    { label: "أقل من 1M", icon: "💚" },
    { label: "1M – 1.5M", icon: "💛" },
    { label: "1.5M – 2M", icon: "🧡" },
    { label: "أكثر من 2M", icon: "❤️" },
  ],
  rooms: [
    { label: "3 غرف", icon: "3️⃣" },
    { label: "4 غرف", icon: "4️⃣" },
    { label: "5+ غرف", icon: "5️⃣" },
  ],
  likes: [
    { label: "قريب من المدارس", icon: "🏫" },
    { label: "مسبح خاص", icon: "🏊" },
    { label: "حديقة واسعة", icon: "🌳" },
    { label: "قريب من التسوق", icon: "🛒" },
    { label: "هدوء تام", icon: "🤫" },
    { label: "غرفة سائق", icon: "🚗" },
  ],
  dislikes: [
    { label: "بعيد عن الضوضاء", icon: "🔇" },
    { label: "لا أرضي فقط", icon: "🚫" },
    { label: "بعيد طريق سريع", icon: "🛣️" },
    { label: "لا شارع تجاري", icon: "🏪" },
  ],
};

function getStepIndex(step: ChatStep): number {
  const order: ChatStep[] = ["type", "location", "budget", "rooms", "likes", "dislikes", "done"];
  return order.indexOf(step);
}

export function SeekerMatchingAssistant({ isDark }: { isDark: boolean }) {
  const [isOpen, setIsOpen] = useState(false);
  const [savedPrefs, setSavedPrefs] = useState<SavedPreferences | null>(null);
  const [showResults, setShowResults] = useState(false);

  return (
    <>
      {/* ── Widget Card ── */}
      <div
        onClick={() => setIsOpen(true)}
        className={`cursor-pointer rounded-2xl border p-4 transition-all hover:scale-[1.01] active:scale-[0.99] relative overflow-hidden ${
          isDark
            ? "bg-gradient-to-br from-purple-950/60 to-pink-950/60 border-purple-500/30 hover:border-purple-400/60"
            : "bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200 hover:border-purple-400"
        }`}
      >
        {/* Glow accent */}
        <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-purple-500/10 blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600`}>
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>مساعد المطابقة AI</div>
              <div className={`text-[9px] ${isDark ? "text-purple-400" : "text-purple-600"}`}>يفهم رغبتك ويجد المثالي</div>
            </div>
          </div>
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold ${
            savedPrefs
              ? (isDark ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-emerald-100 text-emerald-700 border border-emerald-200")
              : (isDark ? "bg-purple-500/20 text-purple-400 border border-purple-500/30" : "bg-purple-100 text-purple-700 border border-purple-200")
          }`}>
            <div className={`w-1.5 h-1.5 rounded-full ${savedPrefs ? "bg-emerald-500 animate-pulse" : "bg-purple-500"}`} />
            {savedPrefs ? "رغبتك محفوظة" : "غير محددة"}
          </div>
        </div>

        {savedPrefs ? (
          <div className="space-y-2">
            {/* Preference summary */}
            <div className={`grid grid-cols-2 gap-1.5`}>
              {[
                { icon: "🏡", label: savedPrefs.type, key: "type" },
                { icon: "📍", label: savedPrefs.location, key: "loc" },
                { icon: "💰", label: savedPrefs.budget, key: "budget" },
                { icon: "🛏️", label: savedPrefs.rooms, key: "rooms" },
              ].map(item => (
                <div key={item.key} className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg ${
                  isDark ? "bg-white/5 border border-white/10" : "bg-white border border-gray-200 shadow-sm"
                }`}>
                  <span className="text-xs">{item.icon}</span>
                  <span className={`text-[10px] font-bold truncate ${isDark ? "text-gray-300" : "text-gray-700"}`}>{item.label}</span>
                </div>
              ))}
            </div>

            {showResults && (
              <div className={`p-2.5 rounded-xl ${isDark ? "bg-emerald-500/10 border border-emerald-500/20" : "bg-emerald-50 border border-emerald-200"}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Target className={`w-3.5 h-3.5 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                    <span className={`text-[11px] font-black ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>
                      3 عقارات تطابق رغبتك
                    </span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${isDark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-200 text-emerald-800"}`}>82%+</span>
                </div>
                <div className="flex gap-1 mt-2">
                  {[97, 89, 82].map((m, i) => (
                    <div key={i} className={`flex-1 h-1 rounded-full ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500"
                        style={{ width: `${m}%` }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={e => { e.stopPropagation(); setIsOpen(true); }}
              className={`w-full py-2 rounded-xl text-xs font-bold transition-all border ${
                isDark
                  ? "bg-purple-500/10 text-purple-300 hover:bg-purple-500/20 border-purple-500/30"
                  : "bg-purple-50 text-purple-700 hover:bg-purple-100 border-purple-200"
              }`}
            >
              تعديل رغبتك ✏️
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center py-3 gap-2">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-gradient-to-br from-purple-500/20 to-pink-500/20 border ${isDark ? "border-purple-500/30" : "border-purple-200"}`}>
              <MessageSquare className={`w-6 h-6 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
            </div>
            <p className={`text-[11px] text-center leading-relaxed ${isDark ? "text-gray-400" : "text-gray-500"}`}>
              تحدث مع مساعد AI الذكي لتحديد رغبتك العقارية وإيجاد أفضل العروض المطابقة تلقائياً
            </p>
            <div className="flex items-center gap-3 mt-1 w-full">
              <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-gray-200"}`} />
              <span className={`text-[9px] ${isDark ? "text-gray-600" : "text-gray-400"}`}>6 أسئلة فقط</span>
              <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-gray-200"}`} />
            </div>
            <div className={`w-full py-2.5 rounded-xl text-xs font-black text-center text-white bg-gradient-to-r from-purple-600 to-pink-600 shadow-lg shadow-purple-500/30`}>
              ابدأ المحادثة ✨
            </div>
          </div>
        )}
      </div>

      {/* ── Full Screen Modal (Portal + RTL) ── */}
      {createPortal(
        <div dir="rtl">
          <AnimatePresence>
            {isOpen && (
              <SeekerChatModal
                isDark={isDark}
                initialPrefs={savedPrefs}
                onClose={() => setIsOpen(false)}
                onSave={(prefs) => {
                  setSavedPrefs(prefs);
                  setShowResults(true);
                  setIsOpen(false);
                }}
              />
            )}
          </AnimatePresence>
        </div>,
        document.body
      )}
    </>
  );
}

// ── Seeker Chat Modal ────────────��─────────────────────────────

function SeekerChatModal({
  isDark, initialPrefs, onClose, onSave
}: {
  isDark: boolean;
  initialPrefs: SavedPreferences | null;
  onClose: () => void;
  onSave: (prefs: SavedPreferences) => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentStep, setCurrentStep] = useState<ChatStep>("welcome");
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedLikes, setSelectedLikes] = useState<string[]>([]);
  const [selectedDislikes, setSelectedDislikes] = useState<string[]>([]);
  const [prefs, setPrefs] = useState<Partial<SavedPreferences>>({});
  const [showProperties, setShowProperties] = useState(false);
  const [searching, setSearching] = useState(false);
  const [searchSteps, setSearchSteps] = useState<number>(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const stepOrder: ChatStep[] = ["type", "location", "budget", "rooms", "likes", "dislikes"];
  const currentStepIndex = stepOrder.indexOf(currentStep as any);
  const progress = currentStepIndex < 0 ? 0 : Math.round(((currentStepIndex) / stepOrder.length) * 100);

  useEffect(() => {
    setTimeout(() => {
      addAiMessage(STEP_QUESTIONS["welcome"]);
      setCurrentStep("type");
    }, 400);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping, searching, showProperties]);

  const addAiMessage = (text: string) => {
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, { from: "ai", text, ts: new Date().toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" }) }]);
    }, 900);
  };

  const handleQuickReply = (reply: string) => {
    setMessages(prev => [...prev, { from: "user", text: reply, ts: new Date().toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" }) }]);
    const nextPrefs = { ...prefs };

    if (currentStep === "type") {
      nextPrefs.type = reply;
      setPrefs(nextPrefs);
      setCurrentStep("location");
      addAiMessage(STEP_QUESTIONS["type"]);
    } else if (currentStep === "location") {
      nextPrefs.location = reply;
      setPrefs(nextPrefs);
      setCurrentStep("budget");
      addAiMessage(STEP_QUESTIONS["location"]);
    } else if (currentStep === "budget") {
      nextPrefs.budget = reply;
      setPrefs(nextPrefs);
      setCurrentStep("rooms");
      addAiMessage(STEP_QUESTIONS["budget"]);
    } else if (currentStep === "rooms") {
      nextPrefs.rooms = reply;
      setPrefs(nextPrefs);
      setCurrentStep("likes");
      addAiMessage(STEP_QUESTIONS["rooms"]);
    }
  };

  const handleLikesDone = () => {
    setMessages(prev => [...prev, { from: "user", text: selectedLikes.length > 0 ? selectedLikes.join(" · ") : "لا تفضيل خاص" }]);
    setCurrentStep("dislikes");
    addAiMessage(STEP_QUESTIONS["likes"]);
  };

  const handleDislikesDone = () => {
    setMessages(prev => [...prev, { from: "user", text: selectedDislikes.length > 0 ? selectedDislikes.join(" · ") : "لا شروط خاصة" }]);
    setCurrentStep("done");
    addAiMessage(STEP_QUESTIONS["dislikes"]);
    setSearching(true);

    let step = 0;
    const interval = setInterval(() => {
      step++;
      setSearchSteps(step);
      if (step >= 3) {
        clearInterval(interval);
        setTimeout(() => {
          setSearching(false);
          setShowProperties(true);
        }, 600);
      }
    }, 700);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    setMessages(prev => [...prev, { from: "user", text: input }]);
    setInput("");
  };

  const finalPrefs: SavedPreferences = {
    type: prefs.type || "فيلا",
    location: prefs.location || "الملقا",
    budget: prefs.budget || "1.5M – 2M",
    rooms: prefs.rooms || "4 غرف",
    likes: selectedLikes,
    dislikes: selectedDislikes,
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ type: "spring", damping: 28, stiffness: 300 }}
      className="fixed inset-0 z-[200] flex flex-col"
      style={{ background: isDark ? "#080C1A" : "#F8FAFF" }}
    >
      {/* Header */}
      <div className={`flex-shrink-0 px-4 pt-4 pb-3 border-b ${isDark ? "border-white/8 bg-[#0A0E1F]" : "border-gray-100 bg-white"}`}>
        <div className="flex items-center gap-3 mb-3">
          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-all ${isDark ? "bg-white/8 text-gray-300 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 flex-1">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>مساعد المطابقة AI</div>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className={`text-[10px] font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>متصل الآن</span>
              </div>
            </div>
          </div>
          {/* Step indicator */}
          {currentStep !== "done" && currentStep !== "welcome" && (
            <div className={`text-[10px] font-black px-3 py-1.5 rounded-full ${isDark ? "bg-purple-500/20 text-purple-300" : "bg-purple-100 text-purple-700"}`}>
              {Math.max(1, currentStepIndex + 1)}/6
            </div>
          )}
        </div>

        {/* Progress bar */}
        {currentStep !== "done" && currentStep !== "welcome" && (
          <div className={`h-1 rounded-full overflow-hidden ${isDark ? "bg-white/8" : "bg-gray-100"}`}>
            <motion.div
              animate={{ width: `${Math.max(progress, 8)}%` }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
            />
          </div>
        )}

        {/* Live preference pills */}
        {Object.keys(prefs).length > 0 && currentStep !== "done" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-wrap gap-1 mt-2">
            {prefs.type && <PrefPill icon="🏡" label={prefs.type} isDark={isDark} />}
            {prefs.location && <PrefPill icon="📍" label={prefs.location} isDark={isDark} />}
            {prefs.budget && <PrefPill icon="💰" label={prefs.budget} isDark={isDark} />}
            {prefs.rooms && <PrefPill icon="🛏️" label={prefs.rooms} isDark={isDark} />}
          </motion.div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        <AnimatePresence initial={false}>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: "spring", damping: 24, stiffness: 350 }}
              className={`flex items-end gap-2 ${msg.from === "user" ? "flex-row-reverse" : "flex-row"}`}
            >
              {msg.from === "ai" && (
                <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center flex-shrink-0 shadow-md">
                  <Sparkles className="w-3 h-3 text-white" />
                </div>
              )}
              <div className={`max-w-[78%] ${msg.from === "user" ? "items-end" : "items-start"} flex flex-col gap-1`}>
                <div className={`px-4 py-3 text-sm whitespace-pre-wrap leading-relaxed ${
                  msg.from === "user"
                    ? "bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-2xl rounded-br-md shadow-lg shadow-purple-500/20"
                    : isDark
                      ? "bg-white/8 text-gray-100 rounded-2xl rounded-bl-md border border-white/8"
                      : "bg-white text-gray-800 rounded-2xl rounded-bl-md border border-gray-100 shadow-sm"
                }`}>
                  {msg.text}
                </div>
                {msg.ts && (
                  <span className={`text-[9px] px-1 ${isDark ? "text-gray-600" : "text-gray-400"}`}>{msg.ts}</span>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing indicator */}
        {isTyping && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-end gap-2">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-3 h-3 text-white" />
            </div>
            <div className={`px-4 py-3 rounded-2xl rounded-bl-md ${isDark ? "bg-white/8 border border-white/8" : "bg-white border border-gray-100 shadow-sm"}`}>
              <div className="flex gap-1.5 items-center h-4">
                {[0, 1, 2].map(i => (
                  <motion.div
                    key={i}
                    animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
                    transition={{ repeat: Infinity, duration: 0.7, delay: i * 0.15 }}
                    className={`w-2 h-2 rounded-full ${isDark ? "bg-purple-400" : "bg-purple-500"}`}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Quick Replies */}
        {!isTyping && QUICK_REPLIES[currentStep] && currentStep !== "likes" && currentStep !== "dislikes" && currentStep !== "done" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-wrap gap-2 pt-1">
            {QUICK_REPLIES[currentStep].map((reply, i) => (
              <motion.button
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => handleQuickReply(`${reply.icon} ${reply.label}`)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                  isDark
                    ? "border-purple-500/30 text-purple-300 bg-purple-500/10 hover:bg-purple-500/20"
                    : "border-purple-200 text-purple-700 bg-purple-50 hover:bg-purple-100"
                }`}
              >
                <span>{reply.icon}</span>
                {reply.label}
              </motion.button>
            ))}
          </motion.div>
        )}

        {/* Likes Multi-Select */}
        {!isTyping && currentStep === "likes" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
            <div className={`text-[10px] font-bold mb-2 ${isDark ? "text-gray-500" : "text-gray-400"}`}>اختر كل ما ينطبق:</div>
            <div className="flex flex-wrap gap-2">
              {QUICK_REPLIES.likes.map((item, i) => (
                <motion.button
                  key={i}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedLikes(prev =>
                    prev.includes(item.label) ? prev.filter(x => x !== item.label) : [...prev, item.label]
                  )}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                    selectedLikes.includes(item.label)
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white border-transparent shadow-md shadow-purple-500/20"
                      : isDark
                        ? "border-white/15 text-gray-300 bg-white/5 hover:bg-white/10"
                        : "border-gray-200 text-gray-600 bg-white hover:bg-gray-50"
                  }`}
                >
                  <span>{item.icon}</span>
                  {item.label}
                  {selectedLikes.includes(item.label) && <Check className="w-3 h-3 ml-0.5" />}
                </motion.button>
              ))}
            </div>
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={handleLikesDone}
              className="w-full py-3 rounded-xl text-xs font-black bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25"
            >
              {selectedLikes.length > 0 ? `تأكيد ${selectedLikes.length} ميزة ←` : "تخطي ←"}
            </motion.button>
          </motion.div>
        )}

        {/* Dislikes Multi-Select */}
        {!isTyping && currentStep === "dislikes" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
            <div className={`text-[10px] font-bold mb-2 ${isDark ? "text-gray-500" : "text-gray-400"}`}>ضع شروطك الصارمة:</div>
            <div className="flex flex-wrap gap-2">
              {QUICK_REPLIES.dislikes.map((item, i) => (
                <motion.button
                  key={i}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedDislikes(prev =>
                    prev.includes(item.label) ? prev.filter(x => x !== item.label) : [...prev, item.label]
                  )}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                    selectedDislikes.includes(item.label)
                      ? "bg-gradient-to-r from-red-500 to-orange-500 text-white border-transparent shadow-md"
                      : isDark
                        ? "border-white/15 text-gray-300 bg-white/5 hover:bg-white/10"
                        : "border-gray-200 text-gray-600 bg-white hover:bg-gray-50"
                  }`}
                >
                  <span>{item.icon}</span>
                  {item.label}
                  {selectedDislikes.includes(item.label) && <X className="w-3 h-3" />}
                </motion.button>
              ))}
            </div>
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={handleDislikesDone}
              className="w-full py-3 rounded-xl text-xs font-black bg-gradient-to-r from-red-500 to-orange-500 text-white shadow-lg"
            >
              {selectedDislikes.length > 0 ? `تأكيد ${selectedDislikes.length} شرط وابدأ البحث 🚀` : "لا شروط – ابدأ البحث 🚀"}
            </motion.button>
          </motion.div>
        )}

        {/* AI Scanning Animation */}
        {searching && (
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`rounded-2xl p-4 border ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-sm"}`}
          >
            <div className="flex items-center gap-3 mb-4">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center flex-shrink-0"
              >
                <Target className="w-5 h-5 text-white" />
              </motion.div>
              <div>
                <div className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>يبحث AI في قاعدة البيانات</div>
                <div className={`text-[10px] ${isDark ? "text-gray-500" : "text-gray-400"}`}>12,400 عقار متاح</div>
              </div>
            </div>

            <div className="space-y-2.5">
              {[
                { label: "يحلل تفضيلاتك الـ 6", icon: "🧠" },
                { label: "يمسح قاعدة العقارات", icon: "🔍" },
                { label: "يحسب نسبة التطابق", icon: "📊" },
              ].map((s, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: searchSteps > i ? 1 : 0.3, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-center gap-2.5"
                >
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs ${
                    searchSteps > i
                      ? "bg-emerald-500/20 text-emerald-400"
                      : isDark ? "bg-white/5" : "bg-gray-100"
                  }`}>
                    {searchSteps > i ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : s.icon}
                  </div>
                  <span className={`text-xs font-bold ${searchSteps > i ? (isDark ? "text-gray-200" : "text-gray-700") : (isDark ? "text-gray-600" : "text-gray-400")}`}>{s.label}</span>
                  {searchSteps > i && (
                    <span className={`text-[10px] mr-auto ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>✓ تم</span>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Progress bar */}
            <div className={`mt-3 h-1.5 rounded-full overflow-hidden ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
              <motion.div
                animate={{ width: `${Math.round((searchSteps / 3) * 100)}%` }}
                transition={{ duration: 0.4 }}
                className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
              />
            </div>
          </motion.div>
        )}

        {/* Results */}
        {showProperties && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
            {/* Summary banner */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`p-4 rounded-2xl border ${isDark ? "bg-emerald-500/10 border-emerald-500/20" : "bg-emerald-50 border-emerald-200"}`}
            >
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className={`w-5 h-5 ${isDark ? "text-emerald-400" : "text-emerald-600"}`} />
                <span className={`text-sm font-black ${isDark ? "text-emerald-300" : "text-emerald-700"}`}>
                  وجدت 3 عقارات تطابق رغبتك! 🎉
                </span>
              </div>
              {/* Preference summary row */}
              <div className="flex flex-wrap gap-1">
                {[
                  prefs.type && `🏡 ${prefs.type}`,
                  prefs.location && `📍 ${prefs.location}`,
                  prefs.budget && `💰 ${prefs.budget}`,
                  prefs.rooms && `🛏️ ${prefs.rooms}`,
                ].filter(Boolean).map((p, i) => (
                  <span key={i} className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${isDark ? "bg-emerald-500/20 text-emerald-300" : "bg-emerald-200 text-emerald-800"}`}>
                    {p}
                  </span>
                ))}
              </div>
            </motion.div>

            {MATCHED_PROPERTIES.map((prop, i) => (
              <motion.div
                key={prop.id}
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.12 }}
                className={`p-4 rounded-2xl border relative overflow-hidden ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-sm"}`}
              >
                {/* Match badge */}
                <div className={`absolute top-3 left-3 px-2 py-1 rounded-lg text-[11px] font-black ${
                  prop.match >= 90
                    ? (isDark ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-emerald-100 text-emerald-700")
                    : (isDark ? "bg-blue-500/20 text-blue-400 border border-blue-500/30" : "bg-blue-100 text-blue-700")
                }`}>
                  {prop.match}% تطابق
                </div>

                <div className="mb-3 pr-1">
                  <div className={`text-sm font-black mb-0.5 ${isDark ? "text-white" : "text-gray-900"}`}>{prop.name}</div>
                  <div className={`text-[11px] ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                    {prop.location} · {prop.rooms} غرف
                  </div>
                </div>

                <div className={`h-1.5 rounded-full mb-3 ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${prop.match}%` }}
                    transition={{ duration: 1, delay: 0.3 + i * 0.1 }}
                    className={`h-full rounded-full ${
                      prop.match >= 90
                        ? "bg-gradient-to-r from-emerald-500 to-cyan-500"
                        : "bg-gradient-to-r from-blue-500 to-purple-500"
                    }`}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className={`text-sm font-black ${isDark ? "text-cyan-400" : "text-blue-600"}`}>{prop.price}</span>
                  <span className={`text-[10px] px-2 py-1 rounded-full font-bold ${isDark ? "bg-purple-500/15 text-purple-400" : "bg-purple-100 text-purple-700"}`}>
                    {prop.tag}
                  </span>
                </div>
              </motion.div>
            ))}

            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onSave(finalPrefs)}
              className="w-full py-4 rounded-2xl text-sm font-black bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-xl shadow-purple-500/30"
            >
              💾 حفظ رغبتي وتفعيل التنبيهات الذكية
            </motion.button>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input bar */}
      {currentStep !== "done" && !searching && !showProperties && (
        <div className={`flex-shrink-0 px-4 py-3 border-t ${isDark ? "border-white/8 bg-[#0A0E1F]" : "border-gray-100 bg-white"}`}>
          <div className={`flex items-center gap-2 px-3 py-2 rounded-2xl border ${isDark ? "bg-white/5 border-white/10" : "bg-gray-50 border-gray-200"}`}>
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSend()}
              placeholder="أو اكتب ردك هنا..."
              className={`flex-1 bg-transparent text-sm outline-none ${isDark ? "text-white placeholder-gray-600" : "text-gray-900 placeholder-gray-400"}`}
            />
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={handleSend}
              disabled={!input.trim()}
              className={`p-2 rounded-xl transition-all ${
                input.trim()
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md"
                  : isDark ? "bg-white/5 text-gray-600" : "bg-gray-200 text-gray-400"
              }`}
            >
              <Send className="w-3.5 h-3.5" />
            </motion.button>
          </div>
        </div>
      )}
    </motion.div>
  );
}

function PrefPill({ icon, label, isDark }: { icon: string; label: string; isDark: boolean }) {
  return (
    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold ${
      isDark ? "bg-purple-500/15 text-purple-300 border border-purple-500/20" : "bg-purple-50 text-purple-700 border border-purple-200"
    }`}>
      {icon} {label}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────
//  DEVELOPER MATCHING ASSISTANT
// ─────────────────────────────────────────────────────────────

interface Project {
  id: number;
  name: string;
  type: string;
  location: string;
  units: number;
  price: string;
  progress: number;
  color: string;
  icon: string;
}

interface MatchedSeeker {
  id: number;
  name: string;
  initials: string;
  want: string;
  budget: string;
  location: string;
  match: number;
  isVip: boolean;
  preferences: string[];
  lastActive: string;
}

const DEVELOPER_PROJECTS: Record<string, Project[]> = {
  starter: [
    { id: 1, name: "مشروع النرجس السكني", type: "فلل سكنية", location: "النرجس", units: 12, price: "1.8M – 2.2M", progress: 75, color: "blue", icon: "��️" },
  ],
  business: [
    { id: 1, name: "مشروع النرجس السكني", type: "فلل سكنية", location: "النرجس", units: 12, price: "1.8M – 2.2M", progress: 75, color: "blue", icon: "🏘️" },
    { id: 2, name: "أبراج العليا التجارية", type: "شقق تجارية", location: "العليا", units: 48, price: "900K – 1.4M", progress: 45, color: "purple", icon: "🏢" },
    { id: 3, name: "فلل الملقا الفاخرة", type: "فلل فاخرة", location: "الملقا", units: 8, price: "3M – 4.5M", progress: 90, color: "amber", icon: "🏰" },
  ],
  enterprise: [
    { id: 1, name: "مشروع النرجس السكني", type: "فلل سكنية", location: "النرجس", units: 12, price: "1.8M – 2.2M", progress: 75, color: "blue", icon: "🏘️" },
    { id: 2, name: "أبراج العليا التجارية", type: "شقق تجارية", location: "العليا", units: 48, price: "900K – 1.4M", progress: 45, color: "purple", icon: "🏢" },
    { id: 3, name: "فلل الملقا الفاخرة", type: "فلل فاخرة", location: "الملقا", units: 8, price: "3M – 4.5M", progress: 90, color: "amber", icon: "🏰" },
    { id: 4, name: "مجمع الرياض الكبير", type: "مجمع متكامل", location: "شمال الرياض", units: 120, price: "600K – 1.2M", progress: 30, color: "emerald", icon: "🏙️" },
  ],
};

const MATCHED_SEEKERS: MatchedSeeker[] = [
  { id: 1, name: "محمد العتيبي", initials: "م", want: "فيلا 4 غرف", budget: "2M ر.س", location: "النرجس / الملقا", match: 97, isVip: true, preferences: ["مسبح خاص", "حديقة"], lastActive: "منذ 5 د" },
  { id: 2, name: "سارة الشمري", initials: "س", want: "فيلا 5 غرف + مسبح", budget: "2.5M ر.س", location: "النرجس", match: 91, isVip: true, preferences: ["قريب مدارس", "هدوء"], lastActive: "منذ 22 د" },
  { id: 3, name: "خالد المالك", initials: "خ", want: "فيلا فاخرة", budget: "1.9M ر.س", location: "شمال الرياض", match: 85, isVip: false, preferences: ["حديقة واسعة"], lastActive: "منذ 1 س" },
  { id: 4, name: "نورة العمري", initials: "ن", want: "فيلا 4 غرف – قريبة مدارس", budget: "2.2M ر.س", location: "النرجس", match: 82, isVip: false, preferences: ["قريب مدارس", "هادئ"], lastActive: "منذ 2 س" },
  { id: 5, name: "فيصل الغامدي", initials: "ف", want: "فيلا مع حديقة كبيرة", budget: "1.8M ر.س", location: "الملقا / النرجس", match: 78, isVip: false, preferences: ["حديقة", "هدوء تام"], lastActive: "أمس" },
];

type DevFilter = "all" | "vip" | "top";

export function DeveloperMatchingAssistant({ tier, isDark }: { tier: "starter" | "business" | "enterprise"; isDark: boolean }) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeMode, setActiveMode] = useState<"marketing" | "search" | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [sentCount, setSentCount] = useState(0);
  const [allSent, setAllSent] = useState(false);
  const [devSeekerPrefs, setDevSeekerPrefs] = useState<SavedPreferences | null>(null);

  const projects = DEVELOPER_PROJECTS[tier];

  const handleOpenWidget = () => {
    setIsOpen(true);
    setActiveMode(null);
  };

  const handleClose = () => {
    setIsOpen(false);
    setActiveMode(null);
  };

  return (
    <>
      {/* ── Widget Card ── */}
      <div
        onClick={handleOpenWidget}
        className={`cursor-pointer rounded-2xl border p-4 transition-all hover:scale-[1.01] active:scale-[0.99] relative overflow-hidden ${
          isDark
            ? "bg-gradient-to-br from-blue-950/60 to-cyan-950/60 border-blue-500/30 hover:border-blue-400/60"
            : "bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 hover:border-blue-400"
        }`}
      >
        {/* Glow accent */}
        <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full bg-blue-500/10 blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Target className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>مساعد المطابقة AI</div>
              <div className={`text-[9px] ${isDark ? "text-blue-400" : "text-blue-600"}`}>تسويق مشاريعك · ابحث عن عقار</div>
            </div>
          </div>
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold border ${
            isDark ? "bg-blue-500/20 text-blue-400 border-blue-500/30" : "bg-blue-100 text-blue-700 border-blue-200"
          }`}>
            <Zap className="w-3 h-3" />
            {MATCHED_SEEKERS.length} مطابق
          </div>
        </div>

        {selectedProject ? (
          <div className="space-y-2">
            {/* Selected project summary */}
            <div className={`p-3 rounded-xl border ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-sm"}`}>
              <div className="flex items-center gap-2">
                <span className="text-base">{selectedProject.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className={`text-xs font-black truncate ${isDark ? "text-white" : "text-gray-900"}`}>{selectedProject.name}</div>
                  <div className={`text-[10px] ${isDark ? "text-gray-400" : "text-gray-500"}`}>{selectedProject.location} · {selectedProject.units} وحدة</div>
                </div>
              </div>
              <div className={`mt-2 h-1 rounded-full ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
                <div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-500" style={{ width: `${selectedProject.progress}%` }} />
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { label: "مطابق", value: MATCHED_SEEKERS.length.toString(), color: "blue" },
                { label: "VIP", value: MATCHED_SEEKERS.filter(s => s.isVip).length.toString(), color: "purple" },
                { label: "تم الإرسال", value: allSent ? MATCHED_SEEKERS.length.toString() : sentCount.toString(), color: allSent ? "emerald" : "gray" },
              ].map((s, i) => (
                <div key={i} className={`p-2 rounded-xl text-center ${isDark ? "bg-white/5 border border-white/8" : "bg-white border border-gray-100"}`}>
                  <div className={`text-sm font-black ${
                    s.color === "blue" ? (isDark ? "text-blue-400" : "text-blue-700") :
                    s.color === "purple" ? (isDark ? "text-purple-400" : "text-purple-700") :
                    s.color === "emerald" ? (isDark ? "text-emerald-400" : "text-emerald-700") :
                    (isDark ? "text-gray-400" : "text-gray-500")
                  }`}>{s.value}</div>
                  <div className={`text-[9px] ${isDark ? "text-gray-600" : "text-gray-400"}`}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Top 2 seekers preview */}
            <div className="flex gap-1.5">
              {MATCHED_SEEKERS.slice(0, 2).map(s => (
                <div key={s.id} className={`flex-1 flex items-center gap-1.5 p-2 rounded-xl ${isDark ? "bg-white/5 border border-white/8" : "bg-white border border-gray-100"}`}>
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-black flex-shrink-0 ${
                    s.isVip ? "bg-gradient-to-br from-purple-500 to-pink-500 text-white" : isDark ? "bg-white/10 text-gray-300" : "bg-gray-100 text-gray-600"
                  }`}>{s.initials}</div>
                  <div className="min-w-0">
                    <div className={`text-[9px] font-black truncate ${isDark ? "text-white" : "text-gray-800"}`}>{s.name.split(" ")[0]}</div>
                    <div className={`text-[9px] font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>{s.match}%</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Seeker prefs preview if saved */}
            {devSeekerPrefs && (
              <div className={`p-2.5 rounded-xl border ${isDark ? "bg-purple-500/10 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
                <div className="flex items-center gap-1.5 mb-1">
                  <Sparkles className={`w-3 h-3 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                  <span className={`text-[10px] font-black ${isDark ? "text-purple-300" : "text-purple-700"}`}>رغبتك العقارية محفوظة</span>
                </div>
                <div className="flex gap-1 flex-wrap">
                  {[devSeekerPrefs.type, devSeekerPrefs.location, devSeekerPrefs.budget].map((v, i) => (
                    <span key={i} className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${isDark ? "bg-purple-500/20 text-purple-300" : "bg-purple-100 text-purple-700"}`}>{v}</span>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={e => { e.stopPropagation(); handleOpenWidget(); }}
              className={`w-full py-2 rounded-xl text-xs font-bold border transition-all ${
                isDark
                  ? "bg-blue-500/10 text-blue-300 hover:bg-blue-500/20 border-blue-500/30"
                  : "bg-blue-50 text-blue-700 hover:bg-blue-100 border-blue-200"
              }`}
            >
              {allSent ? "تم الإرسال للجميع ✓" : "إدارة وإرسال العروض ←"}
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center py-3 gap-2">
            {/* Two mode preview badges */}
            <div className="flex gap-2 w-full">
              <div className={`flex-1 flex items-center gap-1.5 px-2.5 py-2 rounded-xl border ${isDark ? "bg-blue-500/10 border-blue-500/20" : "bg-blue-50 border-blue-200"}`}>
                <Target className={`w-3.5 h-3.5 flex-shrink-0 ${isDark ? "text-blue-400" : "text-blue-600"}`} />
                <span className={`text-[9px] font-black ${isDark ? "text-blue-300" : "text-blue-700"}`}>تسويق المشاريع</span>
              </div>
              <div className={`flex-1 flex items-center gap-1.5 px-2.5 py-2 rounded-xl border ${isDark ? "bg-purple-500/10 border-purple-500/20" : "bg-purple-50 border-purple-200"}`}>
                <Sparkles className={`w-3.5 h-3.5 flex-shrink-0 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                <span className={`text-[9px] font-black ${isDark ? "text-purple-300" : "text-purple-700"}`}>بحث عقاري</span>
              </div>
            </div>
            <p className={`text-[11px] text-center leading-relaxed ${isDark ? "text-gray-400" : "text-gray-500"}`}>
              سوّق مشاريعك للباحثين المطابقين أو ابحث عن عقار مثالي لنفسك
            </p>
            {/* ✅ Saved search prefs — visible even with NO selected project */}
            <AnimatePresence>
              {devSeekerPrefs ? (
                <motion.div
                  key="saved-prefs-no-project"
                  initial={{ opacity: 0, scale: 0.95, y: -4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ type: "spring", damping: 20, stiffness: 300 }}
                  className={`w-full p-2.5 rounded-xl border ${isDark ? "bg-purple-500/10 border-purple-500/30" : "bg-purple-50 border-purple-200"}`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <Sparkles className={`w-3 h-3 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
                      <span className={`text-[10px] font-black ${isDark ? "text-purple-300" : "text-purple-700"}`}>
                        بحثك العقاري محفوظ ✓
                      </span>
                    </div>
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  </div>
                  <div className="flex gap-1 flex-wrap">
                    {[devSeekerPrefs.type, devSeekerPrefs.location, devSeekerPrefs.budget, devSeekerPrefs.rooms]
                      .filter(Boolean)
                      .map((v, i) => (
                        <span key={i} className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${isDark ? "bg-purple-500/20 text-purple-300" : "bg-purple-100 text-purple-700"}`}>
                          {v}
                        </span>
                      ))}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="no-prefs-hint"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className={`w-full px-3 py-2 rounded-xl border border-dashed text-center ${isDark ? "border-purple-500/20 bg-purple-500/5" : "border-purple-200 bg-purple-50/50"}`}
                >
                  <span className={`text-[9px] ${isDark ? "text-purple-500" : "text-purple-400"}`}>
                    ابدأ البحث العقاري لحفظ رغبتك هنا
                  </span>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-center gap-3 mt-1 w-full">
              <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-gray-200"}`} />
              <span className={`text-[9px] ${isDark ? "text-gray-600" : "text-gray-400"}`}>{MATCHED_SEEKERS.length} باحث جاهز</span>
              <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-gray-200"}`} />
            </div>
            <div className={`w-full py-2.5 rounded-xl text-xs font-black text-center text-white bg-gradient-to-r from-blue-600 to-cyan-600 shadow-lg shadow-blue-500/30`}>
              اختر الخدمة 🎯
            </div>
          </div>
        )}
      </div>

      {/* ── Modals via Portal (escape motion.div transform + RTL) ── */}
      {createPortal(
        <div dir="rtl">
          <AnimatePresence>
            {isOpen && activeMode === null && (
              <DevModeSelectModal
                isDark={isDark}
                onClose={handleClose}
                onSelectMarketing={() => setActiveMode("marketing")}
                onSelectSearch={() => setActiveMode("search")}
              />
            )}
          </AnimatePresence>

          <AnimatePresence>
            {isOpen && activeMode === "marketing" && (
              <DevMatchingModal
                isDark={isDark}
                projects={projects}
                initialProject={selectedProject}
                onClose={handleClose}
                onProjectSelect={p => setSelectedProject(p)}
                onSentAll={() => { setAllSent(true); setSentCount(MATCHED_SEEKERS.length); }}
                onSentOne={() => setSentCount(prev => prev + 1)}
              />
            )}
          </AnimatePresence>

          <AnimatePresence>
            {isOpen && activeMode === "search" && (
              <SeekerChatModal
                isDark={isDark}
                initialPrefs={devSeekerPrefs}
                onClose={handleClose}
                onSave={(prefs) => {
                  setDevSeekerPrefs(prefs);
                  handleClose();
                }}
              />
            )}
          </AnimatePresence>
        </div>,
        document.body
      )}
    </>
  );
}

// ── Dev Mode Select Modal ────────────────────────────────────────

function DevModeSelectModal({
  isDark, onClose, onSelectMarketing, onSelectSearch
}: {
  isDark: boolean;
  onClose: () => void;
  onSelectMarketing: () => void;
  onSelectSearch: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ type: "spring", damping: 28, stiffness: 300 }}
      className="fixed inset-0 z-[200] flex flex-col"
      style={{ background: isDark ? "#080C1A" : "#F8FAFF" }}
    >
      {/* Header */}
      <div className={`flex-shrink-0 px-4 py-4 border-b ${isDark ? "border-white/8 bg-[#0A0E1F]" : "border-gray-100 bg-white"}`}>
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-all ${isDark ? "bg-white/8 text-gray-300 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 flex-1">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Target className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>مساعد المطابقة AI</div>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className={`text-[10px] font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>اختر وضع الاستخدام</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-center px-5 py-8 gap-5">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-center"
        >
          <div className={`text-lg font-black mb-1.5 ${isDark ? "text-white" : "text-gray-900"}`}>ماذا تريد أن تفعل؟</div>
          <div className={`text-xs leading-relaxed ${isDark ? "text-gray-400" : "text-gray-500"}`}>
            اختر الخدمة التي تناسب احتياجك الآن
          </div>
        </motion.div>

        {/* Mode 1 — Marketing */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.18, type: "spring", damping: 22 }}
          whileHover={{ scale: 1.025 }}
          whileTap={{ scale: 0.975 }}
          onClick={onSelectMarketing}
          className={`w-full p-5 rounded-2xl border text-right transition-all relative overflow-hidden ${
            isDark
              ? "bg-gradient-to-br from-blue-950/70 to-cyan-950/70 border-blue-500/40 hover:border-blue-400/70"
              : "bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 hover:border-blue-400 hover:shadow-lg"
          }`}
        >
          {/* Glow */}
          <div className="absolute -top-8 -right-8 w-28 h-28 rounded-full bg-blue-500/10 blur-2xl pointer-events-none" />

          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-xl shadow-blue-500/35 flex-shrink-0">
              <Target className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className={`text-sm font-black mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
                إيجاد مطابقين لمشروعك
              </div>
              <div className={`text-[11px] leading-relaxed mb-3 ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                اختر مشروعاً وأرسل عروضك للباحثين الأكثر تطابقاً مع مواصفاته تلقائياً
              </div>
              <div className="flex flex-wrap gap-1.5">
                {["🎯 تسويق المشاريع", "👥 5 مطابقين", "⚡ إرسال ذكي"].map((tag, i) => (
                  <span key={i} className={`text-[9px] px-2 py-1 rounded-lg font-bold ${
                    isDark ? "bg-blue-500/15 text-blue-300 border border-blue-500/20" : "bg-blue-100 text-blue-700"
                  }`}>{tag}</span>
                ))}
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 flex-shrink-0 mt-1 rotate-180 ${isDark ? "text-blue-400" : "text-blue-500"}`} />
          </div>

          {/* Bottom badge */}
          <div className={`mt-4 pt-3 border-t flex items-center gap-2 ${isDark ? "border-white/8" : "border-blue-100"}`}>
            <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl ${isDark ? "bg-blue-500/15" : "bg-blue-100"}`}>
              <Zap className={`w-3 h-3 ${isDark ? "text-blue-400" : "text-blue-600"}`} />
              <span className={`text-[10px] font-black ${isDark ? "text-blue-300" : "text-blue-700"}`}>الوضع الأول: تسويق المشاريع</span>
            </div>
          </div>
        </motion.button>

        {/* Divider */}
        <div className="flex items-center gap-3">
          <div className={`flex-1 h-px ${isDark ? "bg-white/8" : "bg-gray-200"}`} />
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${isDark ? "text-gray-500 border-white/10 bg-white/5" : "text-gray-400 border-gray-200 bg-white"}`}>أو</span>
          <div className={`flex-1 h-px ${isDark ? "bg-white/8" : "bg-gray-200"}`} />
        </div>

        {/* Mode 2 — Search (Seeker style) */}
        <motion.button
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.26, type: "spring", damping: 22 }}
          whileHover={{ scale: 1.025 }}
          whileTap={{ scale: 0.975 }}
          onClick={onSelectSearch}
          className={`w-full p-5 rounded-2xl border text-right transition-all relative overflow-hidden ${
            isDark
              ? "bg-gradient-to-br from-purple-950/70 to-pink-950/70 border-purple-500/40 hover:border-purple-400/70"
              : "bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200 hover:border-purple-400 hover:shadow-lg"
          }`}
        >
          {/* Glow */}
          <div className="absolute -top-8 -right-8 w-28 h-28 rounded-full bg-purple-500/10 blur-2xl pointer-events-none" />

          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-xl shadow-purple-500/35 flex-shrink-0">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className={`text-sm font-black mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>
                البحث عن عقار لنفسك
              </div>
              <div className={`text-[11px] leading-relaxed mb-3 ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                تحدث مع مساعد AI الذكي لتحديد رغبتك العقارية وإيجاد أفضل العروض المطابقة تلقائياً
              </div>
              <div className="flex flex-wrap gap-1.5">
                {["🔍 بحث ذكي", "💬 6 أسئ��ة", "🏡 12,400+ عقار"].map((tag, i) => (
                  <span key={i} className={`text-[9px] px-2 py-1 rounded-lg font-bold ${
                    isDark ? "bg-purple-500/15 text-purple-300 border border-purple-500/20" : "bg-purple-100 text-purple-700"
                  }`}>{tag}</span>
                ))}
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 flex-shrink-0 mt-1 rotate-180 ${isDark ? "text-purple-400" : "text-purple-500"}`} />
          </div>

          {/* Bottom badge */}
          <div className={`mt-4 pt-3 border-t flex items-center gap-2 ${isDark ? "border-white/8" : "border-purple-100"}`}>
            <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl ${isDark ? "bg-purple-500/15" : "bg-purple-100"}`}>
              <Search className={`w-3 h-3 ${isDark ? "text-purple-400" : "text-purple-600"}`} />
              <span className={`text-[10px] font-black ${isDark ? "text-purple-300" : "text-purple-700"}`}>الوضع الثاني: البحث العقاري</span>
            </div>
          </div>
        </motion.button>
      </div>
    </motion.div>
  );
}

// ── Developer Matching Modal ────────────────────────────────────

type DevModalStep = "select" | "loading" | "results" | "success";

function DevMatchingModal({
  isDark, projects, initialProject, onClose, onProjectSelect, onSentAll, onSentOne
}: {
  isDark: boolean;
  projects: Project[];
  initialProject: Project | null;
  onClose: () => void;
  onProjectSelect: (p: Project) => void;
  onSentAll: () => void;
  onSentOne: () => void;
}) {
  const [step, setStep] = useState<DevModalStep>(initialProject ? "results" : "select");
  const [selectedProject, setSelectedProject] = useState<Project | null>(initialProject);
  const [sentIds, setSentIds] = useState<Set<number>>(new Set());
  const [allSent, setAllSent] = useState(false);
  const [filter, setFilter] = useState<DevFilter>("all");
  const [loadingStep, setLoadingStep] = useState(0);

  const seekers = MATCHED_SEEKERS;
  const filteredSeekers = filter === "vip"
    ? seekers.filter(s => s.isVip)
    : filter === "top"
      ? seekers.filter(s => s.match >= 85)
      : seekers;

  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
    onProjectSelect(project);
    setStep("loading");
    setLoadingStep(0);

    let ls = 0;
    const interval = setInterval(() => {
      ls++;
      setLoadingStep(ls);
      if (ls >= 4) {
        clearInterval(interval);
        setTimeout(() => setStep("results"), 400);
      }
    }, 500);
  };

  const handleSend = (id: number) => {
    setSentIds(prev => new Set([...prev, id]));
    onSentOne();
  };

  const handleSendAll = () => {
    setSentIds(new Set(seekers.map(s => s.id)));
    setAllSent(true);
    onSentAll();
    setTimeout(() => setStep("success"), 400);
  };

  const unsentCount = filteredSeekers.filter(s => !sentIds.has(s.id)).length;

  const projectColorMap: Record<string, string> = {
    blue: "from-blue-500 to-cyan-500",
    purple: "from-purple-500 to-pink-500",
    amber: "from-amber-500 to-orange-500",
    emerald: "from-emerald-500 to-teal-500",
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ type: "spring", damping: 28, stiffness: 300 }}
      className="fixed inset-0 z-[200] flex flex-col"
      style={{ background: isDark ? "#080C1A" : "#F8FAFF" }}
    >
      {/* Header */}
      <div className={`flex-shrink-0 px-4 py-3 border-b ${isDark ? "border-white/8 bg-[#0A0E1F]" : "border-gray-100 bg-white"}`}>
        <div className="flex items-center gap-3">
          <button
            onClick={step === "results" ? () => setStep("select") : step === "success" ? () => setStep("results") : onClose}
            className={`p-2 rounded-xl ${isDark ? "bg-white/8 text-gray-300 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-blue-500/30 flex-shrink-0">
            <Target className="w-4 h-4 text-white" />
          </div>

          <div className="flex-1 min-w-0">
            <div className={`text-sm font-black truncate ${isDark ? "text-white" : "text-gray-900"}`}>
              {step === "select" && "اختر المشروع"}
              {step === "loading" && "يبحث AI عن المطابقين..."}
              {step === "results" && "الباحثون المطابقون"}
              {step === "success" && "تم الإرسال بنجاح! 🎉"}
            </div>
            {selectedProject && step !== "select" && (
              <div className={`text-[10px] font-bold truncate ${isDark ? "text-blue-400" : "text-blue-600"}`}>
                {selectedProject.icon} {selectedProject.name}
              </div>
            )}
          </div>

          {step === "results" && (
            <div className={`flex-shrink-0 text-[10px] px-2.5 py-1.5 rounded-xl font-black border ${
              isDark ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" : "bg-emerald-100 text-emerald-700 border-emerald-200"
            }`}>
              {sentIds.size}/{seekers.length} أُرسل
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* ── Step 1: Select Project ── */}
        {step === "select" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 space-y-3">
            <div className={`p-3 rounded-xl border ${isDark ? "bg-blue-500/10 border-blue-500/20" : "bg-blue-50 border-blue-200"}`}>
              <p className={`text-xs leading-relaxed ${isDark ? "text-blue-300" : "text-blue-700"}`}>
                🎯 اختر المشروع المراد الترويج له. سيقوم AI بتحليل 2,000+ باحث وإيجاد الأكثر تطابقاً مع مواصفاته.
              </p>
            </div>

            {projects.map((project, i) => (
              <motion.button
                key={project.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.07 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleSelectProject(project)}
                className={`w-full p-4 rounded-2xl border text-right transition-all ${
                  isDark
                    ? "bg-white/5 border-white/10 hover:bg-white/8 hover:border-blue-500/40"
                    : "bg-white border-gray-200 hover:border-blue-400 hover:shadow-md"
                }`}
              >
                {/* Project header */}
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-2xl bg-gradient-to-br ${projectColorMap[project.color]} flex items-center justify-center flex-shrink-0 text-lg shadow-md`}>
                    {project.icon}
                  </div>
                  <div className="flex-1 min-w-0 text-right">
                    <div className={`text-sm font-black mb-0.5 ${isDark ? "text-white" : "text-gray-900"}`}>{project.name}</div>
                    <div className={`text-[11px] ${isDark ? "text-gray-400" : "text-gray-500"}`}>{project.type} · {project.location}</div>
                  </div>
                  <ChevronRight className={`w-4 h-4 flex-shrink-0 rotate-180 ${isDark ? "text-gray-600" : "text-gray-400"}`} />
                </div>

                {/* Badges */}
                <div className="flex items-center gap-1.5 flex-wrap justify-end mb-3">
                  <span className={`text-[10px] px-2 py-1 rounded-lg font-bold ${isDark ? "bg-cyan-500/15 text-cyan-400" : "bg-cyan-100 text-cyan-700"}`}>
                    {project.units} وحدة
                  </span>
                  <span className={`text-[10px] px-2 py-1 rounded-lg font-bold ${isDark ? "bg-purple-500/15 text-purple-400" : "bg-purple-100 text-purple-700"}`}>
                    {project.price}
                  </span>
                  <span className={`text-[10px] px-2 py-1 rounded-lg font-bold ${
                    project.progress >= 80
                      ? (isDark ? "bg-emerald-500/15 text-emerald-400" : "bg-emerald-100 text-emerald-700")
                      : (isDark ? "bg-amber-500/15 text-amber-400" : "bg-amber-100 text-amber-700")
                  }`}>
                    {project.progress}% مكتمل
                  </span>
                </div>

                {/* Progress bar */}
                <div className={`h-1.5 rounded-full overflow-hidden ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${projectColorMap[project.color]}`}
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
              </motion.button>
            ))}
          </motion.div>
        )}

        {/* ── Step 2: Loading ── */}
        {step === "loading" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center h-full py-16 px-6 gap-5"
          >
            {/* Animated orb */}
            <div className="relative">
              <motion.div
                animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0.8, 0.5] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute inset-0 rounded-3xl bg-blue-500/20 blur-xl"
              />
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
                className="relative w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-2xl shadow-blue-500/40"
              >
                <Target className="w-10 h-10 text-white" />
              </motion.div>
            </div>

            <div className="text-center">
              <div className={`text-base font-black mb-1 ${isDark ? "text-white" : "text-gray-900"}`}>يبحث AI عن المطابقين</div>
              <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>يفحص 2,000+ باحث نشط</div>
            </div>

            <div className="w-full max-w-xs space-y-2.5">
              {[
                { label: "يحلل مواصفات المشروع", icon: "🏗️" },
                { label: "يفحص رغبات الباحثين", icon: "🔍" },
                { label: "يحسب نسب التطابق", icon: "📊" },
                { label: "يرتب القائمة بالأعلى", icon: "🏆" },
              ].map((s, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: loadingStep > i ? 1 : 0.25, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-sm flex-shrink-0 transition-all ${
                    loadingStep > i
                      ? "bg-emerald-500/20 border border-emerald-500/30"
                      : isDark ? "bg-white/5" : "bg-gray-100"
                  }`}>
                    {loadingStep > i ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : s.icon}
                  </div>
                  <span className={`text-xs font-bold flex-1 ${loadingStep > i ? (isDark ? "text-gray-200" : "text-gray-700") : (isDark ? "text-gray-600" : "text-gray-400")}`}>
                    {s.label}
                  </span>
                  {loadingStep > i && (
                    <span className={`text-[10px] font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>✓</span>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Progress bar */}
            <div className={`w-full max-w-xs h-2 rounded-full overflow-hidden ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
              <motion.div
                animate={{ width: `${Math.round((loadingStep / 4) * 100)}%` }}
                transition={{ duration: 0.3 }}
                className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-500"
              />
            </div>
          </motion.div>
        )}

        {/* ── Step 3: Results ── */}
        {step === "results" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 space-y-3">
            {/* Project summary banner */}
            {selectedProject && (
              <div className={`p-3 rounded-xl border flex items-center gap-3 ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-sm"}`}>
                <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${projectColorMap[selectedProject.color]} flex items-center justify-center text-base flex-shrink-0`}>
                  {selectedProject.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className={`text-xs font-black truncate ${isDark ? "text-white" : "text-gray-900"}`}>{selectedProject.name}</div>
                  <div className={`text-[10px] ${isDark ? "text-gray-400" : "text-gray-500"}`}>{selectedProject.price} · {selectedProject.units} وحدة</div>
                </div>
                <button
                  onClick={() => setStep("select")}
                  className={`flex-shrink-0 text-[10px] px-2.5 py-1.5 rounded-lg font-bold transition-all ${isDark ? "bg-white/10 text-gray-300 hover:bg-white/15" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
                >
                  تغيير
                </button>
              </div>
            )}

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: "إجمالي المطابقين", value: seekers.length.toString(), accent: "blue" },
                { label: "باحث VIP", value: seekers.filter(s => s.isVip).length.toString(), accent: "purple" },
                { label: "تم الإرسال", value: sentIds.size.toString(), accent: sentIds.size > 0 ? "emerald" : "gray" },
              ].map((s, i) => (
                <div key={i} className={`p-2.5 rounded-xl text-center border ${isDark ? "bg-white/5 border-white/8" : "bg-white border-gray-100 shadow-sm"}`}>
                  <div className={`text-lg font-black ${
                    s.accent === "blue" ? (isDark ? "text-blue-400" : "text-blue-700") :
                    s.accent === "purple" ? (isDark ? "text-purple-400" : "text-purple-700") :
                    s.accent === "emerald" ? (isDark ? "text-emerald-400" : "text-emerald-700") :
                    (isDark ? "text-gray-500" : "text-gray-400")
                  }`}>{s.value}</div>
                  <div className={`text-[9px] font-bold ${isDark ? "text-gray-500" : "text-gray-400"}`}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Filter tabs */}
            <div className={`flex gap-1.5 p-1 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-100"}`}>
              {([
                { key: "all", label: `الكل (${seekers.length})` },
                { key: "vip", label: `VIP (${seekers.filter(s => s.isVip).length})` },
                { key: "top", label: `85%+ (${seekers.filter(s => s.match >= 85).length})` },
              ] as Array<{ key: DevFilter; label: string }>).map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setFilter(tab.key)}
                  className={`flex-1 py-2 rounded-lg text-[11px] font-black transition-all ${
                    filter === tab.key
                      ? (isDark ? "bg-blue-500/30 text-blue-300 border border-blue-500/40" : "bg-white text-blue-700 shadow-sm border border-blue-200")
                      : (isDark ? "text-gray-500 hover:text-gray-300" : "text-gray-400 hover:text-gray-600")
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Seeker cards */}
            <div className="space-y-2.5">
              {filteredSeekers.map((seeker, i) => (
                <motion.div
                  key={seeker.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.06 }}
                  className={`p-4 rounded-2xl border relative overflow-hidden ${
                    isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-sm"
                  }`}
                >
                  {/* VIP glow */}
                  {seeker.isVip && (
                    <div className="absolute top-0 right-0 w-16 h-16 bg-purple-500/10 rounded-full -translate-y-4 translate-x-4 blur-xl pointer-events-none" />
                  )}

                  <div className="flex items-start gap-3">
                    {/* Avatar */}
                    <div className="relative flex-shrink-0">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-sm shadow-md ${
                        seeker.isVip
                          ? "bg-gradient-to-br from-purple-500 to-pink-600 text-white"
                          : isDark ? "bg-white/10 text-gray-200" : "bg-gray-100 text-gray-700"
                      }`}>
                        {seeker.initials}
                      </div>
                      {seeker.isVip && (
                        <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                          <Crown className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{seeker.name}</span>
                        {seeker.isVip && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black ${isDark ? "bg-purple-500/20 text-purple-400" : "bg-purple-100 text-purple-700"}`}>VIP</span>
                        )}
                      </div>
                      <div className={`text-[11px] mb-1 ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                        {seeker.want}
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[10px] font-bold ${isDark ? "text-cyan-400" : "text-blue-600"}`}>
                          💰 {seeker.budget}
                        </span>
                        <span className={`text-[10px] ${isDark ? "text-gray-500" : "text-gray-400"}`}>
                          📍 {seeker.location}
                        </span>
                      </div>

                      {/* Preferences tags */}
                      <div className="flex gap-1 mt-1.5 flex-wrap">
                        {seeker.preferences.map((p, pi) => (
                          <span key={pi} className={`text-[9px] px-1.5 py-0.5 rounded-md font-bold ${isDark ? "bg-white/8 text-gray-400" : "bg-gray-100 text-gray-500"}`}>
                            {p}
                          </span>
                        ))}
                      </div>

                      {/* Match bar */}
                      <div className="flex items-center gap-2 mt-2">
                        <div className={`flex-1 h-1.5 rounded-full overflow-hidden ${isDark ? "bg-white/10" : "bg-gray-100"}`}>
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${seeker.match}%` }}
                            transition={{ duration: 0.8, delay: 0.3 + i * 0.08 }}
                            className={`h-full rounded-full ${
                              seeker.match >= 90 ? "bg-gradient-to-r from-emerald-500 to-cyan-500" : "bg-gradient-to-r from-blue-500 to-purple-500"
                            }`}
                          />
                        </div>
                        <span className={`text-[10px] font-black flex-shrink-0 ${
                          seeker.match >= 90
                            ? (isDark ? "text-emerald-400" : "text-emerald-700")
                            : (isDark ? "text-blue-400" : "text-blue-700")
                        }`}>{seeker.match}%</span>
                      </div>
                    </div>

                    {/* Send button */}
                    <div className="flex flex-col items-center gap-1 flex-shrink-0">
                      <motion.button
                        whileHover={!sentIds.has(seeker.id) ? { scale: 1.08 } : {}}
                        whileTap={!sentIds.has(seeker.id) ? { scale: 0.92 } : {}}
                        onClick={() => !sentIds.has(seeker.id) && handleSend(seeker.id)}
                        disabled={sentIds.has(seeker.id)}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-[10px] font-black transition-all ${
                          sentIds.has(seeker.id)
                            ? (isDark ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-emerald-100 text-emerald-700 border border-emerald-200")
                            : (isDark ? "bg-blue-500 text-white shadow-lg shadow-blue-500/30 hover:bg-blue-400" : "bg-blue-600 text-white shadow-md shadow-blue-500/25 hover:bg-blue-700")
                        }`}
                      >
                        {sentIds.has(seeker.id) ? (
                          <><Check className="w-3 h-3" /> تم</>
                        ) : (
                          <><Send className="w-3 h-3" /> إرسال</>
                        )}
                      </motion.button>
                      <span className={`text-[9px] ${isDark ? "text-gray-600" : "text-gray-400"}`}>{seeker.lastActive}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Bottom spacer for sticky button */}
            <div className="h-20" />
          </motion.div>
        )}

        {/* ── Step 4: Success ── */}
        {step === "success" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center h-full px-6 py-16 gap-5 text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", damping: 15, stiffness: 200, delay: 0.1 }}
              className="w-24 h-24 rounded-3xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center shadow-2xl shadow-emerald-500/40"
            >
              <Rocket className="w-12 h-12 text-white" />
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
              <div className={`text-xl font-black mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
                تم الإرسال بنجاح! 🎉
              </div>
              <div className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                أُرسل عرضك لـ {MATCHED_SEEKERS.length} باحث مطابق
              </div>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.45 }}
              className={`w-full p-4 rounded-2xl border ${isDark ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-sm"}`}
            >
              <div className={`text-xs font-black mb-3 ${isDark ? "text-gray-400" : "text-gray-500"}`}>إحصائيات الإرسال</div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "أُرسل", value: MATCHED_SEEKERS.length.toString(), color: "emerald" },
                  { label: "VIP", value: MATCHED_SEEKERS.filter(s => s.isVip).length.toString(), color: "purple" },
                  { label: "توقع الردود", value: "3-5", color: "blue" },
                ].map((s, i) => (
                  <div key={i} className={`text-center p-2 rounded-xl ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                    <div className={`text-lg font-black ${
                      s.color === "emerald" ? (isDark ? "text-emerald-400" : "text-emerald-600") :
                      s.color === "purple" ? (isDark ? "text-purple-400" : "text-purple-600") :
                      (isDark ? "text-blue-400" : "text-blue-600")
                    }`}>{s.value}</div>
                    <div className={`text-[9px] ${isDark ? "text-gray-500" : "text-gray-400"}`}>{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="w-full space-y-2"
            >
              <button
                onClick={onClose}
                className="w-full py-3.5 rounded-2xl text-sm font-black bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-xl shadow-blue-500/30"
              >
                العودة للداشبورد
              </button>
              <button
                onClick={() => { setStep("select"); setAllSent(false); setSentIds(new Set()); }}
                className={`w-full py-2.5 rounded-2xl text-xs font-bold border transition-all ${
                  isDark ? "bg-white/5 text-gray-300 border-white/10 hover:bg-white/10" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
                }`}
              >
                إرسال لمشروع آخر
              </button>
            </motion.div>
          </motion.div>
        )}
      </div>

      {/* Sticky Send All button (only in results step) */}
      {step === "results" && (
        <div className={`flex-shrink-0 p-4 border-t ${isDark ? "border-white/8 bg-[#0A0E1F]" : "border-gray-100 bg-white"}`}>
          <motion.button
            whileHover={!allSent ? { scale: 1.02 } : {}}
            whileTap={!allSent ? { scale: 0.98 } : {}}
            onClick={handleSendAll}
            disabled={allSent}
            className={`w-full py-4 rounded-2xl text-sm font-black transition-all ${
              allSent
                ? (isDark ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/25" : "bg-emerald-100 text-emerald-700 border border-emerald-200")
                : "bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-xl shadow-blue-500/30"
            }`}
          >
            {allSent ? (
              <span className="flex items-center justify-center gap-2">
                <CheckCircle className="w-5 h-5" />
                تم الإرسال لجميع المطابقين ✓
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <Users className="w-5 h-5" />
                إرسال لكل المطابقين
                {unsentCount > 0 && (
                  <span className="bg-white/20 px-2 py-0.5 rounded-full text-[11px]">
                    {unsentCount} باحث
                  </span>
                )}
              </span>
            )}
          </motion.button>
        </div>
      )}
    </motion.div>
  );
}
