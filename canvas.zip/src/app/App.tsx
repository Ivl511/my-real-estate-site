import { useState } from "react";
import { HomeScreen } from "./components/aion/HomeScreen";
import { PropertyDetails } from "./components/aion/PropertyDetails";
import { SearchScreen } from "./components/aion/SearchScreen";
import { FavoritesScreen } from "./components/aion/FavoritesScreen";
import { ProfileScreen } from "./components/aion/ProfileScreen";
import { RequestsScreen } from "./components/aion/RequestsScreen";
import { RequestDetailScreen } from "./components/aion/RequestDetailScreen";
import { AIONIntelligence } from "./components/aion/AIONIntelligence";
import { AddMenu } from "./components/aion/AddMenu";
import { FloatingAION } from "./components/aion/FloatingAION";
import { InboxScreen } from "./screens/InboxScreen";
import { DirectChatScreen } from "./screens/DirectChatScreen";
import { WalletScreen } from "./screens/WalletScreen";
import { ContractsScreen } from "./screens/ContractsScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { ThemeProvider } from "./context/ThemeContext";
import { BottomNav } from "./components/aion/BottomNav";
import { WebHeader } from "./components/aion/WebHeader";
import { SuperAdminDashboard } from "./screens/admin/SuperAdminDashboard";
import { ProfileDashboard } from "./screens/ProfileDashboard";
import { DeveloperProjectsScreen } from "./components/aion/DeveloperProjectsScreen";
import { AIONChatScreen } from "./components/aion/AIONChatScreen";

export type Screen = "home" | "requests" | "requestDetail" | "aion" | "search" | "favorites" | "profile" | "profileDashboard" | "details" | "inbox" | "chat" | "wallet" | "contracts" | "settings" | "admin" | "developerProjects" | "aionChat";

function AppContent() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home");
  const [chatData, setChatData] = useState<any>(null);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);
  const [selectedDevProjectId, setSelectedDevProjectId] = useState<string | null>(null);

  const handleSelectProperty = (id: string) => {
    setSelectedPropertyId(id);
    setCurrentScreen("details");
  };

  const handleSelectRequest = (id: string) => {
    setSelectedRequestId(id);
    setCurrentScreen("requestDetail");
  };

  const handleSelectDevProject = (projectId: string) => {
    setSelectedDevProjectId(projectId);
    setCurrentScreen("developerProjects");
  };

  const handleBack = () => {
    setCurrentScreen("home");
  };

  const handleBackFromRequestDetail = () => {
    setCurrentScreen("requests");
  };

  const handleOpenAddMenu = () => {
    setIsAddMenuOpen(true);
  };

  const handleOpenChat = (data: any) => {
    setChatData(data);
    setCurrentScreen("chat");
  };

  return (
    <div className={`fixed inset-0 overflow-hidden ${currentScreen === 'admin' ? '' : ''}`} dir={currentScreen === 'admin' ? 'ltr' : 'rtl'}>
      {currentScreen === "home" && (
        <HomeScreen
          onNavigate={setCurrentScreen}
          onSelectProperty={handleSelectProperty}
          onOpenAddMenu={handleOpenAddMenu}
          onSelectDevProject={handleSelectDevProject}
        />
      )}
      {currentScreen === "details" && selectedPropertyId && (
        <PropertyDetails propertyId={selectedPropertyId} onBack={handleBack} />
      )}
      {currentScreen === "search" && <SearchScreen onBack={handleBack} />}
      {currentScreen === "favorites" && <FavoritesScreen onBack={handleBack} />}
      {currentScreen === "profile" && <ProfileScreen onBack={handleBack} onNavigate={setCurrentScreen} />}
      {currentScreen === "requests" && <RequestsScreen onBack={handleBack} onSelectRequest={handleSelectRequest} />}
      {currentScreen === "requestDetail" && selectedRequestId && (
        <RequestDetailScreen requestId={selectedRequestId} onBack={handleBackFromRequestDetail} />
      )}
      {currentScreen === "aion" && <AIONIntelligence onBack={handleBack} />}
      {currentScreen === "aionChat" && <AIONChatScreen onBack={handleBack} />}
      {currentScreen === "inbox" && <InboxScreen onBack={handleBack} onNavigate={setCurrentScreen} onOpenChat={handleOpenChat} />}
      {currentScreen === "chat" && <DirectChatScreen onBack={() => setCurrentScreen("inbox")} chatData={chatData} />}
      
      {/* Profile Sub-Screens */}
      {currentScreen === "wallet" && <WalletScreen onBack={() => setCurrentScreen("profile")} />}
      {currentScreen === "contracts" && <ContractsScreen onBack={() => setCurrentScreen("profile")} />}
      {currentScreen === "settings" && <SettingsScreen onBack={() => setCurrentScreen("profile")} />}

      {/* Add Menu */}
      <AddMenu isOpen={isAddMenuOpen} onClose={() => setIsAddMenuOpen(false)} />

      {/* Floating Draggable AION Orb - Only show on Home and Requests screens */}
      {(currentScreen === "home" || currentScreen === "requests") && currentScreen !== "admin" && (
        <div className="md:fixed md:bottom-8 md:right-8 md:z-50">
           <FloatingAION onNavigate={setCurrentScreen} />
        </div>
      )}

      {/* Global Persistent Bottom Navigation (Mobile Only) */}
      {currentScreen !== "admin" && (
        <div className="md:hidden">
          <BottomNav 
            currentScreen={currentScreen}
            onNavigate={setCurrentScreen}
            onOpenAddMenu={handleOpenAddMenu}
          />
        </div>
      )}
      
      {/* Desktop Top Navbar */}
      {currentScreen !== "admin" && (
        <WebHeader 
          currentScreen={currentScreen}
          onNavigate={setCurrentScreen}
        />
      )}
      
      {/* Profile Dashboard - Demo Screen */}
      {currentScreen === "profileDashboard" && <ProfileDashboard onBack={handleBack} />}
      
      {/* Super Admin Dashboard */}
      {currentScreen === "admin" && <SuperAdminDashboard onBack={() => setCurrentScreen("profile")} />}
      
      {/* Developer Projects Screen */}
      {currentScreen === "developerProjects" && (
        <DeveloperProjectsScreen 
          onBack={handleBack} 
          initialProjectId={selectedDevProjectId}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}