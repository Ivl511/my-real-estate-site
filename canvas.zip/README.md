
  # canvas

  This is a code bundle for canvas. The original project is available at https://www.figma.com/design/3PiExXDKOZDNQhAbnMh6s8/canvas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  