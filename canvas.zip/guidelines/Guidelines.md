**Add your own guidelines here**
<!--

System Guidelines

Use this file to provide the AI with rules and guidelines you want it to follow.
This template outlines a few examples of things you can add. You can add your own sections and format it to suit your needs

TIP: More context isn't always better. It can confuse the LLM. Try and add the most important rules you need

# General guidelines

Any general rules you want the AI to follow.
For example:

* Only use absolute positioning when necessary. Opt for responsive and well structured layouts that use flexbox and grid by default
* Refactor code as you go to keep code clean
* Keep file sizes small and put helper functions and components in their own files.

--------------

# Design system guidelines
Rules for how the AI should make generations look like your company's design system

Additionally, if you select a design system to use in the prompt box, you can reference
your design system's components, tokens, variables and components.
For example:

* Use a base font-size of 14px
* Date formats should always be in the format “Jun 10”
* The bottom toolbar should only ever have a maximum of 4 items
* Never use the floating action button with the bottom toolbar
* Chips should always come in sets of 3 or more
* Don't use a dropdown if there are 2 or fewer options

You can also create sub sections and add more specific details
For example:


## Button
The Button component is a fundamental interactive element in our design system, designed to trigger actions or navigate
users through the application. It provides visual feedback and clear affordances to enhance user experience.

### Usage
Buttons should be used for important actions that users need to take, such as form submissions, confirming choices,
or initiating processes. They communicate interactivity and should have clear, action-oriented labels.

### Variants
* Primary Button
  * Purpose : Used for the main action in a section or page
  * Visual Style : Bold, filled with the primary brand color
  * Usage : One primary button per section to guide users toward the most important action
* Secondary Button
  * Purpose : Used for alternative or supporting actions
  * Visual Style : Outlined with the primary color, transparent background
  * Usage : Can appear alongside a primary button for less important actions
* Tertiary Button
  * Purpose : Used for the least important actions
  * Visual Style : Text-only with no border, using primary color
  * Usage : For actions that should be available but not emphasized
-->

THE FINAL UNTOUCHED MASTER PROMPT (Full Detail)
Project: AION Real Estate Super-App.
Target Screen: "Profile Dashboard" (Interactive Demo).
Goal: Visualize the Tier-Based Feature Locking System for ALL 4 User Personas.
⛔ CORE INSTRUCTION:
This screen is a "Sales Demo". It must show how features appear/disappear based on the subscription.
 * Top Header: Must include the "Simulation Bar" (User Type + Package).
 * The Rule: Higher Tier = More Widgets/Data. Lower Tier = Locked/Hidden Widgets.
PART 1: The Simulation Controller (Header)
Instruction: Create a fixed Control Strip at the top.
 * Toggle A (Persona): [ 👔 Broker ] - [ 🏗️ Developer ] - [ 🔑 Landlord ] - [ 🔍 Seeker ].
 * Toggle B (Tier):
   * For Broker/Dev: [ Starter ] - [ Business ] - [ PRO/Enterprise ].
   * For Landlord/Seeker: [ Free ] - [ Premium/VIP ].
PART 2: USER TYPE 1 -> THE BROKER (3 Tiers)
Tier 1: STARTER (The Beginner)
 * ID Card: Green Glass (Simple).
 * Widgets State:
   * My Listings: Active (Basic Stats).
   * My Tasks: Active (Simple List).
   * My Landlords: RESTRICTED. Shows "Total Count" only. Clicking shows "Upgrade to view Details".
   * Market Heatmap: LOCKED 🔒. Grayed out with "PRO Feature" label.
Tier 2: NOMAD (The Professional)
 * ID Card: Holographic/Iridescent.
 * Widgets State:
   * My Listings: Active + "Drafts" enabled.
   * My Tasks: Active + "AI Contract Review" enabled.
   * My Landlords: UNLOCKED. Full Access to CRM & Alerts.
   * Market Heatmap: LOCKED 🔒. Still Grayed out.
Tier 3: PRO (The Elite)
 * ID Card: Matte Black Metal + Gold FAL Authority Stamp.
 * Widgets State:
   * ALL WIDGETS UNLOCKED.
   * Market Heatmap: Fully Visible (Shows Hot Zones Map).
   * My Landlords: Shows "AI Predictive Insights".
PART 3: USER TYPE 2 -> THE DEVELOPER (3 Tiers)
Tier 1: STARTER (Single Project)
 * Widgets State:
   * Project Dashboard: Active (Limit: 1 Project).
   * Inventory: Active (Manual Edit).
   * Sales Team: LOCKED 🔒. "Upgrade to Business to add Agents".
   * Land Acquisition: HIDDEN. (Widget does not exist or is fully blurred).
Tier 2: BUSINESS (The Company)
 * Widgets State:
   * Project Dashboard: Active (Multi-Project).
   * Sales Team: UNLOCKED. Shows Agent Performance (e.g., "Sarah: 12 Deals").
   * Campaigns: Active.
   * Land Acquisition: LOCKED 🔒. "Enterprise Feature".
Tier 3: ENTERPRISE (The Tycoon)
 * ID Card: Black Metal + Platinum Accents.
 * Widgets State:
   * ALL UNLOCKED.
   * Land Acquisition: Active. Shows "AI Found 3 Raw Lands".
   * Predictive Analytics: Active.
PART 4: USER TYPE 3 -> THE LANDLORD (2 Tiers)
Tier 1: FREE (Basic)
 * ID Card: Bronze/Standard.
 * Widgets State:
   * My Assets: Active (Simple Value).
   * Offers: Active.
   * AI Inquiry Guard: OFF. Shows "Manual Chat Mode".
   * Broker Match: LOCKED 🔒. "Upgrade to Premium to find Brokers".
Tier 2: PREMIUM (Smart Owner)
 * ID Card: Gold Metal Texture.
 * Widgets State:
   * AI Inquiry Guard: ACTIVE 🟢. "AI Filtered 15 Chats".
   * Broker Match: UNLOCKED. "3 Brokers Requesting Access".
   * Legal Contracts: Active (Auto-Generated).
PART 5: USER TYPE 4 -> THE SEEKER (2 Tiers)
Tier 1: GUEST (Free)
 * ID Card: Blue Glass.
 * Widgets State:
   * Wishlist: Active.
   * My Requests: Active (Standard Search).
   * Fair Price Analysis: LOCKED 🔒. "VIP Only".
   * Early Alerts: HIDDEN.
Tier 2: VIP HUNTER (Paid)
 * ID Card: Purple Neon / Cyberpunk.
 * Widgets State:
   * Fair Price Analysis: UNLOCKED. Shows "Under Market Price by 10%".
   * Early Alerts: ACTIVE. "Notified 24h before listing".
   * Smart Matching: "95% Match Found".
PART 6: Summary for Developer
 * The Logic: The UI must clearly differentiate between "Having the feature" (PRO) and "Missing out" (Free).
 * The Visuals: Use Lock Icons 🔒, Blur Effects, and Grayscale to indicate restricted features on lower tiers.
 * The Header: Ensure the Simulation Bar allows switching between all these states instantly.
