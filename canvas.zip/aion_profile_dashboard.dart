// ================================================================
// AION Real Estate Super-App
// Profile Dashboard – Flutter Conversion
// ================================================================
// Screens covered:
//   • ProfileDashboard (Simulation Controller + all 4 persona dashboards)
//     - Broker  : Starter / Nomad / PRO
//     - Developer: Starter / Business / Enterprise
//     - Landlord : Free  / Premium
//     - Seeker   : Guest / VIP Hunter
//
// Dependencies (add to pubspec.yaml):
//   flutter:
//     sdk: flutter
//
// Optional Arabic font (add to pubspec.yaml):
//   fonts:
//     - family: Tajawal
//       fonts:
//         - asset: fonts/Tajawal-Regular.ttf
//         - asset: fonts/Tajawal-Bold.ttf    (weight: 700)
//         - asset: fonts/Tajawal-Black.ttf   (weight: 900)
//
// Run: flutter run
// ================================================================

import 'dart:ui' as ui;
import 'package:flutter/material.dart';

// ──────────────────────────────────────────────────────────────
// ENTRY POINT
// ──────────────────────────────────────────────────────────────
void main() {
  runApp(const AIONApp());
}

// ──────────────────────────────────────────────────────────────
// ENUMS
// ──────────────────────────────────────────────────────────────
enum Persona { broker, developer, landlord, seeker }

enum BrokerTier { starter, nomad, pro }

enum DeveloperTier { starter, business, enterprise }

enum LandlordTier { free, premium }

enum SeekerTier { guest, vip }

enum WidgetAccessState { active, activeBasic, restricted, locked, hidden }

// ──────────────────────────────────────────────────────────────
// DESIGN TOKENS
// ──────────────────────────────────────────────────────────────
abstract class C {
  // Background layers
  static const Color bg = Color(0xFF0A0E1A);
  static const Color surface = Color(0xFF0D1221);

  // Accent palette
  static const Color cyan = Color(0xFF06B6D4);
  static const Color cyanLight = Color(0xFF67E8F9);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color purpleLight = Color(0xFFC084FC);
  static const Color emerald = Color(0xFF10B981);
  static const Color emeraldLight = Color(0xFF6EE7B7);
  static const Color amber = Color(0xFFF59E0B);
  static const Color amberLight = Color(0xFFFDE68A);
  static const Color red = Color(0xFFEF4444);
  static const Color orange = Color(0xFFF97316);
  static const Color orangeLight = Color(0xFFFDBA74);
  static const Color pink = Color(0xFFEC4899);
  static const Color blue = Color(0xFF3B82F6);
  static const Color blueLight = Color(0xFF93C5FD);
  static const Color indigo = Color(0xFF6366F1);
  static const Color indigoLight = Color(0xFFA5B4FC);

  // Greyscale text
  static const Color white = Colors.white;
  static const Color grey300 = Color(0xFFD1D5DB);
  static const Color grey400 = Color(0xFF9CA3AF);
  static const Color grey500 = Color(0xFF6B7280);
  static const Color grey600 = Color(0xFF4B5563);

  // Utility
  static Color a(Color base, int alpha) =>
      Color.fromARGB(alpha, base.red, base.green, base.blue);
}

// ──────────────────────────────────────────────────────────────
// APP ROOT
// ──────────────────────────────────────────────────────────────
class AIONApp extends StatelessWidget {
  const AIONApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AION Real Estate',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: C.bg,
        colorScheme: const ColorScheme.dark(
          primary: C.cyan,
          secondary: C.purple,
          surface: C.surface,
        ),
      ),
      home: const ProfileDashboardScreen(),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// PROFILE DASHBOARD SCREEN
// ──────────────────────────────────────────────────────────────
class ProfileDashboardScreen extends StatefulWidget {
  const ProfileDashboardScreen({super.key});

  @override
  State<ProfileDashboardScreen> createState() =>
      _ProfileDashboardScreenState();
}

class _ProfileDashboardScreenState extends State<ProfileDashboardScreen> {
  Persona _persona = Persona.broker;
  BrokerTier _brokerTier = BrokerTier.starter;
  DeveloperTier _developerTier = DeveloperTier.starter;
  LandlordTier _landlordTier = LandlordTier.free;
  SeekerTier _seekerTier = SeekerTier.guest;

  // Returns persona-specific tier options as a list of value+label maps
  List<_TierOption> get _tierOptions {
    switch (_persona) {
      case Persona.broker:
        return [
          _TierOption(BrokerTier.starter, 'Starter'),
          _TierOption(BrokerTier.nomad, 'Nomad'),
          _TierOption(BrokerTier.pro, 'PRO'),
        ];
      case Persona.developer:
        return [
          _TierOption(DeveloperTier.starter, 'Starter'),
          _TierOption(DeveloperTier.business, 'Business'),
          _TierOption(DeveloperTier.enterprise, 'Enterprise'),
        ];
      case Persona.landlord:
        return [
          _TierOption(LandlordTier.free, 'Free'),
          _TierOption(LandlordTier.premium, 'Premium'),
        ];
      case Persona.seeker:
        return [
          _TierOption(SeekerTier.guest, 'Guest'),
          _TierOption(SeekerTier.vip, 'VIP Hunter'),
        ];
    }
  }

  bool _isCurrentTier(Object tierValue) {
    switch (_persona) {
      case Persona.broker:
        return _brokerTier == tierValue;
      case Persona.developer:
        return _developerTier == tierValue;
      case Persona.landlord:
        return _landlordTier == tierValue;
      case Persona.seeker:
        return _seekerTier == tierValue;
    }
  }

  void _setTier(Object tierValue) {
    setState(() {
      if (tierValue is BrokerTier) _brokerTier = tierValue;
      if (tierValue is DeveloperTier) _developerTier = tierValue;
      if (tierValue is LandlordTier) _landlordTier = tierValue;
      if (tierValue is SeekerTier) _seekerTier = tierValue;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: C.bg,
        body: Column(
          children: [
            // ── Fixed simulation header ──
            SimulationHeader(
              persona: _persona,
              tierOptions: _tierOptions,
              isCurrentTier: _isCurrentTier,
              onPersonaChanged: (p) => setState(() => _persona = p),
              onTierChanged: _setTier,
            ),
            // ── Scrollable dashboard body ──
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  transitionBuilder: (child, anim) =>
                      FadeTransition(opacity: anim, child: child),
                  child: _buildDashboard(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboard() {
    switch (_persona) {
      case Persona.broker:
        return BrokerDashboard(
          key: ValueKey('broker-${_brokerTier.name}'),
          tier: _brokerTier,
        );
      case Persona.developer:
        return DeveloperDashboard(
          key: ValueKey('developer-${_developerTier.name}'),
          tier: _developerTier,
        );
      case Persona.landlord:
        return LandlordDashboard(
          key: ValueKey('landlord-${_landlordTier.name}'),
          tier: _landlordTier,
        );
      case Persona.seeker:
        return SeekerDashboard(
          key: ValueKey('seeker-${_seekerTier.name}'),
          tier: _seekerTier,
        );
    }
  }
}

// Simple data class for tier options
class _TierOption {
  final Object value;
  final String label;
  const _TierOption(this.value, this.label);
}

// ──────────────────────────────────────────────────────────────
// SIMULATION HEADER
// ──────────────────────────────────────────────────────────────
class SimulationHeader extends StatelessWidget {
  final Persona persona;
  final List<_TierOption> tierOptions;
  final bool Function(Object) isCurrentTier;
  final ValueChanged<Persona> onPersonaChanged;
  final ValueChanged<Object> onTierChanged;

  const SimulationHeader({
    super.key,
    required this.persona,
    required this.tierOptions,
    required this.isCurrentTier,
    required this.onPersonaChanged,
    required this.onTierChanged,
  });

  static final _personas = [
    {'value': Persona.broker, 'label': 'وسيط', 'emoji': '👔'},
    {'value': Persona.developer, 'label': 'مطور', 'emoji': '🏗️'},
    {'value': Persona.landlord, 'label': 'مالك', 'emoji': '🔑'},
    {'value': Persona.seeker, 'label': 'باحث', 'emoji': '🔍'},
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: C.a(C.surface, 242), // ~95% opacity
        border: Border(
          bottom: BorderSide(color: C.a(C.cyan, 51)), // 20% opacity
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Demo badge
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [C.a(C.cyan, 51), C.a(C.purple, 51)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: C.a(C.cyan, 76)),
                ),
                child: const Text(
                  '🎯 SALES DEMO - نظام القفل التجريبي',
                  style: TextStyle(
                    fontSize: 10,
                    color: C.cyanLight,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 10),

              // Persona toggle row
              Row(
                children: _personas.map((p) {
                  final isSelected = persona == p['value'];
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: GestureDetector(
                        onTap: () =>
                            onPersonaChanged(p['value'] as Persona),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                            gradient: isSelected
                                ? const LinearGradient(
                                    colors: [C.cyan, C.purple],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  )
                                : null,
                            color:
                                isSelected ? null : C.a(Colors.white, 13),
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: C.a(C.cyan, 128),
                                      blurRadius: 8,
                                    ),
                                  ]
                                : null,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(p['emoji'] as String,
                                  style: const TextStyle(fontSize: 14)),
                              const SizedBox(height: 2),
                              Text(
                                p['label'] as String,
                                style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  color: isSelected
                                      ? Colors.white
                                      : C.grey500,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 8),

              // Tier toggle row
              Row(
                children: tierOptions.map((t) {
                  final isSelected = isCurrentTier(t.value);
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: GestureDetector(
                        onTap: () => onTierChanged(t.value),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                            gradient: isSelected
                                ? const LinearGradient(
                                    colors: [C.emerald, C.cyan],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  )
                                : null,
                            color:
                                isSelected ? null : C.a(Colors.white, 13),
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: C.a(C.emerald, 128),
                                      blurRadius: 8,
                                    ),
                                  ]
                                : null,
                          ),
                          child: Text(
                            t.label,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: isSelected ? Colors.white : C.grey500,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// ==================== BROKER DASHBOARD ====================
// ──────────────────────────────────────────────────────────────
class BrokerDashboard extends StatelessWidget {
  final BrokerTier tier;
  const BrokerDashboard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        BrokerIDCard(tier: tier),
        const SizedBox(height: 16),

        // My Listings
        AIONWidget(
          title: 'عقاراتي',
          icon: Icons.apartment_rounded,
          state: tier == BrokerTier.starter
              ? WidgetAccessState.activeBasic
              : WidgetAccessState.active,
          children: [
            StatRow(
                label: 'إجمالي العقارات',
                value: tier == BrokerTier.starter ? '12' : '20'),
            const SizedBox(height: 8),
            StatRow(
                label: 'نشط',
                value: tier == BrokerTier.starter ? '8' : '15'),
            if (tier != BrokerTier.starter) ...[
              const SizedBox(height: 8),
              StatRow(label: 'مسودات', value: '3', badge: 'جديد'),
            ],
            const SizedBox(height: 8),
            StatRow(label: 'مباع', value: '4'),
          ],
        ),
        const SizedBox(height: 16),

        // My Tasks
        AIONWidget(
          title: 'مهامي',
          icon: Icons.task_alt_rounded,
          state: tier == BrokerTier.starter
              ? WidgetAccessState.activeBasic
              : WidgetAccessState.active,
          children: [
            TaskItem(text: 'زيارة عقار في الملقا'),
            const SizedBox(height: 8),
            TaskItem(text: 'تحديث صور الفيلا'),
            if (tier != BrokerTier.starter) ...[
              const SizedBox(height: 8),
              AIBadge(
                icon: Icons.auto_awesome_rounded,
                text: 'AI: مراجعة عقد البيع متاحة',
                accentColor: C.purple,
              ),
            ],
          ],
        ),
        const SizedBox(height: 16),

        // My Landlords
        AIONWidget(
          title: 'ملاكي',
          icon: Icons.people_alt_rounded,
          state: tier == BrokerTier.starter
              ? WidgetAccessState.restricted
              : WidgetAccessState.active,
          upgradeMessage: tier == BrokerTier.starter
              ? 'ترقية إلى Nomad لعرض التفاصيل الكاملة'
              : null,
          children: tier == BrokerTier.starter
              ? [
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Column(
                        children: [
                          Icon(Icons.people_alt_rounded,
                              size: 48, color: C.a(Colors.white, 77)),
                          const SizedBox(height: 8),
                          const Text(
                            'إجمالي الملاك: 24',
                            style: TextStyle(
                              color: C.grey400,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'انقر للترقية ورؤية التفاصيل',
                            style: TextStyle(
                                color: C.grey500, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                ]
              : [
                  LandlordItem(
                      name: 'أحمد السعيد',
                      properties: 5,
                      alerts: 2),
                  const SizedBox(height: 8),
                  LandlordItem(
                      name: 'فاطمة العمري',
                      properties: 3,
                      alerts: 0),
                  const SizedBox(height: 8),
                  LandlordItem(
                      name: 'محمد الغامدي',
                      properties: 8,
                      alerts: 1),
                  if (tier == BrokerTier.pro) ...[
                    const SizedBox(height: 8),
                    AIBadge(
                      icon: Icons.bolt_rounded,
                      text: 'AI: 3 ملاك قد يضيفون عقارات قريباً',
                      accentColor: C.cyan,
                    ),
                  ],
                ],
        ),
        const SizedBox(height: 16),

        // Market Heatmap
        AIONWidget(
          title: 'خريطة السوق',
          icon: Icons.location_on_rounded,
          state: tier == BrokerTier.pro
              ? WidgetAccessState.active
              : WidgetAccessState.locked,
          lockMessage: tier != BrokerTier.pro
              ? 'ميزة PRO حصرية - خريطة المناطق الساخنة'
              : null,
          upgradeMessage: tier != BrokerTier.pro ? 'PRO' : null,
          children: tier == BrokerTier.pro
              ? [
                  HeatmapZone(zone: 'الملقا', heat: HeatLevel.high),
                  const SizedBox(height: 8),
                  HeatmapZone(zone: 'العليا', heat: HeatLevel.medium),
                  const SizedBox(height: 8),
                  HeatmapZone(zone: 'النرجس', heat: HeatLevel.high),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          C.a(C.red, 51),
                          C.a(C.orange, 51),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: const [
                        Icon(Icons.trending_up_rounded,
                            color: C.orange, size: 16),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'الطلب في الملقا ارتفع 15% هذا الشهر',
                            style: TextStyle(
                              color: C.amberLight,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ]
              : [],
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────
// BROKER ID CARD
// ──────────────────────────────────────────────────────────────
class BrokerIDCard extends StatelessWidget {
  final BrokerTier tier;
  const BrokerIDCard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    late LinearGradient gradient;
    late Color textColor;
    late Color borderColor;

    switch (tier) {
      case BrokerTier.starter:
        gradient = LinearGradient(
          colors: [C.a(C.emerald, 76), C.a(C.cyan, 76)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
        textColor = C.emeraldLight;
        borderColor = C.a(C.emerald, 128);
        break;
      case BrokerTier.nomad:
        gradient = const LinearGradient(
          colors: [Color(0xFF7C3AED), Color(0xFFDB2777), Color(0xFF0891B2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
        textColor = Colors.white;
        borderColor = C.a(C.purple, 128);
        break;
      case BrokerTier.pro:
        gradient = const LinearGradient(
          colors: [Color(0xFF111827), Color(0xFF000000)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
        textColor = C.amber;
        borderColor = C.a(C.amber, 128);
        break;
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 2),
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.work_rounded, color: textColor, size: 22),
                  const SizedBox(width: 10),
                  Text(
                    'وسيط عقاري',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                'أحمد المحترف',
                style: TextStyle(
                  color: tier == BrokerTier.pro ? Colors.white : textColor,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                tier == BrokerTier.starter
                    ? 'باقة Starter'
                    : tier == BrokerTier.nomad
                        ? 'باقة Nomad - المحترف'
                        : 'باقة PRO - النخبة',
                style: TextStyle(
                  color: tier == BrokerTier.pro
                      ? C.amberLight
                      : C.grey300,
                  fontSize: 12,
                ),
              ),
              if (tier == BrokerTier.pro) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: C.a(C.amber, 51),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: C.a(C.amber, 128)),
                  ),
                  child: const Text(
                    'ختم هيئة FAL الذهبي',
                    style: TextStyle(
                      color: C.amber,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ],
          ),
          if (tier == BrokerTier.pro)
            const Positioned(
              top: 0,
              left: 0,
              child: Icon(Icons.workspace_premium_rounded,
                  color: C.amber, size: 28),
            ),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// ==================== DEVELOPER DASHBOARD ====================
// ──────────────────────────────────────────────────────────────
class DeveloperDashboard extends StatelessWidget {
  final DeveloperTier tier;
  const DeveloperDashboard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DeveloperIDCard(tier: tier),
        const SizedBox(height: 16),

        // Project Dashboard
        AIONWidget(
          title: 'لوحة المشاريع',
          icon: Icons.business_rounded,
          state: WidgetAccessState.active,
          children: [
            if (tier == DeveloperTier.starter) ...[
              ProjectItem(name: 'مشروع النرجس السكني', progress: 75),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: C.a(C.amber, 26),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: C.a(C.amber, 76)),
                ),
                child: const Text(
                  'حد واحد مشروع - ترقية إلى Business لمشاريع متعددة',
                  style: TextStyle(
                    color: C.amberLight,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
            if (tier == DeveloperTier.business) ...[
              ProjectItem(name: 'مشروع النرجس السكني', progress: 75),
              const SizedBox(height: 8),
              ProjectItem(name: 'أبراج العليا التجارية', progress: 45),
              const SizedBox(height: 8),
              ProjectItem(name: 'فلل الملقا الفاخرة', progress: 90),
            ],
            if (tier == DeveloperTier.enterprise) ...[
              ProjectItem(name: 'مشروع النرجس السكني', progress: 75),
              const SizedBox(height: 8),
              ProjectItem(name: 'أبراج العليا التجارية', progress: 45),
              const SizedBox(height: 8),
              ProjectItem(name: 'فلل الملقا الفاخرة', progress: 90),
              const SizedBox(height: 8),
              ProjectItem(name: 'مجمع الرياض الكبير', progress: 30),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [C.a(C.purple, 51), C.a(C.cyan, 51)]),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: StatRow(label: 'إجمالي المشاريع', value: '10+'),
              ),
            ],
          ],
        ),
        const SizedBox(height: 16),

        // Inventory
        AIONWidget(
          title: 'المخزون',
          icon: Icons.inventory_2_rounded,
          state: tier == DeveloperTier.starter
              ? WidgetAccessState.activeBasic
              : WidgetAccessState.active,
          children: [
            StatRow(label: 'إجمالي الوحدات', value: '48'),
            const SizedBox(height: 8),
            StatRow(label: 'متاح', value: '22'),
            const SizedBox(height: 8),
            StatRow(label: 'محجوز', value: '18'),
            const SizedBox(height: 8),
            StatRow(label: 'مباع', value: '8'),
            if (tier != DeveloperTier.starter) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: C.a(C.emerald, 26),
                  borderRadius: BorderRadius.circular(8),
                ),
                child:
                    StatRow(label: 'معدل البيع الشهري', value: '6 وحدات', badge: '+12%'),
              ),
            ],
          ],
        ),
        const SizedBox(height: 16),

        // Sales Team
        AIONWidget(
          title: 'فريق المبيعات',
          icon: Icons.group_rounded,
          state: tier == DeveloperTier.starter
              ? WidgetAccessState.locked
              : WidgetAccessState.active,
          lockMessage: tier == DeveloperTier.starter
              ? 'ترقية إلى Business لإضافة فريق مبيعات'
              : null,
          upgradeMessage:
              tier == DeveloperTier.starter ? 'Business+' : null,
          children: tier != DeveloperTier.starter
              ? [
                  AgentItem(name: 'سارة المطيري', deals: 12),
                  const SizedBox(height: 8),
                  AgentItem(name: 'خالد العتيبي', deals: 8),
                  const SizedBox(height: 8),
                  AgentItem(name: 'نورة الشمري', deals: 15),
                  if (tier == DeveloperTier.enterprise) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: C.a(C.purple, 26),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: C.a(C.purple, 76)),
                      ),
                      child: StatRow(
                          label: 'إجمالي الوكلاء',
                          value: '8',
                          badge: 'نشط'),
                    ),
                  ],
                ]
              : [],
        ),
        const SizedBox(height: 16),

        // Campaigns
        AIONWidget(
          title: 'الحملات التسويقية',
          icon: Icons.campaign_rounded,
          state: tier == DeveloperTier.starter
              ? WidgetAccessState.locked
              : WidgetAccessState.active,
          lockMessage: tier == DeveloperTier.starter
              ? 'ترقية إلى Business لتفعيل الحملات الذكية'
              : null,
          upgradeMessage:
              tier == DeveloperTier.starter ? 'Business+' : null,
          children: tier != DeveloperTier.starter
              ? [
                  CampaignItem(name: 'حملة فلل الملقا', reach: '12,400'),
                  const SizedBox(height: 8),
                  CampaignItem(
                      name: 'إعلان أبراج العليا', reach: '8,700'),
                  if (tier == DeveloperTier.enterprise) ...[
                    const SizedBox(height: 8),
                    CampaignItem(
                        name: 'تسويق مجمع الرياض', reach: '21,300'),
                    const SizedBox(height: 8),
                    AIBadge(
                      icon: Icons.trending_up_rounded,
                      text: 'AI: أفضل وقت للنشر غداً الساعة 7م',
                      accentColor: C.emerald,
                    ),
                  ],
                ]
              : [],
        ),
        const SizedBox(height: 16),

        // Predictive Analytics (Enterprise only)
        AIONWidget(
          title: 'التحليلات التنبؤية',
          icon: Icons.analytics_rounded,
          state: tier == DeveloperTier.enterprise
              ? WidgetAccessState.active
              : WidgetAccessState.locked,
          lockMessage: tier != DeveloperTier.enterprise
              ? 'ميزة Enterprise حصرية - تحليلات AI متقدمة'
              : null,
          upgradeMessage:
              tier != DeveloperTier.enterprise ? 'Enterprise' : null,
          children: tier == DeveloperTier.enterprise
              ? [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [C.a(C.purple, 51), C.a(C.cyan, 51)],
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          '+23%',
                          style: TextStyle(
                            color: Color(0xFFD8B4FE),
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'زيادة متوقعة في المبيعات Q2',
                          style: TextStyle(color: C.grey400, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  StatRow(label: 'أفضل منطقة للاستثمار', value: 'النرجس'),
                  const SizedBox(height: 8),
                  StatRow(
                      label: 'نوع الوحدات الأعلى طلباً',
                      value: 'فيلا 4 غرف'),
                  const SizedBox(height: 8),
                  StatRow(
                      label: 'الميزانية الأكثر شيوعاً',
                      value: '1.5M – 2M'),
                  const SizedBox(height: 8),
                  AIBadge(
                    icon: Icons.auto_awesome_rounded,
                    text: 'AI: ابدأ مشروع سكني في الياسمين خلال 6 أشهر',
                    accentColor: C.cyan,
                  ),
                ]
              : [],
        ),
        const SizedBox(height: 16),

        // Land Acquisition (Enterprise only)
        AIONWidget(
          title: 'اقتناء الأراضي',
          icon: Icons.landscape_rounded,
          state: tier == DeveloperTier.enterprise
              ? WidgetAccessState.active
              : WidgetAccessState.locked,
          lockMessage: tier != DeveloperTier.enterprise
              ? 'ميزة Enterprise حصرية - AI لاكتشاف الأراضي'
              : null,
          upgradeMessage:
              tier != DeveloperTier.enterprise ? 'Enterprise' : null,
          children: tier == DeveloperTier.enterprise
              ? [
                  LandItem(
                      name: 'أرض الملقا الشمالية',
                      desc: '5,000 م² - سعر مناسب'),
                  const SizedBox(height: 8),
                  LandItem(
                      name: 'أرض العليا الغربية',
                      desc: '8,000 م² - فرصة ذهبية'),
                  const SizedBox(height: 8),
                  AIBadge(
                    icon: Icons.bolt_rounded,
                    text: 'AI وجد 3 أراضي خام مناسبة للتطوير',
                    accentColor: C.cyan,
                  ),
                ]
              : [],
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────
// DEVELOPER ID CARD
// ──────────────────────────────────────────────────────────────
class DeveloperIDCard extends StatelessWidget {
  final DeveloperTier tier;
  const DeveloperIDCard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    late LinearGradient gradient;
    late Color textColor;
    late Color borderColor;

    switch (tier) {
      case DeveloperTier.starter:
        gradient = LinearGradient(
          colors: [C.a(C.blue, 76), C.a(C.purple, 76)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
        textColor = C.blueLight;
        borderColor = C.a(C.blue, 128);
        break;
      case DeveloperTier.business:
        gradient = LinearGradient(
          colors: [C.a(C.indigo, 102), C.a(C.purple, 102)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
        textColor = C.indigoLight;
        borderColor = C.a(C.indigo, 128);
        break;
      case DeveloperTier.enterprise:
        gradient = const LinearGradient(
          colors: [Color(0xFF111827), Color(0xFF000000)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );
        textColor = C.grey300;
        borderColor = C.grey400;
        break;
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.domain_rounded, color: textColor, size: 22),
              const SizedBox(width: 10),
              Text(
                'مطور عقاري',
                style: TextStyle(
                  color: textColor,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'شركة العمران',
            style: TextStyle(
              color: tier == DeveloperTier.enterprise
                  ? Colors.white
                  : textColor,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            tier == DeveloperTier.starter
                ? 'باقة Starter - مشروع واحد'
                : tier == DeveloperTier.business
                    ? 'باقة Business - الشركة'
                    : 'باقة Enterprise - قطب العقارات',
            style: TextStyle(
              color: tier == DeveloperTier.enterprise
                  ? C.grey400
                  : C.grey300,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// ==================== LANDLORD DASHBOARD ====================
// ──────────────────────────────────────────────────────────────
class LandlordDashboard extends StatelessWidget {
  final LandlordTier tier;
  const LandlordDashboard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LandlordIDCard(tier: tier),
        const SizedBox(height: 16),

        // My Assets
        AIONWidget(
          title: 'أصولي العقارية',
          icon: Icons.real_estate_agent_rounded,
          state: WidgetAccessState.active,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [C.a(C.emerald, 51), C.a(C.cyan, 51)]),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    '2.4M ر.س',
                    style: TextStyle(
                      color: C.emeraldLight,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'إجمالي قيمة الأصول',
                    style: TextStyle(color: C.grey400, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            StatRow(label: 'فيلا الملقا', value: '1.2M ر.س'),
            const SizedBox(height: 8),
            StatRow(label: 'شقة العليا', value: '800K ر.س'),
            const SizedBox(height: 8),
            StatRow(label: 'محل تجاري', value: '400K ر.س'),
          ],
        ),
        const SizedBox(height: 16),

        // My Tasks
        AIONWidget(
          title: 'مهامي',
          icon: Icons.task_alt_rounded,
          state: WidgetAccessState.active,
          children: [
            TaskItem(text: 'تجديد عقد إيجار فيلا الملقا'),
            const SizedBox(height: 8),
            TaskItem(text: 'متابعة طلب الصيانة للشقة'),
            if (tier == LandlordTier.premium) ...[
              const SizedBox(height: 8),
              AIBadge(
                icon: Icons.auto_awesome_rounded,
                text: 'AI: عقد الإيجار ينتهي خلال 30 يوم',
                accentColor: C.purple,
              ),
            ],
          ],
        ),
        const SizedBox(height: 16),

        // Offers
        AIONWidget(
          title: 'العروض الواردة',
          icon: Icons.local_offer_rounded,
          state: WidgetAccessState.active,
          children: [
            OfferItem(buyer: 'محمد العتيبي', amount: '1.1M', status: 'pending'),
            const SizedBox(height: 8),
            OfferItem(buyer: 'سارة الشمري', amount: '780K', status: 'accepted'),
          ],
        ),
        const SizedBox(height: 16),

        // AI Inquiry Guard
        AIONWidget(
          title: 'حارس الاستفسارات AI',
          icon: Icons.shield_rounded,
          state: tier == LandlordTier.premium
              ? WidgetAccessState.active
              : WidgetAccessState.activeBasic,
          children: tier == LandlordTier.free
              ? [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: C.a(Colors.grey, 26),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: C.a(Colors.grey, 76)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          'وضع يدوي',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'جميع الرسائل تصل مباشرة',
                          style:
                              TextStyle(color: C.grey500, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: C.a(C.amber, 26),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: C.a(C.amber, 76)),
                    ),
                    child: const Text(
                      'ترقية إلى Premium للحصول على AI فلترة ذكية',
                      style: TextStyle(
                        color: C.amberLight,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ]
              : [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: C.a(C.emerald, 26),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            PulsingDot(color: C.emerald),
                            const SizedBox(width: 8),
                            const Text(
                              'AI نشط 🟢',
                              style: TextStyle(
                                color: C.emeraldLight,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'تم فلترة 15 استفسار غير جاد',
                          style:
                              TextStyle(color: C.grey400, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  StatRow(
                      label: 'استفسارات جادة', value: '8', badge: 'اليوم'),
                  const SizedBox(height: 8),
                  StatRow(label: 'تم حظرها', value: '15'),
                ],
        ),
        const SizedBox(height: 16),

        // Broker Match
        AIONWidget(
          title: 'مطابقة الوسطاء',
          icon: Icons.handshake_rounded,
          state: tier == LandlordTier.premium
              ? WidgetAccessState.active
              : WidgetAccessState.locked,
          lockMessage: tier == LandlordTier.free
              ? 'ترقية إلى Premium للعثور على وسطاء محترفين'
              : null,
          upgradeMessage: tier == LandlordTier.free ? 'Premium' : null,
          children: tier == LandlordTier.premium
              ? [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: C.a(C.purple, 26),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: C.a(C.purple, 76)),
                    ),
                    child: Row(
                      children: const [
                        Icon(Icons.auto_awesome_rounded,
                            color: C.purpleLight, size: 16),
                        SizedBox(width: 8),
                        Text(
                          '3 وسطاء يطلبون الوصول',
                          style: TextStyle(
                            color: C.purpleLight,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  BrokerRequestItem(
                      name: 'أحمد المحترف',
                      experience: '5 سنوات خبرة'),
                  const SizedBox(height: 8),
                  BrokerRequestItem(
                      name: 'خالد السعيد', experience: '8 سنوات خبرة'),
                  const SizedBox(height: 8),
                  BrokerRequestItem(
                      name: 'فاطمة العمري',
                      experience: '3 سنوات خبرة'),
                ]
              : [],
        ),
        if (tier == LandlordTier.premium) ...[
          const SizedBox(height: 16),
          // Legal Contracts (Premium only)
          AIONWidget(
            title: 'العقود القانونية',
            icon: Icons.description_rounded,
            state: WidgetAccessState.active,
            children: [
              ContractItem(
                name: 'عقد إيجار - فيلا الملقا',
                desc: 'تم إنشاؤه تلقائياً بواسطة AI',
                isCompleted: true,
              ),
              const SizedBox(height: 8),
              ContractItem(
                name: 'عقد بيع - شقة العليا',
                desc: 'جاهز للتوقيع',
                isCompleted: false,
              ),
            ],
          ),
        ],
        const SizedBox(height: 16),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────
// LANDLORD ID CARD
// ──────────────────────────────────────────────────────────────
class LandlordIDCard extends StatelessWidget {
  final LandlordTier tier;
  const LandlordIDCard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    final LinearGradient gradient = tier == LandlordTier.free
        ? LinearGradient(
            colors: [C.a(C.orange, 76), C.a(C.amber, 76)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
        : LinearGradient(
            colors: [C.a(C.amber, 102), C.a(const Color(0xFFEAB308), 102)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          );

    final Color textColor =
        tier == LandlordTier.free ? C.orangeLight : C.amberLight;
    final Color borderColor =
        tier == LandlordTier.free ? C.a(C.orange, 128) : C.a(C.amber, 128);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.vpn_key_rounded, color: textColor, size: 22),
              const SizedBox(width: 10),
              Text(
                'مالك عقار',
                style: TextStyle(
                  color: textColor,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'خالد المالك',
            style: TextStyle(
              color: textColor,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            tier == LandlordTier.free
                ? 'باقة Free - الأساسي'
                : 'باقة Premium - المالك الذكي',
            style: const TextStyle(color: C.grey300, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// ==================== SEEKER DASHBOARD ====================
// ──────────────────────────────────────────────────────────────
class SeekerDashboard extends StatelessWidget {
  final SeekerTier tier;
  const SeekerDashboard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SeekerIDCard(tier: tier),
        const SizedBox(height: 16),

        // My Tasks
        AIONWidget(
          title: 'مهامي',
          icon: Icons.task_alt_rounded,
          state: WidgetAccessState.active,
          children: [
            TaskItem(text: 'زيارة فيلا الملقا الفاخرة'),
            const SizedBox(height: 8),
            TaskItem(text: 'مراجعة عرض شقة العليا'),
            if (tier == SeekerTier.vip) ...[
              const SizedBox(height: 8),
              AIBadge(
                icon: Icons.auto_awesome_rounded,
                text: 'AI: عقار جديد يطابق معاييرك 95%',
                accentColor: C.purple,
              ),
            ],
          ],
        ),
        const SizedBox(height: 16),

        // Wishlist
        AIONWidget(
          title: 'قائمة الرغبات',
          icon: Icons.favorite_rounded,
          state: WidgetAccessState.active,
          children: [
            WishlistItem(name: 'فيلا الملقا الفاخرة', price: '1.2M ر.س'),
            const SizedBox(height: 8),
            WishlistItem(name: 'شقة العليا الحديثة', price: '850K ر.س'),
            const SizedBox(height: 8),
            WishlistItem(name: 'دوبلكس النرجس', price: '950K ر.س'),
          ],
        ),
        const SizedBox(height: 16),

        // My Requests
        AIONWidget(
          title: 'طلبات البحث',
          icon: Icons.search_rounded,
          state: WidgetAccessState.active,
          children: [
            SearchRequestItem(
                type: 'فيلا في الملقا - 4 غرف', status: 'active'),
            const SizedBox(height: 8),
            SearchRequestItem(
                type: 'شقة في العليا - 3 غرف', status: 'pending'),
            if (tier == SeekerTier.vip) ...[
              const SizedBox(height: 8),
              AIBadge(
                icon: Icons.bolt_rounded,
                text: 'AI يبحث عن 12 عقار يطابق معاييرك',
                accentColor: C.purple,
              ),
            ],
          ],
        ),
        const SizedBox(height: 16),

        // Fair Price Analysis
        AIONWidget(
          title: 'تحليل السعر العادل',
          icon: Icons.trending_up_rounded,
          state: tier == SeekerTier.vip
              ? WidgetAccessState.active
              : WidgetAccessState.locked,
          lockMessage: tier == SeekerTier.guest
              ? 'ميزة VIP حصرية - احصل على تحليل AI للأسعار'
              : null,
          upgradeMessage: tier == SeekerTier.guest ? 'VIP Hunter' : null,
          children: tier == SeekerTier.vip
              ? [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [C.a(C.emerald, 51), C.a(C.cyan, 51)],
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Row(
                          children: [
                            Icon(Icons.trending_down_rounded,
                                color: C.emeraldLight, size: 18),
                            SizedBox(width: 8),
                            Text(
                              'سعر أقل من السوق',
                              style: TextStyle(
                                color: C.emeraldLight,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8),
                        Text(
                          '-10%',
                          style: TextStyle(
                            color: C.emeraldLight,
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'فيلا الملقا الفاخرة - فرصة ممتازة',
                          style:
                              TextStyle(color: C.grey400, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  StatRow(label: 'السعر المطلوب', value: '1.2M ر.س'),
                  const SizedBox(height: 8),
                  StatRow(
                      label: 'متوسط السوق',
                      value: '1.33M ر.س',
                      badge: '+10%'),
                  const SizedBox(height: 8),
                  AIBadge(
                    icon: Icons.auto_awesome_rounded,
                    text: 'AI ينصح: صفقة ممتازة - تصرف بسرعة',
                    accentColor: C.cyan,
                  ),
                ]
              : [],
        ),
        const SizedBox(height: 16),

        // Matching Assistant
        if (tier == SeekerTier.vip) ...[
          AIONWidget(
            title: 'مساعد المطابقة AI',
            icon: Icons.psychology_rounded,
            state: WidgetAccessState.active,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [C.a(C.purple, 51), C.a(C.pink, 51)]),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      '95%',
                      style: TextStyle(
                        color: C.purpleLight,
                        fontSize: 32,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'تطابق مع فيلا الملقا الفاخرة',
                      style: TextStyle(color: C.grey400, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Early Alerts (VIP only)
          AIONWidget(
            title: 'التنبيهات المبكرة',
            icon: Icons.notifications_active_rounded,
            state: WidgetAccessState.active,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: C.a(C.cyan, 26),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: C.a(C.cyan, 76)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Row(
                      children: [
                        Icon(Icons.bolt_rounded,
                            color: C.cyanLight, size: 16),
                        SizedBox(width: 8),
                        Text(
                          'إشعار قبل 24 ساعة من النشر',
                          style: TextStyle(
                            color: C.cyanLight,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                    Text(
                      'احصل على العقارات قبل المنافسين',
                      style: TextStyle(color: C.grey400, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: C.a(Colors.white, 13),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'فيلا جديدة في النرجس',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: C.a(C.orange, 51),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'غداً',
                        style: TextStyle(
                            color: C.orangeLight, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ] else ...[
          // Locked Matching for Guest
          AIONWidget(
            title: 'مساعد المطابقة AI',
            icon: Icons.psychology_rounded,
            state: WidgetAccessState.locked,
            lockMessage:
                'ميزة VIP - تحدث مع AI لتحديد رغبتك وإيجاد أفضل العروض',
            upgradeMessage: 'VIP Hunter',
            children: const [],
          ),
          const SizedBox(height: 16),
        ],
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────
// SEEKER ID CARD
// ──────────────────────────────────────────────────────────────
class SeekerIDCard extends StatelessWidget {
  final SeekerTier tier;
  const SeekerIDCard({super.key, required this.tier});

  @override
  Widget build(BuildContext context) {
    final LinearGradient gradient = tier == SeekerTier.guest
        ? LinearGradient(
            colors: [C.a(C.blue, 76), C.a(C.cyan, 76)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
        : const LinearGradient(
            colors: [
              Color(0xFF7C3AED),
              Color(0xFFDB2777),
              Color(0xFF0891B2)
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          );

    final Color textColor =
        tier == SeekerTier.guest ? C.blueLight : Colors.white;
    final Color borderColor = tier == SeekerTier.guest
        ? C.a(C.blue, 128)
        : C.a(C.purple, 153);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 2),
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.search_rounded, color: textColor, size: 22),
                  const SizedBox(width: 10),
                  Text(
                    'باحث عقاري',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                'فاطمة الباحثة',
                style: TextStyle(
                  color: textColor,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                tier == SeekerTier.guest
                    ? 'باقة Guest - مجاني'
                    : 'باقة VIP Hunter - الصياد المحترف',
                style: TextStyle(
                  color: tier == SeekerTier.vip
                      ? const Color(0xFFE9D5FF)
                      : C.grey300,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          if (tier == SeekerTier.vip)
            const Positioned(
              top: 0,
              left: 0,
              child: Icon(Icons.workspace_premium_rounded,
                  color: Color(0xFFD8B4FE), size: 28),
            ),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────
// AION WIDGET CARD (with lock/restricted/active states)
// ──────────────────────────────────────────────────────────────
class AIONWidget extends StatelessWidget {
  final String title;
  final IconData icon;
  final WidgetAccessState state;
  final List<Widget> children;
  final String? lockMessage;
  final String? upgradeMessage;

  const AIONWidget({
    super.key,
    required this.title,
    required this.icon,
    required this.state,
    required this.children,
    this.lockMessage,
    this.upgradeMessage,
  });

  @override
  Widget build(BuildContext context) {
    if (state == WidgetAccessState.hidden) return const SizedBox.shrink();

    final bool isLocked = state == WidgetAccessState.locked;
    final bool isRestricted = state == WidgetAccessState.restricted;

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        children: [
          // Base card
          Container(
            decoration: BoxDecoration(
              color: isLocked ? C.a(Colors.white, 13) : C.a(Colors.white, 26),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isLocked
                    ? C.a(Colors.white, 26)
                    : C.a(Colors.white, 51),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: C.a(Colors.white, 26)),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Icon(
                            icon,
                            size: 18,
                            color: isLocked ? C.grey600 : C.cyan,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                      if (isLocked)
                        const Icon(Icons.lock_rounded,
                            color: C.grey500, size: 16)
                      else if (isRestricted)
                        const Icon(Icons.warning_amber_rounded,
                            color: C.amber, size: 16),
                    ],
                  ),
                ),
                // Body
                Opacity(
                  opacity: isLocked ? 0.4 : 1.0,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: isLocked ? _skeletonChildren() : children,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Lock overlay
          if (isLocked)
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  color: C.a(Colors.black, 76), // ~30% opacity
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: Container(
                    margin: const EdgeInsets.all(24),
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: C.a(const Color(0xFF111827), 242),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: C.a(Colors.white, 51)),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black54,
                          blurRadius: 20,
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.lock_rounded,
                            color: C.grey400, size: 40),
                        const SizedBox(height: 10),
                        Text(
                          lockMessage ?? 'ميزة مقفلة',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        if (upgradeMessage != null) ...[
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [C.cyan, C.purple],
                              ),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              'ترقية إلى $upgradeMessage',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // Restricted badge (top-left in RTL context)
          if (isRestricted && upgradeMessage != null)
            Positioned(
              top: 12,
              left: 12,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: C.a(C.amber, 51),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: C.a(C.amber, 128)),
                ),
                child: Text(
                  upgradeMessage!,
                  style: const TextStyle(
                    color: C.amber,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // Skeleton placeholder for locked state
  List<Widget> _skeletonChildren() {
    return [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: C.a(Colors.white, 13),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 14,
              decoration: BoxDecoration(
                color: C.a(Colors.white, 26),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              height: 10,
              width: 180,
              decoration: BoxDecoration(
                color: C.a(Colors.white, 26),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: C.a(Colors.white, 13),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 14,
              decoration: BoxDecoration(
                color: C.a(Colors.white, 26),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              height: 10,
              width: 130,
              decoration: BoxDecoration(
                color: C.a(Colors.white, 26),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ],
        ),
      ),
    ];
  }
}

// ──────────────────────────────────────────────────────────────
// REUSABLE HELPER WIDGETS
// ──────────────────────────────────────────────────────────────

/// A stat row with optional badge chip.
class StatRow extends StatelessWidget {
  final String label;
  final String value;
  final String? badge;

  const StatRow({
    super.key,
    required this.label,
    required this.value,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: const TextStyle(color: C.grey400, fontSize: 12),
            ),
            if (badge != null) ...[
              const SizedBox(width: 6),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: C.a(C.purple, 51),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  badge!,
                  style: const TextStyle(
                      color: C.purpleLight, fontSize: 9),
                ),
              ),
            ],
          ],
        ),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

/// A task item with a check-circle icon.
class TaskItem extends StatelessWidget {
  final String text;
  const TaskItem({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle_rounded,
              color: C.cyanLight, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: C.grey300, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

/// An AI feature highlight badge.
class AIBadge extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color accentColor;

  const AIBadge({
    super.key,
    required this.icon,
    required this.text,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(accentColor, 26),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: C.a(accentColor, 76)),
      ),
      child: Row(
        children: [
          Icon(icon, color: accentColor, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: accentColor,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A landlord CRM row.
class LandlordItem extends StatelessWidget {
  final String name;
  final int properties;
  final int alerts;

  const LandlordItem({
    super.key,
    required this.name,
    required this.properties,
    required this.alerts,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                '$properties عقارات',
                style: const TextStyle(color: C.grey400, fontSize: 11),
              ),
            ],
          ),
          if (alerts > 0)
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: C.red,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '$alerts',
                style: const TextStyle(color: Colors.white, fontSize: 10),
              ),
            ),
        ],
      ),
    );
  }
}

/// Enum used only in the heatmap widget.
enum HeatLevel { high, medium, low }

/// A heatmap zone row.
class HeatmapZone extends StatelessWidget {
  final String zone;
  final HeatLevel heat;

  const HeatmapZone({super.key, required this.zone, required this.heat});

  @override
  Widget build(BuildContext context) {
    late List<Color> colors;
    late String label;

    switch (heat) {
      case HeatLevel.high:
        colors = [C.a(C.red, 76), C.a(C.orange, 76)];
        label = 'ساخن 🔥';
        break;
      case HeatLevel.medium:
        colors = [C.a(const Color(0xFFEAB308), 76), C.a(C.amber, 76)];
        label = 'متوسط';
        break;
      case HeatLevel.low:
        colors = [C.a(C.blue, 76), C.a(C.cyan, 76)];
        label = 'هادئ';
        break;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: colors.first),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            zone,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
          Text(
            label,
            style: const TextStyle(color: C.grey300, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

/// A project progress item.
class ProjectItem extends StatelessWidget {
  final String name;
  final int progress;

  const ProjectItem(
      {super.key, required this.name, required this.progress});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ),
              Text(
                '$progress%',
                style: const TextStyle(color: C.cyanLight, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: progress / 100,
              minHeight: 6,
              backgroundColor: C.a(Colors.white, 26),
              valueColor: const AlwaysStoppedAnimation<Color>(C.cyan),
            ),
          ),
        ],
      ),
    );
  }
}

/// A sales agent performance row.
class AgentItem extends StatelessWidget {
  final String name;
  final int deals;

  const AgentItem({super.key, required this.name, required this.deals});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: C.a(C.emerald, 51),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              '$deals صفقات',
              style: const TextStyle(
                  color: C.emeraldLight, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
}

/// A marketing campaign row.
class CampaignItem extends StatelessWidget {
  final String name;
  final String reach;

  const CampaignItem(
      {super.key, required this.name, required this.reach});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              name,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ),
          Text(
            '$reach وصول',
            style: const TextStyle(color: C.cyanLight, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

/// A land acquisition row.
class LandItem extends StatelessWidget {
  final String name;
  final String desc;

  const LandItem({super.key, required this.name, required this.desc});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                desc,
                style: const TextStyle(color: C.grey400, fontSize: 11),
              ),
            ],
          ),
          const Icon(Icons.auto_awesome_rounded,
              color: C.cyanLight, size: 16),
        ],
      ),
    );
  }
}

/// An offer item row with pending/accepted status.
class OfferItem extends StatelessWidget {
  final String buyer;
  final String amount;
  final String status; // 'pending' | 'accepted'

  const OfferItem({
    super.key,
    required this.buyer,
    required this.amount,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    final bool isAccepted = status == 'accepted';
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                buyer,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                '$amount ريال',
                style: const TextStyle(color: C.grey400, fontSize: 11),
              ),
            ],
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isAccepted ? C.a(C.emerald, 51) : C.a(C.amber, 51),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              isAccepted ? 'مقبول' : 'معلق',
              style: TextStyle(
                color: isAccepted ? C.emeraldLight : C.amberLight,
                fontSize: 11,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A broker access-request row.
class BrokerRequestItem extends StatelessWidget {
  final String name;
  final String experience;

  const BrokerRequestItem(
      {super.key, required this.name, required this.experience});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                experience,
                style: const TextStyle(color: C.grey400, fontSize: 11),
              ),
            ],
          ),
          // Chevron points left in RTL
          const Icon(Icons.chevron_left_rounded,
              color: C.grey400, size: 20),
        ],
      ),
    );
  }
}

/// A wishlist property row.
class WishlistItem extends StatelessWidget {
  final String name;
  final String price;

  const WishlistItem(
      {super.key, required this.name, required this.price});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              name,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ),
          Text(
            price,
            style: const TextStyle(color: C.cyanLight, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

/// A search request row with active/pending status.
class SearchRequestItem extends StatelessWidget {
  final String type;
  final String status; // 'active' | 'pending'

  const SearchRequestItem(
      {super.key, required this.type, required this.status});

  @override
  Widget build(BuildContext context) {
    final bool isActive = status == 'active';
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              type,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color:
                  isActive ? C.a(C.emerald, 51) : C.a(Colors.grey, 51),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              isActive ? 'نشط' : 'معلق',
              style: TextStyle(
                color: isActive ? C.emeraldLight : C.grey400,
                fontSize: 11,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A legal contract row with completed/pending indicator.
class ContractItem extends StatelessWidget {
  final String name;
  final String desc;
  final bool isCompleted;

  const ContractItem({
    super.key,
    required this.name,
    required this.desc,
    required this.isCompleted,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: C.a(Colors.white, 13),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  desc,
                  style: const TextStyle(color: C.grey400, fontSize: 11),
                ),
              ],
            ),
          ),
          isCompleted
              ? const Icon(Icons.check_circle_rounded,
                  color: C.emeraldLight, size: 18)
              : const Icon(Icons.auto_awesome_rounded,
                  color: C.cyanLight, size: 18),
        ],
      ),
    );
  }
}

/// An animated pulsing dot (used for "AI active" indicator).
class PulsingDot extends StatefulWidget {
  final Color color;
  const PulsingDot({super.key, required this.color});

  @override
  State<PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<PulsingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _anim,
      child: Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: widget.color,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}
